namespace Inchcape.YourISS.Integration.IMOS.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.Finance.Schema.IMOSFinance", typeof(global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.IMOSFinance))]
    public sealed class Map_Finance_To_IMOSFinance : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 ScriptNS0 ScriptNS1 userCSharp"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.IMOS.Finance.Disbursement"" xmlns:s0=""http://Inchcape.YourISS.Integration.IMOS.FinalDA"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <xsl:variable name=""var:v23"" select=""string(s0:MessageHeader/s0:AppointmentNumber/text())"" />
    <ns0:Form>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS1:DBLookup(0 , &quot;IMOSFINANCEFORMIDENTIFIER&quot; , string($var:v1) , &quot;Configuration&quot; , &quot;cast (  [Key]  as varchar(500) )&quot;)"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBValueExtract(string($var:v2) , &quot;Value&quot;)"" />
      <xsl:attribute name=""FormIdentifier"">
        <xsl:value-of select=""$var:v3"" />
      </xsl:attribute>
      <xsl:variable name=""var:v4"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBLookup(1 , string(s0:MessageHeader/s0:AppointmentNumber/text()) , string($var:v4) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v6"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;PrincipalId&quot;)"" />
      <xsl:variable name=""var:v7"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(2 , string($var:v7) , string($var:v4) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast ( AppointmentId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v10"" select=""ScriptNS1:DBLookup(3 , string($var:v9) , string($var:v4) , &quot;master.HubPrincipals&quot; , &quot;cast (  HubPrincipalKey  as varchar(40) )&quot;)"" />
      <xsl:variable name=""var:v11"" select=""ScriptNS1:DBValueExtract(string($var:v10) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v12"" select=""userCSharp:StringConcat(string($var:v6) , &quot;|&quot; , string($var:v11))"" />
      <xsl:variable name=""var:v13"" select=""ScriptNS1:DBLookup(4 , string($var:v12) , string($var:v4) , &quot;master.HubPrincipalPrincipalMap&quot; , &quot;cast ( PrincipalId as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20)  )&quot;)"" />
      <xsl:variable name=""var:v14"" select=""ScriptNS1:DBValueExtract(string($var:v13) , &quot;Code&quot;)"" />
      <xsl:attribute name=""CompanyCode"">
        <xsl:value-of select=""$var:v14"" />
      </xsl:attribute>
      <xsl:variable name=""var:v15"" select=""ScriptNS1:DBValueExtract(string($var:v13) , &quot;Name&quot;)"" />
      <xsl:attribute name=""CompanyName"">
        <xsl:value-of select=""$var:v15"" />
      </xsl:attribute>
      <xsl:variable name=""var:v16"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;PortcallId&quot;)"" />
      <xsl:variable name=""var:v17"" select=""ScriptNS1:DBLookup(5 , string($var:v16) , string($var:v4) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v18"" select=""ScriptNS1:DBValueExtract(string($var:v17) , &quot;VesselId&quot;)"" />
      <xsl:variable name=""var:v19"" select=""userCSharp:StringConcat(string($var:v18) , &quot;|&quot; , string($var:v11))"" />
      <xsl:variable name=""var:v20"" select=""ScriptNS1:DBLookup(6 , string($var:v19) , string($var:v4) , &quot;master.HubPrincipalVesselMap&quot; , &quot;cast ( VesselId as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v21"" select=""ScriptNS1:DBValueExtract(string($var:v20) , &quot;Code&quot;)"" />
      <xsl:attribute name=""VesselCode"">
        <xsl:value-of select=""$var:v21"" />
      </xsl:attribute>
      <xsl:variable name=""var:v22"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v24"" select=""ScriptNS1:DBLookup(1 , $var:v23 , string($var:v22) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v25"" select=""ScriptNS1:DBValueExtract(string($var:v24) , &quot;PerformingAgentId&quot;)"" />
      <xsl:variable name=""var:v26"" select=""ScriptNS1:DBValueExtract(string($var:v24) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v27"" select=""ScriptNS1:DBLookup(2 , string($var:v26) , string($var:v22) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast ( AppointmentId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v28"" select=""ScriptNS1:DBValueExtract(string($var:v27) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v29"" select=""ScriptNS1:DBLookup(3 , string($var:v28) , string($var:v22) , &quot;master.HubPrincipals&quot; , &quot;cast (  HubPrincipalKey  as varchar(40) )&quot;)"" />
      <xsl:variable name=""var:v30"" select=""ScriptNS1:DBValueExtract(string($var:v29) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v31"" select=""userCSharp:StringConcat(string($var:v25) , &quot;|&quot; , string($var:v30))"" />
      <xsl:variable name=""var:v32"" select=""ScriptNS1:DBLookup(7 , string($var:v31) , string($var:v22) , &quot;master.HubPrincipalAgentMap&quot; , &quot;cast ( agentid as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20)  )&quot;)"" />
      <xsl:variable name=""var:v33"" select=""ScriptNS1:DBValueExtract(string($var:v32) , &quot;Code&quot;)"" />
      <ns0:Agent>
        <xsl:value-of select=""$var:v33"" />
      </ns0:Agent>
      <xsl:variable name=""var:v34"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v35"" select=""ScriptNS1:DBLookup(1 , $var:v23 , string($var:v34) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v36"" select=""ScriptNS1:DBValueExtract(string($var:v35) , &quot;PortcallId&quot;)"" />
      <xsl:variable name=""var:v37"" select=""ScriptNS1:DBLookup(5 , string($var:v36) , string($var:v34) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v38"" select=""ScriptNS1:DBValueExtract(string($var:v37) , &quot;PortId&quot;)"" />
      <xsl:variable name=""var:v39"" select=""ScriptNS1:DBValueExtract(string($var:v35) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v40"" select=""ScriptNS1:DBLookup(2 , string($var:v39) , string($var:v34) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast ( AppointmentId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v41"" select=""ScriptNS1:DBValueExtract(string($var:v40) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v42"" select=""ScriptNS1:DBLookup(3 , string($var:v41) , string($var:v34) , &quot;master.HubPrincipals&quot; , &quot;cast (  HubPrincipalKey  as varchar(40) )&quot;)"" />
      <xsl:variable name=""var:v43"" select=""ScriptNS1:DBValueExtract(string($var:v42) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v44"" select=""userCSharp:StringConcat(string($var:v38) , &quot;|&quot; , string($var:v43))"" />
      <xsl:variable name=""var:v45"" select=""ScriptNS1:DBLookup(8 , string($var:v44) , string($var:v34) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast ( PortId as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20)  )&quot;)"" />
      <xsl:variable name=""var:v46"" select=""ScriptNS1:DBValueExtract(string($var:v45) , &quot;Code&quot;)"" />
      <ns0:Port>
        <xsl:value-of select=""$var:v46"" />
      </ns0:Port>
      <xsl:variable name=""var:v47"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v48"" select=""ScriptNS1:DBLookup(1 , $var:v23 , string($var:v47) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v49"" select=""ScriptNS1:DBValueExtract(string($var:v48) , &quot;PortcallId&quot;)"" />
      <xsl:variable name=""var:v50"" select=""ScriptNS1:DBLookup(5 , string($var:v49) , string($var:v47) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v51"" select=""ScriptNS1:DBValueExtract(string($var:v50) , &quot;PortOperationId&quot;)"" />
      <xsl:variable name=""var:v52"" select=""ScriptNS1:DBValueExtract(string($var:v48) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v53"" select=""ScriptNS1:DBLookup(2 , string($var:v52) , string($var:v47) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast ( AppointmentId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v54"" select=""ScriptNS1:DBValueExtract(string($var:v53) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v55"" select=""ScriptNS1:DBLookup(3 , string($var:v54) , string($var:v47) , &quot;master.HubPrincipals&quot; , &quot;cast (  HubPrincipalKey  as varchar(40) )&quot;)"" />
      <xsl:variable name=""var:v56"" select=""ScriptNS1:DBValueExtract(string($var:v55) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v57"" select=""userCSharp:StringConcat(string($var:v51) , &quot;|&quot; , string($var:v56))"" />
      <xsl:variable name=""var:v58"" select=""ScriptNS1:DBLookup(9 , string($var:v57) , string($var:v47) , &quot;Master.HubPrincipalPortOperationMap&quot; , &quot;cast ( PortOperationId as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20)  )&quot;)"" />
      <xsl:variable name=""var:v59"" select=""ScriptNS1:DBValueExtract(string($var:v58) , &quot;CODE&quot;)"" />
      <ns0:PortFunction>
        <xsl:value-of select=""$var:v59"" />
      </ns0:PortFunction>
      <xsl:variable name=""var:v60"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v61"" select=""ScriptNS1:DBLookup(1 , $var:v23 , string($var:v60) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v62"" select=""ScriptNS1:DBValueExtract(string($var:v61) , &quot;PortcallId&quot;)"" />
      <xsl:variable name=""var:v63"" select=""ScriptNS1:DBLookup(5 , string($var:v62) , string($var:v60) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v64"" select=""ScriptNS1:DBValueExtract(string($var:v63) , &quot;VesselId&quot;)"" />
      <xsl:variable name=""var:v65"" select=""ScriptNS1:DBValueExtract(string($var:v61) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v66"" select=""ScriptNS1:DBLookup(2 , string($var:v65) , string($var:v60) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast ( AppointmentId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v67"" select=""ScriptNS1:DBValueExtract(string($var:v66) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v68"" select=""ScriptNS1:DBLookup(3 , string($var:v67) , string($var:v60) , &quot;master.HubPrincipals&quot; , &quot;cast (  HubPrincipalKey  as varchar(40) )&quot;)"" />
      <xsl:variable name=""var:v69"" select=""ScriptNS1:DBValueExtract(string($var:v68) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v70"" select=""userCSharp:StringConcat(string($var:v64) , &quot;|&quot; , string($var:v69))"" />
      <xsl:variable name=""var:v71"" select=""ScriptNS1:DBLookup(6 , string($var:v70) , string($var:v60) , &quot;master.HubPrincipalVesselMap&quot; , &quot;cast ( VesselId as varchar (20) ) + '|' + cast ( HubPrincipalId as varchar(20) )&quot;)"" />
      <xsl:variable name=""var:v72"" select=""ScriptNS1:DBValueExtract(string($var:v71) , &quot;Name&quot;)"" />
      <ns0:VesselName>
        <xsl:value-of select=""$var:v72"" />
      </ns0:VesselName>
      <ns0:VoyageNo>
        <xsl:value-of select=""s0:DisbursementAccount/s0:SN_VoyageNumber/text()"" />
      </ns0:VoyageNo>
      <xsl:variable name=""var:v73"" select=""userCSharp:InvoiceNo(string(s0:DisbursementAccount/s0:InvoiceNo/text()))"" />
      <ns0:InvoiceNo>
        <xsl:value-of select=""$var:v73"" />
      </ns0:InvoiceNo>
      <xsl:variable name=""var:v74"" select=""userCSharp:InvoiceDate(string(s0:DisbursementAccount/s0:InvoiceDate/text()))"" />
      <ns0:InvoiceDate>
        <xsl:value-of select=""$var:v74"" />
      </ns0:InvoiceDate>
      <xsl:variable name=""var:v75"" select=""userCSharp:InvoiceDueDate(string(s0:DisbursementAccount/s0:DueDate/text()))"" />
      <ns0:DueDate>
        <xsl:value-of select=""$var:v75"" />
      </ns0:DueDate>
      <xsl:variable name=""var:v76"" select=""userCSharp:Status(string(s0:DisbursementAccount/s0:Stage/text()))"" />
      <ns0:Status>
        <xsl:value-of select=""$var:v76"" />
      </ns0:Status>
      <ns0:Currency>
        <xsl:value-of select=""s0:DisbursementAccount/s0:DaCurrencyCode/text()"" />
      </ns0:Currency>
      <xsl:if test=""s0:DisbursementAccount/s0:WorkflowStatus"">
        <ns0:Remarks>
          <xsl:value-of select=""s0:DisbursementAccount/s0:WorkflowStatus/text()"" />
        </ns0:Remarks>
      </xsl:if>
      <xsl:for-each select=""s0:DisbursementAccount"">
        <xsl:variable name=""var:v77"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""s0:Lines/s0:DaLine/s0:Amount"">
          <xsl:variable name=""var:v78"" select=""userCSharp:AddToCumulativeSum(0,string(s0:Amount/text()),&quot;3&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v79"" select=""userCSharp:GetCumulativeSum(0)"" />
        <ns0:Total>
          <xsl:value-of select=""$var:v79"" />
        </ns0:Total>
      </xsl:for-each>
      <ns0:Expenses>
        <xsl:for-each select=""s0:DisbursementAccount/s0:Lines/s0:DaLine"">
          <xsl:variable name=""var:v81"" select=""string(s0:ServiceLineName/text())"" />
          <ns0:ExpensesRow>
            <xsl:variable name=""var:v80"" select=""userCSharp:GetLedgerCode(string(s0:ServiceLineName/text()))"" />
            <ns0:LedgerCode>
              <xsl:value-of select=""$var:v80"" />
            </ns0:LedgerCode>
            <xsl:variable name=""var:v82"" select=""userCSharp:GetDesc($var:v81)"" />
            <ns0:Description>
              <xsl:value-of select=""$var:v82"" />
            </ns0:Description>
            <ns0:ExpenseItem>
              <xsl:value-of select=""s0:ServiceLineName/text()"" />
            </ns0:ExpenseItem>
            <ns0:Amount>
              <xsl:value-of select=""s0:Amount/s0:Amount/text()"" />
            </ns0:Amount>
          </ns0:ExpensesRow>
        </xsl:for-each>
      </ns0:Expenses>
    </ns0:Form>
    <xsl:variable name=""var:v83"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string Status ( string stage )
{
     if  ( stage == ""PDA""   )
        return ""Advance"";
     else if ( stage == ""UDA""   )
             return ""Advance"";
     else if    ( stage == ""FDA""   ) 
             return ""Final"";
    else if  ( stage == ""SDA""   ) 
           return ""APR"";
    else
          return """";
}

public string GetDesc ( string ServiceCode )
{
       int   pos =  0;
       pos  =  ServiceCode.IndexOf(  ""__""  ) ;
      return  ServiceCode.Substring (pos + 2);
}

public string GetLedgerCode ( string ServiceCode )
{
       int   pos =  0;
       pos  =  ServiceCode.IndexOf(  ""__""  ) ;
      return  ServiceCode.Substring  (0, pos ) ;
}

public string InvoiceNo ( string InvNo)
{
      if ( String.IsNullOrEmpty(  InvNo )   )
           return ""1"";
     else
           return InvNo ;
}

public string InvoiceDate ( string InvDt)
{
      if ( String.IsNullOrEmpty(  InvDt   )   )
           return    String.Format( ""{0:yyyy-MM-ddTHH:mm:ss}"",   System.DateTime.Now)   ;
     else
           return InvDt   ;
}

public string InvoiceDueDate ( string InvDt)
{
      if ( String.IsNullOrEmpty(  InvDt   )   )
           return    String.Format( ""{0:yyyy-MM-ddTHH:mm:ss}"",   System.DateTime.Now)   ;
     else
           return InvDt   ;
}

public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.IMOSFinance";
        
        private const global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.IMOSFinance _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.IMOSFinance";
                return _TrgSchemas;
            }
        }
    }
}

namespace Inchcape.YourISS.Integration.IMOS.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_TempVariable", typeof(global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_TempVariable))]
    public sealed class Map_Temp_Getvoyage : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 ScriptNS0 ScriptNS1 userCSharp"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.IMOS.FinalDA"" xmlns:ns0=""http://Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <xsl:variable name=""var:v8"" select=""string(s0:MessageHeader/s0:AppointmentNumber/text())"" />
    <ns0:Root>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS1:DBLookup(0 , string(s0:MessageHeader/s0:AppointmentNumber/text()) , string($var:v1) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBValueExtract(string($var:v2) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v4"" select=""ScriptNS1:DBLookup(1 , string($var:v3) , string($var:v1) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBValueExtract(string($var:v4) , &quot;ReferenceCode&quot;)"" />
      <xsl:variable name=""var:v6"" select=""userCSharp:GetVoyage(string($var:v5))"" />
      <VoyageNo>
        <xsl:value-of select=""$var:v6"" />
      </VoyageNo>
      <xsl:variable name=""var:v7"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v9"" select=""ScriptNS1:DBLookup(0 , $var:v8 , string($var:v7) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v10"" select=""ScriptNS1:DBValueExtract(string($var:v9) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v11"" select=""ScriptNS1:DBLookup(1 , string($var:v10) , string($var:v7) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v12"" select=""ScriptNS1:DBValueExtract(string($var:v11) , &quot;ReferenceCode&quot;)"" />
      <xsl:variable name=""var:v13"" select=""userCSharp:GetPortcallSeq(string($var:v12))"" />
      <PortcallSeqNo>
        <xsl:value-of select=""$var:v13"" />
      </PortcallSeqNo>
      <xsl:variable name=""var:v14"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v15"" select=""ScriptNS1:DBLookup(2 , &quot;IMOSFINANCEURL&quot; , string($var:v14) , &quot;Configuration&quot; , &quot;cast (  [Key]  as varchar(50) )&quot;)"" />
      <xsl:variable name=""var:v16"" select=""ScriptNS1:DBValueExtract(string($var:v15) , &quot;Value&quot;)"" />
      <URL>
        <xsl:value-of select=""$var:v16"" />
      </URL>
      <xsl:variable name=""var:v17"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v18"" select=""ScriptNS1:DBLookup(0 , $var:v8 , string($var:v17) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v19"" select=""ScriptNS1:DBValueExtract(string($var:v18) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v20"" select=""ScriptNS1:DBLookup(1 , string($var:v19) , string($var:v17) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v21"" select=""ScriptNS1:DBValueExtract(string($var:v20) , &quot;HubprincipalKey&quot;)"" />
      <xsl:variable name=""var:v22"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v23"" select=""ScriptNS1:DBLookup(3 , string($var:v21) , string($var:v22) , &quot;CustomerConfiguration&quot; , &quot;cast ( HubprincipalID  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v24"" select=""ScriptNS1:DBValueExtract(string($var:v23) , &quot;SecurityMode&quot;)"" />
      <SecurityMode>
        <xsl:value-of select=""$var:v24"" />
      </SecurityMode>
      <xsl:variable name=""var:v25"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v26"" select=""ScriptNS1:DBLookup(0 , $var:v8 , string($var:v25) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v27"" select=""ScriptNS1:DBValueExtract(string($var:v26) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v28"" select=""ScriptNS1:DBLookup(1 , string($var:v27) , string($var:v25) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v29"" select=""ScriptNS1:DBValueExtract(string($var:v28) , &quot;HubprincipalKey&quot;)"" />
      <xsl:variable name=""var:v30"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v31"" select=""ScriptNS1:DBLookup(3 , string($var:v29) , string($var:v30) , &quot;CustomerConfiguration&quot; , &quot;cast ( HubprincipalID  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v32"" select=""ScriptNS1:DBValueExtract(string($var:v31) , &quot;TransportClientCredentialType&quot;)"" />
      <TransportClientCredentialType>
        <xsl:value-of select=""$var:v32"" />
      </TransportClientCredentialType>
      <xsl:variable name=""var:v33"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v34"" select=""ScriptNS1:DBLookup(0 , $var:v8 , string($var:v33) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v35"" select=""ScriptNS1:DBValueExtract(string($var:v34) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v36"" select=""ScriptNS1:DBLookup(1 , string($var:v35) , string($var:v33) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v37"" select=""ScriptNS1:DBValueExtract(string($var:v36) , &quot;HubprincipalKey&quot;)"" />
      <xsl:variable name=""var:v38"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v39"" select=""ScriptNS1:DBLookup(3 , string($var:v37) , string($var:v38) , &quot;CustomerConfiguration&quot; , &quot;cast ( HubprincipalID  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v40"" select=""ScriptNS1:DBValueExtract(string($var:v39) , &quot;UserName&quot;)"" />
      <UserName>
        <xsl:value-of select=""$var:v40"" />
      </UserName>
      <xsl:variable name=""var:v41"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v42"" select=""ScriptNS1:DBLookup(0 , $var:v8 , string($var:v41) , &quot;Appointment.Appointments&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v43"" select=""ScriptNS1:DBValueExtract(string($var:v42) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v44"" select=""ScriptNS1:DBLookup(1 , string($var:v43) , string($var:v41) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (AppointmentId as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v45"" select=""ScriptNS1:DBValueExtract(string($var:v44) , &quot;HubprincipalKey&quot;)"" />
      <xsl:variable name=""var:v46"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v47"" select=""ScriptNS1:DBLookup(3 , string($var:v45) , string($var:v46) , &quot;CustomerConfiguration&quot; , &quot;cast ( HubprincipalID  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v48"" select=""ScriptNS1:DBValueExtract(string($var:v47) , &quot;Password&quot;)"" />
      <Password>
        <xsl:value-of select=""$var:v48"" />
      </Password>
    </ns0:Root>
    <xsl:variable name=""var:v49"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string GetVoyage ( string refcode )
{
     string[] values = refcode .Split(  '|'  );
   
    return values[3];

}

public string GetPortcallSeq ( string refcode )
{
     string[] values = refcode .Split(  '|'  );
   
    return values[2];

}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_TempVariable";
        
        private const global::Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_TempVariable _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_FinalDA";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.Finance.Schema.Schema_TempVariable";
                return _TrgSchemas;
            }
        }
    }
}

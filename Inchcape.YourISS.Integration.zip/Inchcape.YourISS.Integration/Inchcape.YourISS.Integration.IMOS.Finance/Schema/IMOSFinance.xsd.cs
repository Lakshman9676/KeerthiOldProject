namespace Inchcape.YourISS.Integration.IMOS.Finance.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.IMOS.Finance.Disbursement",@"Form")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Form"})]
    public sealed class IMOSFinance : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.IMOS.Finance.Disbursement"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://Inchcape.YourISS.Integration.IMOS.Finance.Disbursement"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""Form"">
    <xs:complexType>
      <xs:all>
        <xs:element minOccurs=""1"" name=""Agent"" type=""String"" />
        <xs:element minOccurs=""1"" name=""Port"" type=""String"" />
        <xs:element minOccurs=""0"" name=""PortFunction"" type=""String"" />
        <xs:element minOccurs=""0"" name=""VesselName"" type=""String"" />
        <xs:element minOccurs=""0"" name=""VoyageNo"" type=""Integer"" />
        <xs:element minOccurs=""0"" name=""DADeskReference"" type=""String"" />
        <xs:element minOccurs=""1"" name=""InvoiceNo"" type=""String"" />
        <xs:element minOccurs=""0"" name=""AdvanceInvoiceNo"" type=""String"" />
        <xs:element minOccurs=""1"" name=""InvoiceDate"" type=""Date"" />
        <xs:element minOccurs=""1"" name=""DueDate"" type=""Date"" />
        <xs:element minOccurs=""1"" name=""Status"" type=""String"" />
        <xs:element minOccurs=""1"" name=""Currency"" type=""String"" />
        <xs:element minOccurs=""0"" name=""Remarks"" type=""String"" />
        <xs:element minOccurs=""0"" name=""Total"" type=""Decimal"" />
        <xs:element minOccurs=""0"" name=""AdvancePercent"" type=""Decimal"" />
        <xs:element minOccurs=""0"" name=""AdvancePayment"" type=""Decimal"" />
        <xs:element minOccurs=""0"" name=""HiddenDateFieldForSharing"" type=""DateTime"" />
        <xs:element name=""Expenses"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""ExpensesRow"">
                <xs:complexType>
                  <xs:all>
                    <xs:element minOccurs=""0"" name=""LedgerCode"" type=""String"" />
                    <xs:element minOccurs=""0"" name=""Description"" type=""String"" />
                    <xs:element minOccurs=""1"" name=""ExpenseItem"" type=""String"" />
                    <xs:element minOccurs=""1"" name=""Amount"" type=""Decimal"" />
                  </xs:all>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:all>
      <xs:attribute fixed=""Veson Offline Port Disbursement"" name=""FormIdentifier"" type=""xs:string"" use=""required"" />
      <xs:attribute name=""CompanyCode"" type=""xs:string"" use=""required"" />
      <xs:attribute name=""CompanyName"" type=""xs:string"" />
      <xs:attribute name=""VesselCode"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:simpleType name=""String"">
    <xs:restriction base=""xs:string"" />
  </xs:simpleType>
  <xs:simpleType name=""Integer"">
    <xs:union>
      <xs:simpleType>
        <xs:restriction base=""xs:integer"" />
      </xs:simpleType>
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:length value=""0"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:union>
  </xs:simpleType>
  <xs:simpleType name=""Decimal"">
    <xs:union>
      <xs:simpleType>
        <xs:restriction base=""xs:decimal"" />
      </xs:simpleType>
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:length value=""0"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:union>
  </xs:simpleType>
  <xs:simpleType name=""Date"">
    <xs:restriction base=""DateTime"" />
  </xs:simpleType>
  <xs:simpleType name=""DateTime"">
    <xs:union>
      <xs:simpleType>
        <xs:restriction base=""xs:dateTime"" />
      </xs:simpleType>
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:length value=""0"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:union>
  </xs:simpleType>
</xs:schema>";
        
        public IMOSFinance() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Form";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

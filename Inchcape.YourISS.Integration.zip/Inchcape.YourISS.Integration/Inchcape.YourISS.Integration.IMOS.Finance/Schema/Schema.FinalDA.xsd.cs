namespace Inchcape.YourISS.Integration.IMOS.Finance.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.IMOS.FinalDA",@"YourIssNotification")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIssNotification"})]
    public sealed class Schema_FinalDA : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.IMOS.FinalDA"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" attributeFormDefault=""unqualified"" elementFormDefault=""qualified"" targetNamespace=""http://Inchcape.YourISS.Integration.IMOS.FinalDA"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""YourIssNotification"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""MessageHeader"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""MessageType"" type=""xs:string"" />
              <xs:element name=""Action"" type=""xs:string"" />
              <xs:element name=""CreatedDate"" type=""xs:dateTime"" />
              <xs:element name=""ShipNetReference"" type=""xs:string"" />
              <xs:element name=""SourceApplication"" type=""xs:string"" />
              <xs:element name=""AppointmentNumber"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""DisbursementAccount"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Stage"" type=""xs:string"" />
              <xs:element name=""SN_DANo"" type=""xs:string"" />
              <xs:element name=""SN_DaType"" type=""xs:string"" />
              <xs:element name=""SN_VoyageNumber"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""SN_VesselCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""SN_AcctsCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""SN_AgentCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""ISS_AgentCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""WorkflowStatus"" nillable=""true"" type=""xs:string"" />
              <xs:element name=""DaDate"" type=""xs:dateTime"" />
              <xs:element name=""InvoiceNo"" type=""xs:string"" />
              <xs:element name=""InvoiceDate"" type=""xs:dateTime"" />
              <xs:element name=""DueDate"" type=""xs:dateTime"" />
              <xs:element name=""DaCurrencyCode"" type=""xs:string"" />
              <xs:element name=""YourIssCurrencyCode"" type=""xs:string"" />
              <xs:element name=""YourIssExchangeRate"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""PerformingAgent"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""CountryCode"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""DaLineCount"" type=""xs:string"" />
              <xs:element name=""Lines"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""DaLine"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name=""ServiceLineCode"" type=""xs:string"" />
                          <xs:element name=""ServiceLineName"" type=""xs:string"" />
                          <xs:element name=""Amount"">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element name=""CurrencyCode"" type=""xs:string"" />
                                <xs:element name=""Amount"" type=""xs:decimal"" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                          <xs:element name=""YourIssAmount"">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element name=""CurrencyCode"" type=""xs:string"" />
                                <xs:element name=""Amount"" type=""xs:decimal"" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                          <xs:element name=""DocumentCount"" type=""xs:string"" />
                          <xs:element name=""Documents"">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Document"" type=""xs:string"" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""DocumentCount"" type=""xs:string"" />
              <xs:element name=""Documents"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Document"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_FinalDA() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIssNotification";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Inchcape.YourISS.Integration.GMT.IntegrationModels;

namespace Inchcape.YourISS.Integration.GMT.IntegrationService
{
    public class ISSGMTIntegrationService : IISSGMTIntegrationService
    {
        public ISSGMTIntegrationDto PostIntegrationMessage(ISSGMTIntegrationDto IntegrationMessage)
        {
            ISSGMTIntegrationDto dtoISSResponse = new ISSGMTIntegrationDto();
            Inchcape.YourISS.Integration.GMT.IntegrationModels.ISSGMTIntegrationResponse dtoResponseBody = new ISSGMTIntegrationResponse();
            string AppServiceResult;
            string resBodyXML;
            try
            {
                //Validate the customer
                int count = 0;
                Guid account = IntegrationMessage.AccountId;

                //ISSIntegrationWebService.ISSIntegrationAppService.ISSIntegrationAppServiceClient AppClient = new ISSIntegrationWebService.ISSIntegrationAppService.ISSIntegrationAppServiceClient();

                System.Diagnostics.EventLog.WriteEntry("Application", "Before Validate ");
                //count = AppClient.ValidateIntegrationSystem(account);
                System.Diagnostics.EventLog.WriteEntry("Application", "After Validate ");

                if (count > 0)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Inside Count ");
                    AppServiceResult = "";
                    //AppServiceResult = AppClient.SaveISSIntegrationMessage(IntegrationMessage);


                    //dtoResponseBody.Code = "0";
                    //dtoResponseBody.Message = "Message Received Sucessfully";
                    //dtoResponseBody.AckNo = AppServiceResult;
                    //dtoResponseBody.AckBy = "INTEGRATION";

                    resBodyXML = "<Response>" +
                                        "<Code>0</Code>" +
                                        "<Message>Message Received Sucessfully</Message>" +
                                        "<AckBy>INTEGRATION</AckBy>" +
                                        "<AckNo>" + AppServiceResult + "</AckNo>" +
                                        " </Response>";


                    //dtoISSResponse.Version = IntegrationMessage.Version;
                    //dtoISSResponse.MessageVersion = IntegrationMessage.MessageVersion;
                    //dtoISSResponse.Header = IntegrationMessage.Header;
                    //dtoISSResponse.SourceIntegrationSystem = IntegrationMessage.SourceIntegrationSystem;
                    //dtoISSResponse.DestinationIntegrationSystem = IntegrationMessage.DestinationIntegrationSystem;
                    //dtoISSResponse.AccountId = IntegrationMessage.AccountId;
                    //dtoISSResponse.Method = "ACK";

                    //dtoISSResponse.DateCreate = System.DateTime.UtcNow;
                    //dtoISSResponse.MessageId = IntegrationMessage.MessageId;
                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Inside ELSE ");
                    //dtoISSResponse.Version = IntegrationMessage.Version;
                    //dtoISSResponse.MessageVersion = IntegrationMessage.MessageVersion;
                    //dtoISSResponse.Header = IntegrationMessage.Header;
                    //dtoISSResponse.SourceIntegrationSystem = IntegrationMessage.SourceIntegrationSystem;
                    //dtoISSResponse.DestinationIntegrationSystem = IntegrationMessage.DestinationIntegrationSystem;
                    //dtoISSResponse.AccountId = IntegrationMessage.AccountId;
                    //dtoISSResponse.Method = "KO";

                    //dtoISSResponse.DateCreate = System.DateTime.UtcNow;
                    //dtoISSResponse.MessageId = IntegrationMessage.MessageId;

                    resBodyXML = "<Response>" +
                                        "<Code>-1</Code>" +
                                        "<Message>Invalid Security Key</Message>" +
                                        "<AckBy>INTEGRATION</AckBy>" +
                                        " </Response>";
                }

                //throw new Exception();
                //Extract the request XML form payload body


                //Save the Request XML into Database

                //Build the response and send to the client

            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Inside Exception ");
                //dtoISSResponse.Version = IntegrationMessage.Version;
                //dtoISSResponse.MessageVersion = IntegrationMessage.MessageVersion;
                //dtoISSResponse.Header = IntegrationMessage.Header;
                //dtoISSResponse.SourceIntegrationSystem = IntegrationMessage.SourceIntegrationSystem;
                //dtoISSResponse.DestinationIntegrationSystem = IntegrationMessage.DestinationIntegrationSystem;
                dtoISSResponse.AccountId = IntegrationMessage.AccountId;

                resBodyXML = "<Response>" +
                                    "<Code>-1</Code>" +
                                    "<Message>" + exp.Message + "</Message>" +
                                    "<AckBy>INTEGRATION</AckBy>" +
                                    " </Response>";
                System.Diagnostics.EventLog.WriteEntry("Application", exp.Message);
            }

            //dtoISSResponse.Body = GetGZippedBytes(resBodyXML);
            return dtoISSResponse;
        }
    }
}

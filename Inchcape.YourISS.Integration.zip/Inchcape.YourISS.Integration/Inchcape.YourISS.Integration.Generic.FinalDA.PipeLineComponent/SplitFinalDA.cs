﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.BizTalk.Component.Interop;
using System.Diagnostics;
using Newtonsoft.Json;


namespace Inchcape.YourISS.Integration.Generic.FinalDA.PipeLineComponent
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_DisassemblingParser)]
    [System.Runtime.InteropServices.Guid("ca6e5593-e1db-49f0-b705-602d598f5b6c")]
    public class SplitFinalDA : IBaseComponent, IPersistPropertyBag, IDisassemblerComponent ,IComponentUI
        {
        public Queue<IBaseMessage> qOutputMsgs = new Queue<IBaseMessage>(); 
        
            public string Description
            {
                get
                {
                    return "Pipeline component to split up the incoming FinalDAs from YourISS";
                }
            }

            public string Name
            {
                get
                {
                    return "SplitFinalDAPipeline";
                }
            }

            public string Version
            {
                get
                {
                    return "1.0.0.0";
                }
            }

            public IntPtr Icon
            {
                get
                {
                    return new System.IntPtr();
                }
            }

            public System.Collections.IEnumerator Validate(object projectSystem)
            {
                return null;
            }

            private string _NameSpace;
            private string _RootNode;
            private int BatchSize;
           
            public int BAtchSize
            {
                get { return BatchSize; }
                set { BatchSize = value; }
            }

            public string NameSpace
            {
                get { return _NameSpace; }
                set { _NameSpace = value; }
            }

            public string RootNode
            {
                get { return _RootNode; }
                set { _RootNode = value; }
            }

         

            public void GetClassID(out Guid classID)
            {
                classID = new Guid("ff2486bf-c6b3-4efd-bc00-b284e806a328");
            }

            public void InitNew()
            {
            }

            public void Load(IPropertyBag propertyBag, int errorLog)
            {

                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Inside Load");

                object val = null;
                object val1 = null;
   
                try
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Before Property Bag Read");
                    propertyBag.Read("DAs", out val, 0);
                    System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - After RootNode Property Bag Read");
                    propertyBag.Read("Namespace", out val1, 0);
             
                    if (val1 != null)
                        _NameSpace = (string)val1;
                    else
                        _NameSpace = "http://AnonymusURL";

                    if (val != null)
                        _RootNode = (string)val;
                    else
                        _RootNode = "DAs";                  

                }
                catch (Exception ex)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Error " + ex.Message);
                    System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Error Throw Commented");
                    // throw new ApplicationException("Error reading propertybag: " + ex.Message);
                }
            }

            public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - SAVE inside");
                object val = (object)_NameSpace;
                object val1 = (object)_RootNode;
                object val2 = (object)BatchSize;
        
                propertyBag.Write("DAs", ref val1);
                propertyBag.Write("Namespace", ref val);
                propertyBag.Write("BatchSize", ref val2);
            
                System.Diagnostics.EventLog.WriteEntry("Application", "DA Split Custom PipeLine - SAVE end");
            }

            public void Disassemble(IPipelineContext pContext, IBaseMessage pInMsg)         
            {
                string xmlString = string.Empty;
                string RoutingDetailID = string.Empty;
                string DA = string.Empty;
               
                var originalStream = pInMsg.BodyPart.GetOriginalDataStream();
                using (TextReader reader = new StreamReader(originalStream))
                {
                    xmlString = reader.ReadToEnd();
                }
                System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Deserializing JSON to Xml…");
                try
                {
                    XmlDocument xmlDoc = new XmlDocument();// !string.IsNullOrWhiteSpace(RootNode) ? JsonConvert.DeserializeXmlNode(xmlString, RootNode) : JsonConvert.DeserializeXmlNode(xmlString);
                    XmlDocument xmlDoc2 = new XmlDocument();
                    System.Diagnostics.EventLog.WriteEntry("Application", "xmlString : " + xmlString);
                    xmlDoc2.LoadXml(xmlString);
                    
                   // xmlDoc2.LoadXml(xmlDoc2.SelectNodes("//*").Item(5).InnerXml.Replace("<![CDATA[", "").Replace("]]>", ""));
                    string strXML = xmlDoc2.SelectNodes("//*").Item(5).InnerXml.Replace("<![CDATA[", "").Replace("]]>", "");
                    RoutingDetailID = xmlDoc2.SelectNodes("//*").Item(3).InnerText;
                    xmlDoc2.LoadXml(strXML);
                                        
                    System.Diagnostics.EventLog.WriteEntry("Application", "Step 1 : " +xmlString);

                    
                //    var nsmgr = new XmlNamespaceManager(xmlDoc2.NameTable);
                //    nsmgr.AddNamespace("x", "http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/integration");
                ////    nsmgr.AddNamespace("x", "http://schemas.microsoft.com/Sql/2008/05/Procedures/Integration");
                //    System.Diagnostics.EventLog.WriteEntry("Application", "Step 1 of 1 After Namespace: ");
                //    XmlNodeList xnList = xmlDoc2.DocumentElement.SelectNodes("/x:SpuGetDAsResponse", nsmgr);
                //    System.Diagnostics.EventLog.WriteEntry("Application", "Step 1 of 2 After Namespace: ");
                //    DA = "<" + _RootNode + ">" + xnList.Item(0).FirstChild.InnerText + "</" + _RootNode + ">";
                    DA = "<" + _RootNode + ">" + (xmlDoc2.FirstChild.FirstChild).InnerText + "</" + _RootNode + ">";

                    System.Diagnostics.EventLog.WriteEntry("Application", "Step 2 : " + DA);
                    xmlDoc.LoadXml(DA);


                    //var nsmgr = new XmlNamespaceManager(xmlDoc2.NameTable);
                    //nsmgr.AddNamespace("x", "http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/integration");
                    //XmlNodeList xnList = xmlDoc2.DocumentElement.SelectNodes("/x:SpuGetDAsResponse", nsmgr);
                    //DA = "<" + _RootNode + ">" + xmlDoc.SelectNodes("//*").Item(5).InnerXml.Replace("<![CDATA[", "").Replace("]]>", "") + "</" + _RootNode + ">";
                    //System.Diagnostics.EventLog.WriteEntry("Application", "Step 2 : " + DA);
                    //xmlDoc.LoadXml(DA);



                    int counter = 0;
                    StringBuilder messageString = new StringBuilder();
                    string namespaceURI = _NameSpace;
                    string rootElement = _RootNode;
                   



                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 21");
                    foreach (XmlNode childNode in xmlDoc.DocumentElement.SelectSingleNode ("//DAS"))
                {
                        messageString.Clear();
                        messageString.Append("<" + "ns0:DA" + " xmlns:ns0='" + namespaceURI + "'>");
                        messageString.Append("<RoutingDetailID>" + RoutingDetailID + "</RoutingDetailID>");
                        messageString.Append(childNode.InnerXml);
                        System.Diagnostics.EventLog.WriteEntry("Application", "Final 23");
                        messageString.Append("</ns0:DA>");
                        System.Diagnostics.EventLog.WriteEntry("Application", "Final 24 : " + Convert.ToString(messageString));
                        CreateOutgoingMessage(pContext, messageString.ToString(), namespaceURI, "ns0:DA", pInMsg);


                }
                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 25 : " + Convert.ToString(messageString));


                    //System.Diagnostics.EventLog.WriteEntry("Application", "Final 27");
                    //messageString.Append("</" + rootElement + ">");
                    //System.Diagnostics.EventLog.WriteEntry("Application", "Final 28 : " + Convert.ToString(messageString));
                    //CreateOutgoingMessage(pContext, messageString.ToString(), namespaceURI, rootElement);
                    //System.Diagnostics.EventLog.WriteEntry("Application", "Final 29");












                    //System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Xml: " + xmlDoc.InnerXml);
                    //var output = Encoding.ASCII.GetBytes(xmlDoc.InnerXml);
                    //var memoryStream = new MemoryStream();
                    //memoryStream.Write(output, 0, output.Length);
                    //memoryStream.Position = 0;
                    //pInMsg.BodyPart.Data = memoryStream;
                    ////This is to assign Namespace to the XML
                    //IBaseMessagePart bodyPart = pInMsg.BodyPart;

                    //if (bodyPart != null)
                    //{
                    //    System.Diagnostics.EventLog.WriteEntry("Application", "Before Name Space – Xml: " + xmlDoc.InnerXml);
                    //    Stream originalStream1 = bodyPart.GetOriginalDataStream();
                    //    if (originalStream1 != null)
                    //    {
                    //        using (XmlReader reader = XmlReader.Create(originalStream1))
                    //        {
                    //            XmlWriterSettings ws = new XmlWriterSettings();
                    //            ws.Indent = true;
                    //            ws.ConformanceLevel = ConformanceLevel.Auto;
                    //            MemoryStream outputStream = new MemoryStream();
                    //            using (XmlWriter writer = XmlWriter.Create(outputStream, ws))
                    //            {
                    //                reader.Read();
                    //                if (reader.NodeType == XmlNodeType.XmlDeclaration)
                    //                {
                    //                    writer.WriteStartDocument();
                    //                    reader.Read();
                    //                }

                    //                // Root Node
                    //                if (reader.NodeType == XmlNodeType.Element)
                    //                    writer.WriteStartElement(reader.Name, _NameSpace);

                    //                reader.Read();
                    //                while (reader.NodeType == XmlNodeType.Element)
                    //                {
                    //                    writer.WriteNode(reader, true);
                    //                }
                    //            }
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Name Space – Xml: After Namespace ");
                    //            outputStream.Position = 0;
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 1");
                    //            bodyPart.Data = outputStream;
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 2");

                    //            //IBaseMessage outMsg = pInMsg;
                    //            IBaseMessage outMsg = pInMsg ;
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 3");


                    //            TextReader tx = new StreamReader(outputStream);
                    //            string temp = tx.ReadToEnd();
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 3.1 : " + temp);
                    //            outMsg.BodyPart.Data.SetLength(outputStream.Length + 10);


                    //            outMsg.BodyPart.Data = bodyPart.Data;// (Stream) originalStream;
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 4");

                    //            outMsg.Context.Promote("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties",   _NameSpace +"#" + _RootNode );
                    //         //   outMsg.Context.Promote("SchemaStrongName",   "http://schemas.microsoft.com/BizTalk/2003/system-properties",    "SchemaAssembly full name");
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 5");
                             
                                
                                
                    //            qOutputMsgs.Enqueue(outMsg);
                                
                                
                    //            System.Diagnostics.EventLog.WriteEntry("Application", "Final 6");
                               

                    //        }
                    //    }
                    //}
                    //This is to assign Namespace to the XML
                }
                catch (Exception ex)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Exception:" + ex.Message);
                }
              //  pInMsg.BodyPart.Data.Position = 0;
               // return pInMsg;
            }



            private void CreateOutgoingMessage(IPipelineContext pContext, String messageString, string namespaceURI, string rootElement, IBaseMessage pInMsg)
        {
           // IBaseMessage outMsg;
            System.Diagnostics.EventLog.WriteEntry("Application", "Final 11");

            try
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 12");
                //create outgoing message
                
                IBaseMessage outMsg = pContext.GetMessageFactory().CreateMessage();
                outMsg.Context = PipelineUtil.CloneMessageContext(pInMsg.Context);
                outMsg.AddPart("Body", pContext.GetMessageFactory().CreateMessagePart(), true);
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 13");
                outMsg.Context.Promote("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties", namespaceURI + "#" + rootElement.Replace("ns0:", ""));
                byte[] bufferOoutgoingMessage = System.Text.ASCIIEncoding.ASCII.GetBytes(messageString);
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 15");
                outMsg.BodyPart.Data = new MemoryStream(bufferOoutgoingMessage);
                outMsg.BodyPart.Data.Position = 0;
                
                //string ss = outMsg.BodyPart.Data.ToString();
                //TextReader tx = new StreamReader(outMsg.BodyPart.Data);
                //string temp = tx.ReadToEnd();
                
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 16 : " );
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 16.1--> Partcount  : " +  outMsg.PartCount );
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 16.1--> PartName  : " + outMsg.BodyPartName );
                qOutputMsgs.Enqueue(outMsg);
            }

            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 17 : " +ex.Message.ToString());
                //throw new ApplicationException("Error in queueing outgoing messages: " + ex.Message);
            }

        }


            public IBaseMessage GetNext(IPipelineContext pContext)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Final 7");
                if (qOutputMsgs.Count > 0)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 8");
                    IBaseMessage msg = (IBaseMessage)qOutputMsgs.Dequeue();
                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 9");
                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 9.1--> Part Name-->" + msg.BodyPartName );
                    System.Diagnostics.EventLog.WriteEntry("Application", "Final 9.2--> Partcount-->" + msg.PartCount);
                    return msg;
                }
                else
                    return null;

                //System.Diagnostics.EventLog.WriteEntry("Application", "Final 10");
            }
        }//JsonToXMLConverter Class End
    }

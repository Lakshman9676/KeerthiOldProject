namespace Inchcape.YourISS.Integration.IMOS.PortCallSchedule {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.StartSchema", typeof(global::Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.StartSchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema_Configuration", typeof(global::Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema_Configuration))]
    public sealed class TransformConfiguration : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.IMOS.PortCallSchedule.StartSchema"" xmlns:ns0=""http://Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:IMOS"" />
  </xsl:template>
  <xsl:template match=""/s0:IMOS"">
    <ns0:Root>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS1:DBLookup(0 , &quot;IMOSPORTCALLURL&quot; , string($var:v1) , &quot;Configuration&quot; , &quot;cast (  [Key]  as varchar(50) )&quot;)"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBValueExtract(string($var:v2) , &quot;Value&quot;)"" />
      <URL>
        <xsl:value-of select=""$var:v3"" />
      </URL>
      <xsl:variable name=""var:v4"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBLookup(1 , &quot;IMOS&quot; , string($var:v4) , &quot;CustomerConfiguration&quot; , &quot;cast ( Code  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v6"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;SecurityMode&quot;)"" />
      <SecurityMode>
        <xsl:value-of select=""$var:v6"" />
      </SecurityMode>
      <xsl:variable name=""var:v7"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(1 , &quot;IMOS&quot; , string($var:v7) , &quot;CustomerConfiguration&quot; , &quot;cast ( Code  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;TransportClientCredentialType&quot;)"" />
      <TransportClientCredentialType>
        <xsl:value-of select=""$var:v9"" />
      </TransportClientCredentialType>
      <xsl:variable name=""var:v10"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v11"" select=""ScriptNS1:DBLookup(1 , &quot;IMOS&quot; , string($var:v10) , &quot;CustomerConfiguration&quot; , &quot;cast ( Code  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v12"" select=""ScriptNS1:DBValueExtract(string($var:v11) , &quot;UserName&quot;)"" />
      <UserName>
        <xsl:value-of select=""$var:v12"" />
      </UserName>
      <xsl:variable name=""var:v13"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v14"" select=""ScriptNS1:DBLookup(1 , &quot;IMOS&quot; , string($var:v13) , &quot;CustomerConfiguration&quot; , &quot;cast ( Code  as varchar (40) )&quot;)"" />
      <xsl:variable name=""var:v15"" select=""ScriptNS1:DBValueExtract(string($var:v14) , &quot;Password&quot;)"" />
      <Password>
        <xsl:value-of select=""$var:v15"" />
      </Password>
    </ns0:Root>
    <xsl:variable name=""var:v16"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.StartSchema";
        
        private const global::Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.StartSchema _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema_Configuration";
        
        private const global::Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema_Configuration _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.StartSchema";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.PortCallSchedule.Schema.Schema_Configuration";
                return _TrgSchemas;
            }
        }
    }
}

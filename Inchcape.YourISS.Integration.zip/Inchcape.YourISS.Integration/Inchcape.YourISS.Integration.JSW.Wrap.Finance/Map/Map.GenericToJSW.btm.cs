namespace Inchcape.YourISS.Integration.JSW.Wrap.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.Schema_ShipnetFinalDA", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.Schema_ShipnetFinalDA))]
    public sealed class Map_GenericToJSW : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA"" xmlns:ns0=""http://Inchcape.YourISS.Integration.ShipnetFinalDA.Schema.Schema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <ns0:YourIssNotification>
      <ns0:MessageHeader>
        <ns0:MessageType>
          <xsl:value-of select=""s0:MessageHeader/s0:MessageType/text()"" />
        </ns0:MessageType>
        <ns0:Action>
          <xsl:value-of select=""s0:MessageHeader/s0:Action/text()"" />
        </ns0:Action>
        <ns0:CreatedDate>
          <xsl:value-of select=""s0:MessageHeader/s0:CreatedDate/text()"" />
        </ns0:CreatedDate>
        <ns0:ShipNetReference>
          <xsl:value-of select=""s0:MessageHeader/s0:ShipNetReference/text()"" />
        </ns0:ShipNetReference>
        <ns0:SourceApplication>
          <xsl:value-of select=""s0:MessageHeader/s0:SourceApplication/text()"" />
        </ns0:SourceApplication>
      </ns0:MessageHeader>
      <ns0:DisbursementAccount>
        <ns0:Stage>
          <xsl:value-of select=""s0:DisbursementAccount/s0:Stage/text()"" />
        </ns0:Stage>
        <ns0:SN_DANo>
          <xsl:value-of select=""s0:DisbursementAccount/s0:SN_DANo/text()"" />
        </ns0:SN_DANo>
        <ns0:SN_DaType>
          <xsl:value-of select=""s0:DisbursementAccount/s0:SN_DaType/text()"" />
        </ns0:SN_DaType>
        <ns0:SN_VoyageNumber>
          <xsl:value-of select=""s0:DisbursementAccount/s0:SN_VoyageNumber/text()"" />
        </ns0:SN_VoyageNumber>
        <xsl:if test=""s0:DisbursementAccount/s0:SN_VesselCode"">
          <xsl:variable name=""var:v1"" select=""string(s0:DisbursementAccount/s0:SN_VesselCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v1)='true'"">
            <ns0:SN_VesselCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:SN_VesselCode>
          </xsl:if>
          <xsl:if test=""string($var:v1)='false'"">
            <ns0:SN_VesselCode>
              <xsl:value-of select=""s0:DisbursementAccount/s0:SN_VesselCode/text()"" />
            </ns0:SN_VesselCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""s0:DisbursementAccount/s0:SN_AcctsCode"">
          <xsl:variable name=""var:v2"" select=""string(s0:DisbursementAccount/s0:SN_AcctsCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v2)='true'"">
            <ns0:SN_AcctsCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:SN_AcctsCode>
          </xsl:if>
          <xsl:if test=""string($var:v2)='false'"">
            <ns0:SN_AcctsCode>
              <xsl:value-of select=""s0:DisbursementAccount/s0:SN_AcctsCode/text()"" />
            </ns0:SN_AcctsCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""s0:DisbursementAccount/s0:SN_AgentCode"">
          <xsl:variable name=""var:v3"" select=""string(s0:DisbursementAccount/s0:SN_AgentCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v3)='true'"">
            <ns0:SN_AgentCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:SN_AgentCode>
          </xsl:if>
          <xsl:if test=""string($var:v3)='false'"">
            <ns0:SN_AgentCode>
              <xsl:value-of select=""s0:DisbursementAccount/s0:SN_AgentCode/text()"" />
            </ns0:SN_AgentCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""s0:DisbursementAccount/s0:ISS_AgentCode"">
          <xsl:variable name=""var:v4"" select=""string(s0:DisbursementAccount/s0:ISS_AgentCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v4)='true'"">
            <ns0:ISS_AgentCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:ISS_AgentCode>
          </xsl:if>
          <xsl:if test=""string($var:v4)='false'"">
            <ns0:ISS_AgentCode>
              <xsl:value-of select=""s0:DisbursementAccount/s0:ISS_AgentCode/text()"" />
            </ns0:ISS_AgentCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""s0:DisbursementAccount/s0:WorkflowStatus"">
          <xsl:variable name=""var:v5"" select=""string(s0:DisbursementAccount/s0:WorkflowStatus/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v5)='true'"">
            <ns0:WorkflowStatus>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:WorkflowStatus>
          </xsl:if>
          <xsl:if test=""string($var:v5)='false'"">
            <ns0:WorkflowStatus>
              <xsl:value-of select=""s0:DisbursementAccount/s0:WorkflowStatus/text()"" />
            </ns0:WorkflowStatus>
          </xsl:if>
        </xsl:if>
        <ns0:DaDate>
          <xsl:value-of select=""s0:DisbursementAccount/s0:DaDate/text()"" />
        </ns0:DaDate>
        <ns0:InvoiceNo>
          <xsl:value-of select=""s0:DisbursementAccount/s0:InvoiceNo/text()"" />
        </ns0:InvoiceNo>
        <ns0:InvoiceDate>
          <xsl:value-of select=""s0:DisbursementAccount/s0:InvoiceDate/text()"" />
        </ns0:InvoiceDate>
        <ns0:DueDate>
          <xsl:value-of select=""s0:DisbursementAccount/s0:DueDate/text()"" />
        </ns0:DueDate>
        <ns0:DaCurrencyCode>
          <xsl:value-of select=""s0:DisbursementAccount/s0:DaCurrencyCode/text()"" />
        </ns0:DaCurrencyCode>
        <ns0:YourIssCurrencyCode>
          <xsl:value-of select=""s0:DisbursementAccount/s0:YourIssCurrencyCode/text()"" />
        </ns0:YourIssCurrencyCode>
        <ns0:YourIssExchangeRate>
          <xsl:value-of select=""s0:DisbursementAccount/s0:YourIssExchangeRate/text()"" />
        </ns0:YourIssExchangeRate>
        <xsl:if test=""s0:DisbursementAccount/s0:CostCentreId"">
          <xsl:variable name=""var:v6"" select=""string(s0:DisbursementAccount/s0:CostCentreId/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v6)='true'"">
            <ns0:CostCentreId>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:CostCentreId>
          </xsl:if>
          <xsl:if test=""string($var:v6)='false'"">
            <ns0:CostCentreId>
              <xsl:value-of select=""s0:DisbursementAccount/s0:CostCentreId/text()"" />
            </ns0:CostCentreId>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""s0:DisbursementAccount/s0:Comment"">
          <xsl:variable name=""var:v7"" select=""string(s0:DisbursementAccount/s0:Comment/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v7)='true'"">
            <ns0:Comment>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ns0:Comment>
          </xsl:if>
          <xsl:if test=""string($var:v7)='false'"">
            <ns0:Comment>
              <xsl:value-of select=""s0:DisbursementAccount/s0:Comment/text()"" />
            </ns0:Comment>
          </xsl:if>
        </xsl:if>
        <xsl:for-each select=""s0:DisbursementAccount/s0:PerformingAgent"">
          <ns0:PerformingAgent>
            <xsl:if test=""s0:Name"">
              <xsl:variable name=""var:v8"" select=""string(s0:Name/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v8)='true'"">
                <ns0:Name>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:Name>
              </xsl:if>
              <xsl:if test=""string($var:v8)='false'"">
                <ns0:Name>
                  <xsl:value-of select=""s0:Name/text()"" />
                </ns0:Name>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:CountryCode"">
              <xsl:variable name=""var:v9"" select=""string(s0:CountryCode/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v9)='true'"">
                <ns0:CountryCode>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:CountryCode>
              </xsl:if>
              <xsl:if test=""string($var:v9)='false'"">
                <ns0:CountryCode>
                  <xsl:value-of select=""s0:CountryCode/text()"" />
                </ns0:CountryCode>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:ISS_AgentCode"">
              <xsl:variable name=""var:v10"" select=""string(s0:ISS_AgentCode/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v10)='true'"">
                <ns0:ISS_AgentCode>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:ISS_AgentCode>
              </xsl:if>
              <xsl:if test=""string($var:v10)='false'"">
                <ns0:ISS_AgentCode>
                  <xsl:value-of select=""s0:ISS_AgentCode/text()"" />
                </ns0:ISS_AgentCode>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:AddressLine1"">
              <xsl:variable name=""var:v11"" select=""string(s0:AddressLine1/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v11)='true'"">
                <ns0:AddressLine1>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:AddressLine1>
              </xsl:if>
              <xsl:if test=""string($var:v11)='false'"">
                <ns0:AddressLine1>
                  <xsl:value-of select=""s0:AddressLine1/text()"" />
                </ns0:AddressLine1>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:AddressLine2"">
              <xsl:variable name=""var:v12"" select=""string(s0:AddressLine2/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v12)='true'"">
                <ns0:AddressLine2>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:AddressLine2>
              </xsl:if>
              <xsl:if test=""string($var:v12)='false'"">
                <ns0:AddressLine2>
                  <xsl:value-of select=""s0:AddressLine2/text()"" />
                </ns0:AddressLine2>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:AddressLine3"">
              <xsl:variable name=""var:v13"" select=""string(s0:AddressLine3/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v13)='true'"">
                <ns0:AddressLine3>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:AddressLine3>
              </xsl:if>
              <xsl:if test=""string($var:v13)='false'"">
                <ns0:AddressLine3>
                  <xsl:value-of select=""s0:AddressLine3/text()"" />
                </ns0:AddressLine3>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:Email"">
              <xsl:variable name=""var:v14"" select=""string(s0:Email/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v14)='true'"">
                <ns0:Email>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:Email>
              </xsl:if>
              <xsl:if test=""string($var:v14)='false'"">
                <ns0:Email>
                  <xsl:value-of select=""s0:Email/text()"" />
                </ns0:Email>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""s0:Phone"">
              <xsl:variable name=""var:v15"" select=""string(s0:Phone/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v15)='true'"">
                <ns0:Phone>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </ns0:Phone>
              </xsl:if>
              <xsl:if test=""string($var:v15)='false'"">
                <ns0:Phone>
                  <xsl:value-of select=""s0:Phone/text()"" />
                </ns0:Phone>
              </xsl:if>
            </xsl:if>
            <xsl:value-of select=""./text()"" />
          </ns0:PerformingAgent>
        </xsl:for-each>
        <xsl:variable name=""var:v16"" select=""userCSharp:MyConcat(string(s0:DisbursementAccount/s0:AdvancePayment/text()) , string(s0:DisbursementAccount/s0:DaLineCount/text()))"" />
        <ns0:DaLineCount>
          <xsl:value-of select=""$var:v16"" />
        </ns0:DaLineCount>
        <ns0:Lines>
          <xsl:for-each select=""s0:DisbursementAccount/s0:Lines/s0:DaLine"">
            <xsl:variable name=""var:v17"" select=""userCSharp:MyConcatAdvance(string(../../s0:AdvancePayment/text()))"" />
            <xsl:variable name=""var:v18"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v19"" select=""ScriptNS1:DBLookup(0 , string(../../s0:CostCentreId/text()) , string($var:v18) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
            <xsl:variable name=""var:v20"" select=""ScriptNS1:DBValueExtract(string($var:v19) , &quot;appointmentid&quot;)"" />
            <xsl:variable name=""var:v21"" select=""ScriptNS1:DBLookup(1 , string($var:v20) , string($var:v18) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
            <xsl:variable name=""var:v22"" select=""ScriptNS1:DBValueExtract(string($var:v21) , &quot;CashToMasterReceived&quot;)"" />
            <xsl:variable name=""var:v23"" select=""userCSharp:MathAbs(string($var:v22))"" />
            <xsl:variable name=""var:v24"" select=""string(../../s0:AdvancePayment/text())"" />
            <xsl:variable name=""var:v25"" select=""userCSharp:MathAbs($var:v24)"" />
            <xsl:variable name=""var:v26"" select=""userCSharp:CalcAdvAmpuntt(string($var:v23) , string($var:v25))"" />
            <xsl:variable name=""var:v27"" select=""userCSharp:MathAbs(string($var:v26))"" />
            <xsl:variable name=""var:v28"" select=""userCSharp:YourISSAdvPayAmountCal(string(../../s0:YourIssExchangeRate/text()) , string($var:v26))"" />
            <xsl:variable name=""var:v29"" select=""'true'"" />
            <xsl:variable name=""var:v30"" select=""userCSharp:LogicalEq(string($var:v29) , &quot;true&quot;)"" />
            <xsl:variable name=""var:v31"" select=""s0:ServiceLineCode"" />
            <xsl:variable name=""var:v32"" select=""userCSharp:AdvancePaymentCountFunc(string($var:v31))"" />
            <xsl:variable name=""var:v33"" select=""userCSharp:LogicalLte(string($var:v32) , &quot;1&quot;)"" />
            <xsl:variable name=""var:v34"" select=""userCSharp:LogicalEq(string($var:v31) , &quot;ADV&quot;)"" />
            <xsl:variable name=""var:v35"" select=""userCSharp:LogicalAnd(string($var:v33) , string($var:v34))"" />
            <xsl:variable name=""var:v36"" select=""userCSharp:LogicalNe(string($var:v31) , &quot;ADV&quot;)"" />
            <xsl:variable name=""var:v37"" select=""userCSharp:LogicalOr(string($var:v35) , string($var:v36))"" />
            <xsl:variable name=""var:v38"" select=""userCSharp:LogicalAnd(string($var:v30) , string($var:v37))"" />
            <xsl:if test=""$var:v38"">
              <xsl:variable name=""var:v41"" select=""string(../../s0:CostCentreId/text())"" />
              <xsl:variable name=""var:v49"" select=""string(../../s0:YourIssExchangeRate/text())"" />
              <ns0:DaLine>
                <xsl:variable name=""var:v39"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v40"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v42"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v40) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v43"" select=""ScriptNS1:DBValueExtract(string($var:v42) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v44"" select=""ScriptNS1:DBLookup(1 , string($var:v43) , string($var:v40) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v45"" select=""ScriptNS1:DBValueExtract(string($var:v44) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v46"" select=""userCSharp:MathAbs(string($var:v45))"" />
                <xsl:variable name=""var:v47"" select=""userCSharp:CalcAdvAmpuntt(string($var:v46) , string($var:v25))"" />
                <xsl:variable name=""var:v48"" select=""userCSharp:MathAbs(string($var:v47))"" />
                <xsl:variable name=""var:v50"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v47))"" />
                <xsl:variable name=""var:v51"" select=""s0:ServiceLineCode"" />
                <ns0:ServiceLineCode>
                  <xsl:value-of select=""$var:v51"" />
                </ns0:ServiceLineCode>
                <xsl:variable name=""var:v52"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v53"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v54"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v53) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v55"" select=""ScriptNS1:DBValueExtract(string($var:v54) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v56"" select=""ScriptNS1:DBLookup(1 , string($var:v55) , string($var:v53) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v57"" select=""ScriptNS1:DBValueExtract(string($var:v56) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v58"" select=""userCSharp:MathAbs(string($var:v57))"" />
                <xsl:variable name=""var:v59"" select=""userCSharp:CalcAdvAmpuntt(string($var:v58) , string($var:v25))"" />
                <xsl:variable name=""var:v60"" select=""userCSharp:MathAbs(string($var:v59))"" />
                <xsl:variable name=""var:v61"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v59))"" />
                <xsl:variable name=""var:v62"" select=""s0:ServiceLineName"" />
                <ns0:ServiceLineName>
                  <xsl:value-of select=""$var:v62"" />
                </ns0:ServiceLineName>
                <xsl:variable name=""var:v63"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v64"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v65"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v64) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v66"" select=""ScriptNS1:DBValueExtract(string($var:v65) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v67"" select=""ScriptNS1:DBLookup(1 , string($var:v66) , string($var:v64) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v68"" select=""ScriptNS1:DBValueExtract(string($var:v67) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v69"" select=""userCSharp:MathAbs(string($var:v68))"" />
                <xsl:variable name=""var:v70"" select=""userCSharp:CalcAdvAmpuntt(string($var:v69) , string($var:v25))"" />
                <xsl:variable name=""var:v71"" select=""userCSharp:MathAbs(string($var:v70))"" />
                <xsl:variable name=""var:v72"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v70))"" />
                <xsl:variable name=""var:v73"" select=""s0:Comment"" />
                <ns0:Comment>
                  <xsl:value-of select=""$var:v73"" />
                </ns0:Comment>
                <ns0:Amount>
                  <xsl:variable name=""var:v74"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v75"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v76"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v75) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v77"" select=""ScriptNS1:DBValueExtract(string($var:v76) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v78"" select=""ScriptNS1:DBLookup(1 , string($var:v77) , string($var:v75) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v79"" select=""ScriptNS1:DBValueExtract(string($var:v78) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v80"" select=""userCSharp:MathAbs(string($var:v79))"" />
                  <xsl:variable name=""var:v81"" select=""userCSharp:CalcAdvAmpuntt(string($var:v80) , string($var:v25))"" />
                  <xsl:variable name=""var:v82"" select=""userCSharp:MathAbs(string($var:v81))"" />
                  <xsl:variable name=""var:v83"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v81))"" />
                  <xsl:variable name=""var:v84"" select=""s0:Amount/s0:CurrencyCode"" />
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""$var:v84"" />
                  </ns0:CurrencyCode>
                  <xsl:variable name=""var:v85"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v86"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v87"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v86) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v88"" select=""ScriptNS1:DBValueExtract(string($var:v87) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v89"" select=""ScriptNS1:DBLookup(1 , string($var:v88) , string($var:v86) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v90"" select=""ScriptNS1:DBValueExtract(string($var:v89) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v91"" select=""userCSharp:MathAbs(string($var:v90))"" />
                  <xsl:variable name=""var:v92"" select=""userCSharp:CalcAdvAmpuntt(string($var:v91) , string($var:v25))"" />
                  <xsl:variable name=""var:v93"" select=""userCSharp:MathAbs(string($var:v92))"" />
                  <xsl:variable name=""var:v94"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v92))"" />
                  <xsl:variable name=""var:v95"" select=""s0:Amount/s0:Amount"" />
                  <ns0:Amount>
                    <xsl:value-of select=""$var:v95"" />
                  </ns0:Amount>
                </ns0:Amount>
                <ns0:YourIssAmount>
                  <xsl:variable name=""var:v96"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v97"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v98"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v97) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v99"" select=""ScriptNS1:DBValueExtract(string($var:v98) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v100"" select=""ScriptNS1:DBLookup(1 , string($var:v99) , string($var:v97) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v101"" select=""ScriptNS1:DBValueExtract(string($var:v100) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v102"" select=""userCSharp:MathAbs(string($var:v101))"" />
                  <xsl:variable name=""var:v103"" select=""userCSharp:CalcAdvAmpuntt(string($var:v102) , string($var:v25))"" />
                  <xsl:variable name=""var:v104"" select=""userCSharp:MathAbs(string($var:v103))"" />
                  <xsl:variable name=""var:v105"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v103))"" />
                  <xsl:variable name=""var:v106"" select=""s0:YourIssAmount/s0:CurrencyCode"" />
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""$var:v106"" />
                  </ns0:CurrencyCode>
                  <xsl:variable name=""var:v107"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v108"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v109"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v108) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v110"" select=""ScriptNS1:DBValueExtract(string($var:v109) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v111"" select=""ScriptNS1:DBLookup(1 , string($var:v110) , string($var:v108) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v112"" select=""ScriptNS1:DBValueExtract(string($var:v111) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v113"" select=""userCSharp:MathAbs(string($var:v112))"" />
                  <xsl:variable name=""var:v114"" select=""userCSharp:CalcAdvAmpuntt(string($var:v113) , string($var:v25))"" />
                  <xsl:variable name=""var:v115"" select=""userCSharp:MathAbs(string($var:v114))"" />
                  <xsl:variable name=""var:v116"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v114))"" />
                  <xsl:variable name=""var:v117"" select=""s0:YourIssAmount/s0:Amount"" />
                  <ns0:Amount>
                    <xsl:value-of select=""$var:v117"" />
                  </ns0:Amount>
                </ns0:YourIssAmount>
                <ns0:DocumentCount>
                  <xsl:value-of select=""s0:DocumentCount/text()"" />
                </ns0:DocumentCount>
                <ns0:Documents>
                  <xsl:for-each select=""s0:Documents/s0:Document"">
                    <ns0:Document>
                      <xsl:value-of select=""./text()"" />
                    </ns0:Document>
                  </xsl:for-each>
                  <xsl:value-of select=""s0:Documents/text()"" />
                </ns0:Documents>
                <xsl:variable name=""var:v118"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v119"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v120"" select=""ScriptNS1:DBLookup(0 , $var:v41 , string($var:v119) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v121"" select=""ScriptNS1:DBValueExtract(string($var:v120) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v122"" select=""ScriptNS1:DBLookup(1 , string($var:v121) , string($var:v119) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v123"" select=""ScriptNS1:DBValueExtract(string($var:v122) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v124"" select=""userCSharp:MathAbs(string($var:v123))"" />
                <xsl:variable name=""var:v125"" select=""userCSharp:CalcAdvAmpuntt(string($var:v124) , string($var:v25))"" />
                <xsl:variable name=""var:v126"" select=""userCSharp:MathAbs(string($var:v125))"" />
                <xsl:variable name=""var:v127"" select=""userCSharp:YourISSAdvPayAmountCal($var:v49 , string($var:v125))"" />
              </ns0:DaLine>
            </xsl:if>
            <xsl:variable name=""var:v128"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
            <xsl:variable name=""var:v129"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v130"" select=""string(../../s0:CostCentreId/text())"" />
            <xsl:variable name=""var:v131"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v129) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
            <xsl:variable name=""var:v132"" select=""ScriptNS1:DBValueExtract(string($var:v131) , &quot;appointmentid&quot;)"" />
            <xsl:variable name=""var:v133"" select=""ScriptNS1:DBLookup(1 , string($var:v132) , string($var:v129) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
            <xsl:variable name=""var:v134"" select=""ScriptNS1:DBValueExtract(string($var:v133) , &quot;CashToMasterReceived&quot;)"" />
            <xsl:variable name=""var:v135"" select=""userCSharp:MathAbs(string($var:v134))"" />
            <xsl:variable name=""var:v136"" select=""userCSharp:CalcAdvAmpuntt(string($var:v135) , string($var:v25))"" />
            <xsl:variable name=""var:v137"" select=""userCSharp:MathAbs(string($var:v136))"" />
            <xsl:variable name=""var:v138"" select=""string(../../s0:YourIssExchangeRate/text())"" />
            <xsl:variable name=""var:v139"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v136))"" />
            <xsl:variable name=""var:v140"" select=""$var:v128"" />
            <xsl:variable name=""var:v141"" select=""userCSharp:LogicalEq(string($var:v140) , &quot;true&quot;)"" />
            <xsl:variable name=""var:v142"" select=""'ADV'"" />
            <xsl:variable name=""var:v143"" select=""userCSharp:AdvancePaymentCountFunc(string($var:v142))"" />
            <xsl:variable name=""var:v144"" select=""userCSharp:LogicalLte(string($var:v143) , &quot;1&quot;)"" />
            <xsl:variable name=""var:v145"" select=""userCSharp:LogicalEq(string($var:v142) , &quot;ADV&quot;)"" />
            <xsl:variable name=""var:v146"" select=""userCSharp:LogicalAnd(string($var:v144) , string($var:v145))"" />
            <xsl:variable name=""var:v147"" select=""userCSharp:LogicalNe(string($var:v142) , &quot;ADV&quot;)"" />
            <xsl:variable name=""var:v148"" select=""userCSharp:LogicalOr(string($var:v146) , string($var:v147))"" />
            <xsl:variable name=""var:v149"" select=""userCSharp:LogicalAnd(string($var:v141) , string($var:v148))"" />
            <xsl:if test=""$var:v149"">
              <ns0:DaLine>
                <xsl:variable name=""var:v150"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v151"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v152"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v151) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v153"" select=""ScriptNS1:DBValueExtract(string($var:v152) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v154"" select=""ScriptNS1:DBLookup(1 , string($var:v153) , string($var:v151) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v155"" select=""ScriptNS1:DBValueExtract(string($var:v154) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v156"" select=""userCSharp:MathAbs(string($var:v155))"" />
                <xsl:variable name=""var:v157"" select=""userCSharp:CalcAdvAmpuntt(string($var:v156) , string($var:v25))"" />
                <xsl:variable name=""var:v158"" select=""userCSharp:MathAbs(string($var:v157))"" />
                <xsl:variable name=""var:v159"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v157))"" />
                <xsl:variable name=""var:v160"" select=""'ADV'"" />
                <ns0:ServiceLineCode>
                  <xsl:value-of select=""$var:v160"" />
                </ns0:ServiceLineCode>
                <xsl:variable name=""var:v161"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v162"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v163"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v162) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v164"" select=""ScriptNS1:DBValueExtract(string($var:v163) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v165"" select=""ScriptNS1:DBLookup(1 , string($var:v164) , string($var:v162) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v166"" select=""ScriptNS1:DBValueExtract(string($var:v165) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v167"" select=""userCSharp:MathAbs(string($var:v166))"" />
                <xsl:variable name=""var:v168"" select=""userCSharp:CalcAdvAmpuntt(string($var:v167) , string($var:v25))"" />
                <xsl:variable name=""var:v169"" select=""userCSharp:MathAbs(string($var:v168))"" />
                <xsl:variable name=""var:v170"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v168))"" />
                <xsl:variable name=""var:v171"" select=""'ADV'"" />
                <ns0:ServiceLineName>
                  <xsl:value-of select=""$var:v171"" />
                </ns0:ServiceLineName>
                <xsl:variable name=""var:v172"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v173"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v174"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v173) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v175"" select=""ScriptNS1:DBValueExtract(string($var:v174) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v176"" select=""ScriptNS1:DBLookup(1 , string($var:v175) , string($var:v173) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v177"" select=""ScriptNS1:DBValueExtract(string($var:v176) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v178"" select=""userCSharp:MathAbs(string($var:v177))"" />
                <xsl:variable name=""var:v179"" select=""userCSharp:CalcAdvAmpuntt(string($var:v178) , string($var:v25))"" />
                <xsl:variable name=""var:v180"" select=""userCSharp:MathAbs(string($var:v179))"" />
                <xsl:variable name=""var:v181"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v179))"" />
                <xsl:variable name=""var:v182"" select=""''"" />
                <ns0:Comment>
                  <xsl:value-of select=""$var:v182"" />
                </ns0:Comment>
                <ns0:Amount>
                  <xsl:variable name=""var:v183"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v184"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v185"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v184) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v186"" select=""ScriptNS1:DBValueExtract(string($var:v185) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v187"" select=""ScriptNS1:DBLookup(1 , string($var:v186) , string($var:v184) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v188"" select=""ScriptNS1:DBValueExtract(string($var:v187) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v189"" select=""userCSharp:MathAbs(string($var:v188))"" />
                  <xsl:variable name=""var:v190"" select=""userCSharp:CalcAdvAmpuntt(string($var:v189) , string($var:v25))"" />
                  <xsl:variable name=""var:v191"" select=""userCSharp:MathAbs(string($var:v190))"" />
                  <xsl:variable name=""var:v192"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v190))"" />
                  <xsl:variable name=""var:v193"" select=""s0:Amount/s0:CurrencyCode"" />
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""$var:v193"" />
                  </ns0:CurrencyCode>
                  <xsl:variable name=""var:v194"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v195"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v196"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v195) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v197"" select=""ScriptNS1:DBValueExtract(string($var:v196) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v198"" select=""ScriptNS1:DBLookup(1 , string($var:v197) , string($var:v195) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v199"" select=""ScriptNS1:DBValueExtract(string($var:v198) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v200"" select=""userCSharp:MathAbs(string($var:v199))"" />
                  <xsl:variable name=""var:v201"" select=""userCSharp:CalcAdvAmpuntt(string($var:v200) , string($var:v25))"" />
                  <xsl:variable name=""var:v202"" select=""userCSharp:MathAbs(string($var:v201))"" />
                  <xsl:variable name=""var:v203"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v201))"" />
                  <xsl:variable name=""var:v204"" select=""$var:v202"" />
                  <ns0:Amount>
                    <xsl:value-of select=""$var:v204"" />
                  </ns0:Amount>
                </ns0:Amount>
                <ns0:YourIssAmount>
                  <xsl:variable name=""var:v205"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v206"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v207"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v206) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v208"" select=""ScriptNS1:DBValueExtract(string($var:v207) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v209"" select=""ScriptNS1:DBLookup(1 , string($var:v208) , string($var:v206) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v210"" select=""ScriptNS1:DBValueExtract(string($var:v209) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v211"" select=""userCSharp:MathAbs(string($var:v210))"" />
                  <xsl:variable name=""var:v212"" select=""userCSharp:CalcAdvAmpuntt(string($var:v211) , string($var:v25))"" />
                  <xsl:variable name=""var:v213"" select=""userCSharp:MathAbs(string($var:v212))"" />
                  <xsl:variable name=""var:v214"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v212))"" />
                  <xsl:variable name=""var:v215"" select=""s0:YourIssAmount/s0:CurrencyCode"" />
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""$var:v215"" />
                  </ns0:CurrencyCode>
                  <xsl:variable name=""var:v216"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                  <xsl:variable name=""var:v217"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v218"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v217) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v219"" select=""ScriptNS1:DBValueExtract(string($var:v218) , &quot;appointmentid&quot;)"" />
                  <xsl:variable name=""var:v220"" select=""ScriptNS1:DBLookup(1 , string($var:v219) , string($var:v217) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                  <xsl:variable name=""var:v221"" select=""ScriptNS1:DBValueExtract(string($var:v220) , &quot;CashToMasterReceived&quot;)"" />
                  <xsl:variable name=""var:v222"" select=""userCSharp:MathAbs(string($var:v221))"" />
                  <xsl:variable name=""var:v223"" select=""userCSharp:CalcAdvAmpuntt(string($var:v222) , string($var:v25))"" />
                  <xsl:variable name=""var:v224"" select=""userCSharp:MathAbs(string($var:v223))"" />
                  <xsl:variable name=""var:v225"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v223))"" />
                  <xsl:variable name=""var:v226"" select=""$var:v225"" />
                  <ns0:Amount>
                    <xsl:value-of select=""$var:v226"" />
                  </ns0:Amount>
                </ns0:YourIssAmount>
                <ns0:DocumentCount>
                  <xsl:value-of select=""s0:DocumentCount/text()"" />
                </ns0:DocumentCount>
                <ns0:Documents>
                  <xsl:for-each select=""s0:Documents/s0:Document"">
                    <ns0:Document>
                      <xsl:value-of select=""./text()"" />
                    </ns0:Document>
                  </xsl:for-each>
                  <xsl:value-of select=""s0:Documents/text()"" />
                </ns0:Documents>
                <xsl:variable name=""var:v227"" select=""userCSharp:MyConcatAdvance($var:v24)"" />
                <xsl:variable name=""var:v228"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v229"" select=""ScriptNS1:DBLookup(0 , $var:v130 , string($var:v228) , &quot;APPOINTMENT.APPOINTMENTCOSTCENTERS&quot; , &quot;cast (  [number]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v230"" select=""ScriptNS1:DBValueExtract(string($var:v229) , &quot;appointmentid&quot;)"" />
                <xsl:variable name=""var:v231"" select=""ScriptNS1:DBLookup(1 , string($var:v230) , string($var:v228) , &quot;APPOINTMENT.APPOINTMENTS&quot; , &quot;cast (  [id]  as varchar(50) )&quot;)"" />
                <xsl:variable name=""var:v232"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;CashToMasterReceived&quot;)"" />
                <xsl:variable name=""var:v233"" select=""userCSharp:MathAbs(string($var:v232))"" />
                <xsl:variable name=""var:v234"" select=""userCSharp:CalcAdvAmpuntt(string($var:v233) , string($var:v25))"" />
                <xsl:variable name=""var:v235"" select=""userCSharp:MathAbs(string($var:v234))"" />
                <xsl:variable name=""var:v236"" select=""userCSharp:YourISSAdvPayAmountCal($var:v138 , string($var:v234))"" />
              </ns0:DaLine>
            </xsl:if>
          </xsl:for-each>
          <xsl:value-of select=""s0:DisbursementAccount/s0:Lines/text()"" />
        </ns0:Lines>
        <ns0:DocumentCount>
          <xsl:value-of select=""s0:DisbursementAccount/s0:DocumentCount/text()"" />
        </ns0:DocumentCount>
        <ns0:Documents>
          <xsl:for-each select=""s0:DisbursementAccount/s0:Documents/s0:Document"">
            <ns0:Document>
              <xsl:value-of select=""./text()"" />
            </ns0:Document>
          </xsl:for-each>
          <xsl:value-of select=""s0:DisbursementAccount/s0:Documents/text()"" />
        </ns0:Documents>
      </ns0:DisbursementAccount>
    </ns0:YourIssNotification>
    <xsl:variable name=""var:v237"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public int MyConcat(decimal Advanceparam, string DaLineparam)
{
int DaCount=0;
DaCount = Int32.Parse(DaLineparam);
if(Advanceparam != 0)
{
   return DaCount+1;

}else
{
 return DaCount;
}	
}


int AdvancePaymentCount=0;

public bool MyConcatAdvance(decimal Advanceobj)
{
if(Advanceobj != 0)
{
   return true;

}else
{
 return false;
}	
}

public int AdvancePaymentCountFunc( string ServiceCode )
{
        if (  ServiceCode == ""ADV""  )
           {
               AdvancePaymentCount  =    AdvancePaymentCount + 1  ;
            }

         return AdvancePaymentCount ;
            
} 

public bool LogicalLte(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 <= d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) <= 0;
	}
	return ret;
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool LogicalNe(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 != d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) != 0;
	}
	return ret;
}


public bool LogicalAnd(string param0, string param1)
{
	return ValToBool(param0) && ValToBool(param1);
	return false;
}


public bool LogicalOr(string param0, string param1)
{
	return ValToBool(param0) || ValToBool(param1);
	return false;
}


public string MathAbs(string val)
{
	string retval = """";
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		double abs = Math.Abs(d);
		retval = abs.ToString(System.Globalization.CultureInfo.InvariantCulture);
	}
	return retval;
}


///*Uncomment the following code for a sample Inline C# function
//that concatenates two inputs. Change the number of parameters of
//this function to be equal to the number of inputs connected to this functoid.*/

public decimal YourISSAdvPayAmountCal(string objExcRate, string objAmount)
{
       decimal convertDecimalExc = 0;
       decimal.TryParse  (objExcRate, out convertDecimalExc);
      decimal convertDecimalAmount = 0;
                decimal.TryParse  (objAmount ,  out  convertDecimalAmount    );
        return  convertDecimalAmount/convertDecimalExc;
}


///*Uncomment the following code for a sample Inline C# function
//that concatenates two inputs. Change the number of parameters of
//this function to be equal to the number of inputs connected to this functoid.*/

public decimal CalcAdvAmpuntt(string objCashMas, string objAmount)
{

decimal a=0;decimal b=0;
decimal.TryParse(objCashMas,out a);
decimal.TryParse(objAmount,out b);
 return a + b;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool ValToBool(string val)
{
	if (val != null)
	{
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		val = val.Trim();
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		double d = 0;
		if (IsNumeric(val, ref d))
		{
			return (d > 0);
		}
	}
	return false;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.Schema_ShipnetFinalDA";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.Schema_ShipnetFinalDA _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.Schema_ShipnetFinalDA";
                return _TrgSchemas;
            }
        }
    }
}

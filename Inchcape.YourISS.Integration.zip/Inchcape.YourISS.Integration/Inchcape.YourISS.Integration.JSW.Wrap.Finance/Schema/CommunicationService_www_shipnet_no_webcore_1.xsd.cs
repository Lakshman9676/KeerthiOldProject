namespace Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://www.shipnet.no/webcore",@"Dto")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Dto"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.CommunicationService_schemas_microsoft_com_2003_10_Serialization", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.CommunicationService_schemas_microsoft_com_2003_10_Serialization))]
    public sealed class CommunicationService_www_shipnet_no_webcore_1 : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ser=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:tns=""http://www.shipnet.no/webcore"" elementFormDefault=""qualified"" targetNamespace=""http://www.shipnet.no/webcore"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.CommunicationService_schemas_microsoft_com_2003_10_Serialization"" namespace=""http://schemas.microsoft.com/2003/10/Serialization/"" />
  <xs:annotation>
    <xs:appinfo>
      <references xmlns=""http://schemas.microsoft.com/BizTalk/2003"">
        <reference targetNamespace=""http://schemas.microsoft.com/2003/10/Serialization/"" />
      </references>
    </xs:appinfo>
  </xs:annotation>
  <xs:complexType name=""Dto"">
    <xs:sequence>
      <xs:element minOccurs=""0"" name=""Version"" type=""xs:int"" />
      <xs:element minOccurs=""0"" name=""Header"" nillable=""true"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""AccountId"" type=""ser:guid"" />
      <xs:element minOccurs=""0"" name=""ObfuscatedAccountPassword"" nillable=""true"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""Method"" nillable=""true"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""Body"" nillable=""true"" type=""xs:base64Binary"" />
      <xs:element minOccurs=""0"" name=""ErrorMessage"" nillable=""true"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
  <xs:element name=""Dto"" nillable=""true"" type=""tns:Dto"" />
</xs:schema>";
        
        public CommunicationService_www_shipnet_no_webcore_1() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Dto";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

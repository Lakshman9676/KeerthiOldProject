namespace Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.EmailTemplateSchema",@"IntegrationEmail")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"IntegrationEmail"})]
    public sealed class EmailTemplateSchema : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.EmailTemplateSchema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.JSW.Wrap.Finance.Schema.EmailTemplateSchema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""IntegrationEmail"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Email"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""row"">
                <xs:complexType>
                  <xs:attribute name=""ErrorType"" type=""xs:string"" />
                  <xs:attribute name=""EmailFrom"" type=""xs:string"" />
                  <xs:attribute name=""EmailTo"" type=""xs:string"" />
                  <xs:attribute name=""EmailCC"" type=""xs:string"" />
                  <xs:attribute name=""EmailBcc"" type=""xs:string"" />
                  <xs:attribute name=""Method"" type=""xs:string"" />
                  <xs:attribute name=""Subject"" type=""xs:string"" />
                  <xs:attribute name=""Body"" type=""xs:string"" />
                  <xs:attribute name=""IsActive"" type=""xs:string"" />
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public EmailTemplateSchema() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "IntegrationEmail";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

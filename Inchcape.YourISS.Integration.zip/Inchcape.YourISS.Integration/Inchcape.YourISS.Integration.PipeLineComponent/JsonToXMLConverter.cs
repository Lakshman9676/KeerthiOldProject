﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.BizTalk.Component.Interop;
using System.Diagnostics;
using Newtonsoft.Json;

namespace Inchcape.YourISS.Integration.PipeLineComponent
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Decoder)]
    [System.Runtime.InteropServices.Guid("68FE13FD-9A21-4020-AE1D-F57C0C901D86")]
    public class JsonToXMLConverter : IBaseComponent, IComponentUI, IComponent, IPersistPropertyBag
    {
        public string Description
        {
            get
            {
                return "Pipeline component used to change include the Json root element";
            }
        }

        public string Name
        {
            get
            {
                return "JsonToXMLConverterPipeline";
            }
        }

        public string Version
        {
            get
            {
                return "1.0.0.0";
            }
        }

        public IntPtr Icon
        {
            get
            {
                return new System.IntPtr();
            }
        }

        public System.Collections.IEnumerator Validate(object projectSystem)
        {
            return null;
        }

        private string _NameSpace;
        private string _RootNode;
        private string _Prefix;
        private string _Suffix;

        public string NameSpace
        {
            get { return _NameSpace; }
            set { _NameSpace = value; }
        }

        public string RootNode
        {
            get { return _RootNode; }
            set { _RootNode = value; }
        }

        public string Prefix
        {
            get { return _Prefix; }
            set { _Prefix = value; }
        }

        public string Suffix
        {
            get { return _Suffix; }
            set { _Suffix = value; }
        }

        public void GetClassID(out Guid classID)
        {
            classID = new Guid("71D4ED14-2CAE-48DF-9F37-CEC1538F67D7");
        }

        public void InitNew()
        {
        }

        public void Load(IPropertyBag propertyBag, int errorLog)
        {

            System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Inside Load");

            object val = null;
            object val1 = null;
            object valPrefix = null;
            object valSuffix = null;

            try
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Before Property Bag Read");
                propertyBag.Read ("RootNode", out val, 0);
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - After RootNode Property Bag Read");
                propertyBag.Read("Namespace", out val1, 0);
               
                propertyBag.Read("Prefix", out valPrefix, 0);
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - After Prefix Property Bag Read");
                propertyBag.Read("Suffix", out valSuffix, 0);
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - After Suffix Property Bag Read");


                if (val1 != null)


                    _NameSpace = (string)val1;
                else
                    _NameSpace = "http://AnonymusURL";

                if (val != null)
                    _RootNode = (string)val;
                else
                    _RootNode = "Root";

                if (valPrefix != null)
                    _Prefix = (string)valPrefix;
                else
                    _Prefix = "";

                if (valSuffix != null)
                    _Suffix = (string)valSuffix ;
                else
                    _Suffix = "";

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Error " + ex.Message);
                System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - Error Throw Commented"  );
               // throw new ApplicationException("Error reading propertybag: " + ex.Message);
            }


        }

        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
            System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - SAVE inside");
            object val = (object)_NameSpace;
            object val1 = (object)_RootNode;
            object valprefix = (object) _Prefix;
            object valsuffix = (object)_Suffix;

            propertyBag.Write("RootNode", ref val1);
            propertyBag.Write("Namespace", ref val);
            propertyBag.Write("Prefix", ref valprefix);
            propertyBag.Write("Suffix", ref valsuffix);

            System.Diagnostics.EventLog.WriteEntry("Application", "Custom PipeLine - SAVE end");
        }

        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {
            string json;
            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Entered Execute()");
            System.Diagnostics.EventLog.WriteEntry("Application","JsonToXmlConverter Pipeline – RootNode:" + RootNode);
            var originalStream = pInMsg.BodyPart.GetOriginalDataStream();
            using (TextReader reader = new StreamReader(originalStream))
            {
                json = reader.ReadToEnd();

                json = _Prefix + json + _Suffix;
               
            }
           System.Diagnostics.EventLog.WriteEntry("Application","JsonToXmlConverter Pipeline – Read JSON Data: " +  json);
            System.Diagnostics.EventLog.WriteEntry("Application","JsonToXmlConverter Pipeline – Deserializing JSON to Xml…");
            try
            {
                // Append deserialized Xml data to master root node.
               // XmlDocument xmlDoc = null;
                //if (!string.IsNullOrEmpty(_Prefix) && !string.IsNullOrEmpty(_Suffix))
                //{
                //      xmlDoc = JsonConvert.DeserializeXmlNode(json);
                //      System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Xml: " + xmlDoc.InnerXml);
                //}
                //else
                //{
                //    xmlDoc = !string.IsNullOrWhiteSpace(RootNode) ? JsonConvert.DeserializeXmlNode(json, RootNode) : JsonConvert.DeserializeXmlNode(json);
                //}

                XmlDocument xmlDoc = !string.IsNullOrWhiteSpace(RootNode) ? JsonConvert.DeserializeXmlNode(json, RootNode) : JsonConvert.DeserializeXmlNode(json);
                
                System.Diagnostics.EventLog.WriteEntry("Application","JsonToXmlConverter Pipeline – Xml: "+ xmlDoc.InnerXml);
                var output = Encoding.ASCII.GetBytes(xmlDoc.InnerXml  );
                var memoryStream = new MemoryStream();
                memoryStream.Write(output, 0, output.Length);
                memoryStream.Position = 0;
                pInMsg.BodyPart.Data = memoryStream;

                //This is to assign Namespace to the XML
                IBaseMessagePart bodyPart = pInMsg.BodyPart;

                if (bodyPart != null)
                {

                    System.Diagnostics.EventLog.WriteEntry("Application", "Before Name Space – Xml: " + xmlDoc.InnerXml);
                    Stream originalStream1 = bodyPart.GetOriginalDataStream();
                    if (originalStream1 != null)
                    {
                        using (XmlReader reader = XmlReader.Create(originalStream1))
                        {
                            XmlWriterSettings ws = new XmlWriterSettings();
                            ws.Indent = true;
                            ws.ConformanceLevel = ConformanceLevel.Auto;

                            MemoryStream outputStream = new MemoryStream();

                            using (XmlWriter writer = XmlWriter.Create(outputStream, ws))
                            {
                                reader.Read();
                                if (reader.NodeType == XmlNodeType.XmlDeclaration)
                                {
                                    writer.WriteStartDocument();
                                    reader.Read();
                                }

                                // Root Node
                                if (reader.NodeType == XmlNodeType.Element)
                                    writer.WriteStartElement(reader.Name, _NameSpace);

                                reader.Read();
                                while (reader.NodeType == XmlNodeType.Element)
                                {
                                    writer.WriteNode(reader, true);
                                }
                            }

                            System.Diagnostics.EventLog.WriteEntry("Application", "Name Space – Xml: After Namespace "  );
                            outputStream.Position = 0;
                            bodyPart.Data = outputStream;
                        }
                    }
                }

                //This is to assign Namespace to the XML




            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application","JsonToXmlConverter Pipeline – Exception:" + ex.Message);
            }




            pInMsg.BodyPart.Data.Position = 0;




            return pInMsg;

        }
    }//JsonToXMLConverter Class End
}

﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
//using System.Xml.Schema;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using System.IO.Compression;
using System.Text.RegularExpressions;

namespace Inchcape.YourISS.Integration.Generic.Common
{
    public class Utilities
    {

        #region UpdatePerformingAgentId
        /******************************************************************************************************************************
     * Function Name    : UpdatePerformingAgentId()
     * Parameters       : AppointmentNumber
     * Description      : This method will update the PerformingAgentId in th Appointment.Appointments table if the Agent acceptance is not completed.
     * Return           : void
     * Author           : Sivakumar Karuppiah
     * Date Created     : 25-Nov-2016
     * Comments         :This will call from Portcall BTS application during the Portcall update message processing. This will not called during portcall create and cancel
     *                      Any exception during the method execution will not be raised 
     * ******************************************************************************************************************************
     */
        public static void UpdatePerformingAgentId(string AppointmentNumber, int   PerformingAgentId)
        {
            try
            {
                if (AppointmentNumber != null && AppointmentNumber != "")
                {
                    using (SqlConnection sqlConnection = new SqlConnection())
                    {
                        string connectionString = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                        sqlConnection.ConnectionString = connectionString;
                        sqlConnection.Open();

                        using (SqlCommand cmd = new SqlCommand())
                        {
                            string strSQL = "update Appointment.Appointments set PerformingAgentId= " + PerformingAgentId + "  where number ='" + AppointmentNumber + "' and IsPerformingAgentAccepted is null";
                            cmd.Connection = sqlConnection;
                            cmd.CommandText = strSQL;
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in UpdatePerformingAgentId -->{0}", exp.Message);
            }
        }

        #endregion

        #region InsertPortCallCreateLaytimeToIntegrationDB
        /******************************************************************************************************************************
     * Function Name    : PortCallLaytimeToIntegration()
     * Parameters       : AccountId , AccountCode, AccountCode, DemurageRate, DespatchRate, LoadingTerms, LoadingType, DischargeTerms, DischargeType
     * Description      : This method will insert the laytime record into integration table.
     * Author           : Saravanan K
     * Date Created     : 18-Nov-2016
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static void PortCallLaytimeToIntegration(string AccountId, string AccountCode, string AppointmentNumber, decimal DemurageRate, decimal DespatchRate, decimal LoadingTerms, string LoadingType, decimal DischargeTerms, string DischargeType)
        {
            try
            {
                if (DemurageRate != 0 || DespatchRate != 0 || LoadingTerms != 0 || DischargeTerms != 0)
                {
                    using (SqlConnection sqlConnection = new SqlConnection())
                    {
                        string connectionString = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                        sqlConnection.ConnectionString = connectionString;
                        sqlConnection.Open();

                        using (SqlCommand sqlCommand = new SqlCommand("Integration.spu_insert_portcall_laytime", sqlConnection))
                        {
                        
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.CommandTimeout = 600;

                            sqlCommand.Parameters.Add("@AccountId", SqlDbType.UniqueIdentifier).Value = new Guid(AccountId);
                            sqlCommand.Parameters.Add("@AccountCode", SqlDbType.VarChar, 100).Value = AccountCode;
                            sqlCommand.Parameters.Add("@AppointmentNumber", SqlDbType.VarChar, 100).Value = AppointmentNumber;

                            sqlCommand.Parameters.Add("@DemurageRate", SqlDbType.Decimal).Value = DemurageRate;
                            SqlParameter paramDem = sqlCommand.Parameters["@DemurageRate"];
                            paramDem.Precision = 10;
                            paramDem.Scale = 2;

                            sqlCommand.Parameters.Add("@DespatchRate", SqlDbType.Decimal).Value = DespatchRate;
                            SqlParameter paramDis = sqlCommand.Parameters["@DespatchRate"];
                            paramDis.Precision = 10;
                            paramDis.Scale = 2;

                            sqlCommand.Parameters.Add("@LoadingTerms", SqlDbType.Decimal).Value = LoadingTerms;
                            SqlParameter paramLT = sqlCommand.Parameters["@LoadingTerms"];
                            paramLT.Precision = 10;
                            paramLT.Scale = 2;

                            sqlCommand.Parameters.Add("@LoadingType", SqlDbType.VarChar, 10).Value = LoadingType;

                            sqlCommand.Parameters.Add("@DischargeTerms", SqlDbType.Decimal).Value = DischargeTerms;
                            SqlParameter paramDT = sqlCommand.Parameters["@DischargeTerms"];
                            paramDT.Precision = 10;
                            paramDT.Scale = 2;

                            sqlCommand.Parameters.Add("@DischargeType", SqlDbType.VarChar, 10).Value = DischargeType;

                            sqlCommand.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in InsertPortCallCreateLaytimeToIntegrationDB -->{0}", exp.Message);
            }
        }


        #endregion InsertPortCallCreateLaytimeToIntegrationDB

        #region GetDocumentId
        /******************************************************************************************************************************
     * Function Name    : GetDocumentId()
     * Parameters       : MessageId
     * Return Value     : Document Ids
     * Description      : This method will return the document Ids from Message table based on the MessageId.
     * Author           : Saravanan K
     * Date Created     : 17-Oct-2016
     * Modified By      : 
     * Date Modified    : 
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static string GetDocumentId(string MessageId)
        {
            string strDocumentIds = string.Empty;
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    string conStr = GetBizConnectionString();

                    con.ConnectionString = conStr.Replace("Provider=SQLOLEDB", "");

                    System.Diagnostics.EventLog.WriteEntry("Application", con.ConnectionString);
                    con.Open();
                    System.Diagnostics.EventLog.WriteEntry("Application", "Open Complete");
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string strSQL = "Select DocumentIDs FROM Messages(NOLOCK) WHERE Id = " + MessageId;
                        cmd.Connection = con;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            strDocumentIds = reader.GetString(0);
                        }
                     }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetDocumentId -->{0}", exp.Message);
            }
            return strDocumentIds;
        }


        #endregion GetDocumentId

        #region UpdateDocumentId
        /******************************************************************************************************************************
     * Function Name    : UpdateDocumentId()
     * Parameters       : DocumentIds 
     * Return Value     : 
     * Description      : This method will update the IsAleardySent flag in Common.IntegrationDocuments table.
     * Author           : Saravanan K
     * Date Created     : 17-Oct-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static void UpdateDocumentId(string MessageId)
        {
            string DocumentIds = string.Empty;
            try
            {
                DocumentIds = GetDocumentId(MessageId);
                if (!string.IsNullOrEmpty(DocumentIds))
                {
                    string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                    using (SqlConnection objCon = new SqlConnection(Connectionstring))
                    {
                        objCon.Open();
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            string strSQL = "Update Common.IntegrationDocuments SET IsAleardySent = 0, ModifiedDate = GETUTCDATE() WHERE Id in (" + DocumentIds + ")";
                            cmd.Connection = objCon;
                            cmd.CommandText = strSQL;
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in UpdateDocumentId -->{0}", exp.Message);
                throw exp;
            }
        }


        #endregion UpdateDocumentId

        #region CreateDelayEvents
        /******************************************************************************************************************************
     * Function Name    : CreateDelayEvents()
     * Parameters       : Source xml from youriss of Operation Update.
     * Return Value     : Source xml with duplication delay events
     * Description      : This method will create duplicate delay events (only for shifting, rotation) in the incoming xml based on the terminal and associated cargo.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 12-September-2016
     * Date Modified    :
     * Comments         : Used in Operation Udpate
     * ******************************************************************************************************************************
     */
        public static XmlDocument CreateDelayEvents(XmlDocument xmlMain)
        {
            try
            {
                XmlNamespaceManager nsMgrMain = new XmlNamespaceManager(xmlMain.NameTable);
                nsMgrMain.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS");
                string[] refCodeArray = new string[2];
                refCodeArray[0] = "TO";
                refCodeArray[1] = "SH";
                foreach (string refCode in refCodeArray)
                {
                    XmlNodeList operationEventList = xmlMain.SelectNodes("//ns0:YourIss2Appointment/OperationEvents[RefCode='" + refCode + "']", nsMgrMain);
                    if (operationEventList.Count > 0)
                    {
                        string OpsEventId = string.Empty;
                        foreach (XmlNode operationEvent in operationEventList)
                        {
                            OpsEventId += operationEvent["Event"].SelectSingleNode("Id").InnerText;
                            OpsEventId += ",";
                        }
                        if (OpsEventId.EndsWith(","))
                            OpsEventId = OpsEventId.Substring(0, OpsEventId.Length - 1);
                        DataSet EventDs = new DataSet();
                        XmlNode PortCallIdNode = xmlMain.SelectSingleNode("//ns0:YourIss2Appointment/Id", nsMgrMain);
                        string PortCallId = PortCallIdNode.InnerText;
                        string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                        using (SqlConnection objCon = new SqlConnection(connectionstring))
                        {
                            objCon.Open();
                            using (SqlCommand objCmd = new SqlCommand())
                            {
                                if (refCode == "TO")
                                    objCmd.CommandText = "SELECT rot.POIId, OpEvt.HubPrincipalEventMapId AS 'EventId', OpEvt.EventDate AS 'StartDate'  FROM Operation.rotations rot JOIN Operation.RotationOperationEvents rotOpEvt ON rot.Id = rotOpEvt.RotationId JOIN Operation.OperationEvents OpEvt ON rotOpEvt.Id = OpEvt.Id WHERE OpEvt.PortCallId = '" + PortCallId + "' and OpEvt.HubPrincipalEventMapId in (" + OpsEventId + ")";
                                else
                                    objCmd.CommandText = "SELECT rot.POIId, OpEvt.HubPrincipalEventMapId AS 'EventId', OpEvt.EventDate AS 'StartDate' FROM Operation.rotations rot JOIN Operation.ShiftingOperationEvents shfOpEvt ON rot.Id = shfOpEvt.RotationId JOIN Operation.OperationEvents OpEvt ON shfOpEvt.Id = OpEvt.Id WHERE OpEvt.PortCallId = '" + PortCallId + "' and OpEvt.HubPrincipalEventMapId in (" + OpsEventId + ")";
                                objCmd.Connection = objCon;
                                SqlDataAdapter Eventda = new SqlDataAdapter();
                                Eventda.SelectCommand = objCmd;
                                Eventda.Fill(EventDs);
                            }
                        }
                        XmlNodeList cargoList = xmlMain.SelectNodes("//ns0:YourIss2Appointment/Cargoes", nsMgrMain);
                        DataTable cargoDt = new DataTable();
                        cargoDt.Clear();
                        cargoDt.Columns.Add("CargoPOIId");
                        cargoDt.Columns.Add("CargoRefCode");
                        foreach (XmlNode cargo in cargoList)
                        {
                            DataRow cargoDr = cargoDt.NewRow();
                            cargoDr["CargoPOIId"] = cargo["Rotation"].SelectSingleNode("Poi/Id").InnerText;
                            cargoDr["CargoRefCode"] = cargo["RefCode"].InnerText;
                            cargoDt.Rows.Add(cargoDr);
                        }
                        foreach (DataRow dr in EventDs.Tables[0].Rows)
                        {
                            int loopInt = 1;
                            string EventId = dr["EventId"].ToString();
                            string POIId = dr["POIId"].ToString();
                            string startDate = Convert.ToDateTime(dr["StartDate"].ToString()).ToString("yyyy-MM-ddTHH:mm:ssZ");
                            foreach (DataRow cargoDr in cargoDt.Rows)
                            {
                                if (POIId == cargoDr["CargoPOIId"].ToString())
                                {

                                    if (loopInt == 1)
                                    {
                                        XmlNode RefNode = xmlMain.SelectSingleNode("//ns0:YourIss2Appointment/OperationEvents[StartDate='" + startDate + "']/Event[Id='" + EventId + "']", nsMgrMain);
                                        RefNode.ParentNode["RefCode"].InnerText = cargoDr["CargoRefCode"].ToString();
                                    }
                                    if (loopInt > 1)
                                    {
                                        XmlNode EventNode = xmlMain.SelectSingleNode("//ns0:YourIss2Appointment/OperationEvents[StartDate='" + startDate + "']/Event[Id='" + EventId + "']", nsMgrMain);
                                        XmlNode OperationEventNode = EventNode.ParentNode.CloneNode(true);
                                        OperationEventNode["RefCode"].InnerText = cargoDr["CargoRefCode"].ToString();
                                        EventNode.ParentNode.ParentNode.InsertAfter(OperationEventNode, EventNode.ParentNode);
                                    }
                                    loopInt++;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in CreateDelayEvents -->{0}", ex.Message);
                //return xmlDoc;
                throw ex;
            }
            return xmlMain;
        }
        #endregion 

        #region RemoveMergeDuplicateService
        /******************************************************************************************************************************
     * Function Name    : RemoveMergeDuplicateService()
     * Parameters       : Generic xml of PDA/CE
     * Return Value     : Generic xml with removal of duplicate services and merging of Amount and YourISSAmount values.
     * Description      : This method will remove the duplicate service in incoming xml while merging the Amount and YourISSAmount values to a single service. Used by only Proforma/CE.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 1-September-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument RemoveMergeDuplicateService(XmlDocument xmlMain)
        {
            try
            {
                XmlNamespaceManager nsMgrMain = new XmlNamespaceManager(xmlMain.NameTable);
                nsMgrMain.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");
                XmlNodeList xmlNodeList = xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine", nsMgrMain);

                foreach (XmlNode xmlNode in xmlNodeList)
                {
                    int tempAmount = 0;
                    int tempYourIssAmount = 0;
                    string serviceLineCode = xmlNode["ns0:ServiceLineCode"].InnerText;
                    int tempCount = xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine[ns0:ServiceLineCode='" + serviceLineCode + "']", nsMgrMain).Count;

                    if (tempCount > 1)
                    {
                        XmlNodeList xmlNodeListCompare = xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine", nsMgrMain);
                        foreach (XmlNode xmlNodeCompare in xmlNodeListCompare)
                        {
                            string strCompare = xmlNodeCompare["ns0:ServiceLineCode"].InnerText;
                            if (serviceLineCode == strCompare)
                            {
                                tempAmount = tempAmount + Convert.ToInt32(xmlNodeCompare["ns0:Amount"].SelectSingleNode("ns0:Amount", nsMgrMain).InnerText);
                                tempYourIssAmount = tempYourIssAmount + Convert.ToInt32(xmlNodeCompare["ns0:YourIssAmount"].SelectSingleNode("ns0:Amount", nsMgrMain).InnerText);

                            }
                        }
                        xmlNode["ns0:Amount"].SelectSingleNode("ns0:Amount", nsMgrMain).InnerText = Convert.ToString(tempAmount);
                        xmlNode["ns0:YourIssAmount"].SelectSingleNode("ns0:Amount", nsMgrMain).InnerText = Convert.ToString(tempYourIssAmount);
                        for (int i = 1; i <= tempCount; i++)
                        {
                            if (i > 1)
                            {
                                XmlNode removeNode = xmlMain.SelectSingleNode("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine[ns0:ServiceLineCode='" + serviceLineCode + "'][2]", nsMgrMain);
                                removeNode.ParentNode.RemoveChild(removeNode);
                            }
                            //XmlNodeList mainNodeList = xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine", nsMgrMain);
                            //foreach (XmlNode mainNode in mainNodeList)
                            //{
                            //    if (mainNode.ChildNodes.Count == 0)
                            //    {
                            //        mainNode.ParentNode.RemoveChild(mainNode);
                            //    }
                            //}
                        }
                    }
                }
                //Below line of code to change the value of DaLineCount
                xmlMain.SelectSingleNode("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:DaLineCount", nsMgrMain).InnerText = Convert.ToString(xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine", nsMgrMain).Count);
            }
            catch (Exception ex)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in RemoveMergeDuplicateService -->{0}", ex.Message);
                //return xmlDoc;
                throw ex;

            }
            return xmlMain;
        }
        #endregion 

        #region XmlMergeProforma
        /******************************************************************************************************************************
     * Function Name    : XmlMergeProforma()
     * Parameters       : Generic xml of PDA/CE, Document xml of PDA/CE, Appointment number
     * Return Value     : Generic xml merged with document xml.
     * Description      : Method used in PDA/CE, to merge the document xml with generic xml.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 6-August-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument XmlMergeProforma(XmlDocument xmlMain, XmlDocument xmlDoc, string AppointmentNumber)
        {
            try
            {
                xmlMain = RemoveMergeDuplicateService(xmlMain);
                XmlNamespaceManager nsMgrDoc = new XmlNamespaceManager(xmlDoc.NameTable);
                nsMgrDoc.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.PDA.CE.Schema.Documents");
                XmlNodeList nodeList = xmlDoc.SelectNodes("//ns0:Documents/Document", nsMgrDoc);
                if (nodeList.Count > 0)
                {
                    int hubPrincipalId = 0;
                    string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                    using (SqlConnection objCon = new SqlConnection(connectionstring))
                    {
                        objCon.Open();
                        using (SqlCommand objCmd = new SqlCommand())
                        {
                            string strSQL = "select id from Master.HubPrincipals where HubPrincipalKey in (select HubPrincipalKey from Appointment.HubPrincipalPortCallAppointmentMap where AppointmentId in (select id from Appointment.Appointments where number = '" + AppointmentNumber + "'))";
                            objCmd.Connection = objCon;
                            objCmd.CommandText = strSQL;
                            hubPrincipalId = Convert.ToInt32(objCmd.ExecuteScalar());
                        }

                        foreach (XmlNode node in nodeList)
                        {
                            string serviceId = node["ServiceId"].InnerText;
                            string serviceCode = string.Empty;
                            using (SqlCommand objCmd = new SqlCommand())
                            {
                                string strSQL = "SELECT code FROM Master.HubPrincipalServiceMap WHERE ISSServiceId = " + serviceId + " AND HubPrincipalId =" + hubPrincipalId + "";
                                objCmd.Connection = objCon;
                                objCmd.CommandText = strSQL;
                                serviceCode = Convert.ToString(objCmd.ExecuteScalar());
                            }
                            XmlNamespaceManager nsMgrMain = new XmlNamespaceManager(xmlMain.NameTable);
                            nsMgrMain.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");
                            XmlNodeList mainNodeList = xmlMain.SelectNodes("//ns0:YourIssNotification/ns0:DisbursementAccount/ns0:Lines/ns0:DaLine", nsMgrMain);
                            foreach (XmlNode mainNode in mainNodeList)
                            {
                                string mainServiceCode = mainNode["ns0:ServiceLineCode"].InnerText;
                                if (serviceCode == mainServiceCode)
                                {
                                    if (mainNode["ns0:DocumentCount"] == null)
                                    {
                                        XmlElement elementDocumentCount = xmlMain.CreateElement("ns0", "DocumentCount", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");
                                        mainNode.AppendChild(elementDocumentCount);
                                    }

                                    if (mainNode["ns0:Documents"] != null)
                                    {
                                        XmlNode valueNode = mainNode["ns0:Documents"];
                                        XmlElement elementDocument = xmlMain.CreateElement("ns0", "Document", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");
                                        elementDocument.InnerText = node["Url"].InnerText;
                                        valueNode.AppendChild(elementDocument);
                                        mainNode["ns0:DocumentCount"].InnerText = valueNode.SelectNodes("ns0:Document", nsMgrMain).Count.ToString();
                                    }
                                    else
                                    {
                                        XmlElement elementDocumentParent = xmlMain.CreateElement("ns0", "Documents", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");                                        
                                        mainNode.AppendChild(elementDocumentParent);
                                        XmlNode valueNode = mainNode["ns0:Documents"];
                                        XmlElement elementDocument = xmlMain.CreateElement("ns0", "Document", "http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA");
                                        elementDocument.InnerText = node["Url"].InnerText;
                                        valueNode.AppendChild(elementDocument);
                                        mainNode["ns0:DocumentCount"].InnerText = valueNode.SelectNodes("ns0:Document", nsMgrMain).Count.ToString();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in XmlMergeProforma -->{0}", ex.Message);
                return xmlDoc;
                //throw ex;

            }
            return xmlMain;
        }
        #endregion 

        #region GetHubPrincipalName
        /******************************************************************************************************************************
     * Function Name    : GetHubPrincipalName()
     * Parameters       : HubPrincipalKey
     * Return Value     : boolean true or false
     * Description      : This method will search customer configuration table with the HubPrincipalKey and gets HubPrincipal's name.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 27-July-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */


        public static string GetHubPrincipalName(string HubPrincipalKey)
        {
            try
            {
                string hubPrincipalName = string.Empty;
                string bizConnectionstring = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objBizCon = new SqlConnection(bizConnectionstring))
                {
                    objBizCon.Open();
                    using (SqlCommand bizCmd = new SqlCommand())
                    {
                        string strSQLBiz = string.Empty;
                        strSQLBiz = "SELECT Name FROM CustomerConfiguration WHERE HubPrincipalID = '" + HubPrincipalKey + "'";
                        bizCmd.Connection = objBizCon;
                        bizCmd.CommandText = strSQLBiz;
                        hubPrincipalName = Convert.ToString(bizCmd.ExecuteScalar());
                    }
                    objBizCon.Close();
                }
                return hubPrincipalName;
            }
            catch (Exception ex)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetHubPrincipalName -->{0}", ex.Message);
                throw ex;
            }
        }


        #endregion 

        #region OperationUpdateMandatoryValidation
        /******************************************************************************************************************************
        * Function Name    : OperationUpdateMandatoryValidation()
        * Parameters       : XmlDocument xmldoc
        * Return Value     : Return XmlDocument
        * Description      : Check the validation field of the incoming xml and will send back the xml with the mapping error message.
        * Author           : Keerthi Reddy Subbiah
        * Date Created     : 25-07-2016
        * Date Modified    : 
        * Comments         :
        * ******************************************************************************************************************************
        */
        public static XmlDocument OperationUpdateMandatoryValidation(XmlDocument xmlIncoming)
        {
            StringBuilder validationErrorMessage = new StringBuilder();
            string portCode = string.Empty;
            string hubprincipal = string.Empty;
            XmlDocument xmlDoc = new XmlDocument();
            XmlElement xmlRootElement = (XmlElement)xmlDoc.AppendChild(xmlDoc.CreateElement("ValidationRoot"));

            //XmlNamespaceManager nsMgr1 = new XmlNamespaceManager(xmlDoc.NameTable);
            //nsMgr1.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.OperationUpdate.TerminalBerthValidationReturn");


            try
            {
                XmlNamespaceManager nsMgr = new XmlNamespaceManager(xmlIncoming.NameTable);
                nsMgr.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.OperationUpdate.TerminalBerthValidation");

                XmlNodeList xmlNodeList = xmlIncoming.SelectNodes("//ns0:TerminalCargoValidation/Cargoes", nsMgr);
                portCode = xmlIncoming.SelectSingleNode("//ns0:TerminalCargoValidation/PortCode", nsMgr).InnerText;
                hubprincipal = xmlIncoming.SelectSingleNode("//ns0:TerminalCargoValidation/HubPrincipal", nsMgr).InnerText;

                foreach (XmlNode node in xmlNodeList)
                {
                    XmlNode xmlNodePOI = node["Rotation"].SelectSingleNode("Poi");
                    XmlNode xmlNodeBerth = node["Rotation"].SelectSingleNode("Berth");

                    if (xmlNodePOI.SelectSingleNode("Id") != null)
                    {
                        string validationResult = string.Empty;
                        validationResult = xmlNodePOI.SelectSingleNode("ValidationResult").InnerText;
                        if (validationResult != "Success")
                        {
                            string terminalNameCode = string.Empty;
                            terminalNameCode = " Terminal Name: " + xmlNodePOI.SelectSingleNode("Name").InnerText + " / Code: " + xmlNodePOI.SelectSingleNode("Code").InnerText;
                            validationErrorMessage.Append(terminalNameCode + " is not mapped for port " + portCode + " for the HubPrincipal " + hubprincipal+" \n");
                        }
                    }
                    if (xmlNodeBerth.SelectSingleNode("Id") != null)
                    {
                        string validationResult = string.Empty;
                        validationResult = xmlNodeBerth.SelectSingleNode("ValidationResult").InnerText;
                        if (validationResult != "Success")
                        {
                            string berthNameCode = string.Empty;
                            berthNameCode = " Berth Name: " + xmlNodeBerth.SelectSingleNode("Name").InnerText + " / Code: " + xmlNodeBerth.SelectSingleNode("Code").InnerText;
                            validationErrorMessage.Append(berthNameCode + " is not mapped for port " + portCode + " for the HubPrincipal " + hubprincipal+" \n");
                        }
                    }
                }

                if (string.IsNullOrEmpty(validationErrorMessage.ToString()))
                {
                    xmlRootElement.AppendChild(xmlDoc.CreateElement("IsValid")).InnerText = "False";
                }
                else
                {
                    xmlRootElement.AppendChild(xmlDoc.CreateElement("IsValid")).InnerText = "True";
                }


                if (validationErrorMessage.Length > 1)
                {
                    validationErrorMessage.Insert(0, " Operation Update is processed successfully, but has some validation error. Please take appropriate action. \nError Message:\n");
                }

               xmlRootElement.AppendChild(xmlDoc.CreateElement("ValidationMessage")).InnerText = validationErrorMessage.ToString();
               xmlDoc.DocumentElement.SetAttribute("xmlns:ns0", "http://Inchcape.YourISS.Integration.Generic.OperationUpdate.TerminalBerthValidationReturn");
                return xmlDoc;

                //return new xmls MandatoryValidation() { IsValid = true, Message = ErrorMessage.ToString() };
            }
            catch (Exception ex)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in SyncAppointmentCheckMandatory Exception Message-->{0}", ex.Message));
                xmlRootElement.AppendChild(xmlDoc.CreateElement("IsValid")).InnerText = "False";
                xmlRootElement.AppendChild(xmlDoc.CreateElement("ValidationMessage")).InnerText = ex.ToString();


                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in OperationUpdateMandatoryValidation -->{0}", ex.Message);
                return xmlDoc;
                //throw ex;

            }
        }
        #endregion

        #region UpdateDelayRefCode
        /******************************************************************************************************************************
     * Function Name    : UpdateDelayRefCode
     * Parameters       : portcallid and xml document
     * Return Value     : xmldocument with IsSOF tag
     * Description      : This method will get cargo details of delay events for the specific portcall and update that in the returning xml.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 14-July-2016
     * Date Modified    :
     * Comments         : was used in Operation update orchestration. METHOD NOT IN USE.
     * ******************************************************************************************************************************
     */

        public static XmlDocument UpdateDelayRefCode(string PortCallId, XmlDocument xmlIncoming)
        {
            try
            {
                string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                XmlNamespaceManager nsMgr = new XmlNamespaceManager(xmlIncoming.NameTable);
                nsMgr.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS");
                using (SqlConnection objCon = new SqlConnection(connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCmd = new SqlCommand())
                    {
                        //objCmd.CommandText = "SELECT portcallid AS portcallid, HubPrincipalEventMapId AS eventid, EventDate AS startdate,ShowOnSOF AS ShowOnSOF FROM operation.OperationEvents WHERE PortCallId = @PortCallId AND IsActive = 1";
                        //objCmd.CommandText = "SELECT  'ROTATIONDELAY' AS OperationType, OE.HubPrincipalEventMapId , OE.EventDate , OE.Id , ROE.RotationId , C.RefCode   FROM [Operation].[OperationEvents]  AS OE JOIN [Operation].[RotationOperationEvents] AS ROE ON ROE.Id = OE.Id JOIN  Operation.Cargoes AS C ON C.RotationId = ROE.RotationId WHERE OE.PortCallId  = @PortCallId AND OE.DelayEventTypeId IS NOT NULL AND OE.IsActive = 1" +
                        //    " UNION ALL " +
                        //    " SELECT  'SHIFTINGDELAY' AS OperationType, OE.HubPrincipalEventMapId , OE.EventDate , OE.Id , SOE.RotationId , C.RefCode   FROM [Operation].[OperationEvents]  AS OE join [Operation].[ShiftingOperationEvents]  AS SOE ON SOE.Id = OE.Id JOIN  Operation.Cargoes AS C ON C.RotationId = SOE.RotationId WHERE OE.PortCallId = @PortCallId AND OE.DelayEventTypeId IS NOT NULL AND OE.IsActive = 1";

                        objCmd.CommandText = "SELECT  'ROTATIONDELAY' AS OperationType,  e.Id as  HubPrincipalEventMapId , OE.EventDate , OE.Id , ROE.RotationId , C.RefCode   FROM [Operation].[OperationEvents]  AS OE JOIN [Operation].[RotationOperationEvents] AS ROE ON ROE.Id = OE.Id JOin master.hubprincipaleventmap as hpem on hpem.id = OE.HubPrincipalEventMapId JOIN master.events as e on e.id = hpem.eventid JOIN  Operation.Cargoes AS C ON C.RotationId = ROE.RotationId WHERE OE.PortCallId  = @PortCallId AND OE.DelayEventTypeId IS NOT NULL AND OE.IsActive = 1 " +
                            " UNION ALL " +
                            " SELECT  'SHIFTINGDELAY' AS OperationType, e.Id as HubPrincipalEventMapId , OE.EventDate , OE.Id , SOE.RotationId , C.RefCode   FROM [Operation].[OperationEvents]  AS OE join [Operation].[ShiftingOperationEvents]  AS SOE ON SOE.Id = OE.Id JOin master.hubprincipaleventmap as hpem on hpem.id = OE.HubPrincipalEventMapId JOIN master.events as e on e.id = hpem.eventid JOIN  Operation.Cargoes AS C ON C.RotationId = SOE.RotationId WHERE OE.PortCallId  = @PortCallId AND OE.DelayEventTypeId IS NOT NULL AND OE.IsActive = 1 ";


                        objCmd.Parameters.AddWithValue("@PortCallId", PortCallId);
                        objCmd.Connection = objCon;
                        SqlDataAdapter sqlAdap = new SqlDataAdapter();
                        DataTable dsEvent = new DataTable();
                        sqlAdap.SelectCommand = objCmd;
                        sqlAdap.Fill(dsEvent);
                        int tabCount = Convert.ToInt32(dsEvent.Rows.Count);
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {

                                XmlNodeList xmlnodelst = xmlIncoming.SelectNodes("//ns0:YourIss2Appointment/OperationEvents", nsMgr);
                                foreach (XmlNode xmlnode in xmlnodelst)
                                {
                                    if ((xmlnode["Name"].InnerText == "Delay") && ((xmlnode["RefCode"].InnerText != "AR") && (xmlnode["RefCode"].InnerText != "DP")))
                                    {
                                        DateTime DBDate = new DateTime();
                                        DateTime xmlDate = new DateTime();
                                        string strEventId = string.Empty;

                                        if (((xmlnode["StartDate"].InnerText).Trim() != "") && ((xmlnode["StartDate"].InnerText).Trim() != null) && ((xmlnode["StartDate"].InnerText).Trim() != string.Empty) && ((Convert.ToString((dsEvent.Rows[i]["EventDate"].ToString()))) != "") && ((Convert.ToString((dsEvent.Rows[i]["EventDate"].ToString()))) != null) && ((Convert.ToString((dsEvent.Rows[i]["EventDate"].ToString()))) != string.Empty))
                                        {
                                            int indexInt = (xmlnode["StartDate"].InnerText).IndexOf("Z");
                                            if (indexInt > 0)
                                                xmlDate = Convert.ToDateTime(xmlnode["StartDate"].InnerText).ToUniversalTime();
                                            else
                                                xmlDate = Convert.ToDateTime(xmlnode["StartDate"].InnerText);
                                            DBDate = Convert.ToDateTime((dsEvent.Rows[i]["EventDate"].ToString()));
                                            strEventId = xmlnode["Event"].SelectSingleNode("Id").InnerText;
                                            if (((dsEvent.Rows[i]["HubPrincipalEventMapId"].ToString()) == strEventId) && (DBDate == xmlDate))
                                            {
                                              //  xmlnode["RefCode"].InnerText = dsEvent.Rows[i]["RefCode"].ToString();
                                            }
                                        }
                                        else
                                        {
                                            strEventId = xmlnode["Event"].SelectSingleNode("Id").InnerText;
                                            if ((dsEvent.Rows[i]["HubPrincipalEventMapId"].ToString()) == strEventId)
                                            {
                                              //  xmlnode["RefCode"].InnerText = dsEvent.Rows[i]["RefCode"].ToString();
                                            }                                            
                                        }





                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in UpdateDelayRefCode -->{0}", exp.Message);
                throw exp;
            }
            return xmlIncoming;
        }


        #endregion UpdateDelayRefCode

        #region CheckIsSOF
        /******************************************************************************************************************************
     * Function Name    : CheckIsSOF
     * Parameters       : portcallid and xml document
     * Return Value     : xmldocument with IsSOF tag
     * Description      : This method will get the SOF and Events data for the specific portcall and update that in the returning xml.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 13-July-2016
     * Date Modified    :
     * Comments         : used in Operation update orchestration.
     * ******************************************************************************************************************************
     */

        public static XmlDocument CheckIsSOF(string PortCallId, XmlDocument xmlIncoming)
        {
            try
            {
                string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                XmlNamespaceManager nsMgr = new XmlNamespaceManager(xmlIncoming.NameTable);
                nsMgr.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schemas.YourISSNew");
                using (SqlConnection objCon = new SqlConnection(connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCmd = new SqlCommand())
                    {
                       // objCmd.CommandText = "SELECT portcallid AS portcallid, HubPrincipalEventMapId AS eventid, EventDate AS startdate,ShowOnSOF AS ShowOnSOF FROM operation.OperationEvents WHERE PortCallId = @PortCallId AND IsActive = 1";
                        objCmd.CommandText = "SELECT OE.portcallid AS portcallid, e.Id AS eventid, OE.EventDate AS startdate,OE.ShowOnSOF AS ShowOnSOF FROM operation.OperationEvents OE Join master.hubprincipaleventmap as hpem on hpem.id = OE.HubPrincipalEventMapId JOIN master.events as e on e.id = hpem.eventid WHERE OE.PortCallId = @PortCallId AND OE.IsActive = 1";
                        objCmd.Parameters.AddWithValue("@PortCallId", PortCallId);
                        objCmd.Connection = objCon;
                        SqlDataAdapter sqlAdap = new SqlDataAdapter();
                        DataTable dsEvent = new DataTable();
                        sqlAdap.SelectCommand = objCmd;
                        sqlAdap.Fill(dsEvent);
                        int tabCount = Convert.ToInt32(dsEvent.Rows.Count);
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                XmlNodeList xmlnodelst = xmlIncoming.SelectNodes("//ns0:YourIss2Appointment/OperationEvents", nsMgr);
                                foreach (XmlNode xmlnode in xmlnodelst)
                                {
                                    DateTime DBDate = new DateTime();
                                    DateTime xmlDate = new DateTime();
                                    string strEventId = string.Empty;



                                    if (((xmlnode["StartDate"].InnerText).Trim() != "") && ((xmlnode["StartDate"].InnerText).Trim() != null) && ((xmlnode["StartDate"].InnerText).Trim() != string.Empty)  && ((Convert.ToString((dsEvent.Rows[i]["startdate"].ToString()))) != "") && ((Convert.ToString((dsEvent.Rows[i]["startdate"].ToString()))) != null) && ((Convert.ToString((dsEvent.Rows[i]["startdate"].ToString()))) != string.Empty))
                                    {

                                        int indexInt = (xmlnode["StartDate"].InnerText).IndexOf("Z");
                                        if (indexInt > 0)
                                            xmlDate = Convert.ToDateTime(xmlnode["StartDate"].InnerText).ToUniversalTime();
                                        else
                                            xmlDate = Convert.ToDateTime(xmlnode["StartDate"].InnerText);
                                        DBDate = Convert.ToDateTime((dsEvent.Rows[i]["startdate"].ToString()));
                                        strEventId = xmlnode["Event"].SelectSingleNode("Id").InnerText;
                                        if (((dsEvent.Rows[i]["eventid"].ToString()) == strEventId) && (DBDate == xmlDate))
                                        {
                                            xmlnode["Event"].SelectSingleNode("IsSOF").InnerText = dsEvent.Rows[i]["ShowOnSOF"].ToString();
                                        }
                                    }
                                    else
                                    {
                                        strEventId = xmlnode["Event"].SelectSingleNode("Id").InnerText;
                                        if ((dsEvent.Rows[i]["eventid"].ToString()) == strEventId)
                                        {
                                            xmlnode["Event"].SelectSingleNode("IsSOF").InnerText = dsEvent.Rows[i]["ShowOnSOF"].ToString();
                                        }
                                    }



                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in CheckIsSOF -->{0}", exp.Message);
                throw exp;
            }
            return xmlIncoming;
        }


        #endregion CheckIsSOF

        #region GetSofEventsForPortCallId
        /******************************************************************************************************************************
     * Function Name    : GetSofEventsForPortCallId()
     * Parameters       : portcallid
     * Return Value     : Xml Document with SOF and Events data.
     * Description      : This method will get the SOF and Events data for the specific portcall.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 12-July-2016
     * Date Modified    :
     * Comments         : used in Operation update orchestration.
     * ******************************************************************************************************************************
     */

        public static XmlDocument GetSofEventsForPortCallId(string PortCallNumber)
        {
            XmlDocument returnXml = new XmlDocument();
            try
            {
                string xmlString = string.Empty;
                string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCmd = new SqlCommand())
                    {                        
                        objCmd.CommandText = "SELECT portcallid AS portcallid, HubPrincipalEventMapId AS eventid, EventDate AS startdate,ShowOnSOF AS ShowOnSOF FROM operation.OperationEvents WHERE PortCallId in (SELECT ID FROM PortCall.PortCalls WHERE Number = @PortCallNumber)AND IsActive = 1";
                        objCmd.Parameters.AddWithValue("@PortCallNumber", PortCallNumber);
                        objCmd.Connection = objCon;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataTable ds = new DataTable();
                        da.SelectCommand = objCmd;
                        da.Fill(ds);
                        int tabCount = Convert.ToInt32(ds.Rows.Count);
                        xmlString = "<ns2:DBOperationEvents xmlns:ns2='http://Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema'>";
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                if (ds.Rows[i]["ShowOnSOF"].ToString() == "True")
                                    xmlString += "<DBEvents><PortcallId>" + ds.Rows[i]["portcallid"].ToString() + "</PortcallId><EventId>" + ds.Rows[i]["eventid"].ToString() + "</EventId><StartDate>" + String.Format("{0:s}", Convert.ToDateTime(ds.Rows[i]["startdate"])) + "</StartDate><ShowOnSOF>1</ShowOnSOF></DBEvents>";
                                if (ds.Rows[i]["ShowOnSOF"].ToString() == "False")
                                    xmlString += "<DBEvents><PortcallId>" + ds.Rows[i]["portcallid"].ToString() + "</PortcallId><EventId>" + ds.Rows[i]["eventid"].ToString() + "</EventId><StartDate>" + String.Format("{0:s}", Convert.ToDateTime(ds.Rows[i]["startdate"])) + "</StartDate><ShowOnSOF>0</ShowOnSOF></DBEvents>";
                            }
                        };
                        xmlString += "</ns2:DBOperationEvents>";
                    }
                }
                returnXml.Load(string.Format(xmlString));
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetSofEventsForPortCallId -->{0}", exp.Message);
                throw exp;
            }
            return returnXml;
        }


        #endregion GetSofEventsForPortCallId

        public static string SanitizeXmlString(string xml)
        {
            if (xml == null)
            {
                throw new ArgumentNullException("xml");
            }

            StringBuilder buffer = new StringBuilder(xml.Length);

            foreach (char c in xml)
            {
                if (IsLegalXmlChar(c))
                {
                    buffer.Append(c);
                }
            }

            return buffer.ToString();
        }

        /// <summary>   
        /// Whether a given character is allowed by XML 1.0.  
        /// Developed: Periasamy T
        /// </summary>   
        public static bool IsLegalXmlChar(int character)
        {
            return
            (
                 character == 0x9 /* == '\t' == 9   */          ||
                 character == 0xA /* == '\n' == 10  */          ||
                 character == 0xD /* == '\r' == 13  */          ||
                (character >= 0x20 && character <= 0xD7FF) ||
                (character >= 0xE000 && character <= 0xFFFD) ||
                (character >= 0x10000 && character <= 0x10FFFF)
            );
        }  

        #region GetAdditionalInformation
        /******************************************************************************************************************************
     * Function Name    : GetAdditionalInformation()
     * Parameters       : portcallid
     * Return Value     : Xml Document with additional information data.
     * Description      : This method will get the additional informations for the specific portcall.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 27-June-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static XmlDocument GetAdditionalInformation(int PortCallId)
        {
            XmlDocument xmldoc = new XmlDocument();
            try
            {
                string strXml = string.Empty;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCom = new SqlCommand())
                    {
                        objCom.CommandText = "SELECT HubPrincipalOperationInfoTypeName AS EventLabel, InfoDetails AS EventComments, InfoDate AS EventDateTime from Integration.AdditionalInformationV (NOLOCK) where portcallId = " + PortCallId + "";
                        objCom.Connection = objCon;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataSet ds = new DataSet();
                        da.SelectCommand = objCom;
                        da.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        { 
                        ds.DataSetName = "Events";
                        ds.Tables[0].TableName = "Event";
                        StringWriter sw = new StringWriter();
                        ds.WriteXml(sw, XmlWriteMode.IgnoreSchema);
                        string strData = sw.ToString();

                        strXml = SanitizeXmlString(strData);
                        xmldoc.LoadXml(strXml);
                        XmlNode Eventsnode;
                        Eventsnode = xmldoc.ChildNodes[0];
                        string ReplaceNode = string.Empty;
                        ReplaceNode = Eventsnode.OuterXml;
                        //ReplaceNode = ReplaceNode.Replace("<ns2:Events>", "<ns2:Events xmlns:ns2='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.AdditionalInformation'>");
                        //ReplaceNode = ReplaceNode.Replace("</ns2:Events>", "</ns2:Events>");
                        ReplaceNode = ReplaceNode.Replace("<Events>", "<ns2:Events xmlns:ns2='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.AdditionalInformation'>");
                        ReplaceNode = ReplaceNode.Replace("</Events>", "</ns2:Events>");
                        xmldoc.LoadXml(ReplaceNode);
                        }
                        else
                        {
                            strXml = "<ns2:Events xmlns:ns2='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.AdditionalInformation'></ns2:Events>";
                            xmldoc.LoadXml(strXml);
                        }
                    }
                    objCon.Close();
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetAdditionalInformation -->{0}", exp.Message);
                throw exp;
            }
            return xmldoc;
        }


        #endregion GetAdditionalInformation





        #region GetIntegrationEmailTemplate
        /******************************************************************************************************************************
     * Function Name    : GetIntegrationEmailTemplate()
     * Parameters       : ErrorType , XMLNamespace, AccountId
     * Return Value     : Xml Document with Email Template contents
     * Description      : This method will get the email template  configuration values for the given error type.
     * Author           : Sivakumar Karuppiah
     * Date Created     : 27-June-2016
     * Modified By      : Saravanan K
     * Date Modified    : 12-July-2016
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static XmlDocument GetIntegrationEmailTemplate( string ErrorType , string xmlnamespace , string AccountId)
        {
            XmlDocument doc = new XmlDocument();
            string strXml = "<ns0:IntegrationEmail  xmlns:ns0='" + xmlnamespace + "'></ns0:IntegrationEmail>";
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    string conStr = GetBizConnectionString(); //   GetNYourIssConnectionString();

                    con.ConnectionString = conStr.Replace("Provider=SQLOLEDB", "");

                    System.Diagnostics.EventLog.WriteEntry("Application", con.ConnectionString);
                    con.Open();
                    System.Diagnostics.EventLog.WriteEntry("Application", "Open Complete");
                    using (SqlCommand cmd = new SqlCommand())
                    {

                        cmd.Connection = con;
                        cmd.CommandText = "GetIntegrationEmailTemplate";
                        cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter pErrorType = new SqlParameter("@ErrorType", SqlDbType.VarChar , 100);
                        pErrorType.Value = ErrorType ;
                        cmd.Parameters.Add(pErrorType);

                        SqlParameter pAccountId = new SqlParameter("@AccountId", SqlDbType.UniqueIdentifier);
                        pAccountId.Value = new Guid(AccountId);
                        cmd.Parameters.Add(pAccountId);

                       // SqlDataReader reader = cmd.ExecuteReader () ;


                        //strXml =  (string) cmd.ExecuteScalar();

                        System.Xml.XmlReader reader = cmd.ExecuteXmlReader();
                        reader.Read();
                        strXml = reader.ReadOuterXml(); 

                        //if (reader.Read())
                       // {
                        //  XmlReader xmlreader =   reader.GetXmlReader(0);
                        //  xmlreader.ReadOuterXml();
                          strXml = "<ns0:IntegrationEmail  xmlns:ns0='" +  xmlnamespace  + "'>" + strXml + "</ns0:IntegrationEmail>";

                       // }

                        doc.LoadXml(strXml);

                    }
                }
            }catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetIntegrationEmailTemplate -->{0}", exp.Message);
            }
            return doc;
        }


        #endregion GetIntegrationEmailTemplate



        #region GetPortcallIdFromReferenceCode
        /******************************************************************************************************************************
     * Function Name    : GetPortcallIdFromReferenceCode()
     * Parameters       : ReferenceCode of Appointment.HubPrincipalPortCallAppointmentMap
     * Return Value     : integer value
     * Description      : This method will return portcallId.
     * Author           : Sivakumar Karuppiah
     * Date Created     : 24-June-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static int GetPortcallIdFromReferenceCode(string ReferenceCode)
        {
            int portcallid = -1;
            try
            {
                string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCmd = new SqlCommand())
                    {
                        //string strSQL = "SELECT COUNT(ID) FROM Common.IntegrationDocuments WHERE ID IN (SELECT ID FROM Operation.CargoDocuments WHERE CargoId IN (SELECT ID FROM Operation.Cargoes WHERE PortCallId IN (SELECT ID FROM PORTCALL.PortCalls WHERE Number = '"+PortCallNumber+"'))) AND IsAleardySent = 0";
                        string strSQL = "select PortCallId  from Appointment.HubPrincipalPortCallAppointmentMap where ReferenceCode ='" + ReferenceCode  + "'";
                        objCmd.Connection = objCon;
                        objCmd.CommandText = strSQL;
                        portcallid = Convert.ToInt32(objCmd.ExecuteScalar());

                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetPortcallIdFromReferenceCode -->{0}", exp.Message);
                throw exp;
            }
            return portcallid;
        }
        #endregion GetPortcallIdFromReferenceCode


        #region CargoDocumentCount
        /******************************************************************************************************************************
     * Function Name    : CargoDocumentCount()
     * Parameters       : portcall Id, RefCode of the cargo
     * Return Value     : integer value
     * Description      : This method will return number of cargo documents uploaded.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 23-June-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        //public static int CargoDocumentCount(string PortCallId, int RefCode)
        public static int CargoDocumentCount(string PortCallId, string RefCode)
        {
            int doccount = 0;
            try
            {
                string connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand objCmd = new SqlCommand())
                    {
                        //string strSQL = "SELECT COUNT(ID) FROM Common.IntegrationDocuments WHERE ID IN (SELECT ID FROM Operation.CargoDocuments WHERE CargoId IN (SELECT ID FROM Operation.Cargoes WHERE PortCallId = " + PortCallId + " AND RefCode = "+RefCode+")) AND IsAleardySent = 0";
                        string strSQL = "SELECT COUNT(ID) FROM Common.IntegrationDocuments WHERE ID IN (SELECT ID FROM Operation.CargoDocuments WHERE CargoId IN (SELECT ID FROM Operation.Cargoes WHERE PortCallId = " + PortCallId + " AND RefCode = '" + RefCode + "') and isActive = 1 ) AND IsAleardySent = 0";
                        objCmd.Connection = objCon;
                        objCmd.CommandText = strSQL;
                        doccount = Convert.ToInt32(objCmd.ExecuteScalar());

                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in CargoDocumentCount -->{0}", exp.Message);
                throw exp;
            }
            return doccount;
        }
        #endregion

        #region GetPortcallId
        /******************************************************************************************************************************
     * Function Name    : GetPortcallId()
     * Parameters       : AppointmentNumber 
         * number
     * Return Value     : PortCall Id
     * Description      : With the input parameter, this method will get the Port Call Id from youriss2 DB.
     * Author           : Sivakumar Karuppiah
     * Date Created     : 21-June-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        
        public static  int GetPortcallId(string AppointmentNumber)
        {
            int portcallid = -1;
        try
            {
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string strSQL = "select top 1 PortCallId  from Appointment.Appointments  where number ='" + AppointmentNumber + "'";
                        cmd.Connection = objCon;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            portcallid = reader.GetInt32(0);
                        }
                    }
                }

            }catch (Exception exp)
             
                {
                    Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetPortcallId -->{0}",exp.Message );
                    throw exp;
                }
        return portcallid;
        }
            

        #endregion GetPortcallId


        #region GetPortcallNumber
        /******************************************************************************************************************************
     * Function Name    : GetPortcallNumber()
     * Parameters       : AppointmentNumber 
         * number
     * Return Value     : PortCall Number
     * Description      : With the input parameter, this method will get the Port Call Number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 21-July-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */

        public static string GetPortcallNumber(string AppointmentNumber)
        {
            //int portcallid = -1;
            string portCallNumber = string.Empty;
            try
            {
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                       // string strSQL = "select top 1 PortCallId  from Appointment.Appointments  where number ='" + AppointmentNumber + "'";
                        string strSQL = "SELECT Number FROM PortCall.PortCalls WHERE Id IN (SELECT TOP 1 PortCallId FROM Appointment.Appointments WHERE Number = '"+AppointmentNumber+"')";
                        cmd.Connection = objCon;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            portCallNumber = reader.GetString(0);
                        }
                    }
                }

            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetPortcallNumber -->{0}", exp.Message);
                throw exp;
            }
            return portCallNumber;
        }


        #endregion GetPortcallId








        #region CreateDataTableFromXML
        /******************************************************************************************************************************
     * Function Name    : CreateDataTableFromXML()
     * Parameters       : XML
     * Return Value     : DataTable
     * Description      : This method will return DataTable from the given XML
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 7-June-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static DataTable CreateDataTableFromXML(XmlDocument XMLDataTable, int PortCallId)
        {
            DataTable dt = new DataTable();
            try
            {
                dt.Clear();
                dt.Columns.Add("PortCallId", typeof(int));
                dt.Columns.Add("CommodityDetailCode", typeof(string));
                dt.Columns.Add("ChartererCode", typeof(string));
                XmlNodeList Xnnode = XMLDataTable.SelectNodes("//PortCall/Cargoes/Cargo");
                foreach (XmlNode node in Xnnode)
                {
                    DataRow dr = dt.NewRow();
                    dr["PortCallId"] = PortCallId;
                    dr["CommodityDetailCode"] = node["ISS_CommodityCode"].InnerText;
                    dr["ChartererCode"] = node["ISS_ChartererCode"].InnerText;
                    dt.Rows.Add(dr);
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Integration.Generic.Common:: ERROR in CreateDataTableFromXML-->{0}", exp.Message));
                throw new Exception(exp.Message);
            }

            return dt;
        }
        #endregion


        #region UpdateShipperReceiverMaster
        /******************************************************************************************************************************
     * Function Name    : UpdateShipRecvMaster()
     * Parameters       : PortCallId, ChartererName, Master
     * Return Value     : Void/NULL
     * Description      : This method will Update ShipperReceiver column of Cargoes table with the chartererName value and CaptainName of PortCallOperations with Master parameter value
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 30-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        //public static void UpdateShipRecvMaster(int PortCallId, string ChartererCode, string Master, XmlDocument MsgYourISSXML)
        public static void UpdateShipRecvMaster(int PortCallId, string Master, XmlDocument MsgYourISSXML)
        {
            //int ChartererId = 0;
            DataTable dt = CreateDataTableFromXML(MsgYourISSXML, PortCallId);
            string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
            using (SqlConnection objCon = new SqlConnection(Connectionstring))
            {
                objCon.Open();
                SqlTransaction SqlTransaction = objCon.BeginTransaction();
                try
                {
                    using (SqlCommand objCmd = new SqlCommand())
                    {
                        //objCmd.CommandText = "SELECT Id FROM Master.Companies WHERE Code = '" + ChartererCode + "'";
                        objCmd.Connection = objCon;
                        objCmd.Transaction = SqlTransaction;
                        //ChartererId = Convert.ToInt32(objCmd.ExecuteScalar());


                        //objCmd.CommandText = "CREATE TABLE #TempTableDT(PortCallId INT, CommodityDetailCode VARCHAR(50), ChartererCode VARCHAR(50))";
                        objCmd.CommandText = "CREATE TABLE #TempTableDT(PortCallId INT , CommodityDetailCode VARCHAR(50) , ChartererCode VARCHAR(50) )";
                         
                        objCmd.ExecuteNonQuery();
                        objCmd.Parameters.Clear();
                        using (SqlBulkCopy objBulkCopy = new SqlBulkCopy(objCon, SqlBulkCopyOptions.Default, SqlTransaction))
                        {
                            objBulkCopy.BulkCopyTimeout = 720;
                            objBulkCopy.DestinationTableName = "#TempTableDT";
                            objBulkCopy.WriteToServer(dt);
                            objBulkCopy.Close();
                        }
                        objCmd.CommandTimeout = 720;
                        // objCmd.CommandText = "UPDATE T SET T.ChartererId = Comp.Id FROM Operation.Cargoes T INNER JOIN #TempTableDT Temp ON T.PortCallId = Temp.PortCallId INNER JOIN MASTER.CommodityDetails Commo ON Temp.CommodityDetailCode = Commo.Code AND T.CommodityDetailId = Commo.Id INNER JOIN MASTER.COMPANIES Comp ON Temp.ChartererCode = Comp.Code WHERE Comp.IsActive = 1; DROP TABLE #TempTableDT;";
                        objCmd.CommandText = "UPDATE T SET T.ChartererId  = Comp.Id  FROM Operation.Cargoes T INNER JOIN #TempTableDT Temp ON T.PortCallId = Temp.PortCallId  INNER JOIN MASTER.CommodityDetails Commo ON Temp.CommodityDetailCode COLLATE DATABASE_DEFAULT = Commo.Code COLLATE DATABASE_DEFAULT AND T.CommodityDetailId  = Commo.Id INNER JOIN MASTER.COMPANIES Comp ON Temp.ChartererCode COLLATE DATABASE_DEFAULT = Comp.Code COLLATE DATABASE_DEFAULT WHERE Comp.IsActive = 1; DROP TABLE #TempTableDT;";
                        objCmd.ExecuteNonQuery();

                        objCmd.Parameters.Clear();

                        if (Master != "")
                        {
                            if (Master != null)
                            {
                                string strSQLBiz = string.Empty;
                                strSQLBiz = "UPDATE Operation.PortCallOperations SET CaptainName = '" + Master + "' WHERE PortCallId = " + PortCallId + "" ;
                                objCmd.Connection = objCon;
                                objCmd.CommandText = strSQLBiz;
                                objCmd.ExecuteNonQuery();
                            }
                        }
                        SqlTransaction.Commit();
                    }
                    objCon.Close();
                }
                catch (Exception exp)
                {
                    SqlTransaction.Rollback();
                    Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.Shipnet.Common:: ERROR in UpdateShipRecvMaster-->{0}", exp.Message));
                    throw new Exception(exp.Message);
                }
            }
        }
        
        #endregion 


        #region UpdateRoutingDetailsSplit
        /******************************************************************************************************************************
     * Function Name    : UpdateRoutingDetailsSplit()
     * Parameters       : RoutingDetailId, isUpdate, isError
     * Return Value     : None
     * Description      : To update RoutingDetail table's FinalDAStatus column.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 23-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static void UpdateRoutingDetailsSplit(int RoutingDetailId, bool isUpdate, bool isError)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    string connectionString = GetBizConnectionString();
                    sqlConnection.ConnectionString = connectionString.Replace("Provider=SQLOLEDB", "");
                    sqlConnection.Open();
                    using (SqlCommand sqlComm = new SqlCommand("SpuGetFinalDAS", sqlConnection))
                    {
                        sqlComm.Parameters.AddWithValue("@isUpdate", isUpdate);
                        sqlComm.Parameters.AddWithValue("@isError", isError);
                        sqlComm.Parameters.AddWithValue("@RoutingDetailId", RoutingDetailId);
                        //sqlComm.Parameters.AddWithValue("@FinalDAData", FinalDAs);
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        sqlComm.CommandTimeout = 600;
                        sqlComm.ExecuteNonQuery();
                    }
                    //SqlCommand sqlcom = new SqlCommand();
                    //sqlcom.Connection = sqlConnection;
                    //sqlcom.CommandType = CommandType.Text;
                    //sqlcom.CommandText = "UPDATE RoutingDetail SET FinalDAData = '" + FinalDAs + "', FinalDAStatus = 0, Status = 200 where RoutingDetailID = " + RoutingDetailId + "";                    
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Integration.Common:: ERROR in UpdateRoutingDetailsSplit-->{0}", exp.Message));
                throw new Exception(exp.Message);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
            }
            //return xDoc;
        }
        #endregion



        #region GetNewGUID

        public static string GetNewGUID()
        {
            return System.Guid.NewGuid().ToString();
        }

#endregion GetNewGUID

        #region CheckAccountRouting
        /******************************************************************************************************************************
     * Function Name    : CheckAccountRouting()
     * Parameters       : HubPrincipalID, Invoice type, IntegOrHAA
     * Return Value     : boolean true or false
     * Description      : This method will check whether mentioned(InvoiceType) type should send to HubPrincipalID, also determines to HAA or Integration.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 30-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */


        public static bool CheckAccountRouting(string HubPrincipalID, string InvoiceType, string IntgOrHAA)
        {
            bool isSent = false;
            string BizConnectionstring = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");
            using (SqlConnection objBizCon = new SqlConnection(BizConnectionstring))
            {
                objBizCon.Open();
                using (SqlCommand Bizcmd = new SqlCommand())
                {
                    string strSQLBiz = string.Empty;

                    if (IntgOrHAA == "Integration")
                    {
                        if (InvoiceType == "OperationUpdate")
                            strSQLBiz = "SELECT OpsUpdSendFlag FROM Routing WHERE AccountID = '" + HubPrincipalID + "' AND OpsUpdSendFlag = 1 ";
                        else if (InvoiceType == "Proforma-Services")
                            strSQLBiz = " SELECT ProformaSendFlag FROM routing WHERE AccountID = '" + HubPrincipalID + "'";
                        else
                            strSQLBiz = " SELECT CESendFlag FROM routing WHERE AccountID = '" + HubPrincipalID + "'";
                    }
                    else if (IntgOrHAA == "HAA")
                    {
                        strSQLBiz = "SELECT status FROM HAASystem WHERE AccountID = '" + HubPrincipalID + "'";
                    }
                    Bizcmd.Connection = objBizCon;
                    Bizcmd.CommandText = strSQLBiz;
                    isSent = Convert.ToBoolean(Bizcmd.ExecuteScalar());
                }
                objBizCon.Close();
            }
            return isSent;
        }


        #endregion 


        #region GetPortCallIdForCE
        /******************************************************************************************************************************
     * Function Name    : GetPortCallIdForCE()
     * Parameters       : Shipnet Reference number, Shipnet DA number
     * Return Value     : PortCall Number
     * Description      : With the input parameter, this method will get the Port Call number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 13-April-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetPortCallIdForCE(string AptNumber)
        {
            string portCallNumber = string.Empty;
            //string shpRef = ShipNetReference + "|" + SNDA;
            string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
            using (SqlConnection objCon = new SqlConnection(Connectionstring))
            {
                objCon.Open();
                using (SqlCommand cmd = new SqlCommand())
                {

                    string strSQL = "SELECT Number FROM portcall.portcalls WHERE ID IN ( " +
                        "SELECT portcallid FROM appointment.appointments WHERE number = '" + AptNumber + "')";

                    //string strSQL = "SELECT Number FROM Appointment.Appointments WHERE ID IN (" +
                    //    "SELECT AppointmentId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                    //                        "WHERE ReferenceCode LIKE '%" + shpRef + "%')";
                    cmd.Connection = objCon;
                    cmd.CommandText = strSQL;
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        portCallNumber = reader.GetString(0);
                    }
                }
            }
            return portCallNumber;
        }
        #endregion 
        #region GetPortCallIdForCancel
        /******************************************************************************************************************************
     * Function Name    : GetPortCallIdForCancel()
     * Parameters       : Shipnet Reference number, Shipnet DA number
     * Return Value     : PortCall Number
     * Description      : With the input parameter, this method will get the Port Call number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 13-April-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetPortCallIdForCancel(string ShipNetReference, string SNDA, string SNKeyPosition)
        {
            string portCallNumber = string.Empty;
            string shpRef = ShipNetReference + "|" + SNDA + "|" + SNKeyPosition;
            string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
            using (SqlConnection objCon = new SqlConnection(Connectionstring))
            {
                objCon.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    string strSQL = "SELECT Number FROM Appointment.Appointments WHERE ID IN (" +
                        "SELECT AppointmentId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                                            "WHERE ReferenceCode LIKE '%" + shpRef + "%')";
                    cmd.Connection = objCon;
                    cmd.CommandText = strSQL;
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        portCallNumber = reader.GetString(0);
                    }
                }
            }
            return portCallNumber;
        }
        #endregion 
        #region GetPortCallIdForUpdate
        /******************************************************************************************************************************
     * Function Name    : GetPortCallIdForUpdate()
     * Parameters       : Shipnet Reference number
     * Return Value     : PortCall Number
     * Description      : With the shipnet ref number, this method will get the Port Call number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 12-April-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetPortCallIdForUpdate(string Action, string ShipNetReference, string SNDA, string SNKeyPosition, string SNVoyageNumber)
        {
            string portCallNumber = string.Empty;
            if (Action != "Create")
            {
                string shpRef = ShipNetReference + "|" + SNDA + "|" + SNKeyPosition + "|" + SNVoyageNumber;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string strSQL = "SELECT Number FROM PortCall.PortCalls WHERE id in (" +
                            "SELECT PortCallId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                                                "WHERE ReferenceCode = '" + shpRef + "')";
                        cmd.Connection = objCon;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            portCallNumber = reader.GetString(0);
                        }
                    }
                }
            }
            return portCallNumber;
        }
        #endregion 
        #region GetAppointmentIdForUpdate
        /******************************************************************************************************************************
     * Function Name    : GetAppointmentIdForUpdate()
     * Parameters       : Shipnet Reference number
     * Return Value     : Appointment Number
     * Description      : With the shipnet ref number, this method will get the appointment number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 11-April-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetAppointmentIdForUpdate(string Action, string ShipNetReference, string SNDA, string SNKeyPosition, string SNVoyageNumber)
        {
            string appointmentNumber = string.Empty;
            if (Action != "Create")
            {
                string shpRef = ShipNetReference + "|" + SNDA + "|" + SNKeyPosition + "|" + SNVoyageNumber;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string strSQL = "SELECT Number FROM Appointment.Appointments WHERE id in (" +
                            "SELECT AppointmentId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                                                "WHERE ReferenceCode = '" + shpRef + "')";
                        cmd.Connection = objCon;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            appointmentNumber = reader.GetString(0);
                        }
                    }
                }
            }
            return appointmentNumber;
        }
        #endregion 

        #region EncryptingDocumentURL
        public static string Encryption(string inputString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;

            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(inputString);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }
        #endregion 

        #region RemoveGuid
        public static string RemoveGuid(string yiss2DocPath)
        {
            string yiss2ModifiedfilePath = string.Empty;

            try
            {
                //string firstSplit = yiss2DocPath.Substring(0, yiss2DocPath.LastIndexOf('.'));
                //firstSplit = "file:" + firstSplit.Replace("\\", "//");
                //yiss2ModifiedfilePath = firstSplit.Substring(firstSplit.LastIndexOf('\\') + 1);


                yiss2DocPath = yiss2DocPath.Substring(0, yiss2DocPath.LastIndexOf("HubPrincipalKey"));
                yiss2ModifiedfilePath = "file:" + yiss2DocPath.Replace("\\", "//");
            }
            catch (Exception exp)
            {
                throw exp;
            }

            return yiss2ModifiedfilePath;
        }
        #endregion 

        #region GetHubPrincipalCode
        /******************************************************************************************************************************
     * Function Name    : GetHubPrincipalCode()
     * Parameters       : URL of operational/Cargo documents
     * Return Value     : part of URL from the input URL 
     * Description      : Method to get the part of the given URL of document
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 08-April-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static string GetHubPrincipalCode(string yiss2DocPath)
        {
            string HubPrincipalCode = string.Empty;
            try
            {
                string firstSplit1 = yiss2DocPath.Substring(yiss2DocPath.LastIndexOf("HubPrincipalKey"));
                HubPrincipalCode = firstSplit1.Substring(firstSplit1.LastIndexOf("::") + 2);
            }
            catch (Exception exp)
            {
                throw exp;
            }

            return HubPrincipalCode;
        }
        #endregion 


        #region GetDocumentBasePath
        /******************************************************************************************************************************
     * Function Name    : GetDocumentBasePath()
     * Parameters       : Nil
     * Return Value     : String value of path 
     * Description      : String value of base path of the document which will be send along with the document url in operational update
     * Author           : Saravanan Kumaresan
     * Date Created     : 08-April-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static string GetDocumentBasePath()
        {
            string baseURL = string.Empty;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    //string connectionString = @"Database=ERP_INTF; Server=ISSIDCBIZTALK\ISSIDCBIZTALK; uid=IDCBizTalkUser; pwd=Sh1pN3t05";

                    string connectionString = GetBizConnectionString();
                    sqlConnection.ConnectionString = connectionString.Replace("Provider=SQLOLEDB", "");
                    System.Diagnostics.EventLog.WriteEntry("Application", "GetDocumentBasePath ConnectionString - " + connectionString);
                    using (SqlCommand sqlCommand = new SqlCommand("SPU_Get_Configuration", sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.CommandTimeout = 600;

                        sqlConnection.Open();

                        baseURL = Convert.ToString(sqlCommand.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return baseURL;
        }

        #endregion

        #region GetCargoDetails
        public static XmlDocument GetCargoDetails(XmlDocument ParentXML, XmlDocument ChildXML, string PortcallPort, string PortcallReasonforCall, string PortcallTerminal, string CargoPortPort, string CargoPortReasonforCall, string CargoPortTerminal)
        {
            string parentContents = ParentXML.OuterXml.ToString();

            try
            {

                if (PortcallPort == CargoPortPort && PortcallReasonforCall == CargoPortReasonforCall && PortcallTerminal == CargoPortTerminal)
                {
                    string contents = ChildXML.OuterXml.ToString();
                    contents = contents.Replace("ns0:root xmlns:ns0=\"http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.CargoOutput\"", "root");
                    contents = contents.Replace("ns0:root", "root");
                    if (string.IsNullOrEmpty(parentContents))
                    {
                        ParentXML = new XmlDocument();

                        XmlNode tagNode = ParentXML.CreateNode(XmlNodeType.Element, "ns1", "Cargos", "http://Inchcape.YourISS.Integration.DataLoy.CreatePortCall.Schema.Cargos");
                        ParentXML.AppendChild(tagNode);

                        XmlNode subTagNode1 = ParentXML.CreateNode(XmlNodeType.Element, "Cargo", null);
                        tagNode.AppendChild(subTagNode1);
                        subTagNode1.InnerXml = contents;
                    }
                    else
                    {

                        XmlNode tagNode = ParentXML.DocumentElement;
                        XmlNode subTagNode1 = ParentXML.CreateNode(XmlNodeType.Element, "Cargo", null);
                        tagNode.AppendChild(subTagNode1);
                        subTagNode1.InnerXml = contents;
                    }
                }
            }
            catch (Exception exp)
            {

            }

            return ParentXML;
        }
        #endregion 

        #region GetCargofilesURL
        /******************************************************************************************************************************
     * Function Name    : GetCargofilesURL()
     * Parameters       : Appointment Number
     * Return Value     : XmlDocument of Cargo document's url
     * Description      : With the appointment, this method will provide the Cargo document's url in a XmlDocument
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 08-April-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument GetCargoFilesURL(string portcallNumber)
        {
            XmlDocument xDoc = new XmlDocument();
            try
            {
                String returnVal = string.Empty;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    //using (SqlCommand sqlComm = new SqlCommand("Operation.SpuGetDocuments", objCon)) 
                    using (SqlCommand sqlComm = new SqlCommand("integration.SpuGetDocumentURL", objCon))
                    {
                        sqlComm.Parameters.AddWithValue("@PortCallNumber", portcallNumber);
                        sqlComm.Parameters.AddWithValue("@DocType", "Cargo");
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataTable ds = new DataTable();
                        da.SelectCommand = sqlComm;
                        da.Fill(ds);
                        int tabCount = Convert.ToInt32(ds.Rows.Count);
                        //returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.YourISS.Integration.Generic.Schema.Documents'>";
                        returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.CargoDocuments'>";
                        StringBuilder strBlderDocIds = new StringBuilder();
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                returnVal += "<Document>";
                                returnVal += "<Url>" + GetDocumentBasePath() + "?id=" + Encryption(GetHubPrincipalCode(ds.Rows[i][0].ToString())) + "&amp;Name=" + Encryption(RemoveGuid(ds.Rows[i][0].ToString())) + "</Url>";
                                returnVal += "<Id>" + ds.Rows[i][1].ToString() + "</Id>";
                                //returnVal += "<Id></Id>";
                                strBlderDocIds.Append(ds.Rows[i][3].ToString());
                                strBlderDocIds.Append(",");
                                returnVal += "</Document>";
                            }
                            strBlderDocIds.Remove(strBlderDocIds.Length - 1, 1);
                        };
                        returnVal += "<DocumentIDs>" + strBlderDocIds.ToString() + "</DocumentIDs>";
                        returnVal += "</ns0:Documents>";
                    }
                }
                xDoc.LoadXml(string.Format(returnVal));

            }
            catch (Exception exp)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetCargoFilesURL-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetCargoFilesURL -->{0}", exp.Message);
                throw new Exception(exp.Message);

            }
            return xDoc;
        }
        #endregion

        #region GetFinalDADocumentURL
        /******************************************************************************************************************************
     * Function Name    : GetFinalDADocumentURL(appointmentNumber)
     * Parameters       : PortCall Number and type of application like DA, Finance, Cargo.
     * Return Value     : XmlDocument of all Final DA document's url of that specific portcall number.
     * Description      : With the PortCall Number, this method will provide the all Final DA document's url in a XmlDocument
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 1-August-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument GetFinalDADocumentURL(string portCallNumber, string type)
        {
            XmlDocument xDoc = new XmlDocument();
            try
            {
                String returnVal = string.Empty;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    //using (SqlCommand sqlComm = new SqlCommand("Operation.SpuGetDocuments", objCon)) integration.SpuGetDocumentURL
                    using (SqlCommand sqlComm = new SqlCommand("integration.SpuGetDocumentURL", objCon))
                    {
                        sqlComm.Parameters.AddWithValue("@PortCallNumber", portCallNumber);
                        sqlComm.Parameters.AddWithValue("@DocType", type);
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataTable ds = new DataTable();
                        da.SelectCommand = sqlComm;
                        da.Fill(ds);
                        int tabCount = Convert.ToInt32(ds.Rows.Count);
                        StringBuilder strBlderDocIds = new StringBuilder();
                        returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.YourISS.Integration.FinalDA.Schema.Documents'>";
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                returnVal += "<Document>";
                                returnVal += "<Url>" + GetDocumentBasePath() + "?id=" + Encryption(GetHubPrincipalCode(ds.Rows[i][0].ToString())) + "&amp;Name=" + Encryption(RemoveGuid(ds.Rows[i][0].ToString())) + "</Url>";
                                returnVal += "<ServiceId>" + ds.Rows[i][2].ToString() + "</ServiceId>";
                                strBlderDocIds.Append(ds.Rows[i][3].ToString());
                                strBlderDocIds.Append(",");
                                returnVal += "</Document>";
                            }
                            strBlderDocIds.Remove(strBlderDocIds.Length - 1, 1);
                        }
                        returnVal += "<DocumentIDs>" + strBlderDocIds.ToString() + "</DocumentIDs>";
                        returnVal += "</ns0:Documents>";
                    }
                }
                xDoc.LoadXml(string.Format(returnVal));
            }
            catch (Exception exp)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetFinanceDocumentURL-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetFinalDADocumentURL -->{0}", exp.Message);
                throw new Exception(exp.Message);

            }
            return xDoc;
        }

        #endregion

        #region GetFinanceDocumentURL
        /******************************************************************************************************************************
     * Function Name    : GetFinanceDocumentURL(appointmentNumber)
     * Parameters       : Appointment Number
     * Return Value     : XmlDocument of all Finance document's url
     * Description      : With the appointment, this method will provide the all Finance document's url in a XmlDocument
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 22-April-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument GetFinanceDocumentURL(string portCallNumber, string type)
        {
            XmlDocument xDoc = new XmlDocument();
            try
            {
                String returnVal = string.Empty;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    //using (SqlCommand sqlComm = new SqlCommand("Operation.SpuGetDocuments", objCon)) integration.SpuGetDocumentURL
                    using (SqlCommand sqlComm = new SqlCommand("integration.SpuGetDocumentURL", objCon))
                    {
                        sqlComm.Parameters.AddWithValue("@PortCallNumber", portCallNumber);
                        sqlComm.Parameters.AddWithValue("@DocType", type);
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataTable ds = new DataTable();
                        da.SelectCommand = sqlComm;
                        da.Fill(ds);
                        int tabCount = Convert.ToInt32(ds.Rows.Count);
                        StringBuilder strBlderDocIds = new StringBuilder();
                        returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.YourISS.Integration.PDA.CE.Schema.Documents'>";
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                returnVal += "<Document>";
                                returnVal += "<Url>" + GetDocumentBasePath() + "?id=" + Encryption(GetHubPrincipalCode(ds.Rows[i][0].ToString())) + "&amp;Name=" + Encryption(RemoveGuid(ds.Rows[i][0].ToString())) + "</Url>";
                                returnVal += "<ServiceId>" + ds.Rows[i][2].ToString() + "</ServiceId>";
                                strBlderDocIds.Append(ds.Rows[i][3].ToString());
                                strBlderDocIds.Append(",");
                                returnVal += "</Document>";
                            }
                            strBlderDocIds.Remove(strBlderDocIds.Length - 1, 1);
                        }
                        returnVal += "<DocumentIDs>" + strBlderDocIds.ToString() + "</DocumentIDs>";
                        returnVal += "</ns0:Documents>";
                    }
                }
                xDoc.LoadXml(string.Format(returnVal));
            }
            catch (Exception exp)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetFinanceDocumentURL-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetFinanceDocumentURL -->{0}", exp.Message);
                throw new Exception(exp.Message);

            }
            return xDoc;
        }

        #endregion

        #region GetOtherOperationFilesURL
        /******************************************************************************************************************************
     * Function Name    : GetOtherOperationFilesURL()
     * Parameters       : Appointment Number
     * Return Value     : XmlDocument of all operational document's url
     * Description      : With the appointment, this method will provide the all operational document's url in a XmlDocument
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 08-April-2016
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static XmlDocument GetOtherOperationFilesURL(string appointmentNumber)
        {
            XmlDocument xDoc = new XmlDocument();
            try
            {
                String returnVal = string.Empty;
                string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    // using (SqlCommand sqlComm = new SqlCommand("Operation.SpuGetDocuments", objCon))  
                    using (SqlCommand sqlComm = new SqlCommand("integration.SpuGetDocumentURL", objCon))
                    {
                        sqlComm.Parameters.AddWithValue("@PortCallNumber", appointmentNumber);
                        sqlComm.Parameters.AddWithValue("@DocType", "Operational");
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter da = new SqlDataAdapter();
                        DataTable ds = new DataTable();
                        da.SelectCommand = sqlComm;
                        da.Fill(ds);
                        int tabCount = Convert.ToInt32(ds.Rows.Count);
                        //returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.Shipnet.BT.PortOperationUpdate.Schema.OtherOpDoc'>";
                        //returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.Documents'>";
                        returnVal = "<ns0:Documents xmlns:ns0='http://Inchcape.Yiss.BT.Generic.Schema.OpsUpdate.CargoDocuments'>";
                        StringBuilder strBlderDocIds = new StringBuilder();
                        if (tabCount > 0)
                        {
                            for (int i = 0; i < tabCount; i++)
                            {
                                //returnVal += "<Document>" + GetDocumentBasePath() + "?id=" + Encryption(GetHubPrincipalCode(ds.Rows[i][0].ToString())) + "&amp;Name=" + Encryption(RemoveGuid(ds.Rows[i][0].ToString())) + "</Document>";
                                returnVal += "<Document>";
                                returnVal += "<Url>" + GetDocumentBasePath() + "?id=" + Encryption(GetHubPrincipalCode(ds.Rows[i][0].ToString())) + "&amp;Name=" + Encryption(RemoveGuid(ds.Rows[i][0].ToString())) +"</Url>";
                                returnVal += "<Id></Id>";
                                strBlderDocIds.Append(ds.Rows[i][3].ToString());
                                strBlderDocIds.Append(",");
                                returnVal += "</Document>";
                            }
                            strBlderDocIds.Remove(strBlderDocIds.Length - 1, 1);
                        }
                        returnVal += "<DocumentIDs>" + strBlderDocIds.ToString() + "</DocumentIDs>";
                        returnVal += "</ns0:Documents>";
                    }
                }
                xDoc.LoadXml(string.Format(returnVal));
            }
            catch (Exception exp)
            {
                //                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetOtherOperationFilesURL-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in GetOtherOperationFilesURL -->{0}", exp.Message);
                throw new Exception(exp.Message);
            }
            return xDoc;
        }

        #endregion


        #region GetBizConnectionString
        /******************************************************************************************************************************
     * Function Name    : GetBizConnectionString()
     * Parameters       : NA
     * Return Value     : string ConnectionString
     * Description      : Retrieves the Connection String configured in the Windows Registry "SOFTWARE\Wow6432Node\Shipnet" and retruns to the calling method         
     * Author           : Bharath Kumar KC
     * Date Created     : 21-Nov-2015
     * Date Modified    :
     * Cooments         :
     * ******************************************************************************************************************************
     */
        public static string GetBizConnectionString()
        {
            string conString = "";
            try
            {

                RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\GenericIntegration", true);
                conString = GetDecryptedConnectionString(reg.GetValue("ControlDBConnectionString").ToString());
                // System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetBizConnectionString  -->" + conString);
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
                throw new Exception(exp.Message);                
            }
            return conString;
        }
        #endregion



        #region GetAppointmentNumber
        /******************************************************************************************************************************
     * Function Name    : GetAppointmentNumber()
     * Parameters       : YourISS Portcall number
     * Return Value     : Hubprincipal key / AccountID
     * Description      : With the input parameter, this method will get the Hub principal key from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 12-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetAppointmentNumber(string PortCallNumber)
        {
            string AppointmentNumber = string.Empty;
            string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");
            try
            {
                using (SqlConnection objCon = new SqlConnection(Connectionstring))
                {
                    objCon.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {

                        string strSQL = "select top 1 Number  from Appointment.Appointments where PortCallId = (select top 1 id from PortCall.PortCalls  where Number ='" + PortCallNumber + "')";

                        //string strSQL = "SELECT Number FROM Appointment.Appointments WHERE ID IN (" +
                        //    "SELECT AppointmentId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                        //                        "WHERE ReferenceCode LIKE '%" + shpRef + "%')";
                        cmd.Connection = objCon;
                        cmd.CommandText = strSQL;
                        AppointmentNumber = Convert.ToString(cmd.ExecuteScalar());

                        Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common: AppointmentNumber -->{0}", AppointmentNumber);
                        //SqlDataReader reader = cmd.ExecuteReader();
                        //if (reader.Read())
                        //{
                        //    HubPrincipalKey = reader.GetString(0);
                        //}
                    }
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common: GetAppointmentNumber -->{0}",exp.Message );
                throw new Exception(exp.Message); 
            }
            return AppointmentNumber;
        }
        #endregion





        #region GetHubPrincipalKeyfromApptNumber
        /******************************************************************************************************************************
     * Function Name    : GetHubPrincipalKey()
     * Parameters       : YourISS Appointment number
     * Return Value     : Hubprincipal key / AccountID
     * Description      : With the input parameter, this method will get the Hub principal key from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 12-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static string GetHubPrincipalKey(string ApptNumber)
        {
            string HubPrincipalKey = string.Empty;
            string Connectionstring = GetNYourIssConnectionString().Replace("Provider=SQLOLEDB", "");

      try { 

            using (SqlConnection objCon = new SqlConnection(Connectionstring))
            {
                objCon.Open();
                using (SqlCommand cmd = new SqlCommand())
                {

                    string strSQL = "SELECT HubPrincipalKey FROM Appointment.HubPrincipalPortCallAppointmentMap WHERE appointmentid IN ( " +
                        "SELECT Id FROM appointment.appointments WHERE number = '" + ApptNumber + "')";

                    //string strSQL = "SELECT Number FROM Appointment.Appointments WHERE ID IN (" +
                    //    "SELECT AppointmentId FROM Appointment.HubPrincipalPortCallAppointmentMap " +
                    //                        "WHERE ReferenceCode LIKE '%" + shpRef + "%')";
                    cmd.Connection = objCon;
                    cmd.CommandText = strSQL;
                    HubPrincipalKey = Convert.ToString(cmd.ExecuteScalar());

                    //SqlDataReader reader = cmd.ExecuteReader();
                    //if (reader.Read())
                    //{
                    //    HubPrincipalKey = reader.GetString(0);
                    //}
                }
            }
           }catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceInfo("Inchcape.YourISS.Integration.Common:: ERROR GetHubPrincipalKey-->{0}",exp.Message );
                throw new Exception(exp.Message); 
            }
            return HubPrincipalKey;
        }
        #endregion 

        #region InsertMessage
        /******************************************************************************************************************************
     * Function Name    : InsertMessage()
     * Parameters       : Shipnet Reference number, Shipnet DA 
         * number
     * Return Value     : PortCall Number
     * Description      : With the input parameter, this method will get the Port Call number from youriss2 DB.
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 13-April-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static int InsertMessage(bool IsSource, bool IsTransform, bool IsResponse, bool IsError, int Id, string AppointmentNumber, string MessageID, string Method, int Version, int MessageVersion, string RequestData, string TransformedData,
           string ResponseData, string Direction, string SourceApplication, int SourceStatus, int TransformStatus, int ResponseStatus, string ErrorMessage, string DocumentIDs)
        {
            int returnVal = 0;
            string HubPrincipalKey = string.Empty;

           // if ( (Method == "UDA") ||  (Method == "PDA"))
                HubPrincipalKey = GetHubPrincipalKey(AppointmentNumber);
           // else
             //   HubPrincipalKey = GetHubPrincipalKeyPortCallNumber(AppointmentNumber);
            
            
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    string connectionString = GetBizConnectionString();
                    sqlConnection.ConnectionString = connectionString.Replace("Provider=SQLOLEDB", "");
                    sqlConnection.Open();
                    using (SqlCommand sqlComm = new SqlCommand("SpuMessageInsert", sqlConnection))
                    {
                        sqlComm.Parameters.AddWithValue("@IsSource", SqlDbType.Bit).Value = IsSource;
                        sqlComm.Parameters.AddWithValue("@IsTransform", SqlDbType.Bit).Value = IsTransform;
                        sqlComm.Parameters.AddWithValue("@IsResponse", SqlDbType.Bit).Value = IsResponse;
                        sqlComm.Parameters.AddWithValue("@IsError", SqlDbType.Bit).Value = IsError;
                        sqlComm.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Id;
                        sqlComm.Parameters.AddWithValue("@ReferenceNo", SqlDbType.NVarChar ).Value = AppointmentNumber;
                        sqlComm.Parameters.AddWithValue("@AccountID", SqlDbType.UniqueIdentifier).Value = HubPrincipalKey;
                        sqlComm.Parameters.AddWithValue("@MessageID", SqlDbType.UniqueIdentifier).Value = MessageID;
                        sqlComm.Parameters.AddWithValue("@Method", SqlDbType.NVarChar).Value = Method;
                        sqlComm.Parameters.AddWithValue("@Version", SqlDbType.Int).Value = Version;
                        sqlComm.Parameters.AddWithValue("@MessageVersion", SqlDbType.Int).Value = MessageVersion;
                        sqlComm.Parameters.AddWithValue("@RequestData", SqlDbType.NVarChar).Value = RequestData;
                        sqlComm.Parameters.AddWithValue("@TransformedData", SqlDbType.NVarChar).Value = TransformedData;
                        sqlComm.Parameters.AddWithValue("@ResponseData", SqlDbType.NVarChar).Value = ResponseData;
                        sqlComm.Parameters.AddWithValue("@Direction", SqlDbType.NVarChar).Value = Direction;
                        sqlComm.Parameters.AddWithValue("@SourceApplication", SqlDbType.NVarChar).Value = SourceApplication;
                        sqlComm.Parameters.AddWithValue("@SourceStatus", SqlDbType.Int).Value = SourceStatus;
                        sqlComm.Parameters.AddWithValue("@TransformStatus", SqlDbType.Int).Value = TransformStatus;
                        sqlComm.Parameters.AddWithValue("@ResponseStatus", SqlDbType.Int).Value = ResponseStatus;
                        sqlComm.Parameters.AddWithValue("@ErrorMessage", SqlDbType.NVarChar).Value = ErrorMessage;
                        sqlComm.Parameters.AddWithValue("@DocumentIDs", SqlDbType.VarChar).Value = DocumentIDs;
                        //sqlComm.Parameters.AddWithValue("@IsSource", IsSource);
                        //sqlComm.Parameters.AddWithValue("@IsTransform", IsTransform);
                        //sqlComm.Parameters.AddWithValue("@IsResponse", IsResponse);
                        //sqlComm.Parameters.AddWithValue("@IsError", IsError);
                        //sqlComm.Parameters.AddWithValue("@Id", Id);
                        //sqlComm.Parameters.AddWithValue("@AccountID", HubPrincipalKey);
                        //sqlComm.Parameters.AddWithValue("@MessageID", MessageID);
                        //sqlComm.Parameters.AddWithValue("@Method", MessageID);
                        //sqlComm.Parameters.AddWithValue("@Version", Version);
                        //sqlComm.Parameters.AddWithValue("@MessageVersion", MessageVersion);
                        //sqlComm.Parameters.AddWithValue("@RequestData", RequestData);
                        //sqlComm.Parameters.AddWithValue("@TransformedData", TransformedData);
                        //sqlComm.Parameters.AddWithValue("@ResponseData", ResponseData);
                        //sqlComm.Parameters.AddWithValue("@Direction", Direction);
                        //sqlComm.Parameters.AddWithValue("@SourceApplication", SourceApplication);
                        //sqlComm.Parameters.AddWithValue("@SourceStatus", SourceStatus);
                        //sqlComm.Parameters.AddWithValue("@TransformStatus", TransformStatus);
                        //sqlComm.Parameters.AddWithValue("@ResponseStatus", ResponseStatus);
                        //sqlComm.Parameters.AddWithValue("@ErrorMessage", ErrorMessage);
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        sqlComm.CommandTimeout = 600;
                        if (IsSource == false)
                            sqlComm.ExecuteNonQuery();
                        else
                            returnVal = Convert.ToInt32(sqlComm.ExecuteScalar());

                        return returnVal;
                    }
                }
            }
            catch (Exception exp)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in InsertMessage-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in InsertMessage -->{0}", exp.Message);
                throw new Exception(exp.Message);                
            }
            //return xDoc;
        }

        #endregion 


        #region InsertEmailData
        /******************************************************************************************************************************
     * Function Name    : InsertEmailData()
     * Parameters       :  @Method,@Subject,@Body,@EmailFrom  ,@EmailTo ,@EmailCC ,@EmailBcc ,@Attachment,@FileName,@FileSize
     * Return Value     : Email id
     * Description      : With the input parameter, this method will get the Email id  from Test_INTF DB.
     * Author           : Periasamy T
     * Date Created     : 28-June-2016
     * Date Modified    : 28-June-2016
     * Comments         : To insert the values in email table.
     * ******************************************************************************************************************************
     */
        public static int InsertEmailData(bool IsFlag,string Method, string Subject, string Body, string EmailFrom,string EmailTo,  string EmailCC, string EmailBcc, string Attachment, string FileName, int FileSize)
        {
            int returnVal = 0;
            //string HubPrincipalKey = string.Empty;

            // if ( (Method == "UDA") ||  (Method == "PDA"))
           // HubPrincipalKey = GetHubPrincipalKey(AppointmentNumber);
            // else
            //   HubPrincipalKey = GetHubPrincipalKeyPortCallNumber(AppointmentNumber);


            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    string connectionString = GetBizConnectionString();
                    sqlConnection.ConnectionString = connectionString.Replace("Provider=SQLOLEDB", "");
                    sqlConnection.Open();
                    using (SqlCommand sqlComm = new SqlCommand("spu_insert_email_data", sqlConnection))
                    {
                        sqlComm.Parameters.AddWithValue("@Method", SqlDbType.VarChar).Value = Method;
                        sqlComm.Parameters.AddWithValue("@Subject", SqlDbType.NVarChar).Value = Subject;
                        sqlComm.Parameters.AddWithValue("@Body", SqlDbType.NVarChar).Value = Body;
                        sqlComm.Parameters.AddWithValue("@EmailFrom", SqlDbType.NVarChar).Value = EmailFrom;
                        sqlComm.Parameters.AddWithValue("@EmailTo", SqlDbType.NVarChar).Value = EmailTo;
                        sqlComm.Parameters.AddWithValue("@EmailCC", SqlDbType.NVarChar).Value = EmailCC;
                        sqlComm.Parameters.AddWithValue("@EmailBcc", SqlDbType.NVarChar).Value = EmailBcc;
                        sqlComm.Parameters.AddWithValue("@Attachment", SqlDbType.NVarChar).Value = Attachment;
                        sqlComm.Parameters.AddWithValue("@FileName", SqlDbType.VarChar).Value = FileName;
                        sqlComm.Parameters.AddWithValue("@FileSize", SqlDbType.Int).Value = FileSize;
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        sqlComm.CommandTimeout = 600;
                        if (IsFlag == false)
                            sqlComm.ExecuteNonQuery();
                        else
                            returnVal = Convert.ToInt32(sqlComm.ExecuteScalar());

                        return returnVal;
                    }
                }
            }
            catch (Exception exp)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in InsertEmailData-->{0}", exp.Message));
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError("Inchcape.YourISS.Integration.Generic.Common:: ERROR in InsertEmailData -->{0}", exp.Message);
                throw new Exception(exp.Message);
                
            }
            //return xDoc;
        }

        #endregion 









        #region UpdateRoutingDetails
        /******************************************************************************************************************************
     * Function Name    : UpdateRoutingDetails()
     * Parameters       : FinalDAs data from YourISS, and ID of the table column to update.
     * Return Value     : None
     * Description      : To Update the RoutingDetail table with the FinalDAs, and a seperate orchestration will be called and it will split the FinalDAs
     * Author           : Keerthi Reddy Subbiah
     * Date Created     : 23-May-2016
     * Date Modified    :
     * Comments         :
     * ******************************************************************************************************************************
     */
        public static void UpdateRoutingDetails(string FinalDAs, int RoutingDetailId, bool isUpdate, bool isError)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    string connectionString = GetBizConnectionString();
                    sqlConnection.ConnectionString = connectionString.Replace("Provider=SQLOLEDB", "");
                    sqlConnection.Open();
                    using (SqlCommand sqlComm = new SqlCommand("SpuGetRoutingDetail", sqlConnection))
                    {
                        sqlComm.Parameters.AddWithValue("@isUpdate", isUpdate);
                        sqlComm.Parameters.AddWithValue("@isError", isError);
                        sqlComm.Parameters.AddWithValue("@RoutingDetailId", RoutingDetailId);
                        sqlComm.Parameters.AddWithValue("@FinalDAData", FinalDAs);
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        sqlComm.CommandTimeout = 600;
                        sqlComm.ExecuteNonQuery();
                    }
                    //SqlCommand sqlcom = new SqlCommand();
                    //sqlcom.Connection = sqlConnection;
                    //sqlcom.CommandType = CommandType.Text;
                    //sqlcom.CommandText = "UPDATE RoutingDetail SET FinalDAData = '" + FinalDAs + "', FinalDAStatus = 0, Status = 200 where RoutingDetailID = " + RoutingDetailId + "";                    
                }
            }
            catch (Exception exp)
            {
                Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Integration.Common:: ERROR in UpdateRoutingDetails-->{0}", exp.Message));
                throw new Exception(exp.Message);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
            }
            //return xDoc;
        }
        #endregion 


     //   #region GetPaspConnectionString

     //   /******************************************************************************************************************************
     // * Function Name    : GetSourceConnectionString()
     // * Parameters       : string encryptedConString
     // * Return Value     : string decryptedConStr
     // * Description      : Accepts the encrypted connection string and decrypts to original connection string and returns to the calling program 
     // * Author           : Sujatha B.M.
     // * Date Created     : 25-Mar-2014
     // * Date Modified    :
     // * Cooments         :
     // * ******************************************************************************************************************************
     // */
     //   public static string GetPaspConnectionString()
     //   {
     //       string conString = "";
     //       try
     //       {

     //           RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\HorizonIntegration\NYourIss", true);
     //           conString = GetDecryptedConnectionString(reg.GetValue("ConnectionString").ToString());
     //       }
     //       catch (Exception exp)
     //       {
     //           Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
     //       }
     //       return conString;
     //   }
     //   #endregion

        #region GetNYourIssConnectionString
        /******************************************************************************************************************************
        * Function Name    : GetNYourIssConnectionString()
        * Parameters       : string encryptedConString
        * Return Value     : string decryptedConStr
        * Description      : Accepts the encrypted connection string and decrypts to original connection string and returns to the calling program 
        * Author           : Bharath Kumar KC
        * Date Created     : 18-Nov-2015
        * Date Modified    :
        * Cooments         :
        * ******************************************************************************************************************************
        */

        public static string GetNYourIssConnectionString()
        {
            string conString = "";
            try
            {
                // System.Diagnostics.EventLog.WriteEntry("Application", "Inside the Method");

                //   RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\AgencyAdapter\NewYourIss", true);

                RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\GenericIntegration", true);

                //System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetNYourIssConnectionString reg -->" + reg.ToString());
                conString = GetDecryptedConnectionString(reg.GetValue("YourISS2DBConnectionString").ToString());

                // System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Conn String -->" + conString);

            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Conn String Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
            }

            //conString = @"Data Source=idcchnbizdb\Biztalkmetadb;Initial Catalog=HorizonDev04April2014;Integrated Security=SSPI;User ID=sa;Password=Inchcape1;Provider=SQLOLEDB";

            return conString;
        }
        #endregion

        #region GetDecryptedConnectionString
        /******************************************************************************************************************************
        * Function Name    : GetDecryptedConnectionString()
        * Parameters       : string encryptedConString
        * Return Value     : string decryptedConStr
        * Description      : Accepts the encrypted connection string and decrypts to original connection string and returns to the calling program
        * 
        * Author           : Bharath Kumar KC
        * Date Created     : 15-Feb-2014
        * Date Modified    :
        * Cooments         :
        * ******************************************************************************************************************************
        */
        private static string GetDecryptedConnectionString(string encryptedConString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;
            string decryptedConStr = "";
            try
            {

                byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
                byte[] cipherTextBytes = Convert.FromBase64String(encryptedConString);
                PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
                byte[] keyBytes = password.GetBytes(keysize / 8);
                RijndaelManaged symmetricKey = new RijndaelManaged();
                symmetricKey.Mode = CipherMode.CBC;
                ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
                MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
                CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                memoryStream.Close();
                cryptoStream.Close();
                decryptedConStr = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);


            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Decryption  Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDecryptedConnectionString-->{0}", exp.Message));
            }

            return decryptedConStr;
        }
        #endregion

        #region GetGZippedBytes
        //  /*****************************************************************************************************************************
        //* Function Name    : GetGZippedBytes()
        //* Parameters       : 
        //* Return Value     : string ZippedByte
        //* Description      : Convert string to ZippedBytes
        //* Author           : Bharath Kumar KC
        //* Date Created     : 21-Nov-2015
        //* Date Modified    :
        //* Cooments         :
        // * *****************************************************************************************************************************
        //*/

        public static string GetGZippedBytes(string strXML)
        {
            var bytes = Encoding.UTF8.GetBytes(strXML);

            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(mso, CompressionMode.Compress))
                {
                    //msi.CopyTo(gs);
                    CopyTo(msi, gs);
                }

             //   return mso.ToArray();
               return  Convert.ToBase64String(mso.ToArray());
            }
        }
        #endregion
        #region CopyTo
        private static void CopyTo(Stream src, Stream dest)
        {
            byte[] bytes = new byte[4096];

            int cnt;

            while ((cnt = src.Read(bytes, 0, bytes.Length)) != 0)
            {
                dest.Write(bytes, 0, cnt);
            }
        }
        #endregion

        public static int  GetAccountingOfficeCode(int PortCode)
        {
            int  AccCode = -1;
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    string conStr = GetNYourIssConnectionString();

                    con.ConnectionString = conStr.Replace("Provider=SQLOLEDB", "");

                    con.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string strSQL = "select ACCOFF.Id from Master.IssAccountingOfficePortMap ACCOFFMAP " +
                                            " join  Master.IssAccountingOffices ACCOFF" +
                                            "  on ACCOFFMAP.IssAccountingOfficeId = ACCOFF.Id " +
                                             " where " +
                                                " (ACCOFF.Name not like 'ENI%' and ACCOFF.Name not like 'CHAR%' ) and " +
                                                " ACCOFFMAP.PortId=" + PortCode;
                        cmd.Connection = con;
                        cmd.CommandText = strSQL;
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                           AccCode = reader.GetInt32(0) ;
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Error in Shipnet Common ->" + exp.Message);
            }
            return AccCode;
        }

        public static string GetUnZippedBytes(string ZipString)
        {
            byte[] bytes = Convert.FromBase64String(ZipString);
            string result = "";

            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                {
                    //gs.CopyTo(mso);
                    CopyTo(gs, mso);

                }
                result =  System.Text.Encoding.UTF8.GetString(mso.ToArray());
                if (result !="")
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(result);
                    result = doc.SelectSingleNode("//Code").InnerText;
                    result = result + "|" +  doc.SelectSingleNode("//Message").InnerText;

                }

                return result;
            }
        }
       
        public static string RemoveNamespace(XmlDocument xdoc)
        {
            // Regex to search for either xmlns:nsN="..." or xmlns="..."
            const string pattern = @"xmlns:?(\w+)?=""[\w:/.]*""";
            string xml = xdoc.OuterXml;

            Regex replace = new Regex(pattern);
            // Replace all occurances of the namespace declaration
            string temp = replace.Replace(xml, String.Empty);
            foreach (Match match in replace.Matches(xml))
            {
                // Loop through each Match in the Regex, this gives us the namespace aliases found
                if (match.Success && match.Groups.Count > 1)
                {
                    if (!String.IsNullOrEmpty(match.Groups[1].Value))
                    {
                        Regex alias = new Regex(@"\b" + match.Groups[1].Value + ":");
                        // Replace all occurances of the
                        temp = alias.Replace(temp, String.Empty);
                    }
                }
            }
            return temp;
        }

        public static int InsertOrUpdate_PortcallStatus( char TransactionStatus ,
	                        int Id,
	                        string  AccountId,
                            int SourceStatus,
                            string ErrorMessage,
                            string TransformedData,
                            string ResponseData
            )
        {
            int  result = -1;
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    string conStr =  GetBizConnectionString (); //   GetNYourIssConnectionString();

                    con.ConnectionString = conStr.Replace("Provider=SQLOLEDB", "");

                    System.Diagnostics.EventLog.WriteEntry("Application", con.ConnectionString);
                    con.Open();
                    System.Diagnostics.EventLog.WriteEntry("Application", "Open Complete");
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        
                        cmd.Connection = con;
                        cmd.CommandText = "Spu_InsertOrUpdate_PortcallStatus";
                        cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter pTransStatus =  new SqlParameter ("@TransactionStatus",SqlDbType.Char  , 1 );
                        pTransStatus.Value = TransactionStatus;
                        cmd.Parameters.Add(pTransStatus);

                        System.Diagnostics.EventLog.WriteEntry("Application", "ID-->" + Id);
                        SqlParameter pId = new SqlParameter("@Id",SqlDbType.Int);
                        pId.Value = Id;
                        cmd.Parameters.Add(pId);

                        SqlParameter pAccountId = new SqlParameter("@AccountId",SqlDbType.UniqueIdentifier );

                        Guid AccountGuid = new Guid(AccountId);

                        pAccountId.Value = AccountGuid;
                        cmd.Parameters.Add(pAccountId );

                        SqlParameter pSourceStatus = new SqlParameter("@SourceStatus",SqlDbType.Int );
                        pSourceStatus.Value = SourceStatus;
                        cmd.Parameters.Add(pSourceStatus);

                        SqlParameter pErrorMessage = new SqlParameter("@ErrorMessage",SqlDbType.NVarChar , -1);
                        pErrorMessage.Value = ErrorMessage;
                        cmd.Parameters.Add(pErrorMessage );

                       

                        SqlParameter pTransformedData = new SqlParameter("@TransformedData",SqlDbType.NVarChar , -1);
                        pTransformedData.Value = TransformedData;
                        cmd.Parameters.Add(pTransformedData );


                        SqlParameter pResponseData = new SqlParameter("@ResponseData", SqlDbType.NVarChar, -1);
                        pResponseData.Value = ResponseData;
                        cmd.Parameters.Add(pResponseData);

                        result = cmd.ExecuteNonQuery();
                        
                    }
                }
            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Error in common utility procedure InsertOrUpdate_PortcallStatus->" + exp.Message);
            }
            return result ;

        }

      //  #region GetDestinationURL
      //  /*****************************************************************************************************************************
      //* Function Name    : GetDestinationURL()
      //* Parameters       : 
      //* Return Value     : string PaspWcfUrlAddress
      //* Description      : Retrieves the PASP side WCF URL from the RegEdit file and returns to the calling program. 
      //* Author           : Sujatha B.M.
      //* Date Created     : 20-May-2014
      //* Date Modified    :
      //* Cooments         :
      // * *****************************************************************************************************************************
      //*/
      //  public static string GetDestinationURL(string Application)
      //  {
      //      string StrURL = "";
      //      try
      //      {
      //          using (SqlConnection con = new SqlConnection())
      //          {
      //              con.ConnectionString = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");

      //              //                    System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetDestinationURL reg -->" + con.ConnectionString.ToString());
      //              con.Open();
      //              using (SqlCommand cmd = new SqlCommand())
      //              {
      //                  cmd.Connection = con;
      //                  cmd.CommandText = "GetDestinationWcfUrl";
      //                  cmd.CommandType = CommandType.StoredProcedure;
      //                  SqlParameter application = new SqlParameter("@Application", SqlDbType.VarChar, 20);
      //                  application.Value = Application;
      //                  cmd.Parameters.Add(application);
      //                  using (SqlDataReader reader = cmd.ExecuteReader())
      //                  {
      //                      reader.Read();
      //                      StrURL = Convert.ToString(reader.GetValue(0));
      //                  }
      //              }
      //          }

      //      }
      //      catch (Exception exp)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDestinationURL-->{0}", exp.Message));

      //      }
      //      return StrURL;
      //  }
      //  #endregion

      //  #region ValidateXml
      //  /******************************************************************************************************************************
      //  * Function Name    : ValidateXml()
      //  * Parameters       : string Process, string Namespace, XmlDocument InputXmlDoc
      //  * Return Value     : string retVal
      //  * Description      : Validates the given Xml by comparing it with its Schema from Database
      //  * Author           : AJITH KUMAR R.S
      //  * Date Created     : 10-04-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static string ValidateXml(string Process, string StringXmlNamespace, XmlDocument InputXmlDoc)
      //  {
      //      // System.Diagnostics.EventLog.WriteEntry("Application", "Inside ValidateXml Method : ");
      //      string retVal = "";
      //      try
      //      {
      //          string SourceSchema = GetSchema(Process);
      //          string localStorage = Path.GetTempPath();
      //          string xsdFileName = Path.GetRandomFileName();
      //          File.WriteAllText(Path.Combine(localStorage, xsdFileName + ".xsd"), SourceSchema);
      //          XmlSchemaValidator validator = new XmlSchemaValidator();
      //          //System.Xml.Schema.XmlSchemaValidator validator = new System.Xml.Schema.XmlSchemaValidator();

      //          retVal = validator.ValidXmlDoc(InputXmlDoc.OuterXml, StringXmlNamespace, Path.Combine(localStorage, xsdFileName + ".xsd")).ToString();
      //          if (!validator.IsValidXml || retVal.Contains("False"))
      //          {
      //              string validationErrorMessage = validator.ValidationError;
      //              return validationErrorMessage;
      //          }
      //          //System.Diagnostics.EventLog.WriteEntry("Application", "ValidateXml Return Message  :");
      //      }
      //      catch (Exception ex)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in ValidateXml Exception Message-->{0}", ex.Message));
      //          //System.Diagnostics.EventLog.WriteEntry("Application", "ValidateXml Exception Message  :" + ex.Message);
      //      }
      //      return retVal;
      //  }
      //  #endregion

      //  #region GetSchema
      //  /******************************************************************************************************************************
      //  * Function Name    : GetSchema()
      //  * Parameters       : string Process
      //  * Return Value     : string retVal
      //  * Description      : Gets the Schema from Database based on the ProcessName
      //  * Author           : AJITH KUMAR R.S
      //  * Date Created     : 10-04-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static string GetSchema(string Process)
      //  {
      //      string Schema = "";
      //      try
      //      {
      //          string Connectionstring = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");
      //          //string SqlQuery = "Select XMLSchema from inputschema where ProcessName = '" + Process + "'";
      //          using (SqlConnection objSqlConnection = new SqlConnection(Connectionstring))
      //          {
      //              objSqlConnection.Open();
      //              using (SqlCommand objSqlCommand = new SqlCommand())
      //              {
      //                  SqlDataReader objSqlDataReader;
      //                  objSqlCommand.Connection = objSqlConnection;
      //                  objSqlCommand.CommandText = "HAA_GetXMLSchema";
      //                  objSqlCommand.CommandType = CommandType.StoredProcedure;
      //                  SqlParameter sqlProcess = new SqlParameter("@ProcessName", SqlDbType.VarChar, 100);
      //                  sqlProcess.Value = Process;
      //                  objSqlCommand.Parameters.Add(sqlProcess);
      //                  objSqlDataReader = objSqlCommand.ExecuteReader();
      //                  while (objSqlDataReader.Read())
      //                  {
      //                      Schema = objSqlDataReader[0].ToString();
      //                  }
      //                  objSqlDataReader.Close();
      //                  objSqlConnection.Close();
      //                  //System.Diagnostics.EventLog.WriteEntry("Application", "Schema from Database :" + Schema);
      //              }
      //          }
      //      }
      //      catch (Exception ex)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetSchema Exception Message-->{0}", ex.Message));
      //          System.Diagnostics.EventLog.WriteEntry("Application", "GetSchema Exception Message  :" + ex.Message);
      //      }
      //      return Schema;
      //  }
      //  #endregion

      //  #region GetEmailBody
      //  /******************************************************************************************************************************
      //  * Function Name    : GetInvalidMessageEmailBody()
      //  * Parameters       : 
      //  * Return Value     : string EmailBody
      //  * Description      : Returns the Email Body
      //  * Author           : AJITH KUMAR R.S
      //  * Date Created     : 09-04-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static string GetEmailBody(string process)
      //  {
      //      string EmailBody = "";
      //      try
      //      {
      //          string Connectionstring = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");
      //          using (SqlConnection objSqlConnection = new SqlConnection(Connectionstring))
      //          {
      //              objSqlConnection.Open();
      //              using (SqlCommand objSqlCommand = new SqlCommand())
      //              {
      //                  objSqlCommand.Connection = objSqlConnection;
      //                  objSqlCommand.CommandText = "HAA_GetEMailBody";
      //                  objSqlCommand.CommandType = CommandType.StoredProcedure;
      //                  SqlParameter sqlprocess = new SqlParameter("@ProcessName", SqlDbType.VarChar, 20);
      //                  sqlprocess.Value = process;
      //                  objSqlCommand.Parameters.Add(sqlprocess);
      //                  SqlDataReader objSqlDataReader = objSqlCommand.ExecuteReader();
      //                  while (objSqlDataReader.Read())
      //                  {
      //                      EmailBody = objSqlDataReader[0].ToString();
      //                  }
      //                  objSqlDataReader.Close();
      //                  objSqlConnection.Close();
      //                  //System.Diagnostics.EventLog.WriteEntry("Application", "GetEmailBody method  input  :" + process);
      //                  //string Query = "select Body from Email_Details where process = '" + process + "'";
      //                  //string EmailBody = GetValue(Query);                       
      //              }
      //          }
      //      }
      //      catch (Exception ex)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetEmailBody  Exception Message-->{0}", ex.Message));
      //          System.Diagnostics.EventLog.WriteEntry("Application", "GetEmailBody Exception Message  :" + ex.Message);
      //      }
      //      return EmailBody;
      //  }
      //  #endregion

      //  #region GetEmailSubject
      //  /******************************************************************************************************************************
      //  * Function Name    : GetEmailSubject()
      //  * Parameters       : string process
      //  * Return Value     : string EmailSubject
      //  * Description      : Returns the Email Subject
      //  * Author           : B.M.Sujatha
      //  * Date Created     : 02-01-2015
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static string GetEmailSubject(string process)
      //  {
      //      string EmailSubject = "";
      //      try
      //      {
      //          using (SqlConnection con = new SqlConnection())
      //          {
      //              con.ConnectionString = GetBizConnectionString().Replace("Provider=SQLOLEDB", "");
      //              con.Open();
      //              using (SqlCommand cmd = new SqlCommand())
      //              {
      //                  cmd.Connection = con;
      //                  cmd.CommandText = "HAA_GetEMailSubject";
      //                  cmd.CommandType = CommandType.StoredProcedure;
      //                  SqlParameter application = new SqlParameter("@ProcessName", SqlDbType.VarChar, 100);
      //                  application.Value = process;
      //                  cmd.Parameters.Add(application);
      //                  using (SqlDataReader reader = cmd.ExecuteReader())
      //                  {
      //                      reader.Read();
      //                      EmailSubject = Convert.ToString(reader.GetValue(0));
      //                  }
      //              }
      //          }

      //      }
      //      catch (Exception exp)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDestinationURL-->{0}", exp.Message));
      //          System.Diagnostics.EventLog.WriteEntry("Application", "GetEmailSubject Exception Message  :" + exp.Message);
      //      }
      //      return EmailSubject;
      //  }
      //  #endregion

      //  //////#region GetValue
      //  ///////******************************************************************************************************************************
      //  //////* Function Name    : GetValue()
      //  //////* Parameters       : string Query
      //  //////* Return Value     : 
      //  //////* Description      : Returns the Email Body
      //  //////* Author           : AJITH KUMAR R.S
      //  //////* Date Created     : 09-04-2014
      //  //////* Date Modified    :
      //  //////* Comments         :
      //  //////* ******************************************************************************************************************************
      //  //////*/
      //  //////private static string GetValue(string SqlQuery)
      //  //////{
      //  //////    try
      //  //////    {
      //  //////        using (SqlConnection con = new SqlConnection(@"Data Source=SHIPCHN008\MSSQL2012;Initial Catalog=HAA_Integration;Integrated Security=True"))
      //  //////        {
      //  //////            using (SqlCommand cmd = new SqlCommand())
      //  //////            {
      //  //////                cmd.Connection = con;
      //  //////                cmd.CommandType = CommandType.Text;
      //  //////                cmd.CommandText = SqlQuery;
      //  //////                con.Open();
      //  //////                var res = cmd.ExecuteScalar();
      //  //////                if (res == null) { return string.Empty; }
      //  //////                return Convert.ToString(res);
      //  //////            }
      //  //////        }
      //  //////    }
      //  //////    finally { }
      //  //////}
      //  //////#endregion

        #region SyncAppointmentCheckMandatory
        /******************************************************************************************************************************
        * Function Name    : SyncAppointmentCheckMandatory()
        * Parameters       : XmlDocument xmldoc
        * Return Value     : Return XmlDocument
        * Description      : Check the Mandatory field for Sync Appointment
        * Author           : B.M.Sujatha
        * Date Created     : 09-07-2014
        * Date Modified    : 06-01-2015
        * Comments         :
        * ******************************************************************************************************************************
        */
        public static XmlDocument PortCallCreateMandatory(XmlDocument xmldoc)
        {
            StringBuilder ErrorMessage = new StringBuilder();
            StringBuilder NonMandatoryErrorMsg = new StringBuilder();
            XmlDocument doc = new XmlDocument();
            XmlElement rootelement = (XmlElement)doc.AppendChild(doc.CreateElement("Root"));

            try
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Inside the helper class Mandatory xmldoc " + xmldoc.OuterXml);

                XmlNamespaceManager tempns = new XmlNamespaceManager(xmldoc.NameTable);
                tempns.AddNamespace("ns0", "http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate");

                XmlNode PortId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Port/Id", tempns);
                if (PortId.InnerText == null || PortId.InnerText == "") { ErrorMessage.Append("PortId is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After First Validation");
                XmlNode PortName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Port/Name", tempns);
                if (PortName.InnerText == null || PortName.InnerText == "") { ErrorMessage.Append("PortName is not configured or missing. <br>"); }

                XmlNode PortCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Port/Code", tempns);
                if (PortCode.InnerText == null || PortCode.InnerText == "") { ErrorMessage.Append("PortCode is not configured or missing. <br>"); }

                System.Diagnostics.EventLog.WriteEntry("Application", "After Port");
                XmlNode PrincipalId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/Principal/Id", tempns);
                if (PrincipalId.InnerText == null || PrincipalId.InnerText == "") { ErrorMessage.Append("PrincipalId is not configured or missing. <br>"); }

                XmlNode PrincipalCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/Principal/Code", tempns);
                if (PrincipalCode.InnerText == null || PrincipalCode.InnerText == "") { ErrorMessage.Append("PrincipalCode is not configured or missing. <br>"); }

                XmlNode PrincipalName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/Principal/Name", tempns);
                if (PrincipalName.InnerText == null || PrincipalName.InnerText == "") { ErrorMessage.Append("PrincipalName is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After Principal");
                XmlNode AccountingOfficeId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/AccountingOffice/Id", tempns);
                if (AccountingOfficeId.InnerText == null || AccountingOfficeId.InnerText == "") { ErrorMessage.Append("AccountingOfficeId is not configured or missing. <br>"); }

                XmlNode AccountingOfficeName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/AccountingOffice/Name", tempns);
                if (AccountingOfficeName.InnerText == null || AccountingOfficeName.InnerText == "") { ErrorMessage.Append("AccountingOfficeName is not configured or missing. <br>"); }

                XmlNode AccountingOfficeCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/AccountingOffice/Code", tempns);
                if (AccountingOfficeCode.InnerText == null || AccountingOfficeCode.InnerText == "") { ErrorMessage.Append("AccountingOfficeCode is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After AccountingOffice");
                XmlNode MainCommodityId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/MainCommodity/Id", tempns);
                if (MainCommodityId.InnerText == null || MainCommodityId.InnerText == "") { ErrorMessage.Append("MainCommodityId is not configured or missing. <br>"); }

                XmlNode MainCommodityName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/MainCommodity/Name", tempns);
                if (MainCommodityName.InnerText == null || MainCommodityName.InnerText == "") { ErrorMessage.Append("MainCommodityName is not configured or missing. <br>"); }

                XmlNode MainCommodityCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/MainCommodity/Code", tempns);
                if (MainCommodityCode.InnerText == null || MainCommodityCode.InnerText == "") { ErrorMessage.Append("MainCommodityCode is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After MainCommodity");
                XmlNode VesselId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Vessel/Id", tempns);
                if (VesselId.InnerText == null || VesselId.InnerText == "") { ErrorMessage.Append("VesselId is not configured or missing. <br>"); }

                XmlNode VesselName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Vessel/Name", tempns);
                if (VesselName.InnerText == null || VesselName.InnerText == "") { ErrorMessage.Append("VesselName is not configured or missing. <br>"); }

                XmlNode VesselCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Vessel/Imo", tempns);
                if (VesselCode.InnerText == null || VesselCode.InnerText == "") { ErrorMessage.Append("VesselImo is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After Vessel");
                XmlNode PortCallOperationsId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/PortOperation/Id", tempns);
                if (PortCallOperationsId.InnerText == null || PortCallOperationsId.InnerText == "") { ErrorMessage.Append("PortOperationId is not configured or missing. <br>"); }

                XmlNode PortCallOperationsName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/PortOperation/Name", tempns);
                if (PortCallOperationsName.InnerText == null || PortCallOperationsName.InnerText == "") { ErrorMessage.Append("PortOperationName is not configured or missing. <br>"); }

                XmlNode PortCallOperationsCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/PortOperation/Code", tempns);
                if (PortCallOperationsCode.InnerText == null || PortCallOperationsCode.InnerText == "") { ErrorMessage.Append("PortOperationCode is not configured or missing. <br>"); }
                System.Diagnostics.EventLog.WriteEntry("Application", "After PortCallOperations");
                XmlNode PerformingAgentId = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/PerformingAgent/Id", tempns);
                if (PerformingAgentId.InnerText == null || PerformingAgentId.InnerText == "") { ErrorMessage.Append("PerformingAgentId is not configured or missing. <br>"); }

                XmlNode PerformingAgentName = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/PerformingAgent/Name", tempns);
                if (PerformingAgentName.InnerText == null || PerformingAgentName.InnerText == "") { ErrorMessage.Append("PerformingAgentName is not configured or missing. <br>"); }

                XmlNode PerformingAgentCode = xmldoc.SelectSingleNode("//ns0:YourIss2Appointment/Appointments/PerformingAgent/Code", tempns);
                if (PerformingAgentCode.InnerText == null || PerformingAgentCode.InnerText == "") { ErrorMessage.Append("PerformingAgentCode is not configured or missing. <br>"); }

                System.Diagnostics.EventLog.WriteEntry("Application", "After PerformingAgent");
                if (string.IsNullOrEmpty(ErrorMessage.ToString()))
                {
                    rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
                }
                else
                {
                    rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
                }

                rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ErrorMessage.ToString();

                System.Diagnostics.EventLog.WriteEntry("Application", "Validation Exception Inside SN Common" + ErrorMessage.ToString());
                
                return doc;

                //return new xmls MandatoryValidation() { IsValid = true, Message = ErrorMessage.ToString() };
            }
            catch (Exception ex)
            {
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in SyncAppointmentCheckMandatory Exception Message-->{0}", ex.Message));
                rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
                rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ex.ToString();

                System.Diagnostics.EventLog.WriteEntry("Application" , "Exception Inside SN Common" + ex.Message );
                
                return doc;                
            }
        }
        #endregion

      //  #region LinkAppointmentCheckMandatory
      //  /******************************************************************************************************************************
      //  * Function Name    : LinkAppointmentCheckMandatory()
      //  * Parameters       : XmlDocument xmldoc
      //  * Return Value     : Return XmlDocument
      //  * Description      : Check the Mandatory field for Link Appointment
      //  * Author           : B.M.Sujatha
      //  * Date Created     : 15-07-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static XmlDocument LinkAppointmentCheckMandatory(XmlDocument xmldoc)
      //  {
      //      Boolean ErrorFlag = false; //to capture exception 
      //      StringBuilder ErrorMessage = new StringBuilder();
      //      StringBuilder NonMandatoryErrorMsg = new StringBuilder();
      //      XmlDocument doc = new XmlDocument();
      //      XmlElement rootelement = (XmlElement)doc.AppendChild(doc.CreateElement("Root"));

      //      try
      //      {
      //          System.Diagnostics.EventLog.WriteEntry("Application", "Inside the helper class Mandatory xmldoc " + xmldoc.OuterXml);

      //          XmlNamespaceManager tempns = new XmlNamespaceManager(xmldoc.NameTable);
      //          tempns.AddNamespace("ns0", "http://schema.iss-shipping.com/marine/appointment/pasp");

      //          XmlNode PASPAppointmentNumber = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/ExternalJobCode", tempns);
      //          if (PASPAppointmentNumber.InnerText == null || PASPAppointmentNumber.InnerText == "") { ErrorMessage.Append("PASPAppointmentNumber is missing. <br>"); }

      //          XmlNode ISSAccountingOffice = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/ISSAccountingOffice", tempns);
      //          if (ISSAccountingOffice.Attributes["Id"].Value == null || ISSAccountingOffice.Attributes["Id"].Value == "") { ErrorMessage.Append("ISSAccountingOffice is missing. <br>"); }

      //          XmlNode Principal = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Principal", tempns);
      //          if (Principal.Attributes["Id"].Value == null || Principal.Attributes["Id"].Value.Trim() == "") { ErrorMessage.Append("Mapping for Principal is missing. <br>"); }

      //          XmlNode Commodity = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Commodity", tempns);
      //          if (Commodity.Attributes["Id"].Value == null || Commodity.Attributes["Id"].Value.Trim() == "") { ErrorMessage.Append("Mapping for Commodity is missing. <br>"); }

      //          XmlNode Ports = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Ports/Port", tempns);
      //          if (Ports.Attributes["Id"].Value == null || Ports.Attributes["Id"].Value.Trim() == "")
      //          {
      //              string PaspPort;
      //              PaspPort = Ports.Attributes["PaspCode"].Value;
      //              ErrorMessage.Append("Mapping for Ports " + PaspPort + " is missing. <br>");
      //          }

      //          XmlNode Vessel = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Vessel", tempns);
      //          if (Vessel.Attributes["Id"].Value == null || Vessel.Attributes["Id"].Value.Trim() == "")
      //          {
      //              string PaspVessel;
      //              PaspVessel = Vessel.Attributes["PaspCode"].Value;
      //              ErrorMessage.Append("Mapping for Vessel " + PaspVessel + " is missing. <br>");
      //          }

      //          XmlNode PerformingAgent = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Agents/PerformingAgent", tempns);
      //          if (PerformingAgent.Attributes["Id"].Value == null || PerformingAgent.Attributes["Id"].Value.Trim() == "")
      //          {
      //              string PaspAgent;
      //              PaspAgent = PerformingAgent.Attributes["PaspCode"].Value;
      //              ErrorMessage.Append("Mapping for PerformingAgent " + PaspAgent + " is missing. <br>");
      //          }

      //          XmlNode PortOperation = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/PortOperation", tempns);
      //          if (PortOperation.Attributes["Id"].Value == null || PortOperation.Attributes["Id"].Value.Trim() == "")
      //          {
      //              string PaspOperation;
      //              PaspOperation = PortOperation.Attributes["PaspCode"].Value;
      //              ErrorMessage.Append("Mapping for PortOperation " + PaspOperation + " is missing. <br>");
      //          }

      //          /* System.Diagnostics.EventLog.WriteEntry("Application", "PASPAppointmentNumber : " + PASPAppointmentNumber.InnerText);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "PortCallNumber : " + PortCallNumber.InnerText);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "Ports : " + Ports.Attributes["Id"].Value);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "Vessel : " + Vessel.Attributes["Id"].Value);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "PerformingAgent : " + PerformingAgent.Attributes["Id"].Value);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "PortOperation : " + PortOperation.Attributes["Id"].Value);
      //           System.Diagnostics.EventLog.WriteEntry("Application", "Error Message : " + ErrorMessage.ToString());*/

      //          if (string.IsNullOrEmpty(ErrorMessage.ToString()))
      //          {
      //              //No error then set IsValid to True
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              //Error then set IsValid to False
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          }

      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ErrorMessage.ToString();
      //          ErrorFlag = true;
      //          //begin
      //          XmlNode Charterer = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Charterer", tempns);
      //          if (Charterer != null)
      //          {
      //              if (Charterer.Attributes["Id"].Value == null || Charterer.Attributes["Id"].Value.Trim() == "")
      //              {

      //                  string PaspCharterer;

      //                  PaspCharterer = Charterer.Attributes["PaspCode"].Value;
      //                  NonMandatoryErrorMsg.Append("Mapping for Charterer " + PaspCharterer + " is missing. <br>");
      //              }
      //          }

      //          XmlNode PreviousPort = xmldoc.SelectSingleNode("/ns0:PortCall/Appointment/Ports/PreviousPort", tempns);
      //          if (PreviousPort != null)
      //          {
      //              if (PreviousPort.Attributes["Id"].Value == null || PreviousPort.Attributes["Id"].Value.Trim() == "")
      //              {
      //                  string PaspPreviousPort;
      //                  PaspPreviousPort = PreviousPort.Attributes["PaspCode"].Value;
      //                  NonMandatoryErrorMsg.Append("Mapping for PreviousPort " + PaspPreviousPort + " is missing. <br>");
      //              }
      //          }

      //          XmlNode NextPort = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Ports/NextPort", tempns);
      //          if (NextPort != null)
      //          {
      //              if (NextPort.Attributes["Id"].Value == null || NextPort.Attributes["Id"].Value.Trim() == "")
      //              {
      //                  string PaspNextPort;
      //                  PaspNextPort = NextPort.Attributes["PaspCode"].Value;
      //                  NonMandatoryErrorMsg.Append("Mapping for NextPort " + PaspNextPort + " is missing. <br>");
      //              }
      //          }

      //          // XmlNode ControllingAgent = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Agents/ControllingAgent", tempns);
      //          //if (ControllingAgent.Attributes["Id"].Value == null || ControllingAgent.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for ControllingAgent is missing. <br>"); }

      //          /* These fields are not transfered from pasp to youriss2
      //                          XmlNodeList Rotationlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/Rotations/Rotation", tempns);
      //                          foreach (XmlNode RotationNode in Rotationlist)
      //                          {
      //                              XmlNode Terminal = RotationNode.SelectSingleNode("Terminal", tempns);
      //                              if (Terminal != null)
      //                              {
      //                                  if (Terminal.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (Terminal.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>");
      //                              }

      //                              XmlNode Berth = xmldoc.SelectSingleNode("Berth", tempns);
      //                              if (Berth != null)
      //                              {
      //                                  if (Berth.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (Berth.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>");
      //                              }

      //                          }

      //                          XmlNodeList Draftlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/Drafts/Draft", tempns);
      //                          foreach (XmlNode DraftNode in Draftlist)
      //                          {
      //                              XmlNode UOM = xmldoc.SelectSingleNode("UOM", tempns);
      //                              if (UOM != null)
      //                              {
      //                                  if (UOM.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (UOM.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Draft UOM is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Draft UOM is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Draft UOM is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Draft UOM is missing. <br>");
      //                              }
      //                          }

      //                          XmlNodeList Eventlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/OperationEvents/OperationEvent", tempns);
      //                          foreach (XmlNode EventNode in Eventlist)
      //                          {
      //                              XmlNode EventBerth = EventNode.SelectSingleNode("Berth", tempns);
      //                              if (EventBerth != null)
      //                              {
      //                                  if (EventBerth.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (EventBerth.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>");
      //                              }

      //                              XmlNode EventTerminal = EventNode.SelectSingleNode("Terminal", tempns);
      //                              if (EventTerminal != null)
      //                              {
      //                                  if (EventTerminal.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (EventTerminal.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>");
      //                              }

      //                              XmlNode Event = EventNode.SelectSingleNode("Event", tempns);
      //                              if (Event != null)
      //                              {
      //                                  if (Event.Attributes.GetNamedItem("Id") != null)
      //                                  {
      //                                      if (Event.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Timesheet Event is missing. <br>"); }
      //                                      else
      //                                      {
      //                                          NonMandatoryErrorMsg.Append("Mapping for Timesheet Event is missing. <br>");
      //                                      }
      //                                  }
      //                                  else
      //                                  {
      //                                      NonMandatoryErrorMsg.Append("Mapping for Timesheet Event is missing. <br>");
      //                                  }
      //                              }
      //                              else
      //                              {
      //                                  NonMandatoryErrorMsg.Append("Mapping for Timesheet Event is missing. <br>");
      //                              }
      //                          } 
      //                          */

      //          if (string.IsNullOrEmpty(NonMandatoryErrorMsg.ToString()))
      //          {
      //              //No error then set IsNonMandatoryValid to True
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              //Error then set IsNonMandatoryValid to False
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "False";
      //          }
      //          rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = NonMandatoryErrorMsg.ToString();


      //          //end
      //          return doc;

      //          //return new xmls MandatoryValidation() { IsValid = true, Message = ErrorMessage.ToString() };
      //      }
      //      catch (Exception ex)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in LinkAppointmentCheckMandatory Exception Message-->{0}", ex.Message));
      //          if (ErrorFlag == false)
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //              rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ex.ToString();
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "True";
      //              rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = "";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "False";
      //              rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = ex.ToString();
      //          }

      //          return doc;
      //          //return new MandatoryValidation() { IsValid = false, Message = ex.ToString() };
      //      }
      //  }
      //  #endregion

      //  #region SyncYourIss2ToPaspApptCheckMandatory
      //  /******************************************************************************************************************************
      //  * Function Name    : SyncYourIss2ToPaspApptCheckMandatory()
      //  * Parameters       : XmlDocument xmldoc
      //  * Return Value     : Return XmlDocument
      //  * Description      : Check the Mandatory & Non Mandatory field for Sync Appointment from YourISS2 to PASP
      //  * Author           : B.M.Sujatha
      //  * Date Created     : 15-07-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static XmlDocument SyncYourIss2ToPaspApptCheckMandatory(XmlDocument xmldoc)
      //  {
      //      StringBuilder ErrorMessage = new StringBuilder();
      //      StringBuilder NonMandatoryErrorMsg = new StringBuilder();
      //      XmlDocument doc = new XmlDocument();
      //      XmlElement rootelement = (XmlElement)doc.AppendChild(doc.CreateElement("Root"));

      //      try
      //      {
      //          //System.Diagnostics.EventLog.WriteEntry("Application", "Inside the helper class Mandatory xmldoc " + xmldoc.OuterXml);

      //          XmlNamespaceManager tempns = new XmlNamespaceManager(xmldoc.NameTable);
      //          tempns.AddNamespace("ns0", "http://schema.iss-shipping.com/hub/appointment/pasp");

      //          XmlNode PASPAppointmentNumber = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/PASPAppointmentNumber", tempns);
      //          if (PASPAppointmentNumber != null)
      //          {
      //              if (PASPAppointmentNumber.InnerText == null || PASPAppointmentNumber.InnerText == "") { ErrorMessage.Append("PASPAppointmentNumber is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PASPAppointmentNumber is missing. <br>");
      //          }

      //          XmlNode PortCallNumber = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/PortCallNumber", tempns);
      //          if (PortCallNumber != null)
      //          {
      //              if (PortCallNumber.InnerText == null || PortCallNumber.InnerText == "") { ErrorMessage.Append("PortCallNumber is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PortCallNumber is missing. <br>");
      //          }

      //          //XmlNode Ports = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Ports/Port", tempns);
      //          //if (Ports != null)
      //          //{
      //          //    if (Ports.Attributes["Code"].Value == null || Ports.Attributes["Code"].Value == "") { ErrorMessage.Append("Mapping for Ports is missing. <br>"); }
      //          //}
      //          //else
      //          //{
      //          //    ErrorMessage.Append("Mapping for Ports is missing. <br>");
      //          //}

      //          //XmlNode Vessel = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Vessel", tempns);
      //          //if (Vessel != null)
      //          //{
      //          //    if (Vessel.Attributes.Count > 0) //.Value != null)
      //          //    {
      //          //        if (Vessel.Attributes.GetNamedItem("Code") != null)
      //          //        {
      //          //            if ( Vessel.Attributes["Code"].Value == "") { ErrorMessage.Append("Mapping for Vessel is missing. <br>"); }
      //          //        }
      //          //    }
      //          //    else
      //          //    {
      //          //        ErrorMessage.Append("Mapping for Vessel is missing. <br>");
      //          //    }
      //          //}
      //          //else
      //          //{
      //          //    ErrorMessage.Append("Mapping for Vessel is missing. <br>");
      //          //}

      //          //XmlNode PerformingAgent = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Agents/PerformingAgent", tempns);
      //          //if (PerformingAgent != null)
      //          //{
      //          //    if (PerformingAgent.Attributes["Code"].Value == null || PerformingAgent.Attributes["Code"].Value == "") { ErrorMessage.Append("Mapping for PerformingAgent is missing. <br>"); }
      //          //}
      //          //else
      //          //{
      //          //    ErrorMessage.Append("Mapping for PerformingAgent is missing. <br>");
      //          //}

      //          //XmlNode PortOperation = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/CargoActivity", tempns);
      //          //if (PortOperation != null)
      //          //{
      //          //    if (PortOperation.Attributes["Code"].Value == null || PortOperation.Attributes["Code"].Value == "") { ErrorMessage.Append("Mapping for PortOperation is missing. <br>"); }
      //          //}
      //          //else
      //          //{
      //          //    ErrorMessage.Append("Mapping for PortOperation is missing. <br>");
      //          //}


      //          //XmlNode ControllingAgent = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Agents/ControllingAgent", tempns);
      //          //if (ControllingAgent != null)
      //          //{
      //          //    if (ControllingAgent.Attributes.Count > 0) //.Value != null)
      //          //    {
      //          //        if (ControllingAgent.Attributes.GetNamedItem("Code") != null)
      //          //        {
      //          //            if (ControllingAgent.Attributes.GetNamedItem("Code").Value == null || ControllingAgent.Attributes.GetNamedItem("Code").Value == "")
      //          //            {
      //          //                NonMandatoryErrorMsg.Append("Mapping for ControllingAgent is missing. <br>");
      //          //            }
      //          //        }
      //          //        else
      //          //        {
      //          //            NonMandatoryErrorMsg.Append("Mapping for ControllingAgent is missing. <br>");
      //          //        }
      //          //    }
      //          //}
      //          //else
      //          //{
      //          //    NonMandatoryErrorMsg.Append("Mapping for ControllingAgent is missing. <br>");
      //          //}
      //          //XmlNode Terminal = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Terminal", tempns);
      //          //if (Terminal != null)
      //          //{
      //          //    if (Terminal.Attributes["Id"].Value == null || Terminal.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>"); }
      //          //}
      //          //else
      //          //{
      //          //    NonMandatoryErrorMsg.Append("Mapping for Terminal is missing. <br>");
      //          //}
      //          //XmlNode Berth = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Berth", tempns);
      //          //if (Berth != null)
      //          //{
      //          //    if (Berth.Attributes["Id"].Value == null || Berth.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>"); }
      //          //}
      //          //else
      //          //{
      //          //    NonMandatoryErrorMsg.Append("Mapping for Berth is missing. <br>");
      //          //}




      //          //Non Mandatory Feild checks - Begin
      //          //Charterer are not transfered from YourIss2 to Pasp
      //          // XmlNode Charterer = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Charterer", tempns);
      //          // if (Charterer.Attributes["Code"].Value == null || Charterer.Attributes["Code"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Charterer is missing. <br>"); }

      //          XmlNode PreviousPort = xmldoc.SelectSingleNode("/ns0:PortCall/Appointment/Ports/PreviousPort", tempns);

      //          if (PreviousPort != null)
      //          {
      //              string YourIss2PreviousPort = PreviousPort.Attributes["YourIss2Id"].Value;
      //              if (PreviousPort.Attributes["Code"].Value == null || PreviousPort.Attributes["Code"].Value == "")
      //              { NonMandatoryErrorMsg.Append("Mapping for PreviousPort " + YourIss2PreviousPort + " is missing. <br>"); }
      //          }
      //          //else
      //          //{
      //          //    NonMandatoryErrorMsg.Append("Mapping for PreviousPort " + YourIss2PreviousPort + " is missing. <br>");
      //          //}

      //          XmlNode NextPort = xmldoc.SelectSingleNode("//ns0:PortCall/Appointment/Ports/NextPort", tempns);

      //          if (NextPort != null)
      //          {
      //              string YourIss2NextPort = NextPort.Attributes["YourIss2Id"].Value;
      //              if (NextPort.Attributes["Code"].Value == null || NextPort.Attributes["Code"].Value == "")
      //              {
      //                  NonMandatoryErrorMsg.Append("Mapping for NextPort " + YourIss2NextPort + " is missing. <br>");
      //              }
      //          }
      //          //else
      //          //{
      //          //    NonMandatoryErrorMsg.Append("Mapping for NextPort " + YourIss2NextPort + " is missing. <br>");
      //          //}

      //          XmlNodeList Draftlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/Drafts/Draft", tempns);
      //          foreach (XmlNode Draftnode in Draftlist)
      //          {
      //              XmlNode DraftUOM = Draftnode.SelectSingleNode("Unit", tempns);

      //              if (DraftUOM != null)
      //              {
      //                  string YourIss2DraftUnit = DraftUOM.Attributes["YourIss2Id"].Value;
      //                  if (DraftUOM.Attributes.GetNamedItem("Code") != null)
      //                  {
      //                      if (DraftUOM.Attributes["Code"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Draft Unit is missing. <br>"); }
      //                  }
      //                  else
      //                  {
      //                      NonMandatoryErrorMsg.Append("Mapping for Draft Unit " + YourIss2DraftUnit + " is missing. <br>");
      //                  }
      //              }
      //              //else
      //              //{
      //              //    NonMandatoryErrorMsg.Append("Mapping for Draft Unit " + YourIss2DraftUnit + " is missing. <br>");
      //              //}
      //          }
      //          XmlNodeList Bunkerlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/Bunkers/Bunker", tempns);
      //          foreach (XmlNode Bunkernode in Bunkerlist)
      //          {
      //              XmlNode BunkersUOM = Bunkernode.SelectSingleNode("Unit", tempns);

      //              if (BunkersUOM != null)
      //              {
      //                  string YourIss2BunkerUnit = BunkersUOM.Attributes["YourIss2Id"].Value;
      //                  if (BunkersUOM.Attributes["Code"].Value == "")
      //                  { NonMandatoryErrorMsg.Append("Mapping for Bunkers Unit " + YourIss2BunkerUnit + " is missing. <br>"); }
      //              }
      //              //else
      //              //{ NonMandatoryErrorMsg.Append("Mapping for Bunkers Unit " + YourIss2BunkerUnit + " is missing. <br>"); }
      //          }

      //          XmlNodeList Commoditylist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/BookingDetails/BookingDetail", tempns);
      //          foreach (XmlNode Commoditynode in Commoditylist)
      //          {
      //              XmlNode CommodityDetail = Commoditynode.SelectSingleNode("CommodityDetail", tempns);

      //              if (CommodityDetail != null)
      //              {
      //                  string YourIss2Commodity = CommodityDetail.Attributes["YourIss2Id"].Value;
      //                  if (CommodityDetail.Attributes.GetNamedItem("Code") != null)
      //                  {
      //                      if (CommodityDetail.Attributes["Code"].Value == null || CommodityDetail.Attributes["Code"].Value == "")
      //                      { NonMandatoryErrorMsg.Append("Mapping for CommodityDetail " + YourIss2Commodity + " is missing. <br>"); }
      //                  }
      //              }
      //              //else
      //              //{
      //              //    NonMandatoryErrorMsg.Append("Mapping for CommodityDetail " + YourIss2Commodity + " is missing. <br>");
      //              //}

      //              XmlNode CargoUnit = Commoditynode.SelectSingleNode("Unit", tempns);

      //              if (CargoUnit != null)
      //              {
      //                  string YourIss2CargoUnit = CargoUnit.Attributes["YourIss2Id"].Value;
      //                  if (CargoUnit.Attributes.GetNamedItem("Code") != null)
      //                  {
      //                      if (CargoUnit.Attributes["Code"].Value == null || CargoUnit.Attributes["Code"].Value == "")
      //                      { NonMandatoryErrorMsg.Append("Mapping for Cargo Unit " + YourIss2CargoUnit + " is missing. <br>"); }
      //                  }
      //              }
      //              //else
      //              //{
      //              //    NonMandatoryErrorMsg.Append("Mapping for Cargo Unit " + YourIss2CargoUnit + " is missing. <br>");
      //              //}

      //              //Cargo temperature is not transfered from YourIss2 to Pasp 11-Sep- 
      //              //XmlNode CargoTemperature = Commoditynode.SelectSingleNode("CargoTemperature/Unit", tempns);
      //              //if (CargoTemperature != null)
      //              //{
      //              //    if (CargoTemperature.Attributes.GetNamedItem("Code") != null)
      //              //    {
      //              //        if (CargoTemperature.Attributes["Code"].Value == null || CargoTemperature.Attributes["Code"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Cargo Temperature Unit is missing. <br>"); }
      //              //    }
      //              //}
      //              //else
      //              //{
      //              //    NonMandatoryErrorMsg.Append("Mapping for Cargo Temperature Unit is missing. <br>");
      //              //}

      //          }


      //          XmlNodeList Rotaionlist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/TerminalBerths/TerminalBerth", tempns);

      //          foreach (XmlNode RotaionNode in Rotaionlist)
      //          {
      //              XmlNode RotationTerminal = RotaionNode.SelectSingleNode("Terminal", tempns);

      //              if (RotationTerminal.Attributes.GetNamedItem("Id") != null)
      //              {
      //                  string YourIss2RotationTerminal = RotationTerminal.Attributes["YourIss2Id"].Value;
      //                  if (RotationTerminal.Attributes["Id"].Value == null || RotationTerminal.Attributes["Id"].Value == "")
      //                  { NonMandatoryErrorMsg.Append("Mapping for Rotation Terminal " + YourIss2RotationTerminal + " is missing. <br>"); }
      //              }

      //              XmlNode RotationBerth = RotaionNode.SelectSingleNode("Berth", tempns);
      //              if (RotationBerth.Attributes.GetNamedItem("Id") != null)
      //              {
      //                  string YourIss2RotationBerth = RotationBerth.Attributes["YourIss2Id"].Value;
      //                  if (RotationBerth.Attributes["Id"].Value == null || RotationBerth.Attributes["Id"].Value == "")
      //                  { NonMandatoryErrorMsg.Append("Mapping for Rotation Berth " + YourIss2RotationBerth + " is missing. <br>"); }
      //              }
      //          }

      //          XmlNodeList TankActivities = xmldoc.SelectNodes("//ns0:PortCall/Appointment/TankActivities/TankActivitie", tempns);
      //          foreach (XmlNode TankActivitiesNode in TankActivities)
      //          {
      //              XmlNode TankTerminal = TankActivitiesNode.SelectSingleNode("Terminal", tempns);

      //              if (TankTerminal.Attributes.GetNamedItem("Id") != null)
      //              {
      //                  string YourIss2TankTerminal = TankTerminal.Attributes["YourIss2Id"].Value;
      //                  if (TankTerminal.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Tank Activity Termial " + YourIss2TankTerminal + " is missing. <br>"); }
      //              }
      //              //else
      //              //{ 
      //              //    NonMandatoryErrorMsg.Append("Mapping for Tank Activity Termial " + YourIss2TankTerminal + "  is missing. <br>"); 
      //              //}

      //              XmlNode TankBerth = TankActivitiesNode.SelectSingleNode("Berth", tempns);

      //              if (TankBerth.Attributes.GetNamedItem("Id") != null)
      //              {
      //                  string YourIss2TankBerth = TankBerth.Attributes["YourIss2Id"].Value;
      //                  if (TankBerth.Attributes["Id"].Value == "")
      //                  { NonMandatoryErrorMsg.Append("Mapping for Tank Activity Berth " + YourIss2TankBerth + " is missing. <br>"); }
      //              }
      //              //else
      //              //{ 
      //              //    NonMandatoryErrorMsg.Append("Mapping for Tank Activity Berth " + YourIss2TankBerth + " is missing. <br>"); 
      //              //}
      //          }

      //          // remove the event mapping on 20-Apr-15 begin 
      //          /*
      //           XmlNodeList EventNodelist = xmldoc.SelectNodes("//ns0:PortCall/Appointment/TimeSheetEvents/TimeSheetEvent", tempns);
      //           foreach (XmlNode EventNode in EventNodelist)
      //           {
      //               //XmlNode EventBerth = EventNode.SelectSingleNode("Berth", tempns);

      //               //if (EventBerth.Attributes.GetNamedItem("Id") != null)
      //               //{
      //               //    if (EventBerth.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>"); }
      //               //}
      //               //else
      //               //{
      //               //    NonMandatoryErrorMsg.Append("Mapping for Timesheet EventBerth is missing. <br>");
      //               //}


      //               //XmlNode EventTerminal = EventNode.SelectSingleNode("Terminal", tempns);

      //               //if (EventTerminal.Attributes.GetNamedItem("Id") != null)
      //               //{
      //               //    if (EventTerminal.Attributes["Id"].Value == "") { NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>"); }
      //               //}
      //               //else
      //               //{
      //               //    NonMandatoryErrorMsg.Append("Mapping for Timesheet EventTerminal is missing. <br>");
      //               //}


      //               XmlNode Event = EventNode.SelectSingleNode("Event", tempns);

      //               if (Event.Attributes.GetNamedItem("Code") != null)
      //               {
      //                   string YourIss2Event = Event.Attributes["YourIss2Id"].Value;
      //                   if (Event.Attributes["Code"].Value == "")
      //                   { NonMandatoryErrorMsg.Append("Mapping for Timesheet Event  " + YourIss2Event + "   is missing. <br>"); }
      //               }
      //               //else
      //               //{
      //               //    NonMandatoryErrorMsg.Append("Mapping for Timesheet Event " + YourIss2Event + " is missing. <br>");
      //               //}

      //           }*/


      //          if (string.IsNullOrEmpty(ErrorMessage.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          }

      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ErrorMessage.ToString();

      //          if (string.IsNullOrEmpty(NonMandatoryErrorMsg.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "False";
      //          }
      //          rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = NonMandatoryErrorMsg.ToString();


      //          //Non Mandatory Feild checks - End
      //          return doc;

      //      }
      //      catch (Exception ex)
      //      {
      //          Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in SyncYourIss2ToPaspApptCheckMandatory Exception Message-->{0}", ex.Message));
      //          if (string.IsNullOrEmpty(ErrorMessage.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
      //              rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = "";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //              rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ex.ToString();
      //          }

      //          if (string.IsNullOrEmpty(NonMandatoryErrorMsg.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "True";
      //              rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = "";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsNonMandatoryValid")).InnerText = "False";
      //              rootelement.AppendChild(doc.CreateElement("NonMandatoryMessage")).InnerText = ex.ToString();
      //          }
      //          return doc;
      //      }
      //  }
      //  #endregion


      //  #region BLTFinanceCheckMandatory
      //  /******************************************************************************************************************************
      //  * Function Name    : BLTFinanceCheckMandatory()
      //  * Parameters       : XmlDocument xmldoc
      //  * Return Value     : Return XmlDocument
      //  * Description      : Check the Mandatory & Non Mandatory field for BLT Finance from PASP to YourISS2
      //  * Author           : B.M.Sujatha
      //  * Date Created     : 21-07-2014
      //  * Date Modified    :
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static XmlDocument BLTFinanceCheckMandatory(XmlDocument xmldoc)
      //  {

      //      StringBuilder ErrorMessage = new StringBuilder();
      //      XmlDocument doc = new XmlDocument();

      //      XmlElement rootelement = (XmlElement)doc.AppendChild(doc.CreateElement("Root"));

      //      try
      //      {
      //          System.Diagnostics.EventLog.WriteEntry("Application", "Inside the helper class Mandatory xmldoc " + xmldoc.OuterXml);

      //          XmlNamespaceManager tempns = new XmlNamespaceManager(xmldoc.NameTable);
      //          tempns.AddNamespace("ns0", "http://schema.iss-shipping.com/marine/finance/pasp");

      //          XmlNode PASPAppointmentNumber = xmldoc.SelectSingleNode("//ns0:Finance/ServiceDetails/ExternalJobCode", tempns);
      //          if (PASPAppointmentNumber != null)
      //          {
      //              if (PASPAppointmentNumber.InnerText == "") { ErrorMessage.Append("ExternalJobCode is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PASPAppointmentNumber is missing. <br>");
      //          }
      //          XmlNode PortCallNumber = xmldoc.SelectSingleNode("//ns0:Finance/ServiceDetails/PortCallNumber", tempns);
      //          if (PortCallNumber != null)
      //          {
      //              if (PortCallNumber.InnerText == null || PortCallNumber.InnerText == "") { ErrorMessage.Append("PortCallNumber is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PortCallNumber is missing. <br>");
      //          }

      //          XmlNodeList IssServiceList = xmldoc.SelectNodes("//ns0:Finance/ServiceDetails/ISSServiceDetail", tempns);

      //          foreach (XmlNode ServiceNode in IssServiceList)
      //          {
      //              string PaspCode;
      //              XmlNode Service = ServiceNode.SelectSingleNode("Service", tempns);
      //              if (Service != null)
      //              {
      //                  PaspCode = Service.Attributes["PaspCode"].Value;
      //                  if (Service.Attributes.GetNamedItem("Id") != null)
      //                  {
      //                      if (Service.Attributes["Id"].Value == "") { ErrorMessage.Append("Mapping for Service " + PaspCode + " is missing. <br>"); }
      //                  }
      //                  else
      //                  {
      //                      ErrorMessage.Append("Mapping for Service " + PaspCode + " is missing. <br>");
      //                  }
      //              }
      //              else
      //              {
      //                  PaspCode = Service.Attributes["PaspCode"].Value;
      //                  ErrorMessage.Append("Mapping for Service " + PaspCode + " is missing. <br>");
      //              }
      //          }


      //          if (string.IsNullOrEmpty(ErrorMessage.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          }

      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ErrorMessage.ToString();

      //          return doc;

      //      }
      //      catch (Exception ex)
      //      {
      //          rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ex.ToString();

      //          return doc;
      //      }
      //  }
      //  #endregion


      //  #region PerformaCloseEstimateMandatoryCheck
      //  /******************************************************************************************************************************
      //  * Function Name    : PerformaCloseEstimateMandatoryCheck()
      //  * Parameters       : XmlDocument xmldoc
      //  * Return Value     : Return XmlDocument
      //  * Description      : Check the Mandatory & Non Mandatory field for Performa & Close Estimate Finance from YourISS2 to PASP
      //  * Author           : B.M.Sujatha
      //  * Date Created     : 21-07-2014
      //  * Date Modified    : 08-01-2015
      //  * Comments         :
      //  * ******************************************************************************************************************************
      //  */
      //  public static XmlDocument PerformaCloseEstimateMandatoryCheck(XmlDocument xmldoc)
      //  {
      //      StringBuilder ErrorMessage = new StringBuilder();
      //      XmlDocument doc = new XmlDocument();
      //      XmlElement rootelement = (XmlElement)doc.AppendChild(doc.CreateElement("Root"));

      //      try
      //      {
      //          System.Diagnostics.EventLog.WriteEntry("Application", "Inside the helper class Mandatory xmldoc " + xmldoc.OuterXml);

      //          XmlNamespaceManager tempns = new XmlNamespaceManager(xmldoc.NameTable);
      //          tempns.AddNamespace("ns0", "http://schema.iss-shipping.com/hub/finance/pasp");

      //          XmlNode PASPAppointmentNumber = xmldoc.SelectSingleNode("//ns0:Finance/ServiceDetails/PASPAppointmentNumber", tempns);
      //          if (PASPAppointmentNumber != null)
      //          {
      //              if (PASPAppointmentNumber.InnerText == "") { ErrorMessage.Append("PASPAppointmentNumber is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PASPAppointmentNumber is missing. <br>");
      //          }
      //          XmlNode PortCallNumber = xmldoc.SelectSingleNode("//ns0:Finance/ServiceDetails/PortCallNumber", tempns);
      //          if (PortCallNumber != null)
      //          {
      //              if (PortCallNumber.InnerText == null || PortCallNumber.InnerText == "") { ErrorMessage.Append("PortCallNumber is missing. <br>"); }
      //          }
      //          else
      //          {
      //              ErrorMessage.Append("PortCallNumber is missing. <br>");
      //          }

      //          XmlNodeList IssServiceList = xmldoc.SelectNodes("//ns0:Finance/ServiceDetails/ServiceDetail", tempns);
      //          foreach (XmlNode ServiceNode in IssServiceList)
      //          {
      //              XmlNode Service = ServiceNode.SelectSingleNode("Service", tempns);

      //              //string IssServiceCode = Service.Attributes["YourIssServiceCode"].Value;
      //              //string IssServiceName = Service.Attributes["YourIssServiceName"].Value;

      //              if (Service != null)
      //              {
      //                  string IssServiceID = Service.Attributes["YourIssServiceId"].Value;
      //                  if (Service.Attributes.GetNamedItem("Code") != null)
      //                  {
      //                      if (Service.Attributes["Code"].Value == "") { ErrorMessage.Append("Mapping for Service " + IssServiceID + " is missing. <br>"); }
      //                  }
      //                  else
      //                  {
      //                      ErrorMessage.Append("Mapping for Service  " + IssServiceID + " is missing. <br>");
      //                  }
      //              }
      //              //else
      //              //{
      //              //    ErrorMessage.Append("Mapping for Service " + IssServiceID + " is missing. <br>");
      //              //}
      //          }


      //          if (string.IsNullOrEmpty(ErrorMessage.ToString()))
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "True";
      //          }
      //          else
      //          {
      //              rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          }

      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ErrorMessage.ToString();

      //          return doc;

      //      }
      //      catch (Exception ex)
      //      {
      //          rootelement.AppendChild(doc.CreateElement("IsValid")).InnerText = "False";
      //          rootelement.AppendChild(doc.CreateElement("MandatoryMessage")).InnerText = ex.ToString();

      //          return doc;
      //      }
      //  }
      //  #endregion


    }
}

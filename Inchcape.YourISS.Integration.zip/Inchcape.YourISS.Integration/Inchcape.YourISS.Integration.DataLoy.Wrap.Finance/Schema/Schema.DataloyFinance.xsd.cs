namespace Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"",@"FinanceDetail")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FinanceDetail"})]
    public sealed class Schema_DataloyFinance : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""FinanceDetail"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""portCall"" type=""xs:unsignedShort"" />
        <xs:element name=""businessPartner"" type=""xs:byte"" />
        <xs:element name=""agentTypeCode"" type=""xs:string"" />
        <xs:element name=""proformaReference"" type=""xs:string"" />
        <xs:element name=""invoiceReference"" type=""xs:string"" />
        <xs:element name=""invoiceDate"" type=""xs:dateTime"" />
        <xs:element name=""currency"" type=""xs:string"" />
        <xs:element name=""exchangeRate"" type=""xs:byte"" />
        <xs:element name=""status"" type=""xs:string"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""costItems"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""accountCode"" type=""xs:string"" />
              <xs:element name=""amount"" type=""xs:short"" />
              <xs:element name=""comment"" type=""xs:string"" />
              <xs:element name=""costItemKey"" type=""xs:short"" />
              <xs:element name=""isOwnersCost"" type=""xs:string"" />
              <xs:element name=""isCharterersCost"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_DataloyFinance() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FinanceDetail";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

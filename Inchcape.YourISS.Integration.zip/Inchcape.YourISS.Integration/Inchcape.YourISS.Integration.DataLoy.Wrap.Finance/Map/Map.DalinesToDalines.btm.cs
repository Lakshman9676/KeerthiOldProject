namespace Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine))]
    public sealed class Map_DalinesToDalines : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <Lines>
      <xsl:for-each select=""s0:DisbursementAccount/s0:Lines/s0:DaLine"">
        <DaLine>
          <ServiceLineCode>
            <xsl:value-of select=""s0:ServiceLineCode/text()"" />
          </ServiceLineCode>
          <ServiceLineName>
            <xsl:value-of select=""s0:ServiceLineName/text()"" />
          </ServiceLineName>
          <Amount>
            <CurrencyCode>
              <xsl:value-of select=""s0:Amount/s0:CurrencyCode/text()"" />
            </CurrencyCode>
            <Amount>
              <xsl:value-of select=""s0:Amount/s0:Amount/text()"" />
            </Amount>
          </Amount>
        </DaLine>
      </xsl:for-each>
    </Lines>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine";
                return _TrgSchemas;
            }
        }
    }
}

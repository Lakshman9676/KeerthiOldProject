namespace Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.TypedPolling_DataloyFinance+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.TypedPolling_DataloyFinance.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance))]
    public sealed class Map_GenericToDataloy : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s3 s2 s0 s1 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s3=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA"" xmlns:s1=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/DataloyFinance"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringTrimLeft(string(InputMessagePart_2/s1:TypedPollingResultSet0/s1:AccountId/text()))"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringTrimRight(string($var:v1))"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringConcat(string($var:v2) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v7"" select=""userCSharp:StringTrimLeft(string(InputMessagePart_2/s1:TypedPollingResultSet0/s1:ReferenceNumber/text()))"" />
    <xsl:variable name=""var:v8"" select=""userCSharp:StringTrimRight(string($var:v7))"" />
    <xsl:variable name=""var:v9"" select=""userCSharp:StringConcat(string($var:v8) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat(&quot;OA&quot;)"" />
    <xsl:variable name=""var:v17"" select=""string(InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:Stage/text())"" />
    <FinanceDetail>
      <portCall>
        <xsl:value-of select=""InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:SN_DANo/text()"" />
      </portCall>
      <xsl:variable name=""var:v4"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBLookup(0 , string($var:v3) , string($var:v4) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
      <xsl:variable name=""var:v6"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;id&quot;)"" />
      <xsl:variable name=""var:v10"" select=""ScriptNS1:DBLookup(1 , string($var:v9) , string($var:v4) , &quot;Appointment.Appointments&quot; , &quot;cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
      <xsl:variable name=""var:v11"" select=""ScriptNS1:DBValueExtract(string($var:v10) , &quot;PerformingAgentId&quot;)"" />
      <xsl:variable name=""var:v12"" select=""userCSharp:StringConcat(string($var:v6) , &quot;|&quot; , string($var:v11) , &quot;|&quot; , &quot;1&quot;)"" />
      <xsl:variable name=""var:v13"" select=""ScriptNS1:DBLookup(2 , string($var:v12) , string($var:v4) , &quot;master.HubPrincipalAgentMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ cast(AgentId as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
      <xsl:variable name=""var:v14"" select=""ScriptNS1:DBValueExtract(string($var:v13) , &quot;Code&quot;)"" />
      <businessPartner>
        <xsl:value-of select=""$var:v14"" />
      </businessPartner>
      <agentTypeCode>
        <xsl:value-of select=""$var:v15"" />
      </agentTypeCode>
      <xsl:variable name=""var:v16"" select=""userCSharp:SetFinanceStatus(string(InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:InvoiceNo/text()) , string(InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:Stage/text()))"" />
      <invoiceReference>
        <xsl:value-of select=""$var:v16"" />
      </invoiceReference>
      <invoiceDate>
        <xsl:value-of select=""InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:InvoiceDate/text()"" />
      </invoiceDate>
      <currency>
        <xsl:value-of select=""InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:YourIssCurrencyCode/text()"" />
      </currency>
      <exchangeRate>
        <xsl:value-of select=""InputMessagePart_0/s0:YourIssNotification/s0:DisbursementAccount/s0:YourIssExchangeRate/text()"" />
      </exchangeRate>
      <xsl:variable name=""var:v18"" select=""userCSharp:SetFinanceStatus($var:v17)"" />
      <status>
        <xsl:value-of select=""$var:v18"" />
      </status>
      <xsl:for-each select=""InputMessagePart_1/FinanceDetail/costItems"">
        <xsl:variable name=""var:v19"" select=""userCSharp:StringConcat(&quot;false&quot;)"" />
        <costItems>
          <accountCode>
            <xsl:value-of select=""accountCode/text()"" />
          </accountCode>
          <amount>
            <xsl:value-of select=""amount/text()"" />
          </amount>
          <costItemKey>
            <xsl:value-of select=""accountCode/text()"" />
          </costItemKey>
          <isOwnersCost>
            <xsl:value-of select=""$var:v19"" />
          </isOwnersCost>
          <isCharterersCost>
            <xsl:value-of select=""$var:v19"" />
          </isCharterersCost>
        </costItems>
      </xsl:for-each>
    </FinanceDetail>
    <xsl:variable name=""var:v20"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string SetFinanceStatus ( string Stage)
{
      if  (  Stage==""PDA""   )
            return ""EST"" ;
     else if (  Stage == ""UDA"" )
           return ""REV"" ;
     else if ( Stage  == ""FDA""  )
            return ""FIN"";
     else if ( Stage  == ""SDA""  )
            return ""FIN"";

    else
          return """";

} 


public string StringConcat(string param0)
{
   return param0;
}


public string SetFinanceStatus (string invoiceNo ,  string Stage)
{

    if ( invoiceNo != null && invoiceNo !="""" )
           return invoiceNo ;
    else  if  (  Stage==""PDA""   )
            return ""EST"" ;
     else if (  Stage == ""UDA"" )
           return ""REV"" ;
     else if ( Stage  == ""FDA""  )
            return ""FIN"";
     else if ( Stage  == ""SDA""  )
            return ""FIN"";

    else
          return """";

} 


public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public string StringTrimRight(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimEnd(null);
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringConcat(string param0, string param1, string param2, string param3, string param4)
{
   return param0 + param1 + param2 + param3 + param4;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance _srcSchemaTypeReference1 = null;
        
        private const string _strSrcSchemasList2 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.TypedPolling_DataloyFinance+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.TypedPolling_DataloyFinance.TypedPollingResultSet0 _srcSchemaTypeReference2 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [3];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
                _SrcSchemas[2] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.TypedPolling_DataloyFinance+TypedPollingResultSet0";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
                return _TrgSchemas;
            }
        }
    }
}

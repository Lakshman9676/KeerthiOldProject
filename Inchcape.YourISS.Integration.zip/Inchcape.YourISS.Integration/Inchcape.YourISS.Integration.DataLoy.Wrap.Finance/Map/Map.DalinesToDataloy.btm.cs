namespace Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance))]
    public sealed class Map_DalinesToDataloy : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var"" version=""1.0"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/Lines"" />
  </xsl:template>
  <xsl:template match=""/Lines"">
    <FinanceDetail>
      <xsl:for-each select=""DaLine[generate-id(.)=generate-id(key('groups',ServiceLineCode))]"">
<xsl:sort select=""ServiceLineCode"" order=""ascending"" />
   <costItems>
       <xsl:variable name=""ServiceLineCode"" select=""ServiceLineCode/text()"" />
     <xsl:variable name=""Total"" select=""sum(key('groups',ServiceLineCode)/Amount/Amount)"" />
      <accountCode>
         <xsl:value-of select=""$ServiceLineCode"" />
      </accountCode>
         <amount>
                    <xsl:value-of select=""$Total"" />
          </amount>
  </costItems>
</xsl:for-each>
    </FinanceDetail>
  </xsl:template>
  <xsl:key name=""groups"" match=""DaLine"" use=""ServiceLineCode"" />
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DaLine";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.Finance.Schema.Schema_DataloyFinance";
                return _TrgSchemas;
            }
        }
    }
}

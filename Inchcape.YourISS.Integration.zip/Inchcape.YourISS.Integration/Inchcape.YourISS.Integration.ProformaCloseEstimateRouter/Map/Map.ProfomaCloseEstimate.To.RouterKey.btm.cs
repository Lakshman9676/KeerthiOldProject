namespace Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_YourISS2ProformaCloseEstimate", typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_YourISS2ProformaCloseEstimate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouterAppt", typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouterAppt))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouter", typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouter))]
    public sealed class Map_ProfomaCloseEstimate_To_RouterKey : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.ProformaCloseEstimateRouter"" xmlns:s1=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:s0=""http://schema.iss-shipping.com/marine/finance/Shipnet"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Root"" />
  </xsl:template>
  <xsl:template match=""/s1:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(string(InputMessagePart_1/ProformaCloseEstRouterAppt/ApptNumber/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <ns0:ProformaCloseEstRouter>
      <xsl:variable name=""var:v2"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBLookup(0 , string($var:v1) , string($var:v2) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
      <xsl:variable name=""var:v4"" select=""ScriptNS1:DBValueExtract(string($var:v3) , &quot;PortCallId&quot;)"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBLookup(1 , string($var:v4) , string($var:v2) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v6"" select=""ScriptNS1:DBValueExtract(string($var:v5) , &quot;id&quot;)"" />
      <xsl:variable name=""var:v7"" select=""ScriptNS1:DBLookup(2 , string($var:v6) , string($var:v2) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
      <xsl:variable name=""var:v8"" select=""ScriptNS1:DBValueExtract(string($var:v7) , &quot;HubPrincipalKey&quot;)"" />
      <Key>
        <xsl:value-of select=""$var:v8"" />
      </Key>
    </ns0:ProformaCloseEstRouter>
    <xsl:variable name=""var:v9"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_YourISS2ProformaCloseEstimate";
        
        private const global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_YourISS2ProformaCloseEstimate _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouterAppt";
        
        private const global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouterAppt _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouter";
        
        private const global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouter _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_YourISS2ProformaCloseEstimate";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouterAppt";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema.Schema_ProformaCloseEstRouter";
                return _TrgSchemas;
            }
        }
    }
}

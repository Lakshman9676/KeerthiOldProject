namespace Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schema.iss-shipping.com/marine/finance/Shipnet",@"YourIss2Finance")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema.MsgType), XPath = @"/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='MsgType' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema.ApptNumber), XPath = @"/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='ApptNumber' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "MsgType", XPath = @"/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='MsgType' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "ApptNumber", XPath = @"/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='ApptNumber' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIss2Finance"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema.PropertySchema))]
    public sealed class Schema_YourISS2ProformaCloseEstimate : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schema.iss-shipping.com/marine/finance/Shipnet"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""https://Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema"" targetNamespace=""http://schema.iss-shipping.com/marine/finance/Shipnet"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema"" location=""Inchcape.YourISS.Integration.ProformaCloseEstimateRouter.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""YourIss2Finance"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:MsgType"" xpath=""/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='MsgType' and namespace-uri()='']"" />
          <b:property name=""ns0:ApptNumber"" xpath=""/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='ApptNumber' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='MsgType' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='YourIss2Finance' and namespace-uri()='http://schema.iss-shipping.com/marine/finance/Shipnet']/*[local-name()='ApptNumber' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element maxOccurs=""unbounded"" name=""services"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""IssService"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Id"" type=""xs:string"" />
                    <xs:element name=""Code"" type=""xs:string"" />
                    <xs:element name=""Name"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""DaCurrency"" type=""xs:string"" />
              <xs:element name=""HomeCurrency"" type=""xs:string"" />
              <xs:element name=""ExchangeRate"" type=""xs:string"" />
              <xs:element name=""Amount"" type=""xs:string"" />
              <xs:element name=""LocalAmount"" type=""xs:string"" />
              <xs:element name=""Comment"" type=""xs:string"" />
              <xs:element name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""MsgType"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""ApptNumber"" nillable=""true"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_YourISS2ProformaCloseEstimate() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIss2Finance";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.BizTalk.Message.Interop ;
using Microsoft.BizTalk.Component.Interop ;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;

namespace Inchcape.YourISS.Integration.PipeLine.RemoveXMLNameSpace
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent )]
    [ComponentCategory(CategoryTypes.CATID_Encoder)]
    [System.Runtime.InteropServices.Guid("D561B76E-44A3-4A0D-9A43-71E512D7F732")]
    public class RemoveNameSpace : IBaseComponent, IPersistPropertyBag,  IComponentUI , IComponent
    {
        #region IBaseComponent
        // Component description
        public string Description
        {
            get { return "Removing Namespce from XML message"; }
        }
        // Component name
        public string Name
        {
            get { return "RemoveXMlNameSpace"; }
        }
        // Component version
        public string Version
        {
            get { return "1.0.0.0"; }
        }
        #endregion

        #region IComponentUI        
        // Icon associated with this component   
        public IntPtr Icon
        {
            get { return new System.IntPtr(); }
        }
        // Verifies that all the configuration properties are set correctly        
        public System.Collections.IEnumerator Validate(object projectSystem)
        {
            return null;
        }
        #endregion

        #region IPersistPropertyBag
        public void GetClassID(out Guid classID)
        {
            classID = new Guid("87DCF5A3-7372-4F78-BC3E-C88F43868B68");           
        }
        public void InitNew()
        {
            //comment
        }
        public void Load(IPropertyBag propertyBag, int errorLog)
        {
            //comment
        }
        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
        }
        #endregion

        #region IComponent
        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {
            var originalStream = pInMsg.BodyPart.GetOriginalDataStream();
            
            using (TextReader reader = new StreamReader(originalStream))
            {
               string    xmlString = reader.ReadToEnd();
               XmlDocument docXML = new XmlDocument();
               docXML.LoadXml(xmlString);
               MemoryStream outputStream = new MemoryStream(ASCIIEncoding.Default.GetBytes(RemoveNamespace(docXML)));
                outputStream.Position = 0;
                pInMsg.BodyPart.Data = outputStream;
            }
            return pInMsg;
        }

        #endregion

        #region Private Methods
        private  string RemoveNamespace(XmlDocument xdoc)
        {
            // Regex to search for either xmlns:nsN="..." or xmlns="..."
            const string pattern = @"xmlns:?(\w+)?=""[\w:/.]*""";
            string xml = xdoc.OuterXml;

            Regex replace = new Regex(pattern);
            // Replace all occurances of the namespace declaration
            string temp = replace.Replace(xml, String.Empty);
            foreach (Match match in replace.Matches(xml))
            {
                // Loop through each Match in the Regex, this gives us the namespace aliases found
                if (match.Success && match.Groups.Count > 1)
                {
                    if (!String.IsNullOrEmpty(match.Groups[1].Value))
                    {
                        Regex alias = new Regex(@"\b" + match.Groups[1].Value + ":");
                        // Replace all occurances of the
                        temp = alias.Replace(temp, String.Empty);
                    }
                }
            }
            return temp;
        }

        #endregion Private Methods

    }
}

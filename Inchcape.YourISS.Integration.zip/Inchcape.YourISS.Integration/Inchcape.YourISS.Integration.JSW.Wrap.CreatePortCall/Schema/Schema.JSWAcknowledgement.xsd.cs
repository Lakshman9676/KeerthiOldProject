namespace Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCallResponse.Schema",@"YourIssNotification")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIssNotification"})]
    public sealed class Schema_JSWAcknowledgement : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCallResponse.Schema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" attributeFormDefault=""unqualified"" elementFormDefault=""qualified"" targetNamespace=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCallResponse.Schema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""YourIssNotification"">
    <xs:annotation>
      <xs:appinfo>
        <b:recordInfo rootTypeName=""YourIssNotification"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""MessageHeader"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""MessageType"" type=""xs:string"" />
              <xs:element name=""Action"" type=""xs:string"" />
              <xs:element name=""CreatedDate"" type=""xs:string"" />
              <xs:element name=""ShipNetReference"" type=""xs:string"" />
              <xs:element name=""ShipNetOperatorId"" type=""xs:string"" />
              <xs:element name=""ShipNetOperatorName"" type=""xs:string"" />
              <xs:element name=""SourceApplication"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""PortCallResponse"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""SN_KeyPosition"" type=""xs:string"" />
              <xs:element name=""SN_DANo"" type=""xs:string"" />
              <xs:element name=""YISS2_PortCallNumber"" type=""xs:string"" />
              <xs:element name=""YISS2_AppointmentNumber"" type=""xs:string"" />
              <xs:element name=""Response"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Code"" type=""xs:string"" />
                    <xs:element name=""Message"" type=""xs:string"" />
                    <xs:element name=""AckBy"" type=""xs:string"" />
                    <xs:element name=""AckNo"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_JSWAcknowledgement() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIssNotification";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

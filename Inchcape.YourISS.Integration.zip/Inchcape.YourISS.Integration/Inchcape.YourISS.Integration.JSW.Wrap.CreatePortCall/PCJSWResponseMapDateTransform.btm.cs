namespace Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement))]
    public sealed class PCJSWResponseMapDateTransform : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s1 s4 s0 s2 s3 userCSharp"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCallResponse.Schema"" xmlns:s4=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s0=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema"" xmlns:s3=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:s1=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreateResponse"" xmlns:s2=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/GetJswCreatePortCallInboundResponse"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s3:Root"" />
  </xsl:template>
  <xsl:template match=""/s3:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;PortCallResponse&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <ns0:YourIssNotification>
      <ns0:MessageHeader>
        <ns0:MessageType>
          <xsl:value-of select=""$var:v1"" />
        </ns0:MessageType>
        <ns0:Action>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/Action/text()"" />
        </ns0:Action>
        <ns0:CreatedDate>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/CreatedDate/text()"" />
        </ns0:CreatedDate>
        <ns0:ShipNetReference>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetReference/text()"" />
        </ns0:ShipNetReference>
        <ns0:ShipNetOperatorId>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetOperatorId/text()"" />
        </ns0:ShipNetOperatorId>
        <ns0:ShipNetOperatorName>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetOperatorName/text()"" />
        </ns0:ShipNetOperatorName>
        <ns0:SourceApplication>
          <xsl:value-of select=""$var:v2"" />
        </ns0:SourceApplication>
      </ns0:MessageHeader>
      <xsl:for-each select=""InputMessagePart_2/s1:LinkAppointment/portcalls"">
        <xsl:for-each select=""Appointments"">
          <xsl:variable name=""var:v3"" select=""userCSharp:StringConcat(&quot;0&quot;)"" />
          <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(&quot;Port Call Created Successfully&quot;)"" />
          <xsl:variable name=""var:v5"" select=""userCSharp:StringConcat(&quot;INTEGRATION&quot;)"" />
          <ns0:PortCallResponse>
            <ns0:SN_KeyPosition>
              <xsl:value-of select=""../../../../InputMessagePart_1/s0:YourIssNotification/PortCall/SN_KeyPosition/text()"" />
            </ns0:SN_KeyPosition>
            <ns0:SN_DANo>
              <xsl:value-of select=""../../../../InputMessagePart_1/s0:YourIssNotification/PortCall/SN_DANo/text()"" />
            </ns0:SN_DANo>
            <xsl:if test=""../Number"">
              <ns0:YISS2_PortCallNumber>
                <xsl:value-of select=""../Number/text()"" />
              </ns0:YISS2_PortCallNumber>
            </xsl:if>
            <ns0:YISS2_AppointmentNumber>
              <xsl:value-of select=""Number/text()"" />
            </ns0:YISS2_AppointmentNumber>
            <ns0:Response>
              <ns0:Code>
                <xsl:value-of select=""$var:v3"" />
              </ns0:Code>
              <ns0:Message>
                <xsl:value-of select=""$var:v4"" />
              </ns0:Message>
              <ns0:AckBy>
                <xsl:value-of select=""$var:v5"" />
              </ns0:AckBy>
              <xsl:if test=""../../../../InputMessagePart_0/s2:TypedPollingResultSet0/s2:Id"">
                <ns0:AckNo>
                  <xsl:value-of select=""../../../../InputMessagePart_0/s2:TypedPollingResultSet0/s2:Id/text()"" />
                </ns0:AckNo>
              </xsl:if>
            </ns0:Response>
          </ns0:PortCallResponse>
        </xsl:for-each>
      </xsl:for-each>
    </ns0:YourIssNotification>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse.TypedPollingResultSet0 _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall _srcSchemaTypeReference1 = null;
        
        private const string _strSrcSchemasList2 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse _srcSchemaTypeReference2 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [3];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall";
                _SrcSchemas[2] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement";
                return _TrgSchemas;
            }
        }
    }
}

namespace Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement))]
    public sealed class Map_YourISSResponseToJSWResponse : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s2 s1 s3 userCSharp"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCallResponse.Schema"" xmlns:s3=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreateResponse"" xmlns:s1=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/GetJswCreatePortCallInboundResponse"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;PortCallResponse&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;0&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringConcat(&quot;JSW Portcall Updated Successfully&quot;)"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(&quot;INTEGRATION&quot;)"" />
    <ns0:YourIssNotification>
      <ns0:MessageHeader>
        <ns0:MessageType>
          <xsl:value-of select=""$var:v1"" />
        </ns0:MessageType>
      </ns0:MessageHeader>
      <ns0:PortCallResponse>
        <ns0:Response>
          <ns0:Code>
            <xsl:value-of select=""$var:v2"" />
          </ns0:Code>
          <ns0:Message>
            <xsl:value-of select=""$var:v3"" />
          </ns0:Message>
          <ns0:AckBy>
            <xsl:value-of select=""$var:v4"" />
          </ns0:AckBy>
          <xsl:if test=""InputMessagePart_1/s1:TypedPollingResultSet0/s1:Id"">
            <ns0:AckNo>
              <xsl:value-of select=""InputMessagePart_1/s1:TypedPollingResultSet0/s1:Id/text()"" />
            </ns0:AckNo>
          </xsl:if>
        </ns0:Response>
      </ns0:PortCallResponse>
    </ns0:YourIssNotification>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse.TypedPollingResultSet0 _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourIss2CreatePortCallResponse";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_GetJswCreatePortCallInboundResponse+TypedPollingResultSet0";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSWAcknowledgement";
                return _TrgSchemas;
            }
        }
    }
}

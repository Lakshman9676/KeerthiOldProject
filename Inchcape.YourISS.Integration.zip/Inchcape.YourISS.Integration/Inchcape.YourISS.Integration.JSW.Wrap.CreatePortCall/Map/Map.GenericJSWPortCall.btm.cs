namespace Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_CreatePortCallJSWInbound+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_CreatePortCallJSWInbound.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall))]
    public sealed class Map_GenericJSWPortCall : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s3 s0 s1 s2"" version=""1.0"" xmlns:s3=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s0=""http://Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema"" xmlns:s1=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/CreatePortCallJSWInbound"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <ns0:YourIssNotification>
      <xsl:if test=""InputMessagePart_0/s1:TypedPollingResultSet0/s1:AccountId"">
        <HubPrincipalKey>
          <xsl:value-of select=""InputMessagePart_0/s1:TypedPollingResultSet0/s1:AccountId/text()"" />
        </HubPrincipalKey>
      </xsl:if>
      <xsl:if test=""InputMessagePart_0/s1:TypedPollingResultSet0/s1:Id"">
        <Id>
          <xsl:value-of select=""InputMessagePart_0/s1:TypedPollingResultSet0/s1:Id/text()"" />
        </Id>
      </xsl:if>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/MessageType/text()"" />
        </MessageType>
        <Action>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/Action/text()"" />
        </Action>
        <CreatedDate>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/CreatedDate/text()"" />
        </CreatedDate>
        <ShipNetReference>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetReference/text()"" />
        </ShipNetReference>
        <ShipNetOperatorId>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetOperatorId/text()"" />
        </ShipNetOperatorId>
        <ShipNetOperatorName>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/ShipNetOperatorName/text()"" />
        </ShipNetOperatorName>
        <SourceApplication>
          <xsl:value-of select=""InputMessagePart_1/s0:YourIssNotification/MessageHeader/SourceApplication/text()"" />
        </SourceApplication>
      </MessageHeader>
      <xsl:for-each select=""InputMessagePart_1/s0:YourIssNotification/PortCall"">
        <PortCall>
          <HubPrincipalCode>
            <xsl:value-of select=""HubPrincipalCode/text()"" />
          </HubPrincipalCode>
          <HubPrincipalName>
            <xsl:value-of select=""HubPrincipalName/text()"" />
          </HubPrincipalName>
          <PrincipalCode>
            <xsl:value-of select=""PrincipalCode/text()"" />
          </PrincipalCode>
          <PrincipalName>
            <xsl:value-of select=""PrincipalName/text()"" />
          </PrincipalName>
          <SN_DANo>
            <xsl:value-of select=""SN_DANo/text()"" />
          </SN_DANo>
          <SN_KeyPosition>
            <xsl:value-of select=""SN_KeyPosition/text()"" />
          </SN_KeyPosition>
          <SN_VesselCode>
            <xsl:value-of select=""SN_VesselCode/text()"" />
          </SN_VesselCode>
          <VesselName>
            <xsl:value-of select=""VesselName/text()"" />
          </VesselName>
          <xsl:if test=""IMO"">
            <xsl:variable name=""var:v1"" select=""string(IMO/@xsi:nil) = 'true'"" />
            <xsl:if test=""string($var:v1)='true'"">
              <IMO>
                <xsl:attribute name=""xsi:nil"">
                  <xsl:value-of select=""'true'"" />
                </xsl:attribute>
              </IMO>
            </xsl:if>
            <xsl:if test=""string($var:v1)='false'"">
              <IMO>
                <xsl:value-of select=""IMO/text()"" />
              </IMO>
            </xsl:if>
          </xsl:if>
          <SN_VoyageNumber>
            <xsl:value-of select=""SN_VoyageNumber/text()"" />
          </SN_VoyageNumber>
          <ETA>
            <xsl:value-of select=""ETA/text()"" />
          </ETA>
          <ETS>
            <xsl:value-of select=""ETS/text()"" />
          </ETS>
          <xsl:if test=""SN_DaType"">
            <xsl:variable name=""var:v2"" select=""string(SN_DaType/@xsi:nil) = 'true'"" />
            <xsl:if test=""string($var:v2)='true'"">
              <SN_DaType>
                <xsl:attribute name=""xsi:nil"">
                  <xsl:value-of select=""'true'"" />
                </xsl:attribute>
              </SN_DaType>
            </xsl:if>
            <xsl:if test=""string($var:v2)='false'"">
              <SN_DaType>
                <xsl:value-of select=""SN_DaType/text()"" />
              </SN_DaType>
            </xsl:if>
          </xsl:if>
          <PortOperationCode>
            <xsl:value-of select=""PortOperationCode/text()"" />
          </PortOperationCode>
          <PortOperationName>
            <xsl:value-of select=""PortOperationName/text()"" />
          </PortOperationName>
          <SN_AgentCode>
            <xsl:value-of select=""SN_AgentCode/text()"" />
          </SN_AgentCode>
          <SN_AgentName>
            <xsl:value-of select=""SN_AgentName/text()"" />
          </SN_AgentName>
          <ISS_AgentCode>
            <xsl:value-of select=""ISS_AgentCode/text()"" />
          </ISS_AgentCode>
          <SN_NominationType>
            <xsl:value-of select=""SN_NominationType/text()"" />
          </SN_NominationType>
          <PortCount>
            <xsl:value-of select=""PortCount/text()"" />
          </PortCount>
          <Ports>
            <Port>
              <SN_AcctsCode>
                <xsl:value-of select=""Ports/Port/SN_AcctsCode/text()"" />
              </SN_AcctsCode>
              <PortName>
                <xsl:value-of select=""Ports/Port/PortName/text()"" />
              </PortName>
              <PortCode>
                <xsl:value-of select=""Ports/Port/PortCode/text()"" />
              </PortCode>
              <ISS_PortCode>
                <xsl:value-of select=""Ports/Port/ISS_PortCode/text()"" />
              </ISS_PortCode>
              <SN_CountryCode>
                <xsl:value-of select=""Ports/Port/SN_CountryCode/text()"" />
              </SN_CountryCode>
              <SN_CountryName>
                <xsl:value-of select=""Ports/Port/SN_CountryName/text()"" />
              </SN_CountryName>
              <xsl:value-of select=""Ports/Port/text()"" />
            </Port>
            <xsl:value-of select=""Ports/text()"" />
          </Ports>
          <PreviousPort>
            <Port>
              <SN_AcctsCode>
                <xsl:value-of select=""PreviousPort/Port/SN_AcctsCode/text()"" />
              </SN_AcctsCode>
              <PortName>
                <xsl:value-of select=""PreviousPort/Port/PortName/text()"" />
              </PortName>
              <PortCode>
                <xsl:value-of select=""PreviousPort/Port/PortCode/text()"" />
              </PortCode>
              <ISS_PortCode>
                <xsl:value-of select=""PreviousPort/Port/ISS_PortCode/text()"" />
              </ISS_PortCode>
              <SN_CountryCode>
                <xsl:value-of select=""PreviousPort/Port/SN_CountryCode/text()"" />
              </SN_CountryCode>
              <SN_CountryName>
                <xsl:value-of select=""PreviousPort/Port/SN_CountryName/text()"" />
              </SN_CountryName>
            </Port>
          </PreviousPort>
          <NextPort>
            <Port>
              <SN_AcctsCode>
                <xsl:value-of select=""NextPort/Port/SN_AcctsCode/text()"" />
              </SN_AcctsCode>
              <PortName>
                <xsl:value-of select=""NextPort/Port/PortName/text()"" />
              </PortName>
              <PortCode>
                <xsl:value-of select=""NextPort/Port/PortCode/text()"" />
              </PortCode>
              <ISS_PortCode>
                <xsl:value-of select=""NextPort/Port/ISS_PortCode/text()"" />
              </ISS_PortCode>
              <SN_CountryCode>
                <xsl:value-of select=""NextPort/Port/SN_CountryCode/text()"" />
              </SN_CountryCode>
              <SN_CountryName>
                <xsl:value-of select=""NextPort/Port/SN_CountryName/text()"" />
              </SN_CountryName>
            </Port>
          </NextPort>
          <xsl:if test=""Master"">
            <xsl:variable name=""var:v3"" select=""string(Master/@xsi:nil) = 'true'"" />
            <xsl:if test=""string($var:v3)='true'"">
              <Master>
                <xsl:attribute name=""xsi:nil"">
                  <xsl:value-of select=""'true'"" />
                </xsl:attribute>
              </Master>
            </xsl:if>
            <xsl:if test=""string($var:v3)='false'"">
              <Master>
                <xsl:value-of select=""Master/text()"" />
              </Master>
            </xsl:if>
          </xsl:if>
          <xsl:if test=""Competitive"">
            <xsl:variable name=""var:v4"" select=""string(Competitive/@xsi:nil) = 'true'"" />
            <xsl:if test=""string($var:v4)='true'"">
              <Competitive>
                <xsl:attribute name=""xsi:nil"">
                  <xsl:value-of select=""'true'"" />
                </xsl:attribute>
              </Competitive>
            </xsl:if>
            <xsl:if test=""string($var:v4)='false'"">
              <Competitive>
                <xsl:value-of select=""Competitive/text()"" />
              </Competitive>
            </xsl:if>
          </xsl:if>
          <CargoCount>
            <xsl:value-of select=""CargoCount/text()"" />
          </CargoCount>
          <Cargoes>
            <xsl:for-each select=""Cargoes/Cargo"">
              <Cargo>
                <SN_KeyCargo>
                  <xsl:value-of select=""SN_KeyCargo/text()"" />
                </SN_KeyCargo>
                <SN_CargoNo>
                  <xsl:value-of select=""SN_CargoNo/text()"" />
                </SN_CargoNo>
                <SN_ChartererCode>
                  <xsl:value-of select=""SN_ChartererCode/text()"" />
                </SN_ChartererCode>
                <ISS_ChartererCode>
                  <xsl:value-of select=""ISS_ChartererCode/text()"" />
                </ISS_ChartererCode>
                <ISS_CommodityCode>
                  <xsl:value-of select=""ISS_CommodityCode/text()"" />
                </ISS_CommodityCode>
                <CommodityCode>
                  <xsl:value-of select=""CommodityCode/text()"" />
                </CommodityCode>
                <CommodityName>
                  <xsl:value-of select=""CommodityName/text()"" />
                </CommodityName>
                <Quantity>
                  <xsl:value-of select=""Quantity/text()"" />
                </Quantity>
                <QuantityTypeCode>
                  <xsl:value-of select=""QuantityTypeCode/text()"" />
                </QuantityTypeCode>
                <QuantityTypeName>
                  <xsl:value-of select=""QuantityTypeName/text()"" />
                </QuantityTypeName>
                <CargoOperationCode>
                  <xsl:value-of select=""CargoOperationCode/text()"" />
                </CargoOperationCode>
                <CargoOperationName>
                  <xsl:value-of select=""CargoOperationName/text()"" />
                </CargoOperationName>
              </Cargo>
            </xsl:for-each>
          </Cargoes>
          <BunkerCount>
            <xsl:value-of select=""BunkerCount/text()"" />
          </BunkerCount>
          <Bunkers>
            <xsl:for-each select=""Bunkers/Bunker"">
              <Bunker>
                <Grade>
                  <xsl:value-of select=""Grade/text()"" />
                </Grade>
                <xsl:value-of select=""./text()"" />
              </Bunker>
            </xsl:for-each>
            <xsl:value-of select=""Bunkers/text()"" />
          </Bunkers>
        </PortCall>
      </xsl:for-each>
      <xsl:for-each select=""InputMessagePart_1/s0:YourIssNotification/CancelPortCall"">
        <CancelPortCal>
          <xsl:if test=""SN_DANo"">
            <SN_DANo>
              <xsl:value-of select=""SN_DANo/text()"" />
            </SN_DANo>
          </xsl:if>
          <SN_KeyPosition>
            <xsl:value-of select=""SN_KeyPosition/text()"" />
          </SN_KeyPosition>
        </CancelPortCal>
      </xsl:for-each>
    </ns0:YourIssNotification>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_CreatePortCallJSWInbound+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_CreatePortCallJSWInbound.TypedPollingResultSet0 _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.TypedPolling_CreatePortCallJSWInbound+TypedPollingResultSet0";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.JSW.Wrap.CreatePortCall.Schema.Schema_JSW_CreatePortCall";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
                return _TrgSchemas;
            }
        }
    }
}

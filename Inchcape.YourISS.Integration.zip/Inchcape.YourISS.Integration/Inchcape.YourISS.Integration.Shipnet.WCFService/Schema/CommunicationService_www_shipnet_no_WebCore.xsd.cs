namespace Inchcape.YourISS.Integration.Shipnet.WCFService.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"InvokeMethodResponse", @"InvokeMethod"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Shipnet.WCFService.Schema.CommunicationService_www_shipnet_no_webcore_1", typeof(global::Inchcape.YourISS.Integration.Shipnet.WCFService.Schema.CommunicationService_www_shipnet_no_webcore_1))]
    public sealed class CommunicationService_www_shipnet_no_WebCore : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:tns=""http://www.shipnet.no/WebCore"" elementFormDefault=""qualified"" targetNamespace=""http://www.shipnet.no/WebCore"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Inchcape.YourISS.Integration.Shipnet.WCFService.Schema.CommunicationService_www_shipnet_no_webcore_1"" namespace=""http://www.shipnet.no/webcore"" />
  <xs:annotation>
    <xs:appinfo>
      <b:references>
        <b:reference targetNamespace=""http://schemas.microsoft.com/2003/10/Serialization/"" />
        <b:reference targetNamespace=""http://www.shipnet.no/webcore"" />
      </b:references>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""InvokeMethodResponse"">
    <xs:complexType>
      <xs:sequence>
        <xs:element xmlns:q2=""http://www.shipnet.no/webcore"" minOccurs=""0"" name=""InvokeMethodResult"" nillable=""true"" type=""q2:Dto"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""InvokeMethod"">
    <xs:complexType>
      <xs:sequence>
        <xs:element xmlns:q1=""http://www.shipnet.no/webcore"" minOccurs=""0"" name=""request"" nillable=""true"" type=""q1:Dto"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public CommunicationService_www_shipnet_no_WebCore() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [2];
                _RootElements[0] = "InvokeMethodResponse";
                _RootElements[1] = "InvokeMethod";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://www.shipnet.no/WebCore",@"InvokeMethodResponse")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"InvokeMethodResponse"})]
        public sealed class InvokeMethodResponse : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public InvokeMethodResponse() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "InvokeMethodResponse";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://www.shipnet.no/WebCore",@"InvokeMethod")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"InvokeMethod"})]
        public sealed class InvokeMethod : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public InvokeMethod() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "InvokeMethod";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}

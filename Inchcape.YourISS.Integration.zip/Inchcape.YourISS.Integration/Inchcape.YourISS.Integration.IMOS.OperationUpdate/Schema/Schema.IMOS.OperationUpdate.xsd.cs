namespace Inchcape.YourISS.Integration.IMOS.OperationUpdate.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.IMOS.OperationUpdate.IMOSOUSOFSchema",@"Form")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Form"})]
    public sealed class Schema_IMOS_OperationUpdate : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.IMOS.OperationUpdate.IMOSOUSOFSchema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://Inchcape.YourISS.Integration.IMOS.OperationUpdate.IMOSOUSOFSchema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""Form"">
    <xs:complexType>
      <xs:all>
        <xs:element minOccurs=""0"" name=""VesselName"" type=""String"" />
        <xs:element minOccurs=""1"" name=""GmtOffset"" type=""String"" />
        <xs:element minOccurs=""0"" name=""EOSP"" type=""DateTime"" />
        <xs:element minOccurs=""0"" name=""VoyageNo"" type=""Integer"" />
        <xs:element minOccurs=""0"" name=""Port"" type=""String"" />
        <xs:element minOccurs=""0"" name=""ETD"" type=""DateTime"" />
        <xs:element minOccurs=""1"" name=""PortActivities"" type=""PortActivities"" />
        <xs:element minOccurs=""0"" name=""Remarks"" type=""String"" />
      </xs:all>
      <xs:attribute name=""FormIdentifier"" type=""xs:string"" use=""required"" />
      <xs:attribute name=""CompanyCode"" type=""xs:string"" use=""required"" />
      <xs:attribute name=""CompanyName"" type=""xs:string"" />
      <xs:attribute name=""VesselCode"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:simpleType name=""String"">
    <xs:restriction base=""xs:string"" />
  </xs:simpleType>
  <xs:simpleType name=""Integer"">
    <xs:union>
      <xs:simpleType>
        <xs:restriction base=""xs:integer"" />
      </xs:simpleType>
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:length value=""0"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:union>
  </xs:simpleType>
  <xs:simpleType name=""DateTime"">
    <xs:union>
      <xs:simpleType>
        <xs:restriction base=""xs:dateTime"" />
      </xs:simpleType>
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:length value=""0"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:union>
  </xs:simpleType>
  <xs:complexType name=""PortActivities"">
    <xs:sequence>
      <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Activity"">
        <xs:complexType>
          <xs:attribute name=""Name"" type=""xs:string"" use=""required"" />
          <xs:attribute name=""Time"" type=""xs:dateTime"" use=""required"" />
          <xs:attribute name=""CargoName"" type=""xs:string"" />
          <xs:attribute name=""Remark"" type=""xs:string"" />
        </xs:complexType>
      </xs:element>
    </xs:sequence>
  </xs:complexType>
</xs:schema>";
        
        public Schema_IMOS_OperationUpdate() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Form";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

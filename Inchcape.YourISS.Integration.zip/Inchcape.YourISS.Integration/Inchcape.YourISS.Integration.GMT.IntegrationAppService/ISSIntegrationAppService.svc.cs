﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Inchcape.YourISS.Integration.GMT.IntegrationModels;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Security.Cryptography;
using System.IO;

namespace Inchcape.YourISS.Integration.GMT.IntegrationAppService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ISSIntegrationAppService : IISSIntegrationAppService
    {
            public bool SaveISSIntegrationMessage(ISSGMTIntegrationDto RequestMsg, Guid AccountId, string Method)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration");
                bool success = false;
                try
                {
                    using (SqlConnection sqlConnection = new SqlConnection())
                    {
                        string connectionString = GetControlDBConnectionString();
                        sqlConnection.ConnectionString = connectionString;
                        System.Diagnostics.EventLog.WriteEntry("Application", "ConnectionString - " + connectionString);
                        using (SqlCommand sqlCommand = new SqlCommand("spu_insert_Message_data_imos", sqlConnection))
                        {
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.CommandTimeout = 600;

                            sqlCommand.Parameters.Add("@AccountId", SqlDbType.UniqueIdentifier).Value = AccountId;
                            sqlCommand.Parameters.Add("@MessageId", SqlDbType.UniqueIdentifier).Value = RequestMsg.MessageID;

                            sqlCommand.Parameters.Add("@Version", SqlDbType.Int).Value = 1;
                            sqlCommand.Parameters.Add("@MessageVersion", SqlDbType.Int).Value = 1;
                            sqlCommand.Parameters.Add("@SourceIntegrationSystem", SqlDbType.VarChar, 50).Value = "IMOS";
                            sqlCommand.Parameters.Add("@DestinationIntegrationSystem", SqlDbType.VarChar, 50).Value = "YourISS";
                            System.Diagnostics.EventLog.WriteEntry("Application", "Before Get Reference method");

                            XmlDocument doc = new XmlDocument();
                            doc.LoadXml(RequestMsg.Message);

                            XmlNodeList xnCompanyCodeList = doc.SelectNodes("/PortCallDetails/CompanyCode");
                            XmlNode xnCompanyCode = xnCompanyCodeList[0];
                            string companyCode = xnCompanyCode.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "CompanyCode - " + companyCode);

                            XmlNodeList xnVesselCodeList = doc.SelectNodes("/PortCallDetails/VesselCode");
                            XmlNode xnVesselCode = xnVesselCodeList[0];
                            string vesselCode = xnVesselCode.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "VesselCode - " + vesselCode);

                            XmlNodeList xnVoyageNoList = doc.SelectNodes("/PortCallDetails/VoyageNo");
                            XmlNode xnVoyageNo = xnVoyageNoList[0];
                            string voyageNumber = xnVoyageNo.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "VoyageNumber - " + voyageNumber);

                            XmlNodeList xnListPortCallSeq = doc.SelectNodes("/PortCallDetails/PortCallSeq");
                            XmlNode xnNodePortCallSeq = xnListPortCallSeq[0];
                            string portcallNumber = xnNodePortCallSeq.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "portcallNumber - " + portcallNumber);

                            string refNumber = string.Empty;

                            refNumber = companyCode + "|" + vesselCode + "|" + voyageNumber + "|" + portcallNumber;
                            System.Diagnostics.EventLog.WriteEntry("Application", "refNumber - " + refNumber);

                            sqlCommand.Parameters.Add("@RequestData", SqlDbType.VarChar).Value = RequestMsg.Message;
                            sqlCommand.Parameters.Add("@MessageDate", SqlDbType.DateTime).Value = DateTime.UtcNow.ToString();
                            sqlCommand.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 100).Value = refNumber;
                            sqlCommand.Parameters.Add("@Method", SqlDbType.VarChar, 50).Value = Method;

                            sqlConnection.Open();

                            sqlCommand.ExecuteNonQuery();
                            success = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "App Server Error - " + ex.Message);
                    throw new Exception(ex.Message);
                }

                return success;
            }

            public int ValidateIntegrationSystem(Guid AccountId)
            {
                int count = 0;
                try
                {
                    using (SqlConnection sqlConnection = new SqlConnection())
                    {

                        string connectionString = GetDecryptedConnectionString(ConfigurationManager.ConnectionStrings["ControlDBConnectionString"].ToString());
                        //string connectionString = @"Database=ERP_INTF; Server=ISSIDCBIZTALK\ISSIDCBIZTALK; uid=IDCBizTalkUser; pwd=Sh1pN3t05";

                        //string connectionString = GetControlDBConnectionString();
                        sqlConnection.ConnectionString = connectionString;
                        System.Diagnostics.EventLog.WriteEntry("Application", "ConnectionString - " + connectionString);
                        System.Diagnostics.EventLog.WriteEntry("Application", "AccountId - " + AccountId);
                        using (SqlCommand sqlCommand = new SqlCommand("SPU_Validate_IntegrationSystem", sqlConnection))
                        {
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.CommandTimeout = 600;

                            sqlCommand.Parameters.Add("@HubPrincipalKey", SqlDbType.UniqueIdentifier).Value = AccountId;

                            sqlConnection.Open();

                            count = Convert.ToInt32(sqlCommand.ExecuteScalar());
                            System.Diagnostics.EventLog.WriteEntry("Application", "count - " + count);
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Error - " + ex.Message);
                    throw new Exception(ex.Message);
                }
                return count;
            }

            public static string GetControlDBConnectionString()
            {
                string conString = "";
                try
                {

                    //RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\Shipnet", true);
                    conString = GetDecryptedConnectionString(ConfigurationManager.ConnectionStrings["ControlDBConnectionString"].ToString());
                    // System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetBizConnectionString  -->" + conString);
                }
                catch (Exception exp)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetControlDBConnectionString  Exception -->" + exp.Message + exp.StackTrace);
                    //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
                }
                return conString;
            }

            public static string GetDecryptedConnectionString(string encryptedConString)
            {
                string initVector = "tu89geji340t89u2";
                string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
                int keysize = 256;
                string decryptedConStr = "";
                try
                {

                    byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
                    byte[] cipherTextBytes = Convert.FromBase64String(encryptedConString);
                    PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
                    byte[] keyBytes = password.GetBytes(keysize / 8);
                    RijndaelManaged symmetricKey = new RijndaelManaged();
                    symmetricKey.Mode = CipherMode.CBC;
                    ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
                    MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
                    CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                    byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                    int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                    memoryStream.Close();
                    cryptoStream.Close();
                    decryptedConStr = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);


                }
                catch (Exception exp)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Decryption  Exception -->" + exp.Message + exp.StackTrace);
                    //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDecryptedConnectionString-->{0}", exp.Message));
                }

                return decryptedConStr;
            }
        }

}

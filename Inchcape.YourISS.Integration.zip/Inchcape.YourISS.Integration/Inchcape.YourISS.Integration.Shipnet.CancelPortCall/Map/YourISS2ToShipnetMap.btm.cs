namespace Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.TypedPolling_ShipnetCancelPortCall+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.Shipnet.CancelPortCall.TypedPolling_ShipnetCancelPortCall.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema_YourISS2ToShipnetCancel", typeof(global::Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema_YourISS2ToShipnetCancel))]
    public sealed class YourISS2ToShipnetMap : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s1 s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema"" xmlns:s1=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/ShipnetCancelPortCall"" xmlns:s0=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:TypedPollingResultSet0"" />
  </xsl:template>
  <xsl:template match=""/s1:TypedPollingResultSet0"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;PortCallCancel&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;Cancel&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringTrimLeft(string(s1:ReferenceNumber/text()))"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringTrimRight(string($var:v3))"" />
    <xsl:variable name=""var:v5"" select=""userCSharp:StringFind(string($var:v4) , &quot;|&quot;)"" />
    <xsl:variable name=""var:v6"" select=""userCSharp:MathSubtract(string($var:v5) , &quot;1&quot;)"" />
    <xsl:variable name=""var:v7"" select=""userCSharp:StringSubstring(string($var:v4) , &quot;1&quot; , string($var:v6))"" />
    <xsl:variable name=""var:v8"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <xsl:variable name=""var:v9"" select=""string(s1:ReferenceNumber/text())"" />
    <xsl:variable name=""var:v10"" select=""userCSharp:StringTrimLeft($var:v9)"" />
    <xsl:variable name=""var:v11"" select=""userCSharp:StringTrimRight(string($var:v10))"" />
    <xsl:variable name=""var:v12"" select=""userCSharp:StringFind(string($var:v11) , &quot;|&quot;)"" />
    <xsl:variable name=""var:v13"" select=""userCSharp:MathAdd(string($var:v12) , &quot;1&quot;)"" />
    <xsl:variable name=""var:v14"" select=""userCSharp:StringSize(string($var:v11))"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringSubstring(string($var:v11) , string($var:v13) , string($var:v14))"" />
    <xsl:variable name=""var:v16"" select=""userCSharp:StringFind(string($var:v15) , &quot;|&quot;)"" />
    <xsl:variable name=""var:v17"" select=""userCSharp:MathAdd(string($var:v16) , &quot;1&quot;)"" />
    <xsl:variable name=""var:v18"" select=""userCSharp:StringSize(string($var:v15))"" />
    <xsl:variable name=""var:v19"" select=""userCSharp:StringSubstring(string($var:v15) , string($var:v17) , string($var:v18))"" />
    <xsl:variable name=""var:v20"" select=""userCSharp:StringFind(string($var:v19) , &quot;|&quot;)"" />
    <xsl:variable name=""var:v21"" select=""userCSharp:MathSubtract(string($var:v20) , &quot;1&quot;)"" />
    <xsl:variable name=""var:v22"" select=""userCSharp:StringSubstring(string($var:v19) , &quot;1&quot; , string($var:v21))"" />
    <xsl:variable name=""var:v23"" select=""userCSharp:MathSubtract(string($var:v16) , &quot;1&quot;)"" />
    <xsl:variable name=""var:v24"" select=""userCSharp:StringSubstring(string($var:v15) , &quot;1&quot; , string($var:v23))"" />
    <ns0:YourIssNotification>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""$var:v1"" />
        </MessageType>
        <Action>
          <xsl:value-of select=""$var:v2"" />
        </Action>
        <xsl:if test=""s1:CreatedDate"">
          <CreatedDate>
            <xsl:value-of select=""s1:CreatedDate/text()"" />
          </CreatedDate>
        </xsl:if>
        <ShipNetReference>
          <xsl:value-of select=""$var:v7"" />
        </ShipNetReference>
        <SourceApplication>
          <xsl:value-of select=""$var:v8"" />
        </SourceApplication>
      </MessageHeader>
      <PortCallCancel>
        <SN_KeyPosition>
          <xsl:value-of select=""$var:v22"" />
        </SN_KeyPosition>
        <SN_DANo>
          <xsl:value-of select=""$var:v24"" />
        </SN_DANo>
      </PortCallCancel>
    </ns0:YourIssNotification>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public string StringTrimRight(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimEnd(null);
}


public int StringFind(string str, string strFind)
{
	if (str == null || strFind == null || strFind == """")
	{
		return 0;
	}
	return (str.IndexOf(strFind) + 1);
}


public string StringSubstring(string str, string left, string right)
{
	string retval = """";
	double dleft = 0;
	double dright = 0;
	if (str != null && IsNumeric(left, ref dleft) && IsNumeric(right, ref dright))
	{
		int lt = (int)dleft;
		int rt = (int)dright;
		lt--; rt--;
		if (lt >= 0 && rt >= lt && lt < str.Length)
		{
			if (rt < str.Length)
			{
				retval = str.Substring(lt, rt-lt+1);
			}
			else
			{
				retval = str.Substring(lt, str.Length-lt);
			}
		}
	}
	return retval;
}


public string MathSubtract(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	bool first = true;
	foreach (string obj in listValues)
	{
		if (first)
		{
			first = false;
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret = d;
			}
			else
			{
				return """";
			}
		}
		else
		{
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret -= d;
			}
			else
			{
				return """";
			}
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string MathAdd(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	foreach (string obj in listValues)
	{
	double d = 0;
		if (IsNumeric(obj, ref d))
		{
			ret += d;
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public int StringSize(string str)
{
	if (str == null)
	{
		return 0;
	}
	return str.Length;
}


public string StringConcat(string param0)
{
   return param0;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.TypedPolling_ShipnetCancelPortCall+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.Shipnet.CancelPortCall.TypedPolling_ShipnetCancelPortCall.TypedPollingResultSet0 _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema_YourISS2ToShipnetCancel";
        
        private const global::Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema_YourISS2ToShipnetCancel _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.TypedPolling_ShipnetCancelPortCall+TypedPollingResultSet0";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Shipnet.CancelPortCall.Schema.Schema_YourISS2ToShipnetCancel";
                return _TrgSchemas;
            }
        }
    }
}

namespace Inchcape.YourISS.Integration.Generic.Schemas.Generic {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA",@"DA")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.RoutingDetailID), XPath = @"/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='RoutingDetailID' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PortCallNumber), XPath = @"/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='Header' and namespace-uri()='']/*[local-name()='PortCallNumber' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Header.PortCallNumber", XPath = @"/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='Header' and namespace-uri()='']/*[local-name()='PortCallNumber' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "RoutingDetailID", XPath = @"/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='RoutingDetailID' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"DA"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema))]
    public sealed class Schema_Generic_SplittedFinalDA : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" location=""Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""DA"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:RoutingDetailID"" xpath=""/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='RoutingDetailID' and namespace-uri()='']"" />
          <b:property name=""ns0:PortCallNumber"" xpath=""/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='Header' and namespace-uri()='']/*[local-name()='PortCallNumber' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='Header' and namespace-uri()='']/*[local-name()='PortCallNumber' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='DA' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA']/*[local-name()='RoutingDetailID' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Header"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""PortCallNumber"" type=""xs:string"" />
              <xs:element name=""HubPrincipalKey"" type=""xs:string"" />
              <xs:element name=""ReferenceCode"" type=""xs:string"" />
              <xs:element name=""DANumber"" type=""xs:string"" />
              <xs:element name=""DATypeFlag"" type=""xs:string"" />
              <xs:element name=""DADate"" type=""xs:dateTime"" />
              <xs:element name=""HomeCurrency"" type=""xs:string"" />
              <xs:element name=""DACurrency"" type=""xs:string"" />
              <xs:element name=""ExchangeRate"" type=""xs:decimal"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Details"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Detail"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""ISSServiceId"" type=""xs:unsignedByte"" />
                    <xs:element name=""Code"" type=""xs:unsignedInt"" />
                    <xs:element name=""Name"" type=""xs:string"" />
                    <xs:element name=""HomeCurrencyAmount"" type=""xs:decimal"" />
                    <xs:element name=""DACurrencyAmount"" type=""xs:decimal"" />
                    <xs:element name=""IsActive"" type=""xs:unsignedByte"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""RoutingDetailID"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_Generic_SplittedFinalDA() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "DA";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

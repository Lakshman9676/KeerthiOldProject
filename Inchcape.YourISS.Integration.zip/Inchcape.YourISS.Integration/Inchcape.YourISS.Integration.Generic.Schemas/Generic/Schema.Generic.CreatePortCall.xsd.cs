namespace Inchcape.YourISS.Integration.Generic.Schemas.Generic {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate",@"YourIssNotification")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIssNotification"})]
    public sealed class Schema_Generic_CreatePortCall : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xsd:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
  <xsd:element name=""YourIssNotification"">
    <xsd:complexType>
      <xsd:sequence>
        <xsd:element name=""HubPrincipalKey"" type=""xsd:string"" />
        <xsd:element name=""Id"" type=""xsd:string"" />
        <xsd:element name=""MessageHeader"">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name=""MessageType"" type=""xsd:string"" />
              <xsd:element name=""Action"" type=""xsd:string"" />
              <xsd:element name=""CreatedDate"" type=""xsd:dateTime"" />
              <xsd:element name=""ShipNetReference"" type=""xsd:string"" />
              <xsd:element name=""ShipNetOperatorId"" type=""xsd:string"" />
              <xsd:element name=""ShipNetOperatorName"" type=""xsd:string"" />
              <xsd:element name=""SourceApplication"" type=""xsd:string"" />
            </xsd:sequence>
          </xsd:complexType>
        </xsd:element>
        <xsd:element name=""PortCall"">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name=""HubPrincipalCode"" type=""xsd:string"" />
              <xsd:element name=""HubPrincipalName"" type=""xsd:string"" />
              <xsd:element name=""PrincipalCode"" type=""xsd:string"" />
              <xsd:element name=""PrincipalName"" type=""xsd:string"" />
              <xsd:element minOccurs=""0"" name=""SN_DANo"" nillable=""true"" type=""xsd:unsignedByte"" />
              <xsd:element name=""SN_KeyPosition"" type=""xsd:unsignedShort"" />
              <xsd:element name=""SN_VesselCode"" type=""xsd:string"" />
              <xsd:element name=""VesselName"" type=""xsd:string"" />
              <xsd:element minOccurs=""0"" name=""IMO"" nillable=""true"" type=""xsd:string"" />
              <xsd:element name=""SN_VoyageNumber"" type=""xsd:string"" />
              <xsd:element name=""ETA"" type=""xsd:dateTime"" />
              <xsd:element name=""ETS"" type=""xsd:dateTime"" />
              <xsd:element minOccurs=""0"" name=""SN_DaType"" nillable=""true"" type=""xsd:string"" />
              <xsd:element name=""PortOperationCode"" type=""xsd:string"" />
              <xsd:element name=""PortOperationName"" type=""xsd:string"" />
              <xsd:element name=""SN_AgentCode"" type=""xsd:string"" />
              <xsd:element name=""SN_AgentName"" type=""xsd:string"" />
              <xsd:element name=""ISS_AgentCode"" type=""xsd:string"" />
              <xsd:element name=""SN_NominationType"" type=""xsd:string"" />
              <xsd:element name=""PortCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Ports"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element name=""Port"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_AcctsCode"" type=""xsd:string"" />
                          <xsd:element name=""PortName"" type=""xsd:string"" />
                          <xsd:element name=""PortCode"" type=""xsd:string"" />
                          <xsd:element name=""ISS_PortCode"" type=""xsd:string"" />
                          <xsd:element name=""SN_CountryCode"" type=""xsd:string"" />
                          <xsd:element name=""SN_CountryName"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element minOccurs=""0"" name=""PreviousPort"" nillable=""true"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element name=""Port"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_AcctsCode"" type=""xsd:string"" />
                          <xsd:element name=""PortName"" type=""xsd:string"" />
                          <xsd:element name=""PortCode"" type=""xsd:string"" />
                          <xsd:element name=""ISS_PortCode"" type=""xsd:string"" />
                          <xsd:element minOccurs=""0"" name=""SN_CountryCode"" nillable=""true"" type=""xsd:string"" />
                          <xsd:element minOccurs=""0"" name=""SN_CountryName"" nillable=""true"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element name=""NextPort"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element name=""Port"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_AcctsCode"" type=""xsd:string"" />
                          <xsd:element name=""PortName"" type=""xsd:string"" />
                          <xsd:element name=""PortCode"" type=""xsd:string"" />
                          <xsd:element name=""ISS_PortCode"" type=""xsd:string"" />
                          <xsd:element minOccurs=""0"" name=""SN_CountryCode"" nillable=""true"" type=""xsd:string"" />
                          <xsd:element minOccurs=""0"" name=""SN_CountryName"" nillable=""true"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element minOccurs=""0"" name=""Master"" nillable=""true"" type=""xsd:string"" />
              <xsd:element minOccurs=""0"" name=""Competitive"" nillable=""true"" type=""xsd:string"" />
              <xsd:element name=""CargoCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Cargoes"">
                <xsd:complexType>
                  <xsd:sequence minOccurs=""0"" maxOccurs=""unbounded"">
                    <xsd:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Cargo"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_KeyCargo"" type=""xsd:unsignedByte"" />
                          <xsd:element name=""SN_CargoNo"" type=""xsd:unsignedByte"" />
                          <xsd:element name=""SN_ChartererCode"" type=""xsd:string"" />
                          <xsd:element name=""SN_ChartererName"" type=""xsd:string"" />
                          <xsd:element name=""ISS_ChartererCode"" type=""xsd:string"" />
                          <xsd:element minOccurs=""0"" name=""ISS_CommodityCode"" nillable=""true"" type=""xsd:string"" />
                          <xsd:element name=""CommodityCode"" type=""xsd:string"" />
                          <xsd:element name=""CommodityName"" type=""xsd:string"" />
                          <xsd:element name=""Quantity"" type=""xsd:decimal"" />
                          <xsd:element name=""QuantityTypeCode"" type=""xsd:string"" />
                          <xsd:element name=""QuantityTypeName"" type=""xsd:string"" />
                          <xsd:element name=""CargoOperationCode"" type=""xsd:string"" />
                          <xsd:element name=""CargoOperationName"" type=""xsd:string"" />
                          <xsd:element name=""DemurageRate"" type=""xsd:decimal"" />
                          <xsd:element name=""DespatchRate"" type=""xsd:decimal"" />
                          <xsd:element name=""LoadingTerms"" type=""xsd:decimal"" />
                          <xsd:element name=""LoadingType"" type=""xsd:string"" />
                          <xsd:element name=""DischargeTerms"" type=""xsd:decimal"" />
                          <xsd:element name=""DischargeType"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element name=""BunkerCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Bunkers"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element maxOccurs=""unbounded"" name=""Bunker"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""Grade"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
            </xsd:sequence>
          </xsd:complexType>
        </xsd:element>
        <xsd:element minOccurs=""0"" name=""CancelPortCal"" nillable=""true"">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name=""SN_DANo"" type=""xsd:string"" />
              <xsd:element name=""SN_KeyPosition"" type=""xsd:unsignedShort"" />
            </xsd:sequence>
          </xsd:complexType>
        </xsd:element>
      </xsd:sequence>
    </xsd:complexType>
  </xsd:element>
</xsd:schema>";
        
        public Schema_Generic_CreatePortCall() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIssNotification";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

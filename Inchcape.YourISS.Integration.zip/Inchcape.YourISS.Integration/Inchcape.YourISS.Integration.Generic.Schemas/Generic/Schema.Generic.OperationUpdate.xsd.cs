namespace Inchcape.YourISS.Integration.Generic.Schemas.Generic {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate",@"YourIssNotification")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIssNotification"})]
    public sealed class Schema_Generic_OperationUpdate : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""YourIssNotification"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""MessageHeader"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""MessageType"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Action"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""CreatedDate"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""ShipNetReference"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""SourceApplication"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element maxOccurs=""1"" name=""Operational"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""SN_DANo"" nillable=""true"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""SN_KeyPosition"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""SN_VesselCode"" nillable=""true"">
                <xs:simpleType>
                  <xs:restriction base=""xs:string"">
                    <xs:maxLength value=""8"" />
                  </xs:restriction>
                </xs:simpleType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""SN_VoyageNumber"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""ETA"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""ETS"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""EOSP"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""CommencedSeaPassage"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""EtaNextPort"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""NextPortCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""NextPortName"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Master"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""WorkflowStatus"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Agentacceptance"" nillable=""true"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""ETB"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""CargoCount"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Cargoes"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Cargo"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""SN_KeyCargo"" nillable=""true"" type=""xs:int"" />
                          <xs:element minOccurs=""0"" name=""SN_CargoNo"" nillable=""true"" type=""xs:int"" />
                          <xs:element minOccurs=""0"" name=""Terminal"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Berth"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""BlFigures"" nillable=""true"" type=""xs:decimal"" />
                          <xs:element minOccurs=""0"" name=""ShipFigures"" nillable=""true"" type=""xs:decimal"" />
                          <xs:element minOccurs=""0"" name=""DraftIn"" nillable=""true"">
                            <xs:simpleType>
                              <xs:restriction base=""xs:string"">
                                <xs:maxLength value=""1"" />
                              </xs:restriction>
                            </xs:simpleType>
                          </xs:element>
                          <xs:element minOccurs=""0"" name=""ArrDraftAft"" nillable=""true"" type=""xs:decimal"" />
                          <xs:element name=""ArrDraftMid"" type=""xs:decimal"" />
                          <xs:element name=""ArrDraftFwd"" type=""xs:decimal"" />
                          <xs:element name=""DepDraftAft"" type=""xs:decimal"" />
                          <xs:element name=""DepDraftMid"" type=""xs:decimal"" />
                          <xs:element name=""DepDraftFwd"" type=""xs:decimal"" />
                          <xs:element minOccurs=""0"" name=""Deadfreight"" nillable=""true"" type=""xs:int"" />
                          <xs:element minOccurs=""0"" name=""Overage"" nillable=""true"" type=""xs:int"" />
                          <xs:element minOccurs=""0"" name=""Shipper"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Receiver"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""BlDate"" nillable=""true"" type=""xs:dateTime"" />
                          <xs:element name=""DocumentCount"" type=""xs:string"" />
                          <xs:element name=""Documents"">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Document"" nillable=""true"" type=""xs:string"" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""BunkerCount"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Bunkers"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Bunker"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Grade"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""ArrQuantity"" nillable=""true"" type=""xs:decimal"" />
                          <xs:element minOccurs=""0"" name=""TakenQuantity"" nillable=""true"" type=""xs:decimal"" />
                          <xs:element minOccurs=""0"" name=""DepQuantity"" nillable=""true"" type=""xs:decimal"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""StatementCount"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Statements"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Sof"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""SN_KeyCargo"" nillable=""true"" type=""xs:int"" />
                          <xs:element minOccurs=""0"" name=""SofLabel"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""SofDateTime"" nillable=""true"" type=""xs:dateTime"" />
                          <xs:element name=""SofEndDate"" type=""xs:dateTime"" />
                          <xs:element minOccurs=""0"" name=""SofComments"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""EventCount"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Events"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Event"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name=""EventLabel"" type=""xs:string"" />
                          <xs:element name=""EventDateTime"" type=""xs:dateTime"" />
                          <xs:element minOccurs=""0"" name=""EventComments"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""EventUtcOffset"" nillable=""true"" type=""xs:int"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""DocumentCount"" type=""xs:string"" />
              <xs:element name=""Documents"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Document"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_Generic_OperationUpdate() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIssNotification";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

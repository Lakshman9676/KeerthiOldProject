namespace Inchcape.YourISS.Integration.Generic.Schemas.YourISS {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS",@"YourIss2Appointment")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.Number), XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS']/*[local-name()='Number' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Number", XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS']/*[local-name()='Number' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIss2Appointment"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema))]
    public sealed class Schema_YourISS_OperationUpdate : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" location=""Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""YourIss2Appointment"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:Number"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS']/*[local-name()='Number' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS']/*[local-name()='Number' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""Number"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""Appointments"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Number"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Principal"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""PerformingAgent"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""MainCommodity"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""AgencyType"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Uri"" type=""xs:anyType"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Eta"" type=""xs:dateTime"" />
        <xs:element minOccurs=""0"" name=""OkToSail"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""PortCallAccepted"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""ControllingAgentAccepted"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""IsPortOperationComplete"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""PortOperationCompleteTime"" nillable=""true"" type=""xs:dateTime"" />
        <xs:element minOccurs=""0"" name=""AccountingOffice"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PortOperation"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Port"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""NextPort"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PreviousPort"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""MainCommodity"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Vessel"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Imo"" type=""xs:unsignedInt"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""FlowStatus"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""PortCallOperations"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Ets"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""Eosp"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""Cosp"" type=""xs:dateTime"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Bunkers"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Lsfo"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Hfo"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Lsgo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Mdo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Mgo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Lo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""FwCrew"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""FwShip"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Drafts"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Fwd"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""Mean"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Aft"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Tugs"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""TugName"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Type"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Total"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""Comments"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Cargoes"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""RefCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Rotation"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Poi"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                          <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Berth"">
                      <xs:complexType>
                        <xs:sequence minOccurs=""0"">
                          <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                          <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Etb"" type=""xs:dateTime"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""NominationQuantity"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""ShipperReceiver"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""LaycanFrom"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""LaycanTo"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""CommodityDetail"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""CargoActivity"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""BillOfLadingQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""ShoreQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""VesselQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Temperature"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""TankName"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""DailyCargoOperations"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""StartOperationTime"" type=""xs:dateTime"" />
                    <xs:element minOccurs=""0"" name=""EndOperationTime"" type=""xs:anyType"" />
                    <xs:element minOccurs=""0"" name=""LdQuantity"" type=""xs:unsignedByte"" />
                    <xs:element minOccurs=""0"" name=""TankHatchNumber"" type=""xs:anyType"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Rotations"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Poi"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Berth"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Etb"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""OperationEvents"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""RefCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Etb"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""StartDate"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""EndDate"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""Comments"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""Poi"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Berth"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Event"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Id"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""Uri"" type=""xs:anyType"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_YourISS_OperationUpdate() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIss2Appointment";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

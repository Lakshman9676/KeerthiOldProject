namespace Inchcape.YourISS.Integration.Generic.Schemas.YourISS {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate",@"YourIss2Appointment")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.Number), XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='Number' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.AppointmentNumber), XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='AppointmentNumber' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Number", XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='Number' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "AppointmentNumber", XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='AppointmentNumber' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIss2Appointment"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema))]
    public sealed class Schema_YourISS_CreatePortCall : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate"" xmlns:ns1=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""https://Inchcape.Shipnet.BT.CreatePortCall.PropertySchema"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns1"" uri=""https://Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema"" location=""Inchcape.YourISS.Integration.Generic.Schemas.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""YourIss2Appointment"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns1:Number"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='Number' and namespace-uri()='']"" />
          <b:property name=""ns1:AppointmentNumber"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='AppointmentNumber' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='Number' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate']/*[local-name()='AppointmentNumber' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""Number"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""OkToSail"" nillable=""true"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" default=""false"" name=""PortCallAccepted"" nillable=""true"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" default=""false"" name=""ControllingAgentAccepted"" nillable=""true"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""HubPrincipalKey"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""AppointmentNumber"" type=""xs:string"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Appointments"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""ExternalJobCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Number"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""CurrencyCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Principal"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                    <xs:element name=""Name"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""PerformingAgent"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element name=""Code"" nillable=""true"" type=""xs:string"" />
                    <xs:element name=""Name"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""MainCommodity"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""AgencyType"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element name=""Code"" nillable=""true"" type=""xs:string"" />
                    <xs:element name=""Name"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""DATimeBar"" nillable=""true"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""AccountingOffice"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
              <xs:element name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PortOperation"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Port"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""NextPort"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PreviousPort"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""MainCommodity"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Vessel"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Imo"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Eta"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""VoyageNumber"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""CurrencyCode"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""FlowStatus"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""Charterer"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""PortCallOperations"" nillable=""true"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""Ets"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""Eosp"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""Cosp"" nillable=""true"" type=""xs:dateTime"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Cargoes"" nillable=""true"">
          <xs:complexType>
            <xs:sequence minOccurs=""0"" maxOccurs=""unbounded"">
              <xs:element minOccurs=""0"" name=""RefCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Rotation"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Poi"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Berth"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence minOccurs=""0"">
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Etb"" nillable=""true"" type=""xs:dateTime"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" nillable=""true"" type=""xs:boolean"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""NominationQuantity"" nillable=""true"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""ShipperReceiver"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""LaycanFrom"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""LaycanTo"" nillable=""true"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""CommodityDetail"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""CargoActivity"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:int"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""BillOfLadingQuantity"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""ShoreQuantity"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""VesselQuantity"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Temperature"" nillable=""true"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""TankName"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""DailyCargoOperations"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""StartOperationTime"" nillable=""true"" type=""xs:dateTime"" />
                    <xs:element minOccurs=""0"" name=""LdQuantity"" nillable=""true"" type=""xs:decimal"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" nillable=""true"" type=""xs:boolean"" />
                    <xs:element minOccurs=""0"" name=""EndOperationTime"" nillable=""true"" type=""xs:dateTime"" />
                    <xs:element minOccurs=""0"" name=""TankHatchNumber"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" nillable=""true"" type=""xs:boolean"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_YourISS_CreatePortCall() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIss2Appointment";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

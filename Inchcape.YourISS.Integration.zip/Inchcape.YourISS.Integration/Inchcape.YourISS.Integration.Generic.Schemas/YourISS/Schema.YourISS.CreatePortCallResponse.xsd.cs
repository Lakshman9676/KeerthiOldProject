namespace Inchcape.YourISS.Integration.Generic.Schemas.YourISS {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreateResponse",@"LinkAppointment")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"LinkAppointment"})]
    public sealed class Schema_YourIss2CreatePortCallResponse : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreateResponse"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreateResponse"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""LinkAppointment"">
    <xs:complexType>
      <xs:sequence>
        <xs:element maxOccurs=""unbounded"" name=""portcalls"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Number"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Appointments"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Number"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""ExternalJobCode"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Principal"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                          <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""PerformingAgent"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""MainCommodity"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""AgencyType"" nillable=""true"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Uri"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Eta"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""OkToSail"" nillable=""true"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""PortCallAccepted"" nillable=""true"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""ControllingAgentAccepted"" nillable=""true"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""HubPrincipalKey"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""AccountingOffice"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""PortOperation"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Port"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""NextPort"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""PreviousPort"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""MainCommodity"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Vessel"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Imo"" nillable=""true"" type=""xs:unsignedInt"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""FlowStatus"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsPortOperationComplete"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""PortOperationCompleteTime"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Charterer"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element name=""Code"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""PortCallOperations"" nillable=""true"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
                    <xs:element minOccurs=""0"" name=""Ets"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Eosp"" nillable=""true"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Cosp"" nillable=""true"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""CurrencyCode"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Id"" nillable=""true"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""Uri"" nillable=""true"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_YourIss2CreatePortCallResponse() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "LinkAppointment";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

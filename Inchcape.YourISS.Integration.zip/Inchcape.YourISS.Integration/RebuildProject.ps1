function RebuildProject ( $project)
{
# Write to the prompt
Write-Host($mode + " " + $project)
 
# Set the directory of the project
$solutionDir = $baseDir + $project
 
# Set the solution file to be used
$solutionFile = $project + ".sln"
 
# Set options for the MSBuild process
$options = $verbosity + "/nologo /p:Configuration=" + $mode
 
# This will use MSBuild to clean the output directory of the solution
$clean = $msbuild + " " + $solutionFile + " " + $options + " /t:Clean"
 
# This will use MSBuild to build the solution
$build = $msbuild + " " + $solutionFile + " " + $options
 
# Go to the directory of the solution
cd $solutionDir
 
# Clean the solution output directory
Invoke-Expression $clean
 
# Build the solution
Invoke-Expression $build
}
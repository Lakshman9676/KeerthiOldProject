namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"spu_get_customer_configuration_dataloyResponse", @"spu_get_customer_configuration_dataloy"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.ProcedureResultSet_dbo_spu_get_customer_configuration_dataloy", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.ProcedureResultSet_dbo_spu_get_customer_configuration_dataloy))]
    public sealed class TypedProcedure_dbo : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns3=""http://schemas.microsoft.com/Sql/2008/05/ProceduresResultSets/dbo/spu_get_customer_configuration_dataloy"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"" version=""1.0"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.ProcedureResultSet_dbo_spu_get_customer_configuration_dataloy"" namespace=""http://schemas.microsoft.com/Sql/2008/05/ProceduresResultSets/dbo/spu_get_customer_configuration_dataloy"" />
  <xs:annotation>
    <xs:appinfo>
      <fileNameHint xmlns=""http://schemas.microsoft.com/servicemodel/adapters/metadata/xsd"">TypedProcedure.dbo</fileNameHint>
      <b:references>
        <b:reference targetNamespace=""http://schemas.microsoft.com/2003/10/Serialization/"" />
        <b:reference targetNamespace=""http://schemas.microsoft.com/Sql/2008/05/ProceduresResultSets/dbo/spu_get_customer_configuration_dataloy"" />
      </b:references>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""spu_get_customer_configuration_dataloyResponse"">
    <xs:annotation>
      <xs:documentation>
        <doc:action xmlns:doc=""http://schemas.microsoft.com/servicemodel/adapters/metadata/documentation"">TypedProcedure/dbo/spu_get_customer_configuration_dataloy/response</doc:action>
      </xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" maxOccurs=""1"" name=""StoredProcedureResultSet0"" nillable=""true"" type=""ns3:ArrayOfStoredProcedureResultSet0"" />
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""ReturnValue"" type=""xs:int"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""spu_get_customer_configuration_dataloy"">
    <xs:annotation>
      <xs:documentation>
        <doc:action xmlns:doc=""http://schemas.microsoft.com/servicemodel/adapters/metadata/documentation"">TypedProcedure/dbo/spu_get_customer_configuration_dataloy</doc:action>
      </xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence />
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public TypedProcedure_dbo() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [2];
                _RootElements[0] = "spu_get_customer_configuration_dataloyResponse";
                _RootElements[1] = "spu_get_customer_configuration_dataloy";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo",@"spu_get_customer_configuration_dataloyResponse")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"spu_get_customer_configuration_dataloyResponse"})]
        public sealed class spu_get_customer_configuration_dataloyResponse : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public spu_get_customer_configuration_dataloyResponse() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "spu_get_customer_configuration_dataloyResponse";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo",@"spu_get_customer_configuration_dataloy")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"spu_get_customer_configuration_dataloy"})]
        public sealed class spu_get_customer_configuration_dataloy : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public spu_get_customer_configuration_dataloy() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "spu_get_customer_configuration_dataloy";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}

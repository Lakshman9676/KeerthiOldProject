namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.CargoPort.Schema",@"root")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"root"})]
    public sealed class Schema_CargoPortOutput : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.CargoPort.Schema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.CargoPort.Schema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""root"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""cargoPortSequence"" type=""xs:byte"" />
        <xs:element name=""port"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""portName"" type=""xs:string"" />
              <xs:element name=""unLoCode"" type=""xs:string"" />
              <xs:element name=""country"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""countryCode"" type=""xs:string"" />
                    <xs:element name=""countryName"" type=""xs:string"" />
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""isCanal"" type=""xs:string"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""reasonForCall"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""reasonForCall"" type=""xs:string"" />
              <xs:element name=""reasonForCallDesc"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""isHandlingCostLumpsum"" type=""xs:string"" />
        <xs:element name=""handlingCostRate"" type=""xs:byte"" />
        <xs:element name=""cargo"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""freightRate"" type=""xs:byte"" />
        <xs:element name=""cargoQuantity"" type=""xs:short"" />
        <xs:element name=""laytimeTermsValue"" type=""xs:byte"" />
        <xs:element name=""laytimeTerms"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""laytimeTerms"" type=""xs:string"" />
              <xs:element name=""laytimeTermsCode"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""hcMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""isCargoQuantityFixed"" type=""xs:string"" />
        <xs:element name=""isBlActive"" type=""xs:string"" />
        <xs:element name=""isFreeDespatch"" type=""xs:string"" />
        <xs:element name=""isLaytimeProrated"" type=""xs:string"" />
        <xs:element name=""isWorking"" type=""xs:string"" />
        <xs:element name=""laytimeQuantity"" type=""xs:byte"" />
        <xs:element name=""onDockQuantity"" type=""xs:byte"" />
        <xs:element name=""pctOfLaytimeUsed"" type=""xs:byte"" />
        <xs:element name=""reversibleMatch"" type=""xs:byte"" />
        <xs:element name=""laytimeCounterpart"" type=""xs:string"" />
        <xs:element name=""tcRateIndex"" type=""xs:string"" />
        <xs:element name=""transshipmentVessel"" type=""xs:string"" />
        <xs:element name=""createdDate"" type=""xs:dateTime"" />
        <xs:element name=""modifiedDate"" type=""xs:dateTime"" />
        <xs:element name=""createdById"" type=""xs:int"" />
        <xs:element name=""handlingCost"" type=""xs:byte"" />
        <xs:element name=""freight"" type=""xs:byte"" />
        <xs:element name=""laytimeAllowed"" type=""xs:byte"" />
        <xs:element name=""volume"" type=""xs:byte"" />
        <xs:element name=""weight"" type=""xs:short"" />
        <xs:element name=""demurrage"" type=""xs:byte"" />
        <xs:element name=""despatch"" type=""xs:byte"" />
        <xs:element name=""timeOnDemurrage"" type=""xs:byte"" />
        <xs:element name=""isDemurrageFixed"" type=""xs:string"" />
        <xs:element name=""isDespatchFixed"" type=""xs:string"" />
        <xs:element name=""laytimeExpireDate"" type=""xs:string"" />
        <xs:element name=""laytimeUsed"" type=""xs:byte"" />
        <xs:element name=""variousCost"" type=""xs:byte"" />
        <xs:element name=""variousRevenue"" type=""xs:byte"" />
        <xs:element name=""exporter"" type=""xs:string"" />
        <xs:element name=""receiver"" type=""xs:string"" />
        <xs:element name=""terminal"" type=""xs:string"" />
        <xs:element name=""laytimeUsedFromDate"" type=""xs:string"" />
        <xs:element name=""laytimeUsedToDate"" type=""xs:string"" />
        <xs:element name=""outturnQuantity"" type=""xs:byte"" />
        <xs:element name=""shipFigure"" type=""xs:byte"" />
        <xs:element name=""timeNotToCount"" type=""xs:byte"" />
        <xs:element name=""self"" type=""xs:anyURI"" />
        <xs:element name=""key"" type=""xs:int"" />
        <xs:element name=""handlingCostCurrency"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""currencyCode"" type=""xs:string"" />
              <xs:element name=""currencyName"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""handlingCostCurrencyAmount"" type=""xs:byte"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_CargoPortOutput() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "root";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

namespace Inchcape.GS.BT.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"",@"YourIssNotification")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIssNotification"})]
    public sealed class Schema_ShipnetCreatePortCall : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xsd:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" attributeFormDefault=""unqualified"" elementFormDefault=""qualified"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
  <xsd:element name=""YourIssNotification"">
    <xsd:complexType>
      <xsd:sequence>
        <xsd:element name=""MessageHeader"">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name=""MessageType"" type=""xsd:string"" />
              <xsd:element name=""Action"" type=""xsd:string"" />
              <xsd:element name=""CreatedDate"" type=""xsd:dateTime"" />
              <xsd:element name=""ShipNetReference"" type=""xsd:string"" />
              <xsd:element name=""ShipNetOperatorId"" type=""xsd:string"" />
              <xsd:element name=""ShipNetOperatorName"" type=""xsd:string"" />
              <xsd:element name=""SourceApplication"" type=""xsd:string"" />
            </xsd:sequence>
          </xsd:complexType>
        </xsd:element>
        <xsd:element name=""PortCall"">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name=""HubPrincipalCode"" type=""xsd:string"" />
              <xsd:element name=""HubPrincipalName"" type=""xsd:string"" />
              <xsd:element name=""PrincipalCode"" type=""xsd:string"" />
              <xsd:element name=""PrincipalName"" type=""xsd:string"" />
              <xsd:element name=""SN_DANo"" type=""xsd:unsignedByte"" />
              <xsd:element name=""SN_KeyPosition"" type=""xsd:unsignedShort"" />
              <xsd:element name=""SN_VesselCode"" type=""xsd:string"" />
              <xsd:element name=""VesselName"" type=""xsd:string"" />
              <xsd:element name=""SN_VoyageNumber"" type=""xsd:string"" />
              <xsd:element name=""ETA"" type=""xsd:dateTime"" />
              <xsd:element name=""ETS"" type=""xsd:dateTime"" />
              <xsd:element name=""SN_DaType"" type=""xsd:string"" />
              <xsd:element name=""SN_AgentCode"" type=""xsd:string"" />
              <xsd:element name=""SN_NominationType"" type=""xsd:string"" />
              <xsd:element name=""PortOperationCode"" type=""xsd:string"" />
              <xsd:element name=""PortOperationName"" type=""xsd:string"" />
              <xsd:element name=""PortCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Ports"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element name=""Port"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_AcctsCode"" type=""xsd:string"" />
                          <xsd:element name=""PortName"" type=""xsd:string"" />
                          <xsd:element name=""PortCode"" type=""xsd:string"" />
                          <xsd:element name=""SN_CountryCode"" type=""xsd:string"" />
                          <xsd:element name=""SN_CountryName"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element name=""CargoCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Cargoes"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element name=""CargoForPortcall"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""SN_KeyCargo"" type=""xsd:unsignedByte"" />
                          <xsd:element name=""SN_CargoNo"" type=""xsd:unsignedByte"" />
                          <xsd:element name=""CommodityCode"" type=""xsd:string"" />
                          <xsd:element name=""CommodityName"" type=""xsd:string"" />
                          <xsd:element name=""Quantity"" type=""xsd:decimal"" />
                          <xsd:element name=""QuantityTypeCode"" type=""xsd:string"" />
                          <xsd:element name=""QuantityTypeName"" type=""xsd:string"" />
                          <xsd:element name=""CargoOperationCode"" type=""xsd:string"" />
                          <xsd:element name=""CargoOperationName"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
              <xsd:element name=""BunkerCount"" type=""xsd:unsignedByte"" />
              <xsd:element name=""Bunkers"">
                <xsd:complexType>
                  <xsd:sequence>
                    <xsd:element maxOccurs=""unbounded"" name=""Bunker"">
                      <xsd:complexType>
                        <xsd:sequence>
                          <xsd:element name=""Grade"" type=""xsd:string"" />
                        </xsd:sequence>
                      </xsd:complexType>
                    </xsd:element>
                  </xsd:sequence>
                </xsd:complexType>
              </xsd:element>
            </xsd:sequence>
          </xsd:complexType>
        </xsd:element>
      </xsd:sequence>
    </xsd:complexType>
  </xsd:element>
</xsd:schema>";
        
        public Schema_ShipnetCreatePortCall() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIssNotification";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

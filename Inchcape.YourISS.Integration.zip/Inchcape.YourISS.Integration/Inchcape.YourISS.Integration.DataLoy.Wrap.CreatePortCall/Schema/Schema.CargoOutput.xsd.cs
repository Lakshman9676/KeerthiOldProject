namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.CargoOutput",@"root")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"root"})]
    public sealed class Schema_CargoOutput : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.CargoOutput"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.CargoOutput"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""root"">
    <xs:complexType>
      <xs:choice minOccurs=""0"" maxOccurs=""unbounded"">
        <xs:element name=""commodity"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""commodityName"" type=""xs:string"" />
              <xs:element name=""commodityCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""subCommodity"" type=""xs:string"" />
        <xs:element name=""charterer"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""businessPartnerName"" type=""xs:string"" />
              <xs:element name=""businessPartnerSort"" type=""xs:string"" />
              <xs:element name=""businessPartnerCode"" type=""xs:string"" />
              <xs:element name=""businessPartnerType"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""businessPartnerType"" type=""xs:string"" />
                    <xs:element name=""businessPartnerTypeDesc"" type=""xs:string"" />
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""portRotation"" type=""xs:string"" />
        <xs:element name=""cpDate"" type=""xs:string"" />
        <xs:element name=""cargoReference"" type=""xs:int"" />
        <xs:element name=""cargoSubReference"" type=""xs:string"" />
        <xs:element name=""externalReference"" type=""xs:string"" />
        <xs:element name=""exchangeRate"" type=""xs:byte"" />
        <xs:element name=""voyage"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""freightRate"" type=""xs:byte"" />
        <xs:element name=""cargoPorts"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""commissions"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""cargoQuantity"" type=""xs:short"" />
        <xs:element name=""cargoMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""bookedQuantity"" type=""xs:short"" />
        <xs:element name=""quantityOption"" type=""xs:string"" />
        <xs:element name=""quantityOptionPct"" type=""xs:byte"" />
        <xs:element name=""minimumQuantity"" type=""xs:byte"" />
        <xs:element name=""volume"" type=""xs:byte"" />
        <xs:element name=""stowageFactor"" type=""xs:byte"" />
        <xs:element name=""stowageUnit"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""weightMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""weightUnit"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""isLumpsum"" type=""xs:string"" />
        <xs:element name=""weight"" type=""xs:short"" />
        <xs:element name=""weightFactor"" type=""xs:byte"" />
        <xs:element name=""width"" type=""xs:byte"" />
        <xs:element name=""commissionBroker"" type=""xs:float"" />
        <xs:element name=""commissionAddress"" type=""xs:float"" />
        <xs:element name=""freightCurrency"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""currencyCode"" type=""xs:string"" />
              <xs:element name=""currencyName"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""freightMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""length"" type=""xs:byte"" />
        <xs:element name=""createdDate"" type=""xs:dateTime"" />
        <xs:element name=""modifiedDate"" type=""xs:dateTime"" />
        <xs:element name=""createdById"" type=""xs:int"" />
        <xs:element name=""area"" type=""xs:byte"" />
        <xs:element name=""businessUnit"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""businessUnitName"" type=""xs:string"" />
              <xs:element name=""businessUnitCode"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""paymentTerms"" type=""xs:string"" />
        <xs:element name=""baselineTerm"" type=""xs:string"" />
        <xs:element name=""commission"" type=""xs:short"" />
        <xs:element name=""vc"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""demurrageTimeBar"" type=""xs:byte"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""handlingCost"" type=""xs:byte"" />
        <xs:element name=""freight"" type=""xs:int"" />
        <xs:element name=""comments"" type=""xs:string"" />
        <xs:element name=""laytimeAllowed"" type=""xs:byte"" />
        <xs:element name=""tsOfCargoPort"" type=""xs:string"" />
        <xs:element name=""reletOfCargo"" type=""xs:string"" />
        <xs:element name=""specificGravity"" type=""xs:byte"" />
        <xs:element name=""demurrage"" type=""xs:byte"" />
        <xs:element name=""deadfreight"" type=""xs:byte"" />
        <xs:element name=""terms"" type=""xs:string"" />
        <xs:element name=""laytimeTerms"" type=""xs:string"" />
        <xs:element name=""laytimeTermsValue"" type=""xs:byte"" />
        <xs:element name=""flatRate"" type=""xs:byte"" />
        <xs:element name=""grossFreight"" type=""xs:int"" />
        <xs:element name=""despatch"" type=""xs:byte"" />
        <xs:element name=""netFreight"" type=""xs:byte"" />
        <xs:element name=""netFio"" type=""xs:float"" />
        <xs:element name=""laycanMissedBy"" type=""xs:byte"" />
        <xs:element name=""overrage"" type=""xs:byte"" />
        <xs:element name=""pctPrepaid"" type=""xs:byte"" />
        <xs:element name=""volumeMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""timeOnDemurrage"" type=""xs:byte"" />
        <xs:element name=""arrivalWindowFrom"" type=""xs:string"" />
        <xs:element name=""arrivalWindowTo"" type=""xs:string"" />
        <xs:element name=""blDate"" type=""xs:string"" />
        <xs:element name=""cargoMatch"" type=""xs:byte"" />
        <xs:element name=""cargoText"" type=""xs:string"" />
        <xs:element name=""deadfreightRate"" type=""xs:byte"" />
        <xs:element name=""demurrageRate"" type=""xs:byte"" />
        <xs:element name=""despatchRate"" type=""xs:byte"" />
        <xs:element name=""doBunkerAdjustment"" type=""xs:byte"" />
        <xs:element name=""doPrice"" type=""xs:byte"" />
        <xs:element name=""finalDestination"" type=""xs:string"" />
        <xs:element name=""foBunkerAdjustment"" type=""xs:byte"" />
        <xs:element name=""foPrice"" type=""xs:byte"" />
        <xs:element name=""hasEqualization"" type=""xs:string"" />
        <xs:element name=""hasN2Padding"" type=""xs:string"" />
        <xs:element name=""height"" type=""xs:byte"" />
        <xs:element name=""isCradleRequired"" type=""xs:string"" />
        <xs:element name=""isDemurrageFixed"" type=""xs:string"" />
        <xs:element name=""isDespatchFixed"" type=""xs:string"" />
        <xs:element name=""isExclusive"" type=""xs:string"" />
        <xs:element name=""isLifo"" type=""xs:string"" />
        <xs:element name=""isOnDeck"" type=""xs:string"" />
        <xs:element name=""isPerformanceCargo"" type=""xs:string"" />
        <xs:element name=""isReversible"" type=""xs:string"" />
        <xs:element name=""laycanFrom"" type=""xs:string"" />
        <xs:element name=""laycanTo"" type=""xs:string"" />
        <xs:element name=""laytimeExpireDate"" type=""xs:string"" />
        <xs:element name=""payee"" type=""xs:string"" />
        <xs:element name=""laytimeUsed"" type=""xs:byte"" />
        <xs:element name=""variousCost"" type=""xs:byte"" />
        <xs:element name=""variousRevenue"" type=""xs:byte"" />
        <xs:element name=""laytimeUsedFromDate"" type=""xs:string"" />
        <xs:element name=""laytimeUsedToDate"" type=""xs:string"" />
        <xs:element name=""maxTransitTime"" type=""xs:byte"" />
        <xs:element name=""onDeckOption"" type=""xs:string"" />
        <xs:element name=""pctOverage"" type=""xs:byte"" />
        <xs:element name=""pieces"" type=""xs:byte"" />
        <xs:element name=""placeOfOrigin"" type=""xs:string"" />
        <xs:element name=""shipFigure"" type=""xs:byte"" />
        <xs:element name=""specificGravityTemperature"" type=""xs:byte"" />
        <xs:element name=""timeNotToCount"" type=""xs:byte"" />
        <xs:element name=""timeOnDespatch"" type=""xs:byte"" />
        <xs:element name=""wsYear"" type=""xs:string"" />
        <xs:element name=""baselineTerm2"" type=""xs:string"" />
        <xs:element name=""bookingStatus"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""statusTypeCode"" type=""xs:string"" />
              <xs:element name=""statusTypeDesc"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""coaLine"" type=""xs:string"" />
        <xs:element name=""coatingType"" type=""xs:string"" />
        <xs:element name=""dimensionMeasurement"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""measurementCode"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""paymentTerms2"" type=""xs:string"" />
        <xs:element name=""project"" type=""xs:string"" />
        <xs:element name=""supplier"" type=""xs:string"" />
        <xs:element name=""valueCurrency"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""currencyCode"" type=""xs:string"" />
              <xs:element name=""currencyName"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""value"" type=""xs:byte"" />
        <xs:element name=""self"" type=""xs:anyURI"" />
        <xs:element name=""key"" type=""xs:int"" />
      </xs:choice>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_CargoOutput() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "root";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

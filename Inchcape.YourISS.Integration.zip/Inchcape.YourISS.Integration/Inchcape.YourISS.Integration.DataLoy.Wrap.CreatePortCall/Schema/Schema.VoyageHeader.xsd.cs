namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageHeader.Schema",@"VoyageHeader")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"VoyageHeader"})]
    public sealed class VoyageHeader : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" attributeFormDefault=""unqualified"" elementFormDefault=""unqualified"" targetNamespace=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageHeader.Schema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""VoyageHeader"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
        <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""voyageStartDate"" type=""xs:dateTime"" />
        <xs:element minOccurs=""0"" name=""createdDate"" type=""xs:dateTime"" />
        <xs:element minOccurs=""0"" name=""modifiedDate"" type=""xs:dateTime"" />
        <xs:element minOccurs=""0"" name=""createdById"" type=""xs:unsignedInt"" />
        <xs:element minOccurs=""0"" name=""voyage"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""referenceNo"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""vessel"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""vesselName"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""ballastPort"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""portName"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""unLoCode"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""country"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""countryCode"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""countryName"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                          <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""isCanal"" type=""xs:boolean"" />
                    <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""portCalls"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                    <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""eventLogs"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                          <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""event"">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                                <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                                <xs:element minOccurs=""0"" name=""eventCode"" type=""xs:string"" />
                                <xs:element minOccurs=""0"" name=""eventDesc"" type=""xs:string"" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                          <xs:element minOccurs=""0"" name=""eventLogDate"" type=""xs:dateTime"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""cargos"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""voyageEndDateGMT"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""voyageStartDateGMT"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""createdDate"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""modifiedDate"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""portCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""isTc"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""commission"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""handlingCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""tcRate"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""commissionAddress"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""freight"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""demurrage"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""variousRevenue"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""variousCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""voyageCurrency"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""currencyCode"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""currencyName"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
                    <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""estimatedVoyageStartDate"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""daysTotal"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""grossFreight"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""despatch"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""netFreight"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""daysBallast"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysWaiting"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""comments"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""doPrice"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""tdw"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""restrictingCubic"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""speedBallast"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""speedLoaded"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foConsumption"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foBallast"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""foLoaded"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""doAtSea"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""doInPort"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foInPort"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foInPortWorking"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""doInPortWorking"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foCleaning"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""foHeating"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysLoaded"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""ballastBonus"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""foPrice"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""ballastBonusCommission"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""ballastBonusNet"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""ballastBonusRevenue"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""canalCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""commissionOwnersCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""cveTcIn"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""cveTcOut"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysCanal"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysCleaning"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysDischarging"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysExtraAtSea"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysExtraInPort"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysHeating"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysIdle"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysLoading"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysOffhire"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysOffhireCharterer"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysOffhireOwner"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""daysTotalAtSea"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""daysTotalInPort"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""dlConsumption"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""dlCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""dlPrice"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""doConsumption"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""doCost"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""flConsumption"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""flCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""flPrice"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""foCost"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""foPumping"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""freightCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""ilohcTcIn"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""ilohcTcOut"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""milesBallast"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""milesLoaded"" type=""xs:unsignedShort"" />
              <xs:element minOccurs=""0"" name=""percentExtraAtSea"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""robFixed"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""runningCost"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""runningCostPerDay"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""tabTitle"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""tcHireCommission"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""tcHireNet"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""tcResult"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""tcResultDay"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""utilisationComments"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""voyageResult"" type=""xs:decimal"" />
              <xs:element minOccurs=""0"" name=""tcIn"" type=""xs:anyType"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""company"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""companyCode"" type=""xs:unsignedByte"" />
              <xs:element minOccurs=""0"" name=""companyName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""businessUnit"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""businessUnitCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""businessUnitName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""vesselCode"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""vesselCode"" type=""xs:unsignedByte"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""referenceNo"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""voyageNo"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""voyageStartYear"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""voyageStatus"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""statusTypeCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""statusTypeDesc"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""isBudget"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""budgetVersion"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""timezoneOffset"" type=""xs:byte"" />
        <xs:element minOccurs=""0"" name=""master"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""bunkersProfitLoss"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""route"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""doConsumptionOffhire"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foConsumptionOffhire"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""voyageSnapshots"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""voyageSnapshotDesc"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""voyage"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""dlConsumptionOffhire"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlPriceEndOfVoyage"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlPriceVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlProfitLoss"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlProfitLossTcIn"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlRobVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""dlSulphurPctVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""doPriceEndOfVoyage"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""doPriceVoyageStart"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""doProfitLoss"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""doProfitLossTcIn"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""doRobVoyageStart"" type=""xs:decimal"" />
        <xs:element minOccurs=""0"" name=""doSulphurPctVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flConsumptionOffhire"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flIndexPriceAdd"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flPriceEndOfVoyage"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flPriceVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flProfitLoss"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flProfitLossTcIn"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flRobVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""flSulphurPctVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foIndexPriceAdd"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foPriceEndOfVoyage"" type=""xs:decimal"" />
        <xs:element minOccurs=""0"" name=""foPriceVoyageStart"" type=""xs:unsignedShort"" />
        <xs:element minOccurs=""0"" name=""foProfitLoss"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foProfitLossHedge"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foProfitLossTcIn"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""foRobVoyageStart"" type=""xs:decimal"" />
        <xs:element minOccurs=""0"" name=""foSulphurPctVoyageStart"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""isDlPriceFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isDoFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isDoPriceFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isEstimate"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isFlPriceFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isFoFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isFoPriceFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isLastVoyage"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isUnallocated"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""isVoyageStartFixed"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""tcBenchmarkPercent"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""tradeVoyageNo"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""vesselEarningPoint"" type=""xs:unsignedByte"" />
        <xs:element minOccurs=""0"" name=""charteringResponsible"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""userCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""userName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""flIndex"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""foIndex"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""leg"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""operator"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""key"" type=""xs:unsignedInt"" />
              <xs:element minOccurs=""0"" name=""self"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""userCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""userName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""tcBenchmarkIndex"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""pool"" type=""xs:anyType"" />
        <xs:element minOccurs=""0"" name=""pattern"" type=""xs:anyType"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public VoyageHeader() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "VoyageHeader";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

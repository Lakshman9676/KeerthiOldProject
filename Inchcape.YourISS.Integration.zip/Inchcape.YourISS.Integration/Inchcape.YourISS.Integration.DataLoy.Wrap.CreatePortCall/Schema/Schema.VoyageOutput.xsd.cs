namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageOutput",@"voyage")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"voyage"})]
    public sealed class Schema_VoyageOutput : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageOutput"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageOutput"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""voyage"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""remarks"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""remarkTitle"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""referenceNo"" type=""xs:short"" />
        <xs:element name=""vessel"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""vesselName"" type=""xs:string"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""ballastPort"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""portName"" type=""xs:string"" />
              <xs:element name=""unLoCode"" type=""xs:string"" />
              <xs:element name=""country"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""countryCode"" type=""xs:string"" />
                    <xs:element name=""countryName"" type=""xs:string"" />
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""isCanal"" type=""xs:string"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""portCalls"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""eventLogs"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""event"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name=""key"" type=""xs:int"" />
                          <xs:element name=""self"" type=""xs:anyURI"" />
                          <xs:element name=""eventDesc"" type=""xs:string"" />
                          <xs:element name=""eventCode"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name=""eventLogDate"" type=""xs:dateTime"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""cargos"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""key"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""voyageEndDateGMT"" type=""xs:dateTime"" />
        <xs:element name=""voyageStartDateGMT"" type=""xs:dateTime"" />
        <xs:element name=""tdw"" type=""xs:int"" />
        <xs:element name=""restrictingCubic"" type=""xs:int"" />
        <xs:element name=""speedBallast"" type=""xs:float"" />
        <xs:element name=""speedLoaded"" type=""xs:float"" />
        <xs:element name=""foConsumption"" type=""xs:float"" />
        <xs:element name=""foBallast"" type=""xs:byte"" />
        <xs:element name=""foLoaded"" type=""xs:byte"" />
        <xs:element name=""foInPortWorking"" type=""xs:float"" />
        <xs:element name=""doInPortWorking"" type=""xs:float"" />
        <xs:element name=""foCleaning"" type=""xs:byte"" />
        <xs:element name=""foHeating"" type=""xs:byte"" />
        <xs:element name=""daysLoaded"" type=""xs:float"" />
        <xs:element name=""ballastBonus"" type=""xs:byte"" />
        <xs:element name=""ballastBonusCommission"" type=""xs:byte"" />
        <xs:element name=""ballastBonusNet"" type=""xs:byte"" />
        <xs:element name=""ballastBonusRevenue"" type=""xs:byte"" />
        <xs:element name=""canalCost"" type=""xs:byte"" />
        <xs:element name=""commissionOwnersCost"" type=""xs:byte"" />
        <xs:element name=""cveTcIn"" type=""xs:byte"" />
        <xs:element name=""cveTcOut"" type=""xs:byte"" />
        <xs:element name=""daysBallast"" type=""xs:float"" />
        <xs:element name=""daysCanal"" type=""xs:byte"" />
        <xs:element name=""daysCleaning"" type=""xs:byte"" />
        <xs:element name=""daysDischarging"" type=""xs:float"" />
        <xs:element name=""daysExtraAtSea"" type=""xs:byte"" />
        <xs:element name=""daysHeating"" type=""xs:byte"" />
        <xs:element name=""daysIdle"" type=""xs:byte"" />
        <xs:element name=""daysLoading"" type=""xs:byte"" />
        <xs:element name=""daysOffhire"" type=""xs:byte"" />
        <xs:element name=""daysOffhireCharterer"" type=""xs:byte"" />
        <xs:element name=""daysOffhireOwner"" type=""xs:byte"" />
        <xs:element name=""daysTotal"" type=""xs:float"" />
        <xs:element name=""daysTotalAtSea"" type=""xs:float"" />
        <xs:element name=""daysTotalInPort"" type=""xs:float"" />
        <xs:element name=""daysWaiting"" type=""xs:byte"" />
        <xs:element name=""dlConsumption"" type=""xs:float"" />
        <xs:element name=""dlCost"" type=""xs:byte"" />
        <xs:element name=""dlPrice"" type=""xs:byte"" />
        <xs:element name=""doConsumption"" type=""xs:float"" />
        <xs:element name=""doCost"" type=""xs:float"" />
        <xs:element name=""estimatedVoyageStartDate"" type=""xs:dateTime"" />
        <xs:element name=""flConsumption"" type=""xs:byte"" />
        <xs:element name=""flCost"" type=""xs:byte"" />
        <xs:element name=""flPrice"" type=""xs:byte"" />
        <xs:element name=""foCost"" type=""xs:float"" />
        <xs:element name=""foPumping"" type=""xs:byte"" />
        <xs:element name=""freightCost"" type=""xs:byte"" />
        <xs:element name=""ilohcTcIn"" type=""xs:byte"" />
        <xs:element name=""ilohcTcOut"" type=""xs:byte"" />
        <xs:element name=""isTc"" type=""xs:string"" />
        <xs:element name=""milesBallast"" type=""xs:short"" />
        <xs:element name=""milesLoaded"" type=""xs:short"" />
        <xs:element name=""robFixed"" type=""xs:byte"" />
        <xs:element name=""runningCost"" type=""xs:byte"" />
        <xs:element name=""runningCostPerDay"" type=""xs:byte"" />
        <xs:element name=""tabTitle"" type=""xs:string"" />
        <xs:element name=""tcHireCommission"" type=""xs:byte"" />
        <xs:element name=""tcHireNet"" type=""xs:byte"" />
        <xs:element name=""tcResult"" type=""xs:float"" />
        <xs:element name=""tcResultDay"" type=""xs:float"" />
        <xs:element name=""utilisationComments"" type=""xs:string"" />
        <xs:element name=""voyageResult"" type=""xs:float"" />
        <xs:element name=""tcIn"" type=""xs:string"" />
        <xs:element name=""voyageCurrency"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""currencyCode"" type=""xs:string"" />
              <xs:element name=""currencyName"" type=""xs:string"" />
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""voyageHeader"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
              <xs:element name=""voyageStartDate"" type=""xs:dateTime"" />
              <xs:element name=""createdDate"" type=""xs:dateTime"" />
              <xs:element name=""modifiedDate"" type=""xs:dateTime"" />
              <xs:element name=""company"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""companyName"" type=""xs:string"" />
                    <xs:element name=""companyCode"" type=""xs:byte"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""businessUnit"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""businessUnitName"" type=""xs:string"" />
                    <xs:element name=""businessUnitCode"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""vesselCode"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""vesselCode"" type=""xs:byte"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""referenceNo"" type=""xs:short"" />
              <xs:element name=""voyageNo"" type=""xs:byte"" />
              <xs:element name=""voyageStartYear"" type=""xs:short"" />
              <xs:element name=""bunkersProfitLoss"" type=""xs:byte"" />
              <xs:element name=""dlConsumptionOffhire"" type=""xs:byte"" />
              <xs:element name=""dlPriceEndOfVoyage"" type=""xs:short"" />
              <xs:element name=""dlPriceVoyageStart"" type=""xs:short"" />
              <xs:element name=""dlProfitLoss"" type=""xs:byte"" />
              <xs:element name=""dlProfitLossTcIn"" type=""xs:byte"" />
              <xs:element name=""dlRobVoyageStart"" type=""xs:short"" />
              <xs:element name=""dlSulphurPctVoyageStart"" type=""xs:byte"" />
              <xs:element name=""doConsumptionOffhire"" type=""xs:byte"" />
              <xs:element name=""doPriceEndOfVoyage"" type=""xs:short"" />
              <xs:element name=""doPriceVoyageStart"" type=""xs:short"" />
              <xs:element name=""doProfitLoss"" type=""xs:byte"" />
              <xs:element name=""doProfitLossTcIn"" type=""xs:byte"" />
              <xs:element name=""doRobVoyageStart"" type=""xs:float"" />
              <xs:element name=""doSulphurPctVoyageStart"" type=""xs:byte"" />
              <xs:element name=""flConsumptionOffhire"" type=""xs:byte"" />
              <xs:element name=""flIndexPriceAdd"" type=""xs:byte"" />
              <xs:element name=""flPriceEndOfVoyage"" type=""xs:short"" />
              <xs:element name=""flPriceVoyageStart"" type=""xs:short"" />
              <xs:element name=""flProfitLoss"" type=""xs:byte"" />
              <xs:element name=""flProfitLossTcIn"" type=""xs:byte"" />
              <xs:element name=""flRobVoyageStart"" type=""xs:short"" />
              <xs:element name=""flSulphurPctVoyageStart"" type=""xs:byte"" />
              <xs:element name=""foConsumptionOffhire"" type=""xs:byte"" />
              <xs:element name=""foIndexPriceAdd"" type=""xs:byte"" />
              <xs:element name=""foPriceEndOfVoyage"" type=""xs:float"" />
              <xs:element name=""foPriceVoyageStart"" type=""xs:float"" />
              <xs:element name=""foProfitLoss"" type=""xs:byte"" />
              <xs:element name=""foProfitLossHedge"" type=""xs:byte"" />
              <xs:element name=""foProfitLossTcIn"" type=""xs:byte"" />
              <xs:element name=""foRobVoyageStart"" type=""xs:float"" />
              <xs:element name=""foSulphurPctVoyageStart"" type=""xs:byte"" />
              <xs:element name=""isBudget"" type=""xs:string"" />
              <xs:element name=""isDlPriceFixed"" type=""xs:string"" />
              <xs:element name=""isDoFixed"" type=""xs:string"" />
              <xs:element name=""isDoPriceFixed"" type=""xs:string"" />
              <xs:element name=""isEstimate"" type=""xs:string"" />
              <xs:element name=""isFlPriceFixed"" type=""xs:string"" />
              <xs:element name=""isFoFixed"" type=""xs:string"" />
              <xs:element name=""isFoPriceFixed"" type=""xs:string"" />
              <xs:element name=""isLastVoyage"" type=""xs:string"" />
              <xs:element name=""isVoyageStartFixed"" type=""xs:string"" />
              <xs:element name=""tcBenchmarkPercent"" type=""xs:byte"" />
              <xs:element name=""tradeVoyageNo"" type=""xs:string"" />
              <xs:element name=""vesselEarningPoint"" type=""xs:byte"" />
              <xs:element name=""budgetVersion"" type=""xs:string"" />
              <xs:element name=""charteringResponsible"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""userCode"" type=""xs:string"" />
                    <xs:element name=""userName"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""flIndex"" type=""xs:string"" />
              <xs:element name=""foIndex"" type=""xs:string"" />
              <xs:element name=""leg"" type=""xs:string"" />
              <xs:element name=""operator"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""userCode"" type=""xs:string"" />
                    <xs:element name=""userName"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""route"" type=""xs:string"" />
              <xs:element name=""timezoneOffset"" type=""xs:byte"" />
              <xs:element name=""master"" type=""xs:string"" />
              <xs:element name=""tcBenchmarkIndex"" type=""xs:string"" />
              <xs:element name=""voyageSnapshots"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""voyageSnapshotDesc"" type=""xs:string"" />
                    <xs:element name=""voyage"" type=""xs:anyURI"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""voyageStatus"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""key"" type=""xs:int"" />
                    <xs:element name=""self"" type=""xs:anyURI"" />
                    <xs:element name=""statusTypeCode"" type=""xs:string"" />
                    <xs:element name=""statusTypeDesc"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""pattern"" type=""xs:string"" />
              <xs:element name=""pool"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""createdDate"" type=""xs:dateTime"" />
        <xs:element name=""modifiedDate"" type=""xs:dateTime"" />
        <xs:element name=""createdById"" type=""xs:int"" />
        <xs:element name=""portCost"" type=""xs:int"" />
        <xs:element name=""commission"" type=""xs:float"" />
        <xs:element name=""handlingCost"" type=""xs:byte"" />
        <xs:element name=""tcRate"" type=""xs:byte"" />
        <xs:element name=""freight"" type=""xs:int"" />
        <xs:element name=""comments"" type=""xs:string"" />
        <xs:element name=""daysExtraInPort"" type=""xs:float"" />
        <xs:element name=""demurrage"" type=""xs:byte"" />
        <xs:element name=""commissionAddress"" type=""xs:byte"" />
        <xs:element name=""grossFreight"" type=""xs:int"" />
        <xs:element name=""despatch"" type=""xs:byte"" />
        <xs:element name=""netFreight"" type=""xs:float"" />
        <xs:element name=""doPrice"" type=""xs:short"" />
        <xs:element name=""foPrice"" type=""xs:float"" />
        <xs:element name=""doAtSea"" type=""xs:float"" />
        <xs:element name=""doInPort"" type=""xs:float"" />
        <xs:element name=""foInPort"" type=""xs:float"" />
        <xs:element name=""percentExtraAtSea"" type=""xs:byte"" />
        <xs:element name=""variousCost"" type=""xs:byte"" />
        <xs:element name=""variousRevenue"" type=""xs:byte"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""variouses"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""key"" type=""xs:int"" />
              <xs:element name=""self"" type=""xs:anyURI"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""self"" type=""xs:anyURI"" />
        <xs:element name=""key"" type=""xs:int"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_VoyageOutput() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "voyage";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

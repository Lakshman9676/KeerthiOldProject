namespace Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Schemas.Schema.DataLoyInput", typeof(global::Inchcape.YourISS.Integration.DataLoy.Schemas.Schema.DataLoyInput))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_VoyageOutput", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_VoyageOutput))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_CargoDetails", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_CargoDetails))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.TypedPolling_DataLoyWrapCreatePortCall+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.TypedPolling_DataLoyWrapCreatePortCall.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_Count", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_Count))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.VoyageHeader", typeof(global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.VoyageHeader))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall))]
    public sealed class Map_DataloyToYourISS2 : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 s7 s2 s3 s6 s4 s5 userCSharp"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageOutput"" xmlns:s7=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s1=""http://Inchcape.YourISS.Integration.DataLoy.PortCallSchedule.DataLoyInput"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:s2=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Count.Schema"" xmlns:s3=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/DataLoyWrapCreatePortCall"" xmlns:s6=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:s4=""http://Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.VoyageHeader.Schema"" xmlns:s5=""http://Inchcape.YourISS.Integration.DataLoy.CreatePortCall.Schema.Cargos"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s6:Root"" />
  </xsl:template>
  <xsl:template match=""/s6:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;PortCall&quot;)"" />
    <ns0:YourIssNotification>
      <xsl:if test=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:AccountId"">
        <HubPrincipalKey>
          <xsl:value-of select=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:AccountId/text()"" />
        </HubPrincipalKey>
      </xsl:if>
      <xsl:if test=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id"">
        <Id>
          <xsl:value-of select=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id/text()"" />
        </Id>
      </xsl:if>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""$var:v1"" />
        </MessageType>
        <xsl:variable name=""var:v2"" select=""userCSharp:SetPortCallAction(string(InputMessagePart_0/s1:root/agencyAppointmentStatus/statusTypeCode/text()))"" />
        <Action>
          <xsl:value-of select=""$var:v2"" />
        </Action>
        <CreatedDate>
          <xsl:value-of select=""InputMessagePart_0/s1:root/createdDate/text()"" />
        </CreatedDate>
        <xsl:if test=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:MessageId"">
          <ShipNetReference>
            <xsl:value-of select=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:MessageId/text()"" />
          </ShipNetReference>
        </xsl:if>
        <ShipNetOperatorId>
          <xsl:value-of select=""InputMessagePart_0/s1:root/createdById/text()"" />
        </ShipNetOperatorId>
        <xsl:if test=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:SourceApplication"">
          <SourceApplication>
            <xsl:value-of select=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:SourceApplication/text()"" />
          </SourceApplication>
        </xsl:if>
      </MessageHeader>
      <xsl:for-each select=""InputMessagePart_5/s4:VoyageHeader/company"">
        <PortCall>
          <xsl:if test=""companyCode"">
            <PrincipalCode>
              <xsl:value-of select=""companyCode/text()"" />
            </PrincipalCode>
          </xsl:if>
          <xsl:if test=""companyName"">
            <PrincipalName>
              <xsl:value-of select=""companyName/text()"" />
            </PrincipalName>
          </xsl:if>
          <SN_DANo>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/key/text()"" />
          </SN_DANo>
          <xsl:if test=""../../../InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id"">
            <SN_KeyPosition>
              <xsl:value-of select=""../../../InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id/text()"" />
            </SN_KeyPosition>
          </xsl:if>
          <SN_VesselCode>
            <xsl:value-of select=""../../../InputMessagePart_1/s0:voyage/voyageHeader/vesselCode/vesselCode/text()"" />
          </SN_VesselCode>
          <IMO>
            <xsl:value-of select=""../../../InputMessagePart_1/s0:voyage/voyageHeader/vesselCode/vesselCode/text()"" />
          </IMO>
          <SN_VoyageNumber>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/voyage/key/text()"" />
          </SN_VoyageNumber>
          <xsl:for-each select=""/*[local-name()='Root' and namespace-uri()='http://schemas.microsoft.com/BizTalk/2003/aggschema']/*[local-name()='InputMessagePart_0' and namespace-uri()='']/*[local-name()='root' and namespace-uri()='http://Inchcape.YourISS.Integration.DataLoy.PortCallSchedule.DataLoyInput']/*[local-name()='eventLogs' and namespace-uri()='']"">

      <xsl:variable name=""EventArrivalCode1"" select=""./event/eventCode/text()"" />
      
     <xsl:if test=""$EventArrivalCode1='ARR'"">
         <xsl:variable name=""EventArrivalDate"" select=""./eventLogDate/text()"" />
                  <ETA>                         
                                 <xsl:value-of select=""$EventArrivalDate"" /> 
                     </ETA>
    </xsl:if>

   </xsl:for-each>
          <xsl:for-each select=""/*[local-name()='Root' and namespace-uri()='http://schemas.microsoft.com/BizTalk/2003/aggschema']/*[local-name()='InputMessagePart_0' and namespace-uri()='']/*[local-name()='root' and namespace-uri()='http://Inchcape.YourISS.Integration.DataLoy.PortCallSchedule.DataLoyInput']/*[local-name()='eventLogs' and namespace-uri()='']"">

      <xsl:variable name=""EventDepCode1"" select=""./event/eventCode/text()"" />
      
     <xsl:if test=""$EventDepCode1='DEP'"">
         <xsl:variable name=""EventDepDate"" select=""./eventLogDate/text()"" />
                  <ETS>                         
                                 <xsl:value-of select=""$EventDepDate"" /> 
                     </ETS>
    </xsl:if>

   </xsl:for-each>
          <PortOperationCode>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/reasonForCall/reasonForCall/text()"" />
          </PortOperationCode>
          <PortOperationName>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/reasonForCall/reasonForCallDesc/text()"" />
          </PortOperationName>
          <SN_AgentCode>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/agent/businessPartnerCode/text()"" />
          </SN_AgentCode>
          <ISS_AgentCode>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/agent/businessPartnerCode/text()"" />
          </ISS_AgentCode>
          <SN_NominationType>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/agent/businessPartnerType/businessPartnerType/text()"" />
          </SN_NominationType>
          <PortCount>
            <xsl:value-of select=""../../../InputMessagePart_4/s2:Root/PortCount/text()"" />
          </PortCount>
          <Ports>
            <Port>
              <PortName>
                <xsl:value-of select=""../../../InputMessagePart_0/s1:root/port/portName/text()"" />
              </PortName>
              <PortCode>
                <xsl:value-of select=""../../../InputMessagePart_0/s1:root/port/unLoCode/text()"" />
              </PortCode>
              <ISS_PortCode>
                <xsl:value-of select=""../../../InputMessagePart_0/s1:root/port/unLoCode/text()"" />
              </ISS_PortCode>
              <SN_CountryCode>
                <xsl:value-of select=""../../../InputMessagePart_0/s1:root/port/country/countryCode/text()"" />
              </SN_CountryCode>
              <SN_CountryName>
                <xsl:value-of select=""../../../InputMessagePart_0/s1:root/port/country/countryName/text()"" />
              </SN_CountryName>
            </Port>
          </Ports>
          <Master>
            <xsl:value-of select=""../../../InputMessagePart_0/s1:root/master/text()"" />
          </Master>
          <CargoCount>
            <xsl:value-of select=""../../../InputMessagePart_4/s2:Root/CargoCount/text()"" />
          </CargoCount>
          <Cargoes>
            <xsl:for-each select=""../../../InputMessagePart_2/s5:Cargos/Cargo"">
              <Cargo>
                <SN_ChartererCode>
                  <xsl:value-of select=""root/charterer/businessPartnerCode/text()"" />
                </SN_ChartererCode>
                <SN_ChartererName>
                  <xsl:value-of select=""root/charterer/businessPartnerName/text()"" />
                </SN_ChartererName>
                <ISS_ChartererCode>
                  <xsl:value-of select=""root/charterer/businessPartnerCode/text()"" />
                </ISS_ChartererCode>
                <ISS_CommodityCode>
                  <xsl:value-of select=""root/commodity/commodityCode/text()"" />
                </ISS_CommodityCode>
                <CommodityCode>
                  <xsl:value-of select=""root/commodity/commodityCode/text()"" />
                </CommodityCode>
                <CommodityName>
                  <xsl:value-of select=""root/commodity/commodityName/text()"" />
                </CommodityName>
                <Quantity>
                  <xsl:value-of select=""root/cargoQuantity/text()"" />
                </Quantity>
                <QuantityTypeCode>
                  <xsl:value-of select=""root/cargoMeasurement/measurementCode/text()"" />
                </QuantityTypeCode>
              </Cargo>
            </xsl:for-each>
          </Cargoes>
        </PortCall>
      </xsl:for-each>
      <CancelPortCal>
        <SN_DANo>
          <xsl:value-of select=""InputMessagePart_0/s1:root/key/text()"" />
        </SN_DANo>
        <xsl:if test=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id"">
          <SN_KeyPosition>
            <xsl:value-of select=""InputMessagePart_3/s3:TypedPollingResultSet0/s3:Id/text()"" />
          </SN_KeyPosition>
        </xsl:if>
      </CancelPortCal>
    </ns0:YourIssNotification>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string SetPortCallAction ( string StatusCode )
{
      if  (  StatusCode ==""SNT""   )
            return ""Create"" ;
     else if (  StatusCode == ""UPSNT"" )
           return ""Update"" ;
     else if ( StatusCode  == ""CASNT""  )
            return ""Cancel"";

    else
          return """";

}

public string StringConcat(string param0)
{
   return param0;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.DataLoy.Schemas.Schema.DataLoyInput";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Schemas.Schema.DataLoyInput _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_VoyageOutput";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_VoyageOutput _srcSchemaTypeReference1 = null;
        
        private const string _strSrcSchemasList2 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_CargoDetails";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_CargoDetails _srcSchemaTypeReference2 = null;
        
        private const string _strSrcSchemasList3 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.TypedPolling_DataLoyWrapCreatePortCall+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.TypedPolling_DataLoyWrapCreatePortCall.TypedPollingResultSet0 _srcSchemaTypeReference3 = null;
        
        private const string _strSrcSchemasList4 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_Count";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_Count _srcSchemaTypeReference4 = null;
        
        private const string _strSrcSchemasList5 = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.VoyageHeader";
        
        private const global::Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.VoyageHeader _srcSchemaTypeReference5 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [6];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.DataLoy.Schemas.Schema.DataLoyInput";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_VoyageOutput";
                _SrcSchemas[2] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_CargoDetails";
                _SrcSchemas[3] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.TypedPolling_DataLoyWrapCreatePortCall+TypedPollingResultSet0";
                _SrcSchemas[4] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.Schema_Count";
                _SrcSchemas[5] = @"Inchcape.YourISS.Integration.DataLoy.Wrap.CreatePortCall.Schema.VoyageHeader";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
                return _TrgSchemas;
            }
        }
    }
}

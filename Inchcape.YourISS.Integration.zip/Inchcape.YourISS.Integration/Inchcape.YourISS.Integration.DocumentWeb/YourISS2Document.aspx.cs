﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inchcape.YourISS.Integration.DocumentWeb
{
    public partial class YourISS2Document : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] != null && Request.QueryString["name"] != null)
            {
                string decryptedId = Request.QueryString["id"].ToString();
                string decryptedPath = Request.QueryString["name"].ToString();
                DownloadwithGUID(decryptedId, decryptedPath);
            }
        }

        public void Download(string decryptedId, string decryptedPath)
        {
            //string urlencodeid = Server.UrlEncode(decryptedId);
            //string str = urlencodeid;
            string replacePath = decryptedPath.Replace(" ", "+");
            string replaceId = decryptedId.Replace(" ", "+");
            //YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();
            YISS2DocBTService.DocumentBizServiceClient obj = new YISS2DocBTService.DocumentBizServiceClient();

            //string yiss2DocPath = "file://idcchnyiss2app/Documents/Da/NADA-137.pdf";
            string yiss2DocPath = Decryption(replacePath);

            //yiss2DocPath = "file://idcchnyiss2app/InchcapeDocuments/MessageAttachments/ISS TURKEY  IDEA Integration UAT.pdf.d187890c-bd91-4db2-b197-4b61e5ca6c3f";

            string[] filename = yiss2DocPath.Split('/');
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After filename");
            string[] extn = filename[filename.Length - 1].Split('.');
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After extn");
            string id = Decryption(replaceId);
            //string id = Decryption(urlencodeid);
            int count = 0;
            string yiss2DocStream = string.Empty;
            Guid account = Guid.Empty;
            account = new Guid(id);
            count = obj.ValidateIntegrationSystem(account);
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After ValidateIntegrationSystem");
            if (count > 0)
            {
                yiss2DocStream = obj.GetDocumentData(yiss2DocPath);
                System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After file base64");
                //return yiss2DocStream;
            }

            byte[] bytStream = Convert.FromBase64String(yiss2DocStream);
            string contentType = string.Empty;
            if (extn[extn.Length - 1].ToLower() == "pdf")
                contentType = "Application/pdf";
            else if (extn[extn.Length - 1].ToLower() == "doc" || extn[extn.Length - 1].ToLower() == "rtf" || extn[extn.Length - 1].ToLower() == "docx")
                contentType = "Application/msword";
            else if (extn[extn.Length - 1].ToLower() == "xls" || extn[extn.Length - 1].ToLower() == "xls")
                contentType = "Application/x-msexcel";
            else if (extn[extn.Length - 1].ToLower() == "txt")
                contentType = "text/plain";

            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - contentType");
            Response.ContentType = contentType;
            Response.AddHeader("content-disposition", "attachment;fileName=" + filename[filename.Length - 1]);
            if (bytStream.Length != 0)
                Response.BinaryWrite(bytStream);
            Response.Flush();
            Response.End();
        }

        public void DownloadwithGUID(string decryptedId, string decryptedPath)
        {
            //string urlencodeid = Server.UrlEncode(decryptedId);
            //string str = urlencodeid;
            string replacePath = decryptedPath.Replace(" ", "+");
            string replaceId = decryptedId.Replace(" ", "+");
            //YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();
            YISS2DocBTService.DocumentBizServiceClient obj = new YISS2DocBTService.DocumentBizServiceClient();

            string yiss2DocPath = Decryption(replacePath);

            string file = RemoveGuid(yiss2DocPath);
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - file Path : " + file.ToString());

            string[] filename = file.Split('/');

            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - filename : " + filename[filename.Length - 1].ToString());
            string[] extn = filename[filename.Length - 1].Split('.');
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - extn : " + extn[extn.Length - 1].ToString());
            string id = Decryption(replaceId);
            //string id = Decryption(urlencodeid);
            int count = 0;
            string yiss2DocStream = string.Empty;
            Guid account = Guid.Empty;
            account = new Guid(id);
            count = obj.ValidateIntegrationSystem(account);
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After ValidateIntegrationSystem");
            if (count > 0)
            {
                yiss2DocStream = obj.GetDocumentData(yiss2DocPath);
                System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - After file base64");
                //return yiss2DocStream;
            }

            byte[] bytStream = Convert.FromBase64String(yiss2DocStream);
            string contentType = string.Empty;
            if (extn[extn.Length - 1].ToLower() == "pdf")
                contentType = "Application/pdf";
            else if (extn[extn.Length - 1].ToLower() == "doc" || extn[extn.Length - 1].ToLower() == "rtf" || extn[extn.Length - 1].ToLower() == "docx")
                contentType = "Application/msword";
            else if (extn[extn.Length - 1].ToLower() == "xls" || extn[extn.Length - 1].ToLower() == "xls")
                contentType = "Application/x-msexcel";
            else if (extn[extn.Length - 1].ToLower() == "txt")
                contentType = "text/plain";

            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration - contentType");
            Response.ContentType = contentType;
            Response.AddHeader("content-disposition", "attachment;fileName=" + filename[filename.Length - 1]);
            if (bytStream.Length != 0)
                Response.BinaryWrite(bytStream);
            Response.Flush();
            Response.End();
        }

        public string RemoveGuid(string yiss2DocPath)
        {
            string yiss2ModifiedfilePath = string.Empty;

            try
            {
                string firstSplit = yiss2DocPath.Substring(0, yiss2DocPath.LastIndexOf('.'));
                yiss2ModifiedfilePath = firstSplit.Substring(firstSplit.LastIndexOf('\\') + 1);
            }
            catch (Exception exp)
            {
                throw exp;
            }

            return yiss2ModifiedfilePath;
        }

        public string Encryption(string inputString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;

            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(inputString);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        public string Decryption(string inputString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(inputString);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }
    }
}
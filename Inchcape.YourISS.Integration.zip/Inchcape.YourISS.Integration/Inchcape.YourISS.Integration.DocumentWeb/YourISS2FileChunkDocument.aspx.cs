﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inchcape.YourISS.Integration.DocumentWeb
{
    public partial class YourISS2FileChunkDocument : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDownload_Click(object sender, EventArgs e)
        {
            string FileName = "Test_DA.pdf";
            string[] Extensions = FileName.Split('.');
            string Ext = Extensions[Extensions.Length - 1];

            if (Ext.ToLower() != "exe" && Ext.ToLower() != "dll")
            {
                YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();
                Response.ContentType = "Application/" + Ext;
                Response.AddHeader("content-disposition", "attachment;fileName=" + FileName);
                //string fn = "file://idcchnyiss2app/Documents/Da/Test_DA.pdf"; 
                string fn = "file://idcchnyiss2app/Documents/Da/Test_DA_27.pdf";
                int ChunkSize = 0;
                int ChunkCount = 0;
                byte[] fileData = null;

                byte[] buffer = obj.GetFirstChk(fn, ref ChunkCount, ref ChunkSize);
                int i = 1;
                int tries = 0;

                while (i <= ChunkCount && tries < 5)
                {
                    if (buffer != null)
                    {
                        if (fileData == null)
                            fileData = buffer;
                        else
                        {
                            int offset = fileData.Length;
                            Array.Resize(ref fileData, offset + buffer.Length);
                            Array.Copy(buffer, 0, fileData, offset, buffer.Length);
                        }

                        i++;
                        tries = 0;
                    }
                    else
                        tries++;

                    if (i == 1)
                    {
                        fn = FileName;
                        ChunkSize = 0;
                        ChunkCount = 0;
                        buffer = obj.GetFirstChk(fn, ref ChunkCount, ref ChunkSize);
                    }
                    else if (i <= ChunkCount)
                        buffer = obj.GetFileChunk(fn, i, ChunkSize);
                }

                Response.BinaryWrite(fileData);
                Response.Flush();
            }

            Response.End();
        }
    }
}
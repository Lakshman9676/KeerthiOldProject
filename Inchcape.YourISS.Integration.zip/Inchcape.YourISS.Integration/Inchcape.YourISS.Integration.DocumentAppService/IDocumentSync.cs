﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Inchcape.YourISS.Integration.DocumentAppService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IDocumentSync
    {

        [OperationContract]
        string GetDocumentData(string yiss2DocPath);

        [OperationContract]
        int ValidateIntegrationSystem(Guid AccountId);

        [OperationContract]
        byte[] GetFirstChk(string yiss2DocPath, ref int ChunkCount, ref int ChunkSize);

        [OperationContract]
        byte[] GetFileChunk(string yiss2DocPath, int ChunkNo, int ChunkSize);
    }
}

﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Inchcape.YourISS.Integration.DocumentAppService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class DocumentSync : IDocumentSync
    {
        public string GetDocumentData(string yiss2DocPath)
        {
            String yiss2DocStream = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(yiss2DocPath))
                {
                    throw new Exception("YourISS2 Path invalid / YourISS2 Document not present ");
                }
                else
                {
                    string modifiedPath = new Uri(yiss2DocPath).LocalPath;

                    byte[] byteArray = File.ReadAllBytes(modifiedPath);
                    yiss2DocStream = Convert.ToBase64String(byteArray, Base64FormattingOptions.None);
                }
            }
            catch (Exception exp)
            {

            }
            finally
            {
               
            }

            return yiss2DocStream;
        }

        public byte[] GetFirstChk( string yiss2DocPath, ref int ChunkCount, ref int ChunkSize)
        {

            ChunkSize = 524288;

            string modifiedPath = new Uri(yiss2DocPath).LocalPath;
            if (File.Exists(modifiedPath))
            {
                FileStream fs = new FileStream(modifiedPath, FileMode.Open, FileAccess.Read);
                double chunks = (double)fs.Length / ChunkSize;
                ChunkCount = (int)Math.Ceiling(chunks);
                int bufferSize = fs.Length > ChunkSize ? ChunkSize : (int)fs.Length;
                byte[] buffer = new byte[bufferSize];
                fs.Read(buffer, 0, bufferSize);
                fs.Close();
                return buffer;
            }

            return null;
        }

        public byte[] GetFileChunk(string yiss2DocPath, int ChunkNo, int ChunkSize)
        {
            string modifiedPath = new Uri(yiss2DocPath).LocalPath;
            if (File.Exists(modifiedPath))
            {
                FileStream fs = new FileStream(modifiedPath, FileMode.Open, FileAccess.Read);
                int offset = (ChunkNo - 1) * ChunkSize;
                int bufferSize = fs.Length - offset > ChunkSize ? ChunkSize : (int)(fs.Length - offset);
                byte[] buffer = new byte[bufferSize];
                fs.Seek(offset, SeekOrigin.Current);
                fs.Read(buffer, 0, bufferSize);
                fs.Close();
                return buffer;
            }

            return null;
        }

        public int ValidateIntegrationSystem(Guid AccountId)
        {
            int count = 0;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {

                    string connectionString = ConfigurationManager.ConnectionStrings["ControlDBConnectionString"].ToString();
                    //string connectionString = @"Database=ERP_INTF; Server=ISSIDCBIZTALK\ISSIDCBIZTALK; uid=IDCBizTalkUser; pwd=Sh1pN3t05";

                    //string connectionString = GetControlDBConnectionString();
                    sqlConnection.ConnectionString = connectionString;
                    System.Diagnostics.EventLog.WriteEntry("Application", "ConnectionString - " + connectionString);
                    using (SqlCommand sqlCommand = new SqlCommand("SPU_Validate_IntegrationSystem", sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.CommandTimeout = 600;

                        sqlCommand.Parameters.Add("@HubPrincipalKey", SqlDbType.UniqueIdentifier).Value = AccountId;

                        sqlConnection.Open();

                        count = Convert.ToInt32(sqlCommand.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return count;
        }

        public static string GetControlDBConnectionString()
        {
            string conString = "";
            try
            {

                RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\Shipnet", true);
                conString = GetDecryptedConnectionString(reg.GetValue("ControlDBConnectionString").ToString());

                //conString = reg.GetValue("ControlDBConnectionString").ToString();

                //conString = "Database=ThirdPartyERP_INTF; Server=lindchn028; uid=sa; pwd=Password12";

                // System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetBizConnectionString  -->" + conString);
            }
            catch (Exception exp)
            {
                //System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetControlDBConnectionString  Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
            }
            return conString;
        }

        public static string GetDecryptedConnectionString(string encryptedConString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;
            string decryptedConStr = "";
            try
            {

                byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
                byte[] cipherTextBytes = Convert.FromBase64String(encryptedConString);
                PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
                byte[] keyBytes = password.GetBytes(keysize / 8);
                RijndaelManaged symmetricKey = new RijndaelManaged();
                symmetricKey.Mode = CipherMode.CBC;
                ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
                MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
                CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                memoryStream.Close();
                cryptoStream.Close();
                decryptedConStr = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);


            }
            catch (Exception exp)
            {
                //System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Decryption  Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDecryptedConnectionString-->{0}", exp.Message));
            }

            return decryptedConStr;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Inchcape.YourISS.Integration.IMOS.IntegrationModels
{
    [DataContract]
    public class ISSIAEmail
    {
        [DataMember]
        public String Id;
        [DataMember]
        public List<string> To;
        [DataMember]
        public List<string> CC;
        [DataMember]
        public List<string> BCC;
        [DataMember]
        public string From;
        [DataMember]
        public string Subject;
        [DataMember]
        public string Body;
        [DataMember]
        public EmailAttachment[] Attachments;

    }
    [DataContract]
    public class EmailAttachment
    {
        [DataMember]
        public byte[] File;

        [DataMember]
        public string FileName;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Inchcape.YourISS.Integration.IMOS.IntegrationModels
{
    [DataContract]
    public class ISSIAMessage
    {
        [DataMember]
        public Guid MessageID { get; set; }
        [DataMember]
        public Guid ProcessId { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public ISSIAEmail Email { get; set; }
        public string Status { get; set; }
    }
}

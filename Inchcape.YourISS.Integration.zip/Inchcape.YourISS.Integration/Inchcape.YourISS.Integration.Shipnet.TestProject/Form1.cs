﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WindowsService
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto RequestObj = new Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto();

            Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto ResponseObj = new Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto();

            XmlSerializer serializer = new XmlSerializer(typeof(Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto));
     


            // convert string to stream
            byte[] byteArray = Encoding.ASCII.GetBytes(RequestText.Text);
            MemoryStream stream = new MemoryStream( byteArray );

            RequestObj = (Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationDto)serializer.Deserialize(stream);
 

            Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationServiceClient RequestClient = new Inchcape.YourISS.Integration.Shipnet.TestProject.ISSIntegrationService.ISSIntegrationServiceClient();
            ResponseObj = RequestClient.PostIntegrationMessage(RequestObj);
            string abe = "";

        }

        private void btnComp_Click(object sender, EventArgs e)
        {
            //Transform string into byte[]  
            string value = Compress.Text;
            byte[] byteArray = new byte[value.Length];
            int indexBA = 0;
            foreach (char item in value.ToCharArray())
            {
                byteArray[indexBA++] = (byte)item;
            }

            //Prepare for compress
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            System.IO.Compression.GZipStream sw = new System.IO.Compression.GZipStream(ms,
                System.IO.Compression.CompressionMode.Compress);

            //Compress
            sw.Write(byteArray, 0, byteArray.Length);
            //Close, DO NOT FLUSH cause bytes will go missing...
            sw.Close();

            //Transform byte[] zip data to string
            byteArray = ms.ToArray();
            System.Text.StringBuilder sB = new System.Text.StringBuilder(byteArray.Length);
            foreach (byte item in byteArray)
            {
                sB.Append((char)item);
            }
            ms.Close();
            sw.Dispose();
            ms.Dispose();
            //return sB.ToString();
            richTextBox1.Text = sB.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string value = Compress.Text;
            //Transform string into byte[]
            byte[] byteArray = new byte[value.Length];
            int indexBA = 0;
            foreach (char item in value.ToCharArray())
            {
                byteArray[indexBA++] = (byte)item;
            }

            //Prepare for decompress
            System.IO.MemoryStream ms = new System.IO.MemoryStream(byteArray);
            System.IO.Compression.GZipStream sr = new System.IO.Compression.GZipStream(ms,
                System.IO.Compression.CompressionMode.Decompress);

            //Reset variable to collect uncompressed result
            byteArray = new byte[byteArray.Length];

            //Decompress
            int rByte = sr.Read(byteArray, 0, byteArray.Length);

            //Transform byte[] unzip data to string
            System.Text.StringBuilder sB = new System.Text.StringBuilder(rByte);
            //Read the number of bytes GZipStream red and do not a for each bytes in
            //resultByteArray;
            for (int i = 0; i < rByte; i++)
            {
                sB.Append((char)byteArray[i]);
            }
            sr.Close();
            ms.Close();
            sr.Dispose();
            ms.Dispose();
            richTextBox1.Text = sB.ToString();
        }

        private void Compress_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string xmlString;
            System.Diagnostics.EventLog.WriteEntry("Application", "XMLToJsonConverter Pipeline – Entered Execute()");
            //System.Diagnostics.EventLog.WriteEntry("Application", "XMLToJsonConverter Pipeline – RootNode:" + RootNode);
            //var originalStream = pInMsg.BodyPart.GetOriginalDataStream();
            //using (TextReader reader = new StreamReader(originalStream))
            //{
            //    xmlString = reader.ReadToEnd();
            //    //json = _Prefix + json + _Suffix;

            //}
            xmlString = "<FinanceDetail><portCall>1370481</portCall><businessPartner>102</businessPartner><agentTypeCode>OA</agentTypeCode><invoiceReference>Inv-786</invoiceReference><invoiceDate>2016-05-03T00:19:35</invoiceDate><currency>USD</currency><exchangeRate>1</exchangeRate><status>REV</status><costItems><accountCode>PLT</accountCode><amount>300.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>PLT</accountCode><amount>400.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>TWG</accountCode><amount>550.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>HBD</accountCode><amount>45.1000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>AGF</accountCode><amount>1000.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems></FinanceDetail>";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);
            XmlNodeList xnList = xmlDoc.SelectNodes("/FinanceDetail/portCall");
            XmlNode xnNode = xnList[0];
            string portcallNumber = xnNode.InnerText;
            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Read XML Data: " + xmlString);
            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Serializing JSON to XML…");

            string jsonText = JsonConvert.SerializeXmlNode(xmlDoc);

            jsonText = jsonText.Substring(17, jsonText.Length - 18);
            string removedString = jsonText.Replace("\"" + portcallNumber + "\"", portcallNumber);

            string abe = removedString + "fsds";
            //Substring
            //Get Portcall no from XML
            //Replace the value in Json eg: "114" replace by 114;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string xmlString;
            System.Diagnostics.EventLog.WriteEntry("Application", "XMLToJsonConverter Pipeline – Entered Execute()");

            xmlString = "<FinanceDetail><portCall>1370481</portCall><businessPartner>102</businessPartner><agentTypeCode>OA</agentTypeCode><invoiceReference>Inv-786</invoiceReference><invoiceDate>2016-05-03T00:19:35</invoiceDate><currency>USD</currency><exchangeRate>1</exchangeRate><status>REV</status><costItems><accountCode>PLT</accountCode><amount>300.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>PLT</accountCode><amount>400.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>TWG</accountCode><amount>550.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>HBD</accountCode><amount>45.1000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems><costItems><accountCode>AGF</accountCode><amount>1000.0000</amount><costItemKey>123</costItemKey><isOwnersCost>false</isOwnersCost><isCharterersCost>false</isCharterersCost></costItems></FinanceDetail>";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);

            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Read XML Data: " + xmlString);
            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Serializing JSON to XML…");

            string jsonText = JsonConvert.SerializeXmlNode(xmlDoc);

            var portCallString = JObject.Parse(jsonText).SelectToken("FinanceDetail").ToString();

            JObject data = JObject.Parse(portCallString.ToString());
            string portCallNumber = data["portCall"].ToString();

            string removedString = portCallString.Replace("\"" + portCallNumber + "\"", portCallNumber);

            string abe = removedString + "fsds";

        }

        private void button5_Click(object sender, EventArgs e)
        {

            // 3E3FE671-66CA-4944-A269-2FD0691A00EE Create IMOS 1
            // 2393F6CC-95A8-43DF-A198-0BA32003E439 Cancel IMOS 1
           Inchcape.YourISS.Integration.Shipnet.TestProject.IMOSIntegrationService.ISSIAMessage RequestObj = new Inchcape.YourISS.Integration.Shipnet.TestProject.IMOSIntegrationService.ISSIAMessage();

            Inchcape.YourISS.Integration.Shipnet.TestProject.IMOSIntegrationService.IntegrationServiceClient RequestClient = new Inchcape.YourISS.Integration.Shipnet.TestProject.IMOSIntegrationService.IntegrationServiceClient();
            //RequestObj.ProcessId = new Guid("497474DD-4386-4E9F-97A5-C0A9A26318E7");//AccountId
            RequestObj.ProcessId = new Guid("3E3FE671-66CA-4944-A269-2FD0691A00EE");
            RequestObj.MessageID = new Guid("A080DC22-F0CC-4787-9747-8C12D109D7B7");
            RequestObj.Message = "<PortCallDetails xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>"  
                                    +"<CompanyCode>VTSG</CompanyCode> " 
                                    +"<VesselCode>A0080</VesselCode>"  
                                    +"<VoyageNo>16004</VoyageNo>  "
                                    +"<PortCallSeq>300</PortCallSeq>  "
                                    +"<PortNo>3558</PortNo>  "
                                    +"<PortName>WHYALLA</PortName>  "
                                    +"<UNCode>AUWYA</UNCode>  "
                                    +"<EtaGmt>2016-05-12T14:50:46Z</EtaGmt>  "
                                    +"<EtdGmt>2016-05-13T23:56:58Z</EtdGmt>  "
                                    +"<PortFunctionCode>D</PortFunctionCode>  "
                                    +"<PortCargoes> "
                                    +"  <PortCargo> "
                                    +"      <CargoID>206</CargoID>  "
                                    +"      <FullName>CHEMICAL</FullName>  "
                                    +"      <ShortName>CHEMICAL</ShortName> " 
                                    +"      <ActivityType>D</ActivityType>  "
                                    +"      <Quantity>40000</Quantity>  "
                                    +"      <Units>MT</Units> "
                                    +"  </PortCargo> "
                                    +"</PortCargoes>  "
                                    + "<Agents> "
                                    +"  <Agent> "
                                    +"      <AgentType>CharterersAgent</AgentType> "
                                    +"      <FullName>Test Agent</FullName> "
                                    +"      <ShortName>AGENT</ShortName> "
                                    +"      <Address1>123 Main Street</Address1> "
                                    +"      <Address2>555</Address2> "
                                    +"      <Address3/> "
                                    +"      <Address4/> "
                                    +"      <Currency>USD</Currency> "
                                    +"      <Country>USA</Country> "
                                    +"      <CompanyNo>100000009</CompanyNo> "
                                    +"      <Phone/> "
                                    +"      <Email/> "
                                    +"      <MainContact/> "
                                    +"  </Agent> "
                                    +"  <Agent> "
                                    +"      <AgentType>ProtectiveAgent</AgentType> "
                                    +"      <FullName>ZAGENT</FullName> "
                                    +"      <ShortName>ZAGT</ShortName> "
                                    +"      <Address1>.</Address1> "
                                    +"      <Address2/> "
                                    +"      <Address3/> "
                                    +"      <Address4/> "
                                    +"      <Currency>USD</Currency> "
                                    +"      <Country/> "
                                    +"      <CompanyNo>100000123</CompanyNo> "
                                    +"      <Phone/> "
                                    +"      <Email>MAYPOH@ABC.COM</Email> "
                                    +"      <MainContact/> "
                                    +"  </Agent> "
                                    +"</Agents> "
                                   +"</PortCallDetails>";



          //  RequestObj.Message = "{ "
          //    + " \"CompanyCode\": \"VTSG\", "
          //    + "\"VesselCode\": \"A0080\", "
          //    + "\"VoyageNo\": \"16003\", "
          //    + "\"PortCallSeq\": \"300\", "
          //    + "\"PortNo\": \"3558\", "
          //    + "\"PortName\": \"WHYALLA\", "
          //    + "\"UNCode\": \"AUWYA\", "
          //    + "\"EtaGmt\": \"2016-05-12T14:50:46Z\", "
          //    + "\"EtdGmt\": \"2016-05-13T23:56:58Z\", "
          //    + "\"PortFunctionCode\": \"D\", "
          //    + "\"PortCargoes\": [ "
          //      + "      { "
          //      + "  \"CargoID\": \"206\", "
          //      + "  \"FullName\": \"CHEMICAL\", "
          //        + "\"ShortName\": \"CHEMICAL\", "
          //       + " \"ActivityType\": \"D\", "
          //        + "\"Quantity\": \"40000\", "
          //        + "\"Units\": \"MT\" "
          //    + "}], "
          //   + "\"Agents\": [ "
          //        + "{ "
          //          + "\"AgentType\": \"CharterersAgent\", "
          //          + "\"FullName\": \"Test Agent\", "
          //          + "\"ShortName\": \"AGENT\", "
          //          + "\"Address1\": \"123 Main Street\", "
          //          + "\"Address2\": \"555\", "
          //          + "\"Currency\": \"USD\", "
          //          + "\"Country\": \"USA\", "
          //          + "\"CompanyNo\": \"100000009\" "
          //        + "}, "
          //        + "{ "
          //         + " \"AgentType\": \"ProtectiveAgent\", "
          //          + "\"FullName\": \"ZAGENT\", "
          //          + "\"ShortName\": \"ZAGT\", "
          //          + "\"Address1\": \".\", "
          //          + "\"Currency\": \"USD\", "
          //          + "\"CompanyNo\": \"100000123\", "
          //          + "\"Email\": \"MAYPOH@ABC.COM\" "
          //        + "} "
          //      + "] "
          //+ "} ";




////            RequestObj.Message = "{ "
////  + " \"CompanyCode\": \"VTSG\", "
////  + "\"VesselCode\": \"A0080\", "
////  + "\"VoyageNo\": \"16002\", "
////  + "\"PortCallSeq\": \"300\", "
////  + "\"PortNo\": \"3558\", "
////  + "\"PortName\": \"WHYALLA\", "
////  + "\"UNCode\": \"AUWYA\", "
////  + "\"EtaGmt\": \"2016-05-12T14:50:46Z\", "
////  + "\"EtdGmt\": \"2016-05-13T23:56:58Z\", "
////  + "\"PortFunctionCode\": \"D\", "
////  + "\"PortCargoes\": {"

////  + "\"PortCargo\": [ "
////    + "      { "
////    + "  \"CargoID\": \"206\", "
////    + "  \"FullName\": \"CHEMICAL\", "
////      + "\"ShortName\": \"CHEMICAL\", "
////     + " \"ActivityType\": \"D\", "
////      + "\"Quantity\": \"40000\", "
////      + "\"Units\": \"MT\" "
////  + "}] "
////  + "}, " 
////  + "\"Agents\": {"
//// + "\"Agent\": [ "
////      + "{ "
////        + "\"AgentType\": \"CharterersAgent\", "
////        + "\"FullName\": \"Test Agent\", "
////        + "\"ShortName\": \"AGENT\", "
////        + "\"Address1\": \"123 Main Street\", "
////        + "\"Address2\": \"555\", "
////        + "\"Currency\": \"USD\", "
////        + "\"Country\": \"USA\", "
////        + "\"CompanyNo\": \"100000009\" "
////      + "}, "
////      + "{ "
////       + " \"AgentType\": \"ProtectiveAgent\", "
////        + "\"FullName\": \"ZAGENT\", "
////        + "\"ShortName\": \"ZAGT\", "
////        + "\"Address1\": \".\", "
////        + "\"Currency\": \"USD\", "
////        + "\"CompanyNo\": \"100000123\", "
////        + "\"Email\": \"MAYPOH@ABC.COM\" "
////      + "} "
////    + "] "
////      + "} " 
////+ "} ";
            
            bool result = RequestClient.CreatePortCall(RequestObj);
            string abe = "";
        }
    }
}

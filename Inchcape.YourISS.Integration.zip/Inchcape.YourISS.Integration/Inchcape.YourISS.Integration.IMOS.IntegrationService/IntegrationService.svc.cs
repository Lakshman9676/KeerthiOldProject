﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Inchcape.YourISS.Integration.IMOS.IntegrationModels;
using System.Configuration;

namespace Inchcape.YourISS.Integration.IMOS.IntegrationService
{
    
    public class IntegrationService : IIntegrationService
    {
        public bool CreatePortCall(ISSIAMessage IntegrationMessage)
        {
            
            bool isSent = false;
            try
            {
                int count = 0;
                Guid account = IntegrationMessage.ProcessId;
                ISSIntegrationAppService.ISSIntegrationAppServiceClient AppClient = new ISSIntegrationAppService.ISSIntegrationAppServiceClient();

                string createPortCallKey = ConfigurationManager.AppSettings.Get("PortCallCreateKey");
                string cancelPortCallKey = ConfigurationManager.AppSettings.Get("PortCallCancelKey");
                string accountId = string.Empty;
                string method = string.Empty;

                System.Diagnostics.EventLog.WriteEntry("Application", "Before Validate ");
                //count = AppClient.ValidateIntegrationSystem(account);
                if (account.ToString().ToUpper() == createPortCallKey.ToUpper())
                {
                    count = 1;
                    accountId =  ConfigurationManager.AppSettings.Get("HubPrincipalKey");
                    method = "PC";
                }
                else if (account.ToString().ToUpper() == cancelPortCallKey.ToUpper())
                {
                    count = 1;
                    accountId = ConfigurationManager.AppSettings.Get("HubPrincipalKey");
                    method = "CAN";
                }

                System.Diagnostics.EventLog.WriteEntry("Application", "After Validate ");
                if (count > 0)
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Inside Count ");
                    isSent = AppClient.SaveISSIntegrationMessage(IntegrationMessage, new Guid(accountId), method);
                }
                //message.Message = message.Message.ToString();
                //isSent = new PortCallObjectClient().CreatePortCall(message);
            }
            catch (Exception ex)
            {
                
                isSent = false;
            }
            return isSent;
        }

        public bool CancelPortCall(ISSIAMessage message)
        {
            
            bool isSent = false;
            try
            {
                //message.Message = message.Message.ToString();
                //isSent = new PortCallObjectClient().CreatePortCall(message);
            }
            catch (Exception ex)
            {
                
                isSent = false;
            }
            return isSent;
        }

    }
}

namespace Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema",@"PortCallDetails")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"PortCallDetails"})]
    public sealed class Schema_IMOSPortCallJson : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""PortCallDetails"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CompanyCode"" type=""xs:string"" />
        <xs:element name=""VesselCode"" type=""xs:string"" />
        <xs:element name=""VoyageNo"" type=""xs:byte"" />
        <xs:element name=""PortCallSeq"" type=""xs:byte"" />
        <xs:element name=""PortNo"" type=""xs:byte"" />
        <xs:element name=""PortName"" type=""xs:string"" />
        <xs:element name=""UNCode"" type=""xs:string"" />
        <xs:element name=""EtaGmt"" type=""xs:dateTime"" />
        <xs:element name=""EtdGmt"" type=""xs:dateTime"" />
        <xs:element name=""PortFunctionCode"" type=""xs:string"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""PortCargoes"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""CargoID"" type=""xs:byte"" />
              <xs:element name=""FullName"" type=""xs:string"" />
              <xs:element name=""ShortName"" type=""xs:string"" />
              <xs:element name=""ActivityType"" type=""xs:string"" />
              <xs:element name=""Quantity"" type=""xs:byte"" />
              <xs:element name=""Units"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Agents"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""AgentType"" type=""xs:string"" />
              <xs:element name=""FullName"" type=""xs:string"" />
              <xs:element name=""ShortName"" type=""xs:string"" />
              <xs:element name=""Address1"" type=""xs:string"" />
              <xs:element name=""Address2"" type=""xs:string"" />
              <xs:element name=""Address3"" type=""xs:string"" />
              <xs:element name=""Address4"" type=""xs:string"" />
              <xs:element name=""Currency"" type=""xs:string"" />
              <xs:element name=""Country"" type=""xs:string"" />
              <xs:element name=""CompanyNo"" type=""xs:byte"" />
              <xs:element name=""Phone"" type=""xs:string"" />
              <xs:element name=""Email"" type=""xs:string"" />
              <xs:element name=""MainContact"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_IMOSPortCallJson() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "PortCallDetails";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

namespace Inchcape.YourISS.Integration.IMOS.GetPortCall {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema_IMOSPortCall", typeof(global::Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema_IMOSPortCall))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.IMOS.GetPortCall.TypedPolling_IMOSPortCall+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.IMOS.GetPortCall.TypedPolling_IMOSPortCall.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall))]
    public sealed class IMOSToGenericTransform : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 s3 s2 userCSharp"" version=""1.0"" xmlns:s0=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/IMOSPortCall"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:s1=""http://Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema"" xmlns:s3=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;PortCall&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(InputMessagePart_0/s1:PortCallDetails/CompanyCode/text()) , &quot;-&quot; , string(InputMessagePart_0/s1:PortCallDetails/VesselCode/text()))"" />
    <xsl:variable name=""var:v5"" select=""InputMessagePart_0/s1:PortCallDetails/Agents/Agent[1]/ShortName/text()"" />
    <xsl:variable name=""var:v6"" select=""InputMessagePart_0/s1:PortCallDetails/Agents/Agent[1]/FullName/text()"" />
    <xsl:variable name=""var:v7"" select=""InputMessagePart_0/s1:PortCallDetails/Agents/Agent[1]/AgentType/text()"" />
    <xsl:variable name=""var:v9"" select=""userCSharp:StringConcat(&quot;1&quot;)"" />
    <xsl:variable name=""var:v10"" select=""count(/s2:Root/InputMessagePart_0/s1:PortCallDetails/PortCargoes/PortCargo)"" />
    <ns0:YourIssNotification>
      <xsl:if test=""InputMessagePart_1/s0:TypedPollingResultSet0/s0:AccountId"">
        <HubPrincipalKey>
          <xsl:value-of select=""InputMessagePart_1/s0:TypedPollingResultSet0/s0:AccountId/text()"" />
        </HubPrincipalKey>
      </xsl:if>
      <xsl:if test=""InputMessagePart_1/s0:TypedPollingResultSet0/s0:Id"">
        <Id>
          <xsl:value-of select=""InputMessagePart_1/s0:TypedPollingResultSet0/s0:Id/text()"" />
        </Id>
      </xsl:if>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""$var:v1"" />
        </MessageType>
        <xsl:variable name=""var:v2"" select=""userCSharp:GetAction(string(InputMessagePart_1/s0:TypedPollingResultSet0/s0:Method/text()))"" />
        <Action>
          <xsl:value-of select=""$var:v2"" />
        </Action>
        <CreatedDate>
          <xsl:value-of select=""$var:v3"" />
        </CreatedDate>
        <ShipNetReference>
          <xsl:value-of select=""$var:v4"" />
        </ShipNetReference>
      </MessageHeader>
      <PortCall>
        <PrincipalCode>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/CompanyCode/text()"" />
        </PrincipalCode>
        <SN_KeyPosition>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/PortCallSeq/text()"" />
        </SN_KeyPosition>
        <SN_VesselCode>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/VesselCode/text()"" />
        </SN_VesselCode>
        <IMO>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/VesselCode/text()"" />
        </IMO>
        <SN_VoyageNumber>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/VoyageNo/text()"" />
        </SN_VoyageNumber>
        <ETA>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/EtaGmt/text()"" />
        </ETA>
        <ETS>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/EtdGmt/text()"" />
        </ETS>
        <PortOperationCode>
          <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/PortFunctionCode/text()"" />
        </PortOperationCode>
        <SN_AgentCode>
          <xsl:value-of select=""$var:v5"" />
        </SN_AgentCode>
        <SN_AgentName>
          <xsl:value-of select=""$var:v6"" />
        </SN_AgentName>
        <ISS_AgentCode>
          <xsl:value-of select=""$var:v5"" />
        </ISS_AgentCode>
        <xsl:variable name=""var:v8"" select=""userCSharp:GetSubstring(string($var:v7))"" />
        <SN_NominationType>
          <xsl:value-of select=""$var:v8"" />
        </SN_NominationType>
        <PortCount>
          <xsl:value-of select=""$var:v9"" />
        </PortCount>
        <Ports>
          <Port>
            <PortName>
              <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/PortName/text()"" />
            </PortName>
            <PortCode>
              <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/UNCode/text()"" />
            </PortCode>
            <ISS_PortCode>
              <xsl:value-of select=""InputMessagePart_0/s1:PortCallDetails/UNCode/text()"" />
            </ISS_PortCode>
          </Port>
        </Ports>
        <CargoCount>
          <xsl:value-of select=""$var:v10"" />
        </CargoCount>
        <Cargoes>
          <xsl:for-each select=""InputMessagePart_0/s1:PortCallDetails/PortCargoes/PortCargo"">
            <Cargo>
              <SN_KeyCargo>
                <xsl:value-of select=""CargoID/text()"" />
              </SN_KeyCargo>
              <SN_CargoNo>
                <xsl:value-of select=""CargoID/text()"" />
              </SN_CargoNo>
              <ISS_CommodityCode>
                <xsl:value-of select=""ShortName/text()"" />
              </ISS_CommodityCode>
              <CommodityName>
                <xsl:value-of select=""FullName/text()"" />
              </CommodityName>
              <Quantity>
                <xsl:value-of select=""Quantity/text()"" />
              </Quantity>
              <QuantityTypeCode>
                <xsl:value-of select=""Units/text()"" />
              </QuantityTypeCode>
              <CargoOperationCode>
                <xsl:value-of select=""ActivityType/text()"" />
              </CargoOperationCode>
            </Cargo>
          </xsl:for-each>
        </Cargoes>
      </PortCall>
    </ns0:YourIssNotification>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public string GetAction(string method)
{
         if(method == ""PC"")
              return ""Create"";
        else  if(method == ""PU"")
              return ""Update"";
        else  if(method == ""CAN"")
              return ""Cancel"";
        else
              return """";
}

public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string GetSubstring(string agencyType)
{
        if  (   agencyType  == null ||    agencyType   == """"  )
{
 return agencyType;
}
else
{
       string subStringAgencyType = agencyType.Substring(0, agencyType.Length - 5);
        return subStringAgencyType;
        
}
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema_IMOSPortCall";
        
        private const global::Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema_IMOSPortCall _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.IMOS.GetPortCall.TypedPolling_IMOSPortCall+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.IMOS.GetPortCall.TypedPolling_IMOSPortCall.TypedPollingResultSet0 _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.IMOS.GetPortCall.Schema.Schema_IMOSPortCall";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.IMOS.GetPortCall.TypedPolling_IMOSPortCall+TypedPollingResultSet0";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
                return _TrgSchemas;
            }
        }
    }
}

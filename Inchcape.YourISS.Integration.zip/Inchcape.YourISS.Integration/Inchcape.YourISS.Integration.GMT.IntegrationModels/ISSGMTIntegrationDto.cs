﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Inchcape.YourISS.Integration.GMT.IntegrationModels
{
    [DataContract]
    public class ISSGMTIntegrationDto
    {
        [DataMember]
        public Guid MessageID { get; set; }
        [DataMember]
        public Guid AccountId { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public string Status { get; set; }
    }

    [Serializable]
    [DataContract]
    public class ISSGMTIntegrationResponse
    {
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember(Name = "AckBy", IsRequired = false)]
        public string AckBy { get; set; }
        [DataMember(Name = "AckNo", IsRequired = false)]
        public string AckNo { get; set; }
    }
}

namespace Inchcape.YourISS.Integration.Generic.Portcalls.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_CreatePortCall", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_CreatePortCall))]
    public sealed class Map_GenericPortcall_To_YourISSPortcall : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schema.PortcallCreate"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schema.YourISS.PortcallCreate"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringUpperCase(string(MessageHeader/Action/text()))"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:LogicalEq(string($var:v1) , &quot;UPDATE&quot;)"" />
    <xsl:variable name=""var:v5"" select=""userCSharp:StringConcat(&quot;true&quot;)"" />
    <xsl:variable name=""var:v6"" select=""string(MessageHeader/Action/text())"" />
    <xsl:variable name=""var:v7"" select=""userCSharp:StringUpperCase($var:v6)"" />
    <xsl:variable name=""var:v8"" select=""userCSharp:LogicalEq(string($var:v7) , &quot;CANCEL&quot;)"" />
    <xsl:variable name=""var:v11"" select=""string(MessageHeader/ShipNetReference/text())"" />
    <xsl:variable name=""var:v12"" select=""string(PortCall/SN_DANo/text())"" />
    <xsl:variable name=""var:v13"" select=""string(PortCall/SN_KeyPosition/text())"" />
    <xsl:variable name=""var:v14"" select=""string(PortCall/SN_VoyageNumber/text())"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat($var:v11 , &quot;|&quot; , $var:v12 , &quot;|&quot; , $var:v13 , &quot;|&quot; , $var:v14)"" />
    <xsl:variable name=""var:v16"" select=""userCSharp:LogicalEq(string($var:v7) , &quot;UPDATE&quot;)"" />
    <xsl:variable name=""var:v18"" select=""userCSharp:StringConcat(string(HubPrincipalKey/text()) , &quot;|1&quot;)"" />
    <xsl:variable name=""var:v38"" select=""string(HubPrincipalKey/text())"" />
    <xsl:variable name=""var:v39"" select=""userCSharp:StringTrimLeft($var:v38)"" />
    <xsl:variable name=""var:v40"" select=""userCSharp:StringTrimRight(string($var:v39))"" />
    <xsl:variable name=""var:v41"" select=""userCSharp:StringConcat(string($var:v40) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v54"" select=""string(PortCall/PrincipalCode/text())"" />
    <xsl:variable name=""var:v82"" select=""string(PortCall/ISS_AgentCode/text())"" />
    <xsl:variable name=""var:v108"" select=""PortCall/Cargoes/Cargo[1]/ISS_CommodityCode/text()"" />
    <xsl:variable name=""var:v138"" select=""string(PortCall/CargoCount/text())"" />
    <xsl:variable name=""var:v172"" select=""string(PortCall/SN_NominationType/text())"" />
    <xsl:variable name=""var:v188"" select=""userCSharp:StringConcat($var:v38 , &quot;|1&quot;)"" />
    <xsl:variable name=""var:v249"" select=""string(PortCall/PortOperationCode/text())"" />
    <xsl:variable name=""var:v277"" select=""string(PortCall/Ports/Port/ISS_PortCode/text())"" />
    <xsl:variable name=""var:v393"" select=""string(PortCall/IMO/text())"" />
    <ns0:YourIss2Appointment>
      <xsl:if test=""string($var:v2)='true'"">
        <xsl:variable name=""var:v3"" select=""string(MessageHeader/Action/text())"" />
        <xsl:variable name=""var:v4"" select=""ScriptNS0:GetPortCallIdForUpdate($var:v3 , string(MessageHeader/ShipNetReference/text()) , string(PortCall/SN_DANo/text()) , string(PortCall/SN_KeyPosition/text()) , string(PortCall/SN_VoyageNumber/text()))"" />
        <Number>
          <xsl:value-of select=""$var:v4"" />
        </Number>
      </xsl:if>
      <OkToSail>
        <xsl:value-of select=""$var:v5"" />
      </OkToSail>
      <PortCallAccepted>
        <xsl:text>false</xsl:text>
      </PortCallAccepted>
      <ControllingAgentAccepted>
        <xsl:text>false</xsl:text>
      </ControllingAgentAccepted>
      <HubPrincipalKey>
        <xsl:value-of select=""HubPrincipalKey/text()"" />
      </HubPrincipalKey>
      <xsl:if test=""string($var:v8)='true'"">
        <xsl:variable name=""var:v9"" select=""string(MessageHeader/ShipNetReference/text())"" />
        <xsl:variable name=""var:v10"" select=""ScriptNS0:GetPortCallIdForCancel($var:v9 , string(CancelPortCal/SN_DANo/text()) , string(CancelPortCal/SN_KeyPosition/text()))"" />
        <AppointmentNumber>
          <xsl:value-of select=""$var:v10"" />
        </AppointmentNumber>
      </xsl:if>
      <Appointments>
        <ExternalJobCode>
          <xsl:value-of select=""$var:v15"" />
        </ExternalJobCode>
        <xsl:if test=""string($var:v16)='true'"">
          <xsl:variable name=""var:v17"" select=""ScriptNS0:GetAppointmentIdForUpdate($var:v6 , $var:v11 , $var:v12 , $var:v13 , $var:v14)"" />
          <Number>
            <xsl:value-of select=""$var:v17"" />
          </Number>
        </xsl:if>
        <xsl:variable name=""var:v19"" select=""ScriptNS0:GetBizConnectionString()"" />
        <xsl:variable name=""var:v20"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v19) , &quot;ISSAccountingOfficeIntegration&quot; , &quot;cast( AccountId as varchar(40)   ) + '|'+ cast (IsActive as varchar (1) )&quot;)"" />
        <xsl:variable name=""var:v21"" select=""ScriptNS1:DBValueExtract(string($var:v20) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v22"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v23"" select=""ScriptNS1:DBLookup(1 , string($var:v21) , string($var:v22) , &quot;master.ISSAccountingOffices&quot; , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v24"" select=""ScriptNS1:DBValueExtract(string($var:v23) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v25"" select=""ScriptNS1:DBLookup(2 , string($var:v15) , string($var:v22) , &quot;YourISS2.Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v26"" select=""ScriptNS1:DBValueExtract(string($var:v25) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v27"" select=""ScriptNS1:DBLookup(3 , string($var:v26) , string($var:v22) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v28"" select=""ScriptNS1:DBValueExtract(string($var:v27) , &quot;ISSAccountingOfficeId&quot;)"" />
        <xsl:variable name=""var:v29"" select=""ScriptNS1:DBLookup(4 , string($var:v28) , string($var:v22) , &quot;Master.ISSAccountingOffices&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v30"" select=""ScriptNS1:DBValueExtract(string($var:v29) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v31"" select=""userCSharp:GetAccountOfficeID&#xD;($var:v6 , string($var:v24) , string($var:v30))"" />
        <xsl:variable name=""var:v32"" select=""userCSharp:StringConcat(string($var:v31) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v33"" select=""ScriptNS1:DBLookup(5 , string($var:v32) , string($var:v22) , &quot;Master.IssAccountingOffices&quot; , &quot;cast (  id  as  varchar(20) ) + '|'+ cast (  isActive as varchar(1)   )&quot;)"" />
        <xsl:variable name=""var:v34"" select=""ScriptNS1:DBValueExtract(string($var:v33) , &quot;CurrencyId&quot;)"" />
        <xsl:variable name=""var:v35"" select=""userCSharp:StringConcat(string($var:v34) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v36"" select=""ScriptNS1:DBLookup(6 , string($var:v35) , string($var:v22) , &quot;Master.Currencies&quot; , &quot;cast(   Id as varchar (20)) + '|' + cast ( IsActive as varchar(1)  )&quot;)"" />
        <xsl:variable name=""var:v37"" select=""ScriptNS1:DBValueExtract(string($var:v36) , &quot;Code&quot;)"" />
        <CurrencyCode>
          <xsl:value-of select=""$var:v37"" />
        </CurrencyCode>
        <Principal>
          <xsl:variable name=""var:v42"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v43"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v42) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v44"" select=""ScriptNS1:DBValueExtract(string($var:v43) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v45"" select=""userCSharp:StringConcat(string($var:v44) , &quot;|&quot; , string(PortCall/PrincipalCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v46"" select=""ScriptNS1:DBLookup(8 , string($var:v45) , string($var:v42) , &quot;Master.HubPrincipalPrincipalMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v47"" select=""ScriptNS1:DBValueExtract(string($var:v46) , &quot;PrincipalId&quot;)"" />
          <xsl:variable name=""var:v48"" select=""userCSharp:StringConcat(string($var:v47) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v49"" select=""ScriptNS1:DBLookup(9 , string($var:v48) , string($var:v42) , &quot;Master.Companies&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v50"" select=""ScriptNS1:DBValueExtract(string($var:v49) , &quot;id&quot;)"" />
          <Id>
            <xsl:value-of select=""$var:v50"" />
          </Id>
          <xsl:variable name=""var:v51"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v52"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v51) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v53"" select=""ScriptNS1:DBValueExtract(string($var:v52) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v55"" select=""userCSharp:StringConcat(string($var:v53) , &quot;|&quot; , $var:v54 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v56"" select=""ScriptNS1:DBLookup(8 , string($var:v55) , string($var:v51) , &quot;Master.HubPrincipalPrincipalMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v57"" select=""ScriptNS1:DBValueExtract(string($var:v56) , &quot;PrincipalId&quot;)"" />
          <xsl:variable name=""var:v58"" select=""userCSharp:StringConcat(string($var:v57) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v59"" select=""ScriptNS1:DBLookup(9 , string($var:v58) , string($var:v51) , &quot;Master.Companies&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v60"" select=""ScriptNS1:DBValueExtract(string($var:v59) , &quot;code&quot;)"" />
          <Code>
            <xsl:value-of select=""$var:v60"" />
          </Code>
          <xsl:variable name=""var:v61"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v62"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v61) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v63"" select=""ScriptNS1:DBValueExtract(string($var:v62) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v64"" select=""userCSharp:StringConcat(string($var:v63) , &quot;|&quot; , $var:v54 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v65"" select=""ScriptNS1:DBLookup(8 , string($var:v64) , string($var:v61) , &quot;Master.HubPrincipalPrincipalMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v66"" select=""ScriptNS1:DBValueExtract(string($var:v65) , &quot;PrincipalId&quot;)"" />
          <xsl:variable name=""var:v67"" select=""userCSharp:StringConcat(string($var:v66) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v68"" select=""ScriptNS1:DBLookup(9 , string($var:v67) , string($var:v61) , &quot;Master.Companies&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v69"" select=""ScriptNS1:DBValueExtract(string($var:v68) , &quot;Name&quot;)"" />
          <Name>
            <xsl:value-of select=""$var:v69"" />
          </Name>
        </Principal>
        <PerformingAgent>
          <xsl:variable name=""var:v70"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v71"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v70) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v72"" select=""ScriptNS1:DBValueExtract(string($var:v71) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v73"" select=""userCSharp:StringConcat(string($var:v72) , &quot;|&quot; , string(PortCall/ISS_AgentCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v74"" select=""ScriptNS1:DBLookup(10 , string($var:v73) , string($var:v70) , &quot;Master.HubPrincipalAgentMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v75"" select=""ScriptNS1:DBValueExtract(string($var:v74) , &quot;AgentId&quot;)"" />
          <xsl:variable name=""var:v76"" select=""userCSharp:StringConcat(string($var:v75) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v77"" select=""ScriptNS1:DBLookup(11 , string($var:v76) , string($var:v70) , &quot;Master.Companies&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v78"" select=""ScriptNS1:DBValueExtract(string($var:v77) , &quot;id&quot;)"" />
          <Id>
            <xsl:value-of select=""$var:v78"" />
          </Id>
          <xsl:variable name=""var:v79"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v80"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v79) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v81"" select=""ScriptNS1:DBValueExtract(string($var:v80) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v83"" select=""userCSharp:StringConcat(string($var:v81) , &quot;|&quot; , $var:v82 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v84"" select=""ScriptNS1:DBLookup(10 , string($var:v83) , string($var:v79) , &quot;Master.HubPrincipalAgentMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v85"" select=""ScriptNS1:DBValueExtract(string($var:v84) , &quot;AgentId&quot;)"" />
          <xsl:variable name=""var:v86"" select=""userCSharp:StringConcat(string($var:v85) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v87"" select=""ScriptNS1:DBLookup(11 , string($var:v86) , string($var:v79) , &quot;Master.Companies&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v88"" select=""ScriptNS1:DBValueExtract(string($var:v87) , &quot;code&quot;)"" />
          <Code>
            <xsl:value-of select=""$var:v88"" />
          </Code>
          <xsl:variable name=""var:v89"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v90"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v89) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v91"" select=""ScriptNS1:DBValueExtract(string($var:v90) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v92"" select=""userCSharp:StringConcat(string($var:v91) , &quot;|&quot; , $var:v82 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v93"" select=""ScriptNS1:DBLookup(10 , string($var:v92) , string($var:v89) , &quot;Master.HubPrincipalAgentMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v94"" select=""ScriptNS1:DBValueExtract(string($var:v93) , &quot;AgentId&quot;)"" />
          <xsl:variable name=""var:v95"" select=""userCSharp:StringConcat(string($var:v94) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v96"" select=""ScriptNS1:DBLookup(11 , string($var:v95) , string($var:v89) , &quot;Master.Companies&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v97"" select=""ScriptNS1:DBValueExtract(string($var:v96) , &quot;name&quot;)"" />
          <Name>
            <xsl:value-of select=""$var:v97"" />
          </Name>
        </PerformingAgent>
        <MainCommodity>
          <xsl:variable name=""var:v98"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v99"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v98) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v100"" select=""ScriptNS1:DBValueExtract(string($var:v99) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v101"" select=""userCSharp:StringConcat(string($var:v100) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v102"" select=""ScriptNS1:DBLookup(12 , string($var:v101) , string($var:v98) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v103"" select=""ScriptNS1:DBValueExtract(string($var:v102) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v104"" select=""ScriptNS1:DBLookup(13 , string($var:v103) , string($var:v98) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v105"" select=""ScriptNS1:DBValueExtract(string($var:v104) , &quot;commodityid&quot;)"" />
          <xsl:variable name=""var:v106"" select=""ScriptNS1:DBLookup(14 , string($var:v105) , string($var:v98) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v107"" select=""ScriptNS1:DBValueExtract(string($var:v106) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v109"" select=""userCSharp:StringConcat(string($var:v100) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v110"" select=""ScriptNS1:DBLookup(15 , string($var:v109) , string($var:v98) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v111"" select=""ScriptNS1:DBValueExtract(string($var:v110) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v112"" select=""userCSharp:StringConcat(string($var:v111) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v113"" select=""ScriptNS1:DBLookup(16 , string($var:v112) , string($var:v98) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v114"" select=""ScriptNS1:DBValueExtract(string($var:v113) , &quot;CommodityId&quot;)"" />
          <xsl:variable name=""var:v115"" select=""userCSharp:StringConcat(string($var:v114) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v116"" select=""ScriptNS1:DBLookup(17 , string($var:v115) , string($var:v98) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
          <xsl:variable name=""var:v117"" select=""ScriptNS1:DBValueExtract(string($var:v116) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v118"" select=""userCSharp:MainCommodityId(string(PortCall/CargoCount/text()) , string($var:v107) , string($var:v117))"" />
          <Id>
            <xsl:value-of select=""$var:v118"" />
          </Id>
          <xsl:variable name=""var:v119"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v120"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v119) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v121"" select=""ScriptNS1:DBValueExtract(string($var:v120) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v122"" select=""userCSharp:StringConcat(string($var:v121) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v123"" select=""ScriptNS1:DBLookup(12 , string($var:v122) , string($var:v119) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v124"" select=""ScriptNS1:DBValueExtract(string($var:v123) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v125"" select=""ScriptNS1:DBLookup(13 , string($var:v124) , string($var:v119) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v126"" select=""ScriptNS1:DBValueExtract(string($var:v125) , &quot;commodityid&quot;)"" />
          <xsl:variable name=""var:v127"" select=""ScriptNS1:DBLookup(14 , string($var:v126) , string($var:v119) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v128"" select=""ScriptNS1:DBValueExtract(string($var:v127) , &quot;Name&quot;)"" />
          <xsl:variable name=""var:v129"" select=""userCSharp:StringConcat(string($var:v121) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v130"" select=""ScriptNS1:DBLookup(15 , string($var:v129) , string($var:v119) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v131"" select=""ScriptNS1:DBValueExtract(string($var:v130) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v132"" select=""userCSharp:StringConcat(string($var:v131) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v133"" select=""ScriptNS1:DBLookup(16 , string($var:v132) , string($var:v119) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v134"" select=""ScriptNS1:DBValueExtract(string($var:v133) , &quot;CommodityId&quot;)"" />
          <xsl:variable name=""var:v135"" select=""userCSharp:StringConcat(string($var:v134) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v136"" select=""ScriptNS1:DBLookup(17 , string($var:v135) , string($var:v119) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
          <xsl:variable name=""var:v137"" select=""ScriptNS1:DBValueExtract(string($var:v136) , &quot;Name&quot;)"" />
          <xsl:variable name=""var:v139"" select=""userCSharp:MainCommodityName($var:v138 , string($var:v128) , string($var:v137))"" />
          <Name>
            <xsl:value-of select=""$var:v139"" />
          </Name>
          <xsl:variable name=""var:v140"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v141"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v140) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v142"" select=""ScriptNS1:DBValueExtract(string($var:v141) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v143"" select=""userCSharp:StringConcat(string($var:v142) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v144"" select=""ScriptNS1:DBLookup(12 , string($var:v143) , string($var:v140) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v145"" select=""ScriptNS1:DBValueExtract(string($var:v144) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v146"" select=""ScriptNS1:DBLookup(13 , string($var:v145) , string($var:v140) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v147"" select=""ScriptNS1:DBValueExtract(string($var:v146) , &quot;commodityid&quot;)"" />
          <xsl:variable name=""var:v148"" select=""ScriptNS1:DBLookup(14 , string($var:v147) , string($var:v140) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v149"" select=""ScriptNS1:DBValueExtract(string($var:v148) , &quot;Code&quot;)"" />
          <xsl:variable name=""var:v150"" select=""userCSharp:StringConcat(string($var:v142) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v151"" select=""ScriptNS1:DBLookup(15 , string($var:v150) , string($var:v140) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v152"" select=""ScriptNS1:DBValueExtract(string($var:v151) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v153"" select=""userCSharp:StringConcat(string($var:v152) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v154"" select=""ScriptNS1:DBLookup(16 , string($var:v153) , string($var:v140) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v155"" select=""ScriptNS1:DBValueExtract(string($var:v154) , &quot;CommodityId&quot;)"" />
          <xsl:variable name=""var:v156"" select=""userCSharp:StringConcat(string($var:v155) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v157"" select=""ScriptNS1:DBLookup(17 , string($var:v156) , string($var:v140) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
          <xsl:variable name=""var:v158"" select=""ScriptNS1:DBValueExtract(string($var:v157) , &quot;Code&quot;)"" />
          <xsl:variable name=""var:v159"" select=""userCSharp:MainCommodityCode($var:v138 , string($var:v149) , string($var:v158))"" />
          <Code>
            <xsl:value-of select=""$var:v159"" />
          </Code>
        </MainCommodity>
        <AgencyType>
          <xsl:variable name=""var:v160"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v161"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v160) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v162"" select=""ScriptNS1:DBValueExtract(string($var:v161) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v163"" select=""userCSharp:StringConcat(string($var:v162) , &quot;|&quot; , string(PortCall/SN_NominationType/text()) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v164"" select=""ScriptNS1:DBLookup(18 , string($var:v163) , string($var:v160) , &quot;Master.HubPrincipalAgencyTypeMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v165"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;AgencyTypeId&quot;)"" />
          <xsl:variable name=""var:v166"" select=""userCSharp:StringConcat(string($var:v165) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v167"" select=""ScriptNS1:DBLookup(19 , string($var:v166) , string($var:v160) , &quot;Master.AgencyTypes&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v168"" select=""ScriptNS1:DBValueExtract(string($var:v167) , &quot;id&quot;)"" />
          <Id>
            <xsl:value-of select=""$var:v168"" />
          </Id>
          <xsl:variable name=""var:v169"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v170"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v169) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v171"" select=""ScriptNS1:DBValueExtract(string($var:v170) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v173"" select=""userCSharp:StringConcat(string($var:v171) , &quot;|&quot; , $var:v172 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v174"" select=""ScriptNS1:DBLookup(18 , string($var:v173) , string($var:v169) , &quot;Master.HubPrincipalAgencyTypeMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v175"" select=""ScriptNS1:DBValueExtract(string($var:v174) , &quot;AgencyTypeId&quot;)"" />
          <xsl:variable name=""var:v176"" select=""userCSharp:StringConcat(string($var:v175) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v177"" select=""ScriptNS1:DBLookup(19 , string($var:v176) , string($var:v169) , &quot;Master.AgencyTypes&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v178"" select=""ScriptNS1:DBValueExtract(string($var:v177) , &quot;Code&quot;)"" />
          <Code>
            <xsl:value-of select=""$var:v178"" />
          </Code>
          <xsl:variable name=""var:v179"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v180"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v179) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v181"" select=""ScriptNS1:DBValueExtract(string($var:v180) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v182"" select=""userCSharp:StringConcat(string($var:v181) , &quot;|&quot; , $var:v172 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v183"" select=""ScriptNS1:DBLookup(18 , string($var:v182) , string($var:v179) , &quot;Master.HubPrincipalAgencyTypeMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v184"" select=""ScriptNS1:DBValueExtract(string($var:v183) , &quot;AgencyTypeId&quot;)"" />
          <xsl:variable name=""var:v185"" select=""userCSharp:StringConcat(string($var:v184) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v186"" select=""ScriptNS1:DBLookup(19 , string($var:v185) , string($var:v179) , &quot;Master.AgencyTypes&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v187"" select=""ScriptNS1:DBValueExtract(string($var:v186) , &quot;name&quot;)"" />
          <Name>
            <xsl:value-of select=""$var:v187"" />
          </Name>
        </AgencyType>
      </Appointments>
      <AccountingOffice>
        <xsl:variable name=""var:v189"" select=""ScriptNS0:GetBizConnectionString()"" />
        <xsl:variable name=""var:v190"" select=""ScriptNS1:DBLookup(0 , string($var:v188) , string($var:v189) , &quot;ISSAccountingOfficeIntegration&quot; , &quot;cast( AccountId as varchar(40)   ) + '|'+ cast (IsActive as varchar (1) )&quot;)"" />
        <xsl:variable name=""var:v191"" select=""ScriptNS1:DBValueExtract(string($var:v190) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v192"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v193"" select=""ScriptNS1:DBLookup(1 , string($var:v191) , string($var:v192) , &quot;master.ISSAccountingOffices&quot; , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v194"" select=""ScriptNS1:DBValueExtract(string($var:v193) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v195"" select=""ScriptNS1:DBLookup(2 , string($var:v15) , string($var:v192) , &quot;YourISS2.Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v196"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v197"" select=""ScriptNS1:DBLookup(3 , string($var:v196) , string($var:v192) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v198"" select=""ScriptNS1:DBValueExtract(string($var:v197) , &quot;ISSAccountingOfficeId&quot;)"" />
        <xsl:variable name=""var:v199"" select=""ScriptNS1:DBLookup(4 , string($var:v198) , string($var:v192) , &quot;Master.ISSAccountingOffices&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v200"" select=""ScriptNS1:DBValueExtract(string($var:v199) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v201"" select=""userCSharp:GetAccountOfficeID&#xD;($var:v6 , string($var:v194) , string($var:v200))"" />
        <xsl:variable name=""var:v202"" select=""userCSharp:StringConcat(string($var:v201) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v203"" select=""ScriptNS1:DBLookup(5 , string($var:v202) , string($var:v192) , &quot;Master.IssAccountingOffices&quot; , &quot;cast (  id  as  varchar(20) ) + '|'+ cast (  isActive as varchar(1)   )&quot;)"" />
        <xsl:variable name=""var:v204"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;Id&quot;)"" />
        <Id>
          <xsl:value-of select=""$var:v204"" />
        </Id>
        <xsl:variable name=""var:v205"" select=""ScriptNS0:GetBizConnectionString()"" />
        <xsl:variable name=""var:v206"" select=""ScriptNS1:DBLookup(0 , string($var:v188) , string($var:v205) , &quot;ISSAccountingOfficeIntegration&quot; , &quot;cast( AccountId as varchar(40)   ) + '|'+ cast (IsActive as varchar (1) )&quot;)"" />
        <xsl:variable name=""var:v207"" select=""ScriptNS1:DBValueExtract(string($var:v206) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v208"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v209"" select=""ScriptNS1:DBLookup(1 , string($var:v207) , string($var:v208) , &quot;master.ISSAccountingOffices&quot; , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v210"" select=""ScriptNS1:DBValueExtract(string($var:v209) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v211"" select=""ScriptNS1:DBLookup(2 , string($var:v15) , string($var:v208) , &quot;YourISS2.Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v212"" select=""ScriptNS1:DBValueExtract(string($var:v211) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v213"" select=""ScriptNS1:DBLookup(3 , string($var:v212) , string($var:v208) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v214"" select=""ScriptNS1:DBValueExtract(string($var:v213) , &quot;ISSAccountingOfficeId&quot;)"" />
        <xsl:variable name=""var:v215"" select=""ScriptNS1:DBLookup(4 , string($var:v214) , string($var:v208) , &quot;Master.ISSAccountingOffices&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v216"" select=""ScriptNS1:DBValueExtract(string($var:v215) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v217"" select=""userCSharp:GetAccountOfficeID&#xD;($var:v6 , string($var:v210) , string($var:v216))"" />
        <xsl:variable name=""var:v218"" select=""userCSharp:StringConcat(string($var:v217) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v219"" select=""ScriptNS1:DBLookup(5 , string($var:v218) , string($var:v208) , &quot;Master.IssAccountingOffices&quot; , &quot;cast (  id  as  varchar(20) ) + '|'+ cast (  isActive as varchar(1)   )&quot;)"" />
        <xsl:variable name=""var:v220"" select=""ScriptNS1:DBValueExtract(string($var:v219) , &quot;Name&quot;)"" />
        <Name>
          <xsl:value-of select=""$var:v220"" />
        </Name>
        <xsl:variable name=""var:v221"" select=""ScriptNS0:GetBizConnectionString()"" />
        <xsl:variable name=""var:v222"" select=""ScriptNS1:DBLookup(0 , string($var:v188) , string($var:v221) , &quot;ISSAccountingOfficeIntegration&quot; , &quot;cast( AccountId as varchar(40)   ) + '|'+ cast (IsActive as varchar (1) )&quot;)"" />
        <xsl:variable name=""var:v223"" select=""ScriptNS1:DBValueExtract(string($var:v222) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v224"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v225"" select=""ScriptNS1:DBLookup(1 , string($var:v223) , string($var:v224) , &quot;master.ISSAccountingOffices&quot; , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v226"" select=""ScriptNS1:DBValueExtract(string($var:v225) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v227"" select=""ScriptNS1:DBLookup(2 , string($var:v15) , string($var:v224) , &quot;YourISS2.Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v228"" select=""ScriptNS1:DBValueExtract(string($var:v227) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v229"" select=""ScriptNS1:DBLookup(3 , string($var:v228) , string($var:v224) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v230"" select=""ScriptNS1:DBValueExtract(string($var:v229) , &quot;ISSAccountingOfficeId&quot;)"" />
        <xsl:variable name=""var:v231"" select=""ScriptNS1:DBLookup(4 , string($var:v230) , string($var:v224) , &quot;Master.ISSAccountingOffices&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v232"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v233"" select=""userCSharp:GetAccountOfficeID&#xD;($var:v6 , string($var:v226) , string($var:v232))"" />
        <xsl:variable name=""var:v234"" select=""userCSharp:StringConcat(string($var:v233) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v235"" select=""ScriptNS1:DBLookup(5 , string($var:v234) , string($var:v224) , &quot;Master.IssAccountingOffices&quot; , &quot;cast (  id  as  varchar(20) ) + '|'+ cast (  isActive as varchar(1)   )&quot;)"" />
        <xsl:variable name=""var:v236"" select=""ScriptNS1:DBValueExtract(string($var:v235) , &quot;Code&quot;)"" />
        <Code>
          <xsl:value-of select=""$var:v236"" />
        </Code>
      </AccountingOffice>
      <PortOperation>
        <xsl:variable name=""var:v237"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v238"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v237) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v239"" select=""ScriptNS1:DBValueExtract(string($var:v238) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v240"" select=""userCSharp:StringConcat(string($var:v239) , &quot;|&quot; , string(PortCall/PortOperationCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v241"" select=""ScriptNS1:DBLookup(20 , string($var:v240) , string($var:v237) , &quot;Master.HubPrincipalPortOperationMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v242"" select=""ScriptNS1:DBValueExtract(string($var:v241) , &quot;PortOperationId&quot;)"" />
        <xsl:variable name=""var:v243"" select=""userCSharp:StringConcat(string($var:v242) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v244"" select=""ScriptNS1:DBLookup(21 , string($var:v243) , string($var:v237) , &quot;Master.PortOperations&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v245"" select=""ScriptNS1:DBValueExtract(string($var:v244) , &quot;id&quot;)"" />
        <Id>
          <xsl:value-of select=""$var:v245"" />
        </Id>
        <xsl:variable name=""var:v246"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v247"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v246) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v248"" select=""ScriptNS1:DBValueExtract(string($var:v247) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v250"" select=""userCSharp:StringConcat(string($var:v248) , &quot;|&quot; , $var:v249 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v251"" select=""ScriptNS1:DBLookup(20 , string($var:v250) , string($var:v246) , &quot;Master.HubPrincipalPortOperationMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v252"" select=""ScriptNS1:DBValueExtract(string($var:v251) , &quot;PortOperationId&quot;)"" />
        <xsl:variable name=""var:v253"" select=""userCSharp:StringConcat(string($var:v252) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v254"" select=""ScriptNS1:DBLookup(21 , string($var:v253) , string($var:v246) , &quot;Master.PortOperations&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v255"" select=""ScriptNS1:DBValueExtract(string($var:v254) , &quot;name&quot;)"" />
        <Name>
          <xsl:value-of select=""$var:v255"" />
        </Name>
        <xsl:variable name=""var:v256"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v257"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v256) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v258"" select=""ScriptNS1:DBValueExtract(string($var:v257) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v259"" select=""userCSharp:StringConcat(string($var:v258) , &quot;|&quot; , $var:v249 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v260"" select=""ScriptNS1:DBLookup(20 , string($var:v259) , string($var:v256) , &quot;Master.HubPrincipalPortOperationMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v261"" select=""ScriptNS1:DBValueExtract(string($var:v260) , &quot;PortOperationId&quot;)"" />
        <xsl:variable name=""var:v262"" select=""userCSharp:StringConcat(string($var:v261) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v263"" select=""ScriptNS1:DBLookup(21 , string($var:v262) , string($var:v256) , &quot;Master.PortOperations&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v264"" select=""ScriptNS1:DBValueExtract(string($var:v263) , &quot;code&quot;)"" />
        <Code>
          <xsl:value-of select=""$var:v264"" />
        </Code>
      </PortOperation>
      <Port>
        <xsl:variable name=""var:v265"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v266"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v265) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v267"" select=""ScriptNS1:DBValueExtract(string($var:v266) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v268"" select=""userCSharp:StringConcat(string($var:v267) , &quot;|&quot; , string(PortCall/Ports/Port/ISS_PortCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v269"" select=""ScriptNS1:DBLookup(22 , string($var:v268) , string($var:v265) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v270"" select=""ScriptNS1:DBValueExtract(string($var:v269) , &quot;PortId&quot;)"" />
        <xsl:variable name=""var:v271"" select=""userCSharp:StringConcat(string($var:v270) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v272"" select=""ScriptNS1:DBLookup(23 , string($var:v271) , string($var:v265) , &quot;Master.Ports&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v273"" select=""ScriptNS1:DBValueExtract(string($var:v272) , &quot;id&quot;)"" />
        <Id>
          <xsl:value-of select=""$var:v273"" />
        </Id>
        <xsl:variable name=""var:v274"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v275"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v274) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v276"" select=""ScriptNS1:DBValueExtract(string($var:v275) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v278"" select=""userCSharp:StringConcat(string($var:v276) , &quot;|&quot; , $var:v277 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v279"" select=""ScriptNS1:DBLookup(22 , string($var:v278) , string($var:v274) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v280"" select=""ScriptNS1:DBValueExtract(string($var:v279) , &quot;PortId&quot;)"" />
        <xsl:variable name=""var:v281"" select=""userCSharp:StringConcat(string($var:v280) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v282"" select=""ScriptNS1:DBLookup(23 , string($var:v281) , string($var:v274) , &quot;Master.Ports&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v283"" select=""ScriptNS1:DBValueExtract(string($var:v282) , &quot;name&quot;)"" />
        <Name>
          <xsl:value-of select=""$var:v283"" />
        </Name>
        <xsl:variable name=""var:v284"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v285"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v284) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v286"" select=""ScriptNS1:DBValueExtract(string($var:v285) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v287"" select=""userCSharp:StringConcat(string($var:v286) , &quot;|&quot; , $var:v277 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v288"" select=""ScriptNS1:DBLookup(22 , string($var:v287) , string($var:v284) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v289"" select=""ScriptNS1:DBValueExtract(string($var:v288) , &quot;PortId&quot;)"" />
        <xsl:variable name=""var:v290"" select=""userCSharp:StringConcat(string($var:v289) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v291"" select=""ScriptNS1:DBLookup(23 , string($var:v290) , string($var:v284) , &quot;Master.Ports&quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v292"" select=""ScriptNS1:DBValueExtract(string($var:v291) , &quot;code&quot;)"" />
        <Code>
          <xsl:value-of select=""$var:v292"" />
        </Code>
      </Port>
      <xsl:variable name=""var:v293"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v294"" select=""ScriptNS1:DBLookup(24 , string(PortCall/NextPort/Port/ISS_PortCode/text()) , string($var:v293) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
      <xsl:variable name=""var:v295"" select=""ScriptNS1:DBValueExtract(string($var:v294) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v296"" select=""userCSharp:LogicalNe(string($var:v295) , &quot;&quot;)"" />
      <xsl:if test=""$var:v296"">
        <xsl:variable name=""var:v298"" select=""string(PortCall/NextPort/Port/ISS_PortCode/text())"" />
        <NextPort>
          <xsl:variable name=""var:v297"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v299"" select=""ScriptNS1:DBLookup(24 , $var:v298 , string($var:v297) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
          <xsl:variable name=""var:v300"" select=""ScriptNS1:DBValueExtract(string($var:v299) , &quot;Id&quot;)"" />
          <Id>
            <xsl:value-of select=""$var:v300"" />
          </Id>
          <xsl:variable name=""var:v301"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v302"" select=""ScriptNS1:DBLookup(24 , $var:v298 , string($var:v301) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
          <xsl:variable name=""var:v303"" select=""ScriptNS1:DBValueExtract(string($var:v302) , &quot;Name&quot;)"" />
          <Name>
            <xsl:value-of select=""$var:v303"" />
          </Name>
          <xsl:variable name=""var:v304"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v305"" select=""ScriptNS1:DBLookup(24 , $var:v298 , string($var:v304) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
          <xsl:variable name=""var:v306"" select=""ScriptNS1:DBValueExtract(string($var:v305) , &quot;Code&quot;)"" />
          <Code>
            <xsl:value-of select=""$var:v306"" />
          </Code>
        </NextPort>
      </xsl:if>
      <xsl:for-each select=""PortCall/PreviousPort"">
        <xsl:variable name=""var:v307"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v308"" select=""ScriptNS1:DBLookup(25 , string(Port/ISS_PortCode/text()) , string($var:v307) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v309"" select=""ScriptNS1:DBValueExtract(string($var:v308) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v310"" select=""userCSharp:LogicalNe(string($var:v309) , &quot;&quot;)"" />
        <xsl:if test=""$var:v310"">
          <xsl:variable name=""var:v312"" select=""string(Port/ISS_PortCode/text())"" />
          <PreviousPort>
            <xsl:variable name=""var:v311"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v313"" select=""ScriptNS1:DBLookup(25 , $var:v312 , string($var:v311) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
            <xsl:variable name=""var:v314"" select=""ScriptNS1:DBValueExtract(string($var:v313) , &quot;Id&quot;)"" />
            <Id>
              <xsl:value-of select=""$var:v314"" />
            </Id>
            <xsl:variable name=""var:v315"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v316"" select=""ScriptNS1:DBLookup(25 , $var:v312 , string($var:v315) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
            <xsl:variable name=""var:v317"" select=""ScriptNS1:DBValueExtract(string($var:v316) , &quot;Name&quot;)"" />
            <Name>
              <xsl:value-of select=""$var:v317"" />
            </Name>
            <xsl:variable name=""var:v318"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v319"" select=""ScriptNS1:DBLookup(25 , $var:v312 , string($var:v318) , &quot;Master.Ports&quot; , &quot;Code&quot;)"" />
            <xsl:variable name=""var:v320"" select=""ScriptNS1:DBValueExtract(string($var:v319) , &quot;Code&quot;)"" />
            <Code>
              <xsl:value-of select=""$var:v320"" />
            </Code>
          </PreviousPort>
        </xsl:if>
      </xsl:for-each>
      <MainCommodity>
        <xsl:variable name=""var:v321"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v322"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v321) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v323"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v324"" select=""userCSharp:StringConcat(string($var:v323) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v325"" select=""ScriptNS1:DBLookup(12 , string($var:v324) , string($var:v321) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v326"" select=""ScriptNS1:DBValueExtract(string($var:v325) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v327"" select=""ScriptNS1:DBLookup(13 , string($var:v326) , string($var:v321) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v328"" select=""ScriptNS1:DBValueExtract(string($var:v327) , &quot;commodityid&quot;)"" />
        <xsl:variable name=""var:v329"" select=""ScriptNS1:DBLookup(14 , string($var:v328) , string($var:v321) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v330"" select=""ScriptNS1:DBValueExtract(string($var:v329) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v331"" select=""userCSharp:StringConcat(string($var:v323) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v332"" select=""ScriptNS1:DBLookup(15 , string($var:v331) , string($var:v321) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v333"" select=""ScriptNS1:DBValueExtract(string($var:v332) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v334"" select=""userCSharp:StringConcat(string($var:v333) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v335"" select=""ScriptNS1:DBLookup(16 , string($var:v334) , string($var:v321) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v336"" select=""ScriptNS1:DBValueExtract(string($var:v335) , &quot;CommodityId&quot;)"" />
        <xsl:variable name=""var:v337"" select=""userCSharp:StringConcat(string($var:v336) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v338"" select=""ScriptNS1:DBLookup(17 , string($var:v337) , string($var:v321) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
        <xsl:variable name=""var:v339"" select=""ScriptNS1:DBValueExtract(string($var:v338) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v340"" select=""userCSharp:MainCommodityId($var:v138 , string($var:v330) , string($var:v339))"" />
        <Id>
          <xsl:value-of select=""$var:v340"" />
        </Id>
        <xsl:variable name=""var:v341"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v342"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v341) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v343"" select=""ScriptNS1:DBValueExtract(string($var:v342) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v344"" select=""userCSharp:StringConcat(string($var:v343) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v345"" select=""ScriptNS1:DBLookup(12 , string($var:v344) , string($var:v341) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v346"" select=""ScriptNS1:DBValueExtract(string($var:v345) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v347"" select=""ScriptNS1:DBLookup(13 , string($var:v346) , string($var:v341) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v348"" select=""ScriptNS1:DBValueExtract(string($var:v347) , &quot;commodityid&quot;)"" />
        <xsl:variable name=""var:v349"" select=""ScriptNS1:DBLookup(14 , string($var:v348) , string($var:v341) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v350"" select=""ScriptNS1:DBValueExtract(string($var:v349) , &quot;Name&quot;)"" />
        <xsl:variable name=""var:v351"" select=""userCSharp:StringConcat(string($var:v343) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v352"" select=""ScriptNS1:DBLookup(15 , string($var:v351) , string($var:v341) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v353"" select=""ScriptNS1:DBValueExtract(string($var:v352) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v354"" select=""userCSharp:StringConcat(string($var:v353) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v355"" select=""ScriptNS1:DBLookup(16 , string($var:v354) , string($var:v341) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v356"" select=""ScriptNS1:DBValueExtract(string($var:v355) , &quot;CommodityId&quot;)"" />
        <xsl:variable name=""var:v357"" select=""userCSharp:StringConcat(string($var:v356) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v358"" select=""ScriptNS1:DBLookup(17 , string($var:v357) , string($var:v341) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
        <xsl:variable name=""var:v359"" select=""ScriptNS1:DBValueExtract(string($var:v358) , &quot;Name&quot;)"" />
        <xsl:variable name=""var:v360"" select=""userCSharp:MainCommodityName($var:v138 , string($var:v350) , string($var:v359))"" />
        <Name>
          <xsl:value-of select=""$var:v360"" />
        </Name>
        <xsl:variable name=""var:v361"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v362"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v361) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v363"" select=""ScriptNS1:DBValueExtract(string($var:v362) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v364"" select=""userCSharp:StringConcat(string($var:v363) , &quot;|&quot; , &quot;TBC&quot; , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v365"" select=""ScriptNS1:DBLookup(12 , string($var:v364) , string($var:v361) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v366"" select=""ScriptNS1:DBValueExtract(string($var:v365) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v367"" select=""ScriptNS1:DBLookup(13 , string($var:v366) , string($var:v361) , &quot;master.CommodityDetails&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v368"" select=""ScriptNS1:DBValueExtract(string($var:v367) , &quot;commodityid&quot;)"" />
        <xsl:variable name=""var:v369"" select=""ScriptNS1:DBLookup(14 , string($var:v368) , string($var:v361) , &quot;Master.Commodities&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
        <xsl:variable name=""var:v370"" select=""ScriptNS1:DBValueExtract(string($var:v369) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v371"" select=""userCSharp:StringConcat(string($var:v363) , &quot;|&quot; , string($var:v108) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v372"" select=""ScriptNS1:DBLookup(15 , string($var:v371) , string($var:v361) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v373"" select=""ScriptNS1:DBValueExtract(string($var:v372) , &quot;CommodityDetailId&quot;)"" />
        <xsl:variable name=""var:v374"" select=""userCSharp:StringConcat(string($var:v373) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v375"" select=""ScriptNS1:DBLookup(16 , string($var:v374) , string($var:v361) , &quot;Master.CommodityDetails&quot; , &quot;cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v376"" select=""ScriptNS1:DBValueExtract(string($var:v375) , &quot;CommodityId&quot;)"" />
        <xsl:variable name=""var:v377"" select=""userCSharp:StringConcat(string($var:v376) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v378"" select=""ScriptNS1:DBLookup(17 , string($var:v377) , string($var:v361) , &quot;Master.Commodities&quot; , &quot;cast (  id as varchar (10) ) + '|' + cast(IsActive as varchar(1) )&quot;)"" />
        <xsl:variable name=""var:v379"" select=""ScriptNS1:DBValueExtract(string($var:v378) , &quot;Code&quot;)"" />
        <xsl:variable name=""var:v380"" select=""userCSharp:MainCommodityCode($var:v138 , string($var:v370) , string($var:v379))"" />
        <Code>
          <xsl:value-of select=""$var:v380"" />
        </Code>
      </MainCommodity>
      <Vessel>
        <xsl:variable name=""var:v381"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v382"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v381) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v383"" select=""ScriptNS1:DBValueExtract(string($var:v382) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v384"" select=""userCSharp:StringConcat(string($var:v383) , &quot;|&quot; , string(PortCall/IMO/text()) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v385"" select=""ScriptNS1:DBLookup(26 , string($var:v384) , string($var:v381) , &quot;Master.HubPrincipalVesselMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v386"" select=""ScriptNS1:DBValueExtract(string($var:v385) , &quot;VesselId&quot;)"" />
        <xsl:variable name=""var:v387"" select=""userCSharp:StringConcat(string($var:v386) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v388"" select=""ScriptNS1:DBLookup(27 , string($var:v387) , string($var:v381) , &quot;Master.Vessels &quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v389"" select=""ScriptNS1:DBValueExtract(string($var:v388) , &quot;id&quot;)"" />
        <Id>
          <xsl:value-of select=""$var:v389"" />
        </Id>
        <xsl:variable name=""var:v390"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v391"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v390) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v392"" select=""ScriptNS1:DBValueExtract(string($var:v391) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v394"" select=""userCSharp:StringConcat(string($var:v392) , &quot;|&quot; , $var:v393 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v395"" select=""ScriptNS1:DBLookup(26 , string($var:v394) , string($var:v390) , &quot;Master.HubPrincipalVesselMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v396"" select=""ScriptNS1:DBValueExtract(string($var:v395) , &quot;VesselId&quot;)"" />
        <xsl:variable name=""var:v397"" select=""userCSharp:StringConcat(string($var:v396) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v398"" select=""ScriptNS1:DBLookup(27 , string($var:v397) , string($var:v390) , &quot;Master.Vessels &quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v399"" select=""ScriptNS1:DBValueExtract(string($var:v398) , &quot;name&quot;)"" />
        <Name>
          <xsl:value-of select=""$var:v399"" />
        </Name>
        <xsl:variable name=""var:v400"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v401"" select=""ScriptNS1:DBLookup(7 , string($var:v41) , string($var:v400) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v402"" select=""ScriptNS1:DBValueExtract(string($var:v401) , &quot;id&quot;)"" />
        <xsl:variable name=""var:v403"" select=""userCSharp:StringConcat(string($var:v402) , &quot;|&quot; , $var:v393 , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v404"" select=""ScriptNS1:DBLookup(26 , string($var:v403) , string($var:v400) , &quot;Master.HubPrincipalVesselMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v405"" select=""ScriptNS1:DBValueExtract(string($var:v404) , &quot;VesselId&quot;)"" />
        <xsl:variable name=""var:v406"" select=""userCSharp:StringConcat(string($var:v405) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v407"" select=""ScriptNS1:DBLookup(27 , string($var:v406) , string($var:v400) , &quot;Master.Vessels &quot; , &quot;   cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v408"" select=""ScriptNS1:DBValueExtract(string($var:v407) , &quot;Imo&quot;)"" />
        <Imo>
          <xsl:value-of select=""$var:v408"" />
        </Imo>
      </Vessel>
      <Eta>
        <xsl:value-of select=""PortCall/ETA/text()"" />
      </Eta>
      <VoyageNumber>
        <xsl:value-of select=""PortCall/SN_VoyageNumber/text()"" />
      </VoyageNumber>
      <xsl:variable name=""var:v409"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v410"" select=""ScriptNS1:DBLookup(0 , string($var:v188) , string($var:v409) , &quot;ISSAccountingOfficeIntegration&quot; , &quot;cast( AccountId as varchar(40)   ) + '|'+ cast (IsActive as varchar (1) )&quot;)"" />
      <xsl:variable name=""var:v411"" select=""ScriptNS1:DBValueExtract(string($var:v410) , &quot;Code&quot;)"" />
      <xsl:variable name=""var:v412"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v413"" select=""ScriptNS1:DBLookup(1 , string($var:v411) , string($var:v412) , &quot;master.ISSAccountingOffices&quot; , &quot;Code&quot;)"" />
      <xsl:variable name=""var:v414"" select=""ScriptNS1:DBValueExtract(string($var:v413) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v415"" select=""ScriptNS1:DBLookup(2 , string($var:v15) , string($var:v412) , &quot;YourISS2.Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;ReferenceCode&quot;)"" />
      <xsl:variable name=""var:v416"" select=""ScriptNS1:DBValueExtract(string($var:v415) , &quot;PortCallId&quot;)"" />
      <xsl:variable name=""var:v417"" select=""ScriptNS1:DBLookup(3 , string($var:v416) , string($var:v412) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v418"" select=""ScriptNS1:DBValueExtract(string($var:v417) , &quot;ISSAccountingOfficeId&quot;)"" />
      <xsl:variable name=""var:v419"" select=""ScriptNS1:DBLookup(4 , string($var:v418) , string($var:v412) , &quot;Master.ISSAccountingOffices&quot; , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v420"" select=""ScriptNS1:DBValueExtract(string($var:v419) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v421"" select=""userCSharp:GetAccountOfficeID&#xD;($var:v6 , string($var:v414) , string($var:v420))"" />
      <xsl:variable name=""var:v422"" select=""userCSharp:StringConcat(string($var:v421) , &quot;|&quot; , &quot;1&quot;)"" />
      <xsl:variable name=""var:v423"" select=""ScriptNS1:DBLookup(5 , string($var:v422) , string($var:v412) , &quot;Master.IssAccountingOffices&quot; , &quot;cast (  id  as  varchar(20) ) + '|'+ cast (  isActive as varchar(1)   )&quot;)"" />
      <xsl:variable name=""var:v424"" select=""ScriptNS1:DBValueExtract(string($var:v423) , &quot;CurrencyId&quot;)"" />
      <xsl:variable name=""var:v425"" select=""userCSharp:StringConcat(string($var:v424) , &quot;|&quot; , &quot;1&quot;)"" />
      <xsl:variable name=""var:v426"" select=""ScriptNS1:DBLookup(6 , string($var:v425) , string($var:v412) , &quot;Master.Currencies&quot; , &quot;cast(   Id as varchar (20)) + '|' + cast ( IsActive as varchar(1)  )&quot;)"" />
      <xsl:variable name=""var:v427"" select=""ScriptNS1:DBValueExtract(string($var:v426) , &quot;Code&quot;)"" />
      <CurrencyCode>
        <xsl:value-of select=""$var:v427"" />
      </CurrencyCode>
      <PortCallOperations>
        <Ets>
          <xsl:value-of select=""PortCall/ETS/text()"" />
        </Ets>
      </PortCallOperations>
      <xsl:for-each select=""PortCall/Cargoes/Cargo"">
        <xsl:variable name=""var:v428"" select=""userCSharp:StringTrimLeft(string(../../../HubPrincipalKey/text()))"" />
        <xsl:variable name=""var:v429"" select=""userCSharp:StringTrimRight(string($var:v428))"" />
        <xsl:variable name=""var:v430"" select=""userCSharp:StringConcat(string($var:v429) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v452"" select=""string(CargoOperationCode/text())"" />
        <xsl:variable name=""var:v456"" select=""string(../../../HubPrincipalKey/text())"" />
        <xsl:variable name=""var:v457"" select=""userCSharp:StringTrimLeft($var:v456)"" />
        <xsl:variable name=""var:v458"" select=""userCSharp:StringTrimRight(string($var:v457))"" />
        <xsl:variable name=""var:v459"" select=""userCSharp:StringConcat(string($var:v458) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v463"" select=""string(ISS_CommodityCode/text())"" />
        <xsl:variable name=""var:v473"" select=""string(QuantityTypeCode/text())"" />
        <Cargoes>
          <xsl:variable name=""var:v431"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v432"" select=""ScriptNS1:DBLookup(7 , string($var:v430) , string($var:v431) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v433"" select=""ScriptNS1:DBValueExtract(string($var:v432) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v434"" select=""userCSharp:StringConcat(string($var:v433) , &quot;|&quot; , string(ISS_CommodityCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v435"" select=""ScriptNS1:DBLookup(28 , string($var:v434) , string($var:v431) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v436"" select=""ScriptNS1:DBValueExtract(string($var:v435) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v437"" select=""userCSharp:StringConcat(string($var:v436) , &quot;|1&quot;)"" />
          <xsl:variable name=""var:v438"" select=""ScriptNS1:DBLookup(29 , string($var:v437) , string($var:v431) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v439"" select=""ScriptNS1:DBValueExtract(string($var:v438) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v440"" select=""ScriptNS1:DBValueExtract(string($var:v438) , &quot;name&quot;)"" />
          <xsl:variable name=""var:v441"" select=""ScriptNS1:DBValueExtract(string($var:v438) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v442"" select=""ScriptNS1:DBValueExtract(string($var:v432) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v443"" select=""userCSharp:StringConcat(string($var:v442) , &quot;|&quot; , string(QuantityTypeCode/text()) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v444"" select=""ScriptNS1:DBLookup(30 , string($var:v443) , string($var:v431) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v445"" select=""ScriptNS1:DBValueExtract(string($var:v444) , &quot;UnitofMeasureId&quot;)"" />
          <xsl:variable name=""var:v446"" select=""userCSharp:StringConcat(string($var:v445) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v447"" select=""ScriptNS1:DBLookup(31 , string($var:v446) , string($var:v431) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v448"" select=""ScriptNS1:DBValueExtract(string($var:v447) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v449"" select=""ScriptNS1:DBValueExtract(string($var:v447) , &quot;Name&quot;)"" />
          <xsl:variable name=""var:v450"" select=""ScriptNS1:DBValueExtract(string($var:v447) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v451"" select=""userCSharp:CargoOperationId(string(CargoOperationCode/text()))"" />
          <xsl:variable name=""var:v453"" select=""userCSharp:CargoOperationName($var:v452)"" />
          <xsl:variable name=""var:v454"" select=""userCSharp:CargoOperationCode($var:v452)"" />
          <xsl:variable name=""var:v455"" select=""SN_KeyCargo"" />
          <RefCode>
            <xsl:value-of select=""$var:v455"" />
          </RefCode>
          <xsl:variable name=""var:v460"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v461"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v460) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v462"" select=""ScriptNS1:DBValueExtract(string($var:v461) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v464"" select=""userCSharp:StringConcat(string($var:v462) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v465"" select=""ScriptNS1:DBLookup(28 , string($var:v464) , string($var:v460) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v466"" select=""ScriptNS1:DBValueExtract(string($var:v465) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v467"" select=""userCSharp:StringConcat(string($var:v466) , &quot;|1&quot;)"" />
          <xsl:variable name=""var:v468"" select=""ScriptNS1:DBLookup(29 , string($var:v467) , string($var:v460) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v469"" select=""ScriptNS1:DBValueExtract(string($var:v468) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v470"" select=""ScriptNS1:DBValueExtract(string($var:v468) , &quot;name&quot;)"" />
          <xsl:variable name=""var:v471"" select=""ScriptNS1:DBValueExtract(string($var:v468) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v472"" select=""ScriptNS1:DBValueExtract(string($var:v461) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v474"" select=""userCSharp:StringConcat(string($var:v472) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v475"" select=""ScriptNS1:DBLookup(30 , string($var:v474) , string($var:v460) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v476"" select=""ScriptNS1:DBValueExtract(string($var:v475) , &quot;UnitofMeasureId&quot;)"" />
          <xsl:variable name=""var:v477"" select=""userCSharp:StringConcat(string($var:v476) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v478"" select=""ScriptNS1:DBLookup(31 , string($var:v477) , string($var:v460) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v479"" select=""ScriptNS1:DBValueExtract(string($var:v478) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v480"" select=""ScriptNS1:DBValueExtract(string($var:v478) , &quot;Name&quot;)"" />
          <xsl:variable name=""var:v481"" select=""ScriptNS1:DBValueExtract(string($var:v478) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v482"" select=""userCSharp:CargoOperationId($var:v452)"" />
          <xsl:variable name=""var:v483"" select=""userCSharp:CargoOperationName($var:v452)"" />
          <xsl:variable name=""var:v484"" select=""userCSharp:CargoOperationCode($var:v452)"" />
          <xsl:variable name=""var:v485"" select=""Quantity"" />
          <NominationQuantity>
            <xsl:value-of select=""$var:v485"" />
          </NominationQuantity>
          <CommodityDetail>
            <xsl:variable name=""var:v486"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v487"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v486) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v488"" select=""ScriptNS1:DBValueExtract(string($var:v487) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v489"" select=""userCSharp:StringConcat(string($var:v488) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v490"" select=""ScriptNS1:DBLookup(28 , string($var:v489) , string($var:v486) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v491"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v492"" select=""userCSharp:StringConcat(string($var:v491) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v493"" select=""ScriptNS1:DBLookup(29 , string($var:v492) , string($var:v486) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v494"" select=""ScriptNS1:DBValueExtract(string($var:v493) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v495"" select=""ScriptNS1:DBValueExtract(string($var:v493) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v496"" select=""ScriptNS1:DBValueExtract(string($var:v493) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v497"" select=""ScriptNS1:DBValueExtract(string($var:v487) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v498"" select=""userCSharp:StringConcat(string($var:v497) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v499"" select=""ScriptNS1:DBLookup(30 , string($var:v498) , string($var:v486) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v500"" select=""ScriptNS1:DBValueExtract(string($var:v499) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v501"" select=""userCSharp:StringConcat(string($var:v500) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v502"" select=""ScriptNS1:DBLookup(31 , string($var:v501) , string($var:v486) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v503"" select=""ScriptNS1:DBValueExtract(string($var:v502) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v504"" select=""ScriptNS1:DBValueExtract(string($var:v502) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v505"" select=""ScriptNS1:DBValueExtract(string($var:v502) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v506"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v507"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v508"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v509"" select=""$var:v494"" />
            <Id>
              <xsl:value-of select=""$var:v509"" />
            </Id>
            <xsl:variable name=""var:v510"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v511"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v510) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v512"" select=""ScriptNS1:DBValueExtract(string($var:v511) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v513"" select=""userCSharp:StringConcat(string($var:v512) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v514"" select=""ScriptNS1:DBLookup(28 , string($var:v513) , string($var:v510) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v515"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v516"" select=""userCSharp:StringConcat(string($var:v515) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v517"" select=""ScriptNS1:DBLookup(29 , string($var:v516) , string($var:v510) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v518"" select=""ScriptNS1:DBValueExtract(string($var:v517) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v519"" select=""ScriptNS1:DBValueExtract(string($var:v517) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v520"" select=""ScriptNS1:DBValueExtract(string($var:v517) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v521"" select=""ScriptNS1:DBValueExtract(string($var:v511) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v522"" select=""userCSharp:StringConcat(string($var:v521) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v523"" select=""ScriptNS1:DBLookup(30 , string($var:v522) , string($var:v510) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v524"" select=""ScriptNS1:DBValueExtract(string($var:v523) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v525"" select=""userCSharp:StringConcat(string($var:v524) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v526"" select=""ScriptNS1:DBLookup(31 , string($var:v525) , string($var:v510) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v527"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v528"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v529"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v530"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v531"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v532"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v533"" select=""$var:v519"" />
            <Name>
              <xsl:value-of select=""$var:v533"" />
            </Name>
            <xsl:variable name=""var:v534"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v535"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v534) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v536"" select=""ScriptNS1:DBValueExtract(string($var:v535) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v537"" select=""userCSharp:StringConcat(string($var:v536) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v538"" select=""ScriptNS1:DBLookup(28 , string($var:v537) , string($var:v534) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v539"" select=""ScriptNS1:DBValueExtract(string($var:v538) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v540"" select=""userCSharp:StringConcat(string($var:v539) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v541"" select=""ScriptNS1:DBLookup(29 , string($var:v540) , string($var:v534) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v542"" select=""ScriptNS1:DBValueExtract(string($var:v541) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v543"" select=""ScriptNS1:DBValueExtract(string($var:v541) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v544"" select=""ScriptNS1:DBValueExtract(string($var:v541) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v545"" select=""ScriptNS1:DBValueExtract(string($var:v535) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v546"" select=""userCSharp:StringConcat(string($var:v545) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v547"" select=""ScriptNS1:DBLookup(30 , string($var:v546) , string($var:v534) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v548"" select=""ScriptNS1:DBValueExtract(string($var:v547) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v549"" select=""userCSharp:StringConcat(string($var:v548) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v550"" select=""ScriptNS1:DBLookup(31 , string($var:v549) , string($var:v534) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v551"" select=""ScriptNS1:DBValueExtract(string($var:v550) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v552"" select=""ScriptNS1:DBValueExtract(string($var:v550) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v553"" select=""ScriptNS1:DBValueExtract(string($var:v550) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v554"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v555"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v556"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v557"" select=""$var:v544"" />
            <Code>
              <xsl:value-of select=""$var:v557"" />
            </Code>
          </CommodityDetail>
          <UnitOfMeasure>
            <xsl:variable name=""var:v558"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v559"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v558) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v560"" select=""ScriptNS1:DBValueExtract(string($var:v559) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v561"" select=""userCSharp:StringConcat(string($var:v560) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v562"" select=""ScriptNS1:DBLookup(28 , string($var:v561) , string($var:v558) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v563"" select=""ScriptNS1:DBValueExtract(string($var:v562) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v564"" select=""userCSharp:StringConcat(string($var:v563) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v565"" select=""ScriptNS1:DBLookup(29 , string($var:v564) , string($var:v558) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v566"" select=""ScriptNS1:DBValueExtract(string($var:v565) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v567"" select=""ScriptNS1:DBValueExtract(string($var:v565) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v568"" select=""ScriptNS1:DBValueExtract(string($var:v565) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v569"" select=""ScriptNS1:DBValueExtract(string($var:v559) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v570"" select=""userCSharp:StringConcat(string($var:v569) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v571"" select=""ScriptNS1:DBLookup(30 , string($var:v570) , string($var:v558) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v572"" select=""ScriptNS1:DBValueExtract(string($var:v571) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v573"" select=""userCSharp:StringConcat(string($var:v572) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v574"" select=""ScriptNS1:DBLookup(31 , string($var:v573) , string($var:v558) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v575"" select=""ScriptNS1:DBValueExtract(string($var:v574) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v576"" select=""ScriptNS1:DBValueExtract(string($var:v574) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v577"" select=""ScriptNS1:DBValueExtract(string($var:v574) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v578"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v579"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v580"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v581"" select=""$var:v575"" />
            <Id>
              <xsl:value-of select=""$var:v581"" />
            </Id>
            <xsl:variable name=""var:v582"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v583"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v582) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v584"" select=""ScriptNS1:DBValueExtract(string($var:v583) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v585"" select=""userCSharp:StringConcat(string($var:v584) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v586"" select=""ScriptNS1:DBLookup(28 , string($var:v585) , string($var:v582) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v587"" select=""ScriptNS1:DBValueExtract(string($var:v586) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v588"" select=""userCSharp:StringConcat(string($var:v587) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v589"" select=""ScriptNS1:DBLookup(29 , string($var:v588) , string($var:v582) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v590"" select=""ScriptNS1:DBValueExtract(string($var:v589) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v591"" select=""ScriptNS1:DBValueExtract(string($var:v589) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v592"" select=""ScriptNS1:DBValueExtract(string($var:v589) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v593"" select=""ScriptNS1:DBValueExtract(string($var:v583) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v594"" select=""userCSharp:StringConcat(string($var:v593) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v595"" select=""ScriptNS1:DBLookup(30 , string($var:v594) , string($var:v582) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v596"" select=""ScriptNS1:DBValueExtract(string($var:v595) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v597"" select=""userCSharp:StringConcat(string($var:v596) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v598"" select=""ScriptNS1:DBLookup(31 , string($var:v597) , string($var:v582) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v599"" select=""ScriptNS1:DBValueExtract(string($var:v598) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v600"" select=""ScriptNS1:DBValueExtract(string($var:v598) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v601"" select=""ScriptNS1:DBValueExtract(string($var:v598) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v602"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v603"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v604"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v605"" select=""$var:v600"" />
            <Name>
              <xsl:value-of select=""$var:v605"" />
            </Name>
            <xsl:variable name=""var:v606"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v607"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v606) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v608"" select=""ScriptNS1:DBValueExtract(string($var:v607) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v609"" select=""userCSharp:StringConcat(string($var:v608) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v610"" select=""ScriptNS1:DBLookup(28 , string($var:v609) , string($var:v606) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v611"" select=""ScriptNS1:DBValueExtract(string($var:v610) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v612"" select=""userCSharp:StringConcat(string($var:v611) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v613"" select=""ScriptNS1:DBLookup(29 , string($var:v612) , string($var:v606) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v614"" select=""ScriptNS1:DBValueExtract(string($var:v613) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v615"" select=""ScriptNS1:DBValueExtract(string($var:v613) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v616"" select=""ScriptNS1:DBValueExtract(string($var:v613) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v617"" select=""ScriptNS1:DBValueExtract(string($var:v607) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v618"" select=""userCSharp:StringConcat(string($var:v617) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v619"" select=""ScriptNS1:DBLookup(30 , string($var:v618) , string($var:v606) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v620"" select=""ScriptNS1:DBValueExtract(string($var:v619) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v621"" select=""userCSharp:StringConcat(string($var:v620) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v622"" select=""ScriptNS1:DBLookup(31 , string($var:v621) , string($var:v606) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v623"" select=""ScriptNS1:DBValueExtract(string($var:v622) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v624"" select=""ScriptNS1:DBValueExtract(string($var:v622) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v625"" select=""ScriptNS1:DBValueExtract(string($var:v622) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v626"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v627"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v628"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v629"" select=""$var:v625"" />
            <Code>
              <xsl:value-of select=""$var:v629"" />
            </Code>
          </UnitOfMeasure>
          <CargoActivity>
            <xsl:variable name=""var:v630"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v631"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v630) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v632"" select=""ScriptNS1:DBValueExtract(string($var:v631) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v633"" select=""userCSharp:StringConcat(string($var:v632) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v634"" select=""ScriptNS1:DBLookup(28 , string($var:v633) , string($var:v630) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v635"" select=""ScriptNS1:DBValueExtract(string($var:v634) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v636"" select=""userCSharp:StringConcat(string($var:v635) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v637"" select=""ScriptNS1:DBLookup(29 , string($var:v636) , string($var:v630) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v638"" select=""ScriptNS1:DBValueExtract(string($var:v637) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v639"" select=""ScriptNS1:DBValueExtract(string($var:v637) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v640"" select=""ScriptNS1:DBValueExtract(string($var:v637) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v641"" select=""ScriptNS1:DBValueExtract(string($var:v631) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v642"" select=""userCSharp:StringConcat(string($var:v641) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v643"" select=""ScriptNS1:DBLookup(30 , string($var:v642) , string($var:v630) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v644"" select=""ScriptNS1:DBValueExtract(string($var:v643) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v645"" select=""userCSharp:StringConcat(string($var:v644) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v646"" select=""ScriptNS1:DBLookup(31 , string($var:v645) , string($var:v630) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v647"" select=""ScriptNS1:DBValueExtract(string($var:v646) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v648"" select=""ScriptNS1:DBValueExtract(string($var:v646) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v649"" select=""ScriptNS1:DBValueExtract(string($var:v646) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v650"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v651"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v652"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v653"" select=""$var:v650"" />
            <Id>
              <xsl:value-of select=""$var:v653"" />
            </Id>
            <xsl:variable name=""var:v654"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v655"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v654) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v656"" select=""ScriptNS1:DBValueExtract(string($var:v655) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v657"" select=""userCSharp:StringConcat(string($var:v656) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v658"" select=""ScriptNS1:DBLookup(28 , string($var:v657) , string($var:v654) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v659"" select=""ScriptNS1:DBValueExtract(string($var:v658) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v660"" select=""userCSharp:StringConcat(string($var:v659) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v661"" select=""ScriptNS1:DBLookup(29 , string($var:v660) , string($var:v654) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v662"" select=""ScriptNS1:DBValueExtract(string($var:v661) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v663"" select=""ScriptNS1:DBValueExtract(string($var:v661) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v664"" select=""ScriptNS1:DBValueExtract(string($var:v661) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v665"" select=""ScriptNS1:DBValueExtract(string($var:v655) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v666"" select=""userCSharp:StringConcat(string($var:v665) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v667"" select=""ScriptNS1:DBLookup(30 , string($var:v666) , string($var:v654) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v668"" select=""ScriptNS1:DBValueExtract(string($var:v667) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v669"" select=""userCSharp:StringConcat(string($var:v668) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v670"" select=""ScriptNS1:DBLookup(31 , string($var:v669) , string($var:v654) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v671"" select=""ScriptNS1:DBValueExtract(string($var:v670) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v672"" select=""ScriptNS1:DBValueExtract(string($var:v670) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v673"" select=""ScriptNS1:DBValueExtract(string($var:v670) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v674"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v675"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v676"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v677"" select=""$var:v675"" />
            <Name>
              <xsl:value-of select=""$var:v677"" />
            </Name>
            <xsl:variable name=""var:v678"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v679"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v678) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v680"" select=""ScriptNS1:DBValueExtract(string($var:v679) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v681"" select=""userCSharp:StringConcat(string($var:v680) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v682"" select=""ScriptNS1:DBLookup(28 , string($var:v681) , string($var:v678) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v683"" select=""ScriptNS1:DBValueExtract(string($var:v682) , &quot;CommodityDetailId&quot;)"" />
            <xsl:variable name=""var:v684"" select=""userCSharp:StringConcat(string($var:v683) , &quot;|1&quot;)"" />
            <xsl:variable name=""var:v685"" select=""ScriptNS1:DBLookup(29 , string($var:v684) , string($var:v678) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v686"" select=""ScriptNS1:DBValueExtract(string($var:v685) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v687"" select=""ScriptNS1:DBValueExtract(string($var:v685) , &quot;name&quot;)"" />
            <xsl:variable name=""var:v688"" select=""ScriptNS1:DBValueExtract(string($var:v685) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v689"" select=""ScriptNS1:DBValueExtract(string($var:v679) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v690"" select=""userCSharp:StringConcat(string($var:v689) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v691"" select=""ScriptNS1:DBLookup(30 , string($var:v690) , string($var:v678) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v692"" select=""ScriptNS1:DBValueExtract(string($var:v691) , &quot;UnitofMeasureId&quot;)"" />
            <xsl:variable name=""var:v693"" select=""userCSharp:StringConcat(string($var:v692) , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v694"" select=""ScriptNS1:DBLookup(31 , string($var:v693) , string($var:v678) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v695"" select=""ScriptNS1:DBValueExtract(string($var:v694) , &quot;id&quot;)"" />
            <xsl:variable name=""var:v696"" select=""ScriptNS1:DBValueExtract(string($var:v694) , &quot;Name&quot;)"" />
            <xsl:variable name=""var:v697"" select=""ScriptNS1:DBValueExtract(string($var:v694) , &quot;code&quot;)"" />
            <xsl:variable name=""var:v698"" select=""userCSharp:CargoOperationId($var:v452)"" />
            <xsl:variable name=""var:v699"" select=""userCSharp:CargoOperationName($var:v452)"" />
            <xsl:variable name=""var:v700"" select=""userCSharp:CargoOperationCode($var:v452)"" />
            <xsl:variable name=""var:v701"" select=""$var:v700"" />
            <Code>
              <xsl:value-of select=""$var:v701"" />
            </Code>
          </CargoActivity>
          <xsl:variable name=""var:v702"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v703"" select=""ScriptNS1:DBLookup(7 , string($var:v459) , string($var:v702) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v704"" select=""ScriptNS1:DBValueExtract(string($var:v703) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v705"" select=""userCSharp:StringConcat(string($var:v704) , &quot;|&quot; , $var:v463 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v706"" select=""ScriptNS1:DBLookup(28 , string($var:v705) , string($var:v702) , &quot;Master.HubPrincipalCommodityDetailMap&quot; , &quot; cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v707"" select=""ScriptNS1:DBValueExtract(string($var:v706) , &quot;CommodityDetailId&quot;)"" />
          <xsl:variable name=""var:v708"" select=""userCSharp:StringConcat(string($var:v707) , &quot;|1&quot;)"" />
          <xsl:variable name=""var:v709"" select=""ScriptNS1:DBLookup(29 , string($var:v708) , string($var:v702) , &quot;Master.CommodityDetails&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v710"" select=""ScriptNS1:DBValueExtract(string($var:v709) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v711"" select=""ScriptNS1:DBValueExtract(string($var:v709) , &quot;name&quot;)"" />
          <xsl:variable name=""var:v712"" select=""ScriptNS1:DBValueExtract(string($var:v709) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v713"" select=""ScriptNS1:DBValueExtract(string($var:v703) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v714"" select=""userCSharp:StringConcat(string($var:v713) , &quot;|&quot; , $var:v473 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v715"" select=""ScriptNS1:DBLookup(30 , string($var:v714) , string($var:v702) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(HubPrincipalId as varchar(40)) +'|'+ CODE + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v716"" select=""ScriptNS1:DBValueExtract(string($var:v715) , &quot;UnitofMeasureId&quot;)"" />
          <xsl:variable name=""var:v717"" select=""userCSharp:StringConcat(string($var:v716) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v718"" select=""ScriptNS1:DBLookup(31 , string($var:v717) , string($var:v702) , &quot;Master.UnitOfMeasures&quot; , &quot;  cast(id as varchar(20)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v719"" select=""ScriptNS1:DBValueExtract(string($var:v718) , &quot;id&quot;)"" />
          <xsl:variable name=""var:v720"" select=""ScriptNS1:DBValueExtract(string($var:v718) , &quot;Name&quot;)"" />
          <xsl:variable name=""var:v721"" select=""ScriptNS1:DBValueExtract(string($var:v718) , &quot;code&quot;)"" />
          <xsl:variable name=""var:v722"" select=""userCSharp:CargoOperationId($var:v452)"" />
          <xsl:variable name=""var:v723"" select=""userCSharp:CargoOperationName($var:v452)"" />
          <xsl:variable name=""var:v724"" select=""userCSharp:CargoOperationCode($var:v452)"" />
        </Cargoes>
      </xsl:for-each>
    </ns0:YourIss2Appointment>
    <xsl:variable name=""var:v725"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public string StringTrimRight(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimEnd(null);
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringConcat(string param0, string param1, string param2, string param3, string param4)
{
   return param0 + param1 + param2 + param3 + param4;
}


public string StringConcat(string param0, string param1)
{
   return param0 + param1;
}


///*Uncomment the following code for a sample Inline C# function
//that concatenates two inputs. Change the number of parameters of
//this function to be equal to the number of inputs connected to this functoid.*/

public string CargoOperationId(string COCode)
{
               string res ="""";
               if ( COCode == ""L"")
                      res = ""1"";
               else if ( COCode == ""D"")
                      res = ""2"";
             
	return res;
}


///*Uncomment the following code for a sample Inline C# function
//that concatenates two inputs. Change the number of parameters of
//this function to be equal to the number of inputs connected to this functoid.*/

public string CargoOperationCode(string COCode)
{
               string res ="""";
               if ( COCode == ""L"")
                      res = ""L"";
               else if ( COCode == ""D"")
                      res = ""D"";
             
	return res;
}



///*Uncomment the following code for a sample Inline C# function
//that concatenates two inputs. Change the number of parameters of
//this function to be equal to the number of inputs connected to this functoid.*/

public string CargoOperationName(string COCode)
{
               string res = """";
               if ( COCode == ""L"")
                      res = ""Loading"";
               else if ( COCode == ""D"")
                      res = ""Discharging"";
             
	return res;
}

public  string MainCommodityId (  string strCargoCount ,  string idTBC, string  id)
{
       int CargoCount = 0;
       int.TryParse ( strCargoCount  , out  CargoCount         );
  
        if   (  CargoCount > 0   )
              return    id   ;
        else
               return    idTBC  ;
}

public  string MainCommodityName (  string strCargoCount ,  string NameTBC  , string  Name  )
{
       int CargoCount = 0;
       int.TryParse ( strCargoCount  , out  CargoCount         );
  
        if   (  CargoCount > 0   )
              return Name  ;  
        else
               return NameTBC  ;
}

public  string MainCommodityCode (  string strCargoCount ,  string CodeTBC  , string  Code )
{
       int CargoCount = 0;
       int.TryParse ( strCargoCount  , out  CargoCount         );
  
        if   (  CargoCount > 0   )
              return Code  ;  
        else
               return CodeTBC  ;
}

public string StringConcat(string param0, string param1, string param2, string param3, string param4, string param5, string param6)
{
   return param0 + param1 + param2 + param3 + param4 + param5 + param6;
}


public int GetAccountOfficeID
        (
          string Action,
            string strIdCreate,
            string strIdUpdate
        )
        {

            int IdCreate = -1 ;
            int IdUpdate = -1 ;

            int.TryParse ( strIdCreate , out IdCreate ) ;
            int.TryParse ( strIdUpdate ,  out  IdUpdate ) ;

            if (Action == ""Create"" && strIdCreate != """" )
            {
                return IdCreate;
            }
          
           else if (Action == ""Update"" && strIdUpdate  != """"   )
            {
                return IdUpdate;
            }
            else
            {
                return -1;
            }

            return -1;


        }

public bool LogicalNe(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 != d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) != 0;
	}
	return ret;
}


public string StringConcat(string param0)
{
   return param0;
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public string StringUpperCase(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.ToUpper(System.Globalization.CultureInfo.InvariantCulture);
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_CreatePortCall";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_CreatePortCall _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_CreatePortCall";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_CreatePortCall";
                return _TrgSchemas;
            }
        }
    }
}

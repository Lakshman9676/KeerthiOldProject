namespace Inchcape.YourISS.Integration.OperationUpdateRouter.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey))]
    public sealed class Map_RouteKeyToRouteName : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.OperationUpdateRouter"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/ns0:PortCallRouter"" />
  </xsl:template>
  <xsl:template match=""/ns0:PortCallRouter"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(string(Key/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <ns0:PortCallRouter>
      <xsl:variable name=""var:v2"" select=""ScriptNS0:GetBizConnectionString()"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBLookup(0 , string($var:v1) , string($var:v2) , &quot;Routing&quot; , &quot;cast( AccountID as varchar(40) )  + '|' +   cast( OpsUpdSendFlag  as varchar(1) )&quot;)"" />
      <xsl:variable name=""var:v4"" select=""ScriptNS1:DBValueExtract(string($var:v3) , &quot;AccountID&quot;)"" />
      <Key>
        <xsl:value-of select=""$var:v4"" />
      </Key>
    </ns0:PortCallRouter>
    <xsl:variable name=""var:v5"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
        
        private const global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
        
        private const global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
                return _TrgSchemas;
            }
        }
    }
}

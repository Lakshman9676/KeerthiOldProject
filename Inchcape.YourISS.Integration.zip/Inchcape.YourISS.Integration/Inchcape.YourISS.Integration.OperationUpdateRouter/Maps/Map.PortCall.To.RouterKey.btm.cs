namespace Inchcape.YourISS.Integration.OperationUpdateRouter.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_YourIss2Appointment", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_YourIss2Appointment))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey))]
    public sealed class Map_PortCall_To_RouterKey : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.OperationUpdateRouter"" xmlns:s0=""http://schema.iss-shipping.com/marine/appointment/YourISS2"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIss2Appointment"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIss2Appointment"">
    <ns0:PortCallRouter>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS1:DBLookup(0 , string(Number/text()) , string($var:v1) , &quot;Portcall.PortCalls&quot; , &quot;Number&quot;)"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS1:DBValueExtract(string($var:v2) , &quot;Id&quot;)"" />
      <xsl:variable name=""var:v4"" select=""ScriptNS1:DBLookup(1 , string($var:v3) , string($var:v1) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
      <xsl:variable name=""var:v5"" select=""ScriptNS1:DBValueExtract(string($var:v4) , &quot;HubPrincipalKey&quot;)"" />
      <Key>
        <xsl:value-of select=""$var:v5"" />
      </Key>
    </ns0:PortCallRouter>
    <xsl:variable name=""var:v6"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_YourIss2Appointment";
        
        private const global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_YourIss2Appointment _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
        
        private const global::Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_YourIss2Appointment";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.OperationUpdateRouter.Schema.Schema_RouterKey";
                return _TrgSchemas;
            }
        }
    }
}

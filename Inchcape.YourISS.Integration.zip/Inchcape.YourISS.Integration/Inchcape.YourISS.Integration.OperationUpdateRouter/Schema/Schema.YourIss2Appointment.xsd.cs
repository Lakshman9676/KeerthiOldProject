namespace Inchcape.YourISS.Integration.OperationUpdateRouter.Schema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schema.iss-shipping.com/marine/appointment/YourISS2",@"YourIss2Appointment")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.Number), XPath = @"/*[local-name()='YourIss2Appointment' and namespace-uri()='http://schema.iss-shipping.com/marine/appointment/YourISS2']/*[local-name()='Number' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"YourIss2Appointment"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema", typeof(global::Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema))]
    public sealed class Schema_YourIss2Appointment : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schema.iss-shipping.com/marine/appointment/YourISS2"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns1=""https://Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema"" xmlns:ns0=""https://Inchcape.Shipnet.BT.PortOpsUpdateRouter.PropertySchema"" targetNamespace=""http://schema.iss-shipping.com/marine/appointment/YourISS2"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Inchcape.Shipnet.BT.PortOpsUpdateRouter.PropertySchema"" location=""Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema"" />
        <b:namespace prefix=""ns1"" uri=""https://Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema"" location=""Inchcape.YourISS.Integration.OperationUpdateRouter.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""YourIss2Appointment"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns1:Number"" xpath=""/*[local-name()='YourIss2Appointment' and namespace-uri()='http://schema.iss-shipping.com/marine/appointment/YourISS2']/*[local-name()='Number' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""Number"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""Appointments"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Number"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Principal"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""PerformingAgent"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""MainCommodity"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Uri"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Eta"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""OkToSail"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""PortCallAccepted"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""ControllingAgentAccepted"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""IsPortOperationComplete"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""PortOperationCompleteTime"" nillable=""true"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""AccountingOffice"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PortOperation"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Port"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""NextPort"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""PreviousPort"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""MainCommodity"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Vessel"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Imo"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""FlowStatus"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""PortCallOperations"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Ets"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Eosp"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Cosp"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Bunkers"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Lsfo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Hfo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Lsgo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Mdo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Mgo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Lo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""FwCrew"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""FwShip"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Drafts"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Fwd"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Mean"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Aft"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Tugs"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""TugName"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Type"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Total"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Comments"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Cargoes"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""RefCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Rotation"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Poi"">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Berth"">
                      <xs:complexType>
                        <xs:sequence minOccurs=""0"">
                          <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                          <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element minOccurs=""0"" name=""Etb"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""NominationQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""ShipperReceiver"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""LaycanFrom"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""LaycanTo"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""CommodityDetail"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""UnitOfMeasure"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""CargoActivity"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""BillOfLadingQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""ShoreQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""VesselQuantity"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Temperature"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""YourIss2Appointment"" type=""xs:string"" />
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""DailyCargoOperations"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""StartOperationTime"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""YourIss2Appointment"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""LdQuantity"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""TankHatchNumber"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Rotations"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Poi"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Berth"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Etb"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""OperationEvents"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""RefCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Etb"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""StartDate"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""EndDate"" nillable=""true"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""Comments"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""IsActive"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""Poi"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Berth"">
                <xs:complexType>
                  <xs:sequence minOccurs=""0"">
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element minOccurs=""0"" name=""Event"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Name"" type=""xs:string"" />
                    <xs:element minOccurs=""0"" name=""Code"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Id"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""Uri"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Schema_YourIss2Appointment() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "YourIss2Appointment";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}

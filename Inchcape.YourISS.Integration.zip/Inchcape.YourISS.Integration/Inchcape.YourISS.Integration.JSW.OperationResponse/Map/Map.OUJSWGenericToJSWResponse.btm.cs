namespace Inchcape.YourISS.Integration.JSW.OperationResponse.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.JSW.OperationResponse.Schema.Schema_JSW_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.JSW.OperationResponse.Schema.Schema_JSW_OperationUpdate))]
    public sealed class Map_OUJSWGenericToJSWResponse : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.JSW.OperationResponse.Schema"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIssNotification"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIssNotification"">
    <ns0:YourIssNotification>
      <MessageHeader>
        <xsl:if test=""MessageHeader/MessageType"">
          <xsl:variable name=""var:v1"" select=""string(MessageHeader/MessageType/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v1)='true'"">
            <MessageType>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </MessageType>
          </xsl:if>
          <xsl:if test=""string($var:v1)='false'"">
            <MessageType>
              <xsl:value-of select=""MessageHeader/MessageType/text()"" />
            </MessageType>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""MessageHeader/Action"">
          <xsl:variable name=""var:v2"" select=""string(MessageHeader/Action/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v2)='true'"">
            <Action>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </Action>
          </xsl:if>
          <xsl:if test=""string($var:v2)='false'"">
            <Action>
              <xsl:value-of select=""MessageHeader/Action/text()"" />
            </Action>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""MessageHeader/CreatedDate"">
          <xsl:variable name=""var:v3"" select=""string(MessageHeader/CreatedDate/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v3)='true'"">
            <CreatedDate>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </CreatedDate>
          </xsl:if>
          <xsl:if test=""string($var:v3)='false'"">
            <CreatedDate>
              <xsl:value-of select=""MessageHeader/CreatedDate/text()"" />
            </CreatedDate>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""MessageHeader/ShipNetReference"">
          <xsl:variable name=""var:v4"" select=""string(MessageHeader/ShipNetReference/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v4)='true'"">
            <ShipNetReference>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ShipNetReference>
          </xsl:if>
          <xsl:if test=""string($var:v4)='false'"">
            <ShipNetReference>
              <xsl:value-of select=""MessageHeader/ShipNetReference/text()"" />
            </ShipNetReference>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""MessageHeader/SourceApplication"">
          <xsl:variable name=""var:v5"" select=""string(MessageHeader/SourceApplication/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v5)='true'"">
            <SourceApplication>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </SourceApplication>
          </xsl:if>
          <xsl:if test=""string($var:v5)='false'"">
            <SourceApplication>
              <xsl:value-of select=""MessageHeader/SourceApplication/text()"" />
            </SourceApplication>
          </xsl:if>
        </xsl:if>
      </MessageHeader>
      <Operational>
        <xsl:if test=""Operational/SN_DANo"">
          <xsl:variable name=""var:v6"" select=""string(Operational/SN_DANo/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v6)='true'"">
            <SN_DANo>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </SN_DANo>
          </xsl:if>
          <xsl:if test=""string($var:v6)='false'"">
            <SN_DANo>
              <xsl:value-of select=""Operational/SN_DANo/text()"" />
            </SN_DANo>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/SN_KeyPosition"">
          <xsl:variable name=""var:v7"" select=""string(Operational/SN_KeyPosition/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v7)='true'"">
            <SN_KeyPosition>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </SN_KeyPosition>
          </xsl:if>
          <xsl:if test=""string($var:v7)='false'"">
            <SN_KeyPosition>
              <xsl:value-of select=""Operational/SN_KeyPosition/text()"" />
            </SN_KeyPosition>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/SN_VesselCode"">
          <xsl:variable name=""var:v8"" select=""string(Operational/SN_VesselCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v8)='true'"">
            <SN_VesselCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </SN_VesselCode>
          </xsl:if>
          <xsl:if test=""string($var:v8)='false'"">
            <SN_VesselCode>
              <xsl:value-of select=""Operational/SN_VesselCode/text()"" />
            </SN_VesselCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/SN_VoyageNumber"">
          <xsl:variable name=""var:v9"" select=""string(Operational/SN_VoyageNumber/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v9)='true'"">
            <SN_VoyageNumber>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </SN_VoyageNumber>
          </xsl:if>
          <xsl:if test=""string($var:v9)='false'"">
            <SN_VoyageNumber>
              <xsl:value-of select=""Operational/SN_VoyageNumber/text()"" />
            </SN_VoyageNumber>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/ETA"">
          <xsl:variable name=""var:v10"" select=""string(Operational/ETA/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v10)='true'"">
            <ETA>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ETA>
          </xsl:if>
          <xsl:if test=""string($var:v10)='false'"">
            <ETA>
              <xsl:value-of select=""Operational/ETA/text()"" />
            </ETA>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/ETS"">
          <xsl:variable name=""var:v11"" select=""string(Operational/ETS/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v11)='true'"">
            <ETS>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ETS>
          </xsl:if>
          <xsl:if test=""string($var:v11)='false'"">
            <ETS>
              <xsl:value-of select=""Operational/ETS/text()"" />
            </ETS>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/EOSP"">
          <xsl:variable name=""var:v12"" select=""string(Operational/EOSP/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v12)='true'"">
            <EOSP>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </EOSP>
          </xsl:if>
          <xsl:if test=""string($var:v12)='false'"">
            <EOSP>
              <xsl:value-of select=""Operational/EOSP/text()"" />
            </EOSP>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/CommencedSeaPassage"">
          <xsl:variable name=""var:v13"" select=""string(Operational/CommencedSeaPassage/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v13)='true'"">
            <CommencedSeaPassage>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </CommencedSeaPassage>
          </xsl:if>
          <xsl:if test=""string($var:v13)='false'"">
            <CommencedSeaPassage>
              <xsl:value-of select=""Operational/CommencedSeaPassage/text()"" />
            </CommencedSeaPassage>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/EtaNextPort"">
          <xsl:variable name=""var:v14"" select=""string(Operational/EtaNextPort/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v14)='true'"">
            <EtaNextPort>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </EtaNextPort>
          </xsl:if>
          <xsl:if test=""string($var:v14)='false'"">
            <EtaNextPort>
              <xsl:value-of select=""Operational/EtaNextPort/text()"" />
            </EtaNextPort>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/NextPortCode"">
          <xsl:variable name=""var:v15"" select=""string(Operational/NextPortCode/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v15)='true'"">
            <NextPortCode>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </NextPortCode>
          </xsl:if>
          <xsl:if test=""string($var:v15)='false'"">
            <NextPortCode>
              <xsl:value-of select=""Operational/NextPortCode/text()"" />
            </NextPortCode>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/NextPortName"">
          <xsl:variable name=""var:v16"" select=""string(Operational/NextPortName/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v16)='true'"">
            <NextPortName>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </NextPortName>
          </xsl:if>
          <xsl:if test=""string($var:v16)='false'"">
            <NextPortName>
              <xsl:value-of select=""Operational/NextPortName/text()"" />
            </NextPortName>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/Master"">
          <xsl:variable name=""var:v17"" select=""string(Operational/Master/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v17)='true'"">
            <Master>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </Master>
          </xsl:if>
          <xsl:if test=""string($var:v17)='false'"">
            <Master>
              <xsl:value-of select=""Operational/Master/text()"" />
            </Master>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/WorkflowStatus"">
          <xsl:variable name=""var:v18"" select=""string(Operational/WorkflowStatus/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v18)='true'"">
            <WorkflowStatus>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </WorkflowStatus>
          </xsl:if>
          <xsl:if test=""string($var:v18)='false'"">
            <WorkflowStatus>
              <xsl:value-of select=""Operational/WorkflowStatus/text()"" />
            </WorkflowStatus>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/Agentacceptance"">
          <xsl:variable name=""var:v19"" select=""string(Operational/Agentacceptance/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v19)='true'"">
            <Agentacceptance>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </Agentacceptance>
          </xsl:if>
          <xsl:if test=""string($var:v19)='false'"">
            <Agentacceptance>
              <xsl:value-of select=""Operational/Agentacceptance/text()"" />
            </Agentacceptance>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/ETB"">
          <xsl:variable name=""var:v20"" select=""string(Operational/ETB/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v20)='true'"">
            <ETB>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </ETB>
          </xsl:if>
          <xsl:if test=""string($var:v20)='false'"">
            <ETB>
              <xsl:value-of select=""Operational/ETB/text()"" />
            </ETB>
          </xsl:if>
        </xsl:if>
        <xsl:if test=""Operational/CargoCount"">
          <xsl:variable name=""var:v21"" select=""string(Operational/CargoCount/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v21)='true'"">
            <CargoCount>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </CargoCount>
          </xsl:if>
          <xsl:if test=""string($var:v21)='false'"">
            <CargoCount>
              <xsl:value-of select=""Operational/CargoCount/text()"" />
            </CargoCount>
          </xsl:if>
        </xsl:if>
        <xsl:for-each select=""Operational/Cargoes"">
          <Cargoes>
            <xsl:for-each select=""Cargo"">
              <Cargo>
                <xsl:if test=""SN_KeyCargo"">
                  <xsl:variable name=""var:v22"" select=""string(SN_KeyCargo/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v22)='true'"">
                    <SN_KeyCargo>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""string($var:v22)='false'"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""SN_KeyCargo/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""Terminal"">
                  <xsl:variable name=""var:v23"" select=""string(Terminal/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v23)='true'"">
                    <Terminal>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Terminal>
                  </xsl:if>
                  <xsl:if test=""string($var:v23)='false'"">
                    <Terminal>
                      <xsl:value-of select=""Terminal/text()"" />
                    </Terminal>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""Berth"">
                  <xsl:variable name=""var:v24"" select=""string(Berth/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v24)='true'"">
                    <Berth>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Berth>
                  </xsl:if>
                  <xsl:if test=""string($var:v24)='false'"">
                    <Berth>
                      <xsl:value-of select=""Berth/text()"" />
                    </Berth>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""BlFigures"">
                  <xsl:variable name=""var:v25"" select=""string(BlFigures/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v25)='true'"">
                    <BlFigures>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </BlFigures>
                  </xsl:if>
                  <xsl:if test=""string($var:v25)='false'"">
                    <BlFigures>
                      <xsl:value-of select=""BlFigures/text()"" />
                    </BlFigures>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""ShipFigures"">
                  <xsl:variable name=""var:v26"" select=""string(ShipFigures/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v26)='true'"">
                    <ShipFigures>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </ShipFigures>
                  </xsl:if>
                  <xsl:if test=""string($var:v26)='false'"">
                    <ShipFigures>
                      <xsl:value-of select=""ShipFigures/text()"" />
                    </ShipFigures>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""DraftIn"">
                  <xsl:variable name=""var:v27"" select=""string(DraftIn/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v27)='true'"">
                    <DraftIn>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </DraftIn>
                  </xsl:if>
                  <xsl:if test=""string($var:v27)='false'"">
                    <DraftIn>
                      <xsl:value-of select=""DraftIn/text()"" />
                    </DraftIn>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""ArrDraftAft"">
                  <xsl:variable name=""var:v28"" select=""string(ArrDraftAft/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v28)='true'"">
                    <ArrDraftAft>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </ArrDraftAft>
                  </xsl:if>
                  <xsl:if test=""string($var:v28)='false'"">
                    <ArrDraftAft>
                      <xsl:value-of select=""ArrDraftAft/text()"" />
                    </ArrDraftAft>
                  </xsl:if>
                </xsl:if>
                <ArrDraftMid>
                  <xsl:value-of select=""ArrDraftMid/text()"" />
                </ArrDraftMid>
                <ArrDraftFwd>
                  <xsl:value-of select=""ArrDraftFwd/text()"" />
                </ArrDraftFwd>
                <DepDraftAft>
                  <xsl:value-of select=""DepDraftAft/text()"" />
                </DepDraftAft>
                <DepDraftMid>
                  <xsl:value-of select=""DepDraftMid/text()"" />
                </DepDraftMid>
                <DepDraftFwd>
                  <xsl:value-of select=""DepDraftFwd/text()"" />
                </DepDraftFwd>
                <xsl:if test=""Deadfreight"">
                  <xsl:variable name=""var:v29"" select=""string(Deadfreight/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v29)='true'"">
                    <Deadfreight>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Deadfreight>
                  </xsl:if>
                  <xsl:if test=""string($var:v29)='false'"">
                    <Deadfreight>
                      <xsl:value-of select=""Deadfreight/text()"" />
                    </Deadfreight>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""Overage"">
                  <xsl:variable name=""var:v30"" select=""string(Overage/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v30)='true'"">
                    <Overage>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Overage>
                  </xsl:if>
                  <xsl:if test=""string($var:v30)='false'"">
                    <Overage>
                      <xsl:value-of select=""Overage/text()"" />
                    </Overage>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""Shipper"">
                  <xsl:variable name=""var:v31"" select=""string(Shipper/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v31)='true'"">
                    <Shipper>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Shipper>
                  </xsl:if>
                  <xsl:if test=""string($var:v31)='false'"">
                    <Shipper>
                      <xsl:value-of select=""Shipper/text()"" />
                    </Shipper>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""Receiver"">
                  <xsl:variable name=""var:v32"" select=""string(Receiver/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v32)='true'"">
                    <Receiver>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Receiver>
                  </xsl:if>
                  <xsl:if test=""string($var:v32)='false'"">
                    <Receiver>
                      <xsl:value-of select=""Receiver/text()"" />
                    </Receiver>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""BlDate"">
                  <xsl:variable name=""var:v33"" select=""string(BlDate/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v33)='true'"">
                    <BlDate>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </BlDate>
                  </xsl:if>
                  <xsl:if test=""string($var:v33)='false'"">
                    <BlDate>
                      <xsl:value-of select=""BlDate/text()"" />
                    </BlDate>
                  </xsl:if>
                </xsl:if>
                <DocumentCount>
                  <xsl:value-of select=""DocumentCount/text()"" />
                </DocumentCount>
                <Documents>
                  <xsl:for-each select=""Documents/Document"">
                    <xsl:variable name=""var:v34"" select=""string(./@xsi:nil) = 'true'"" />
                    <xsl:if test=""string($var:v34)='true'"">
                      <Document>
                        <xsl:attribute name=""xsi:nil"">
                          <xsl:value-of select=""'true'"" />
                        </xsl:attribute>
                      </Document>
                    </xsl:if>
                    <xsl:if test=""string($var:v34)='false'"">
                      <Document>
                        <xsl:value-of select=""./text()"" />
                      </Document>
                    </xsl:if>
                  </xsl:for-each>
                  <xsl:value-of select=""Documents/text()"" />
                </Documents>
                <xsl:value-of select=""./text()"" />
              </Cargo>
            </xsl:for-each>
            <xsl:value-of select=""./text()"" />
          </Cargoes>
        </xsl:for-each>
        <xsl:if test=""Operational/BunkerCount"">
          <xsl:variable name=""var:v35"" select=""string(Operational/BunkerCount/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v35)='true'"">
            <BunkerCount>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </BunkerCount>
          </xsl:if>
          <xsl:if test=""string($var:v35)='false'"">
            <BunkerCount>
              <xsl:value-of select=""Operational/BunkerCount/text()"" />
            </BunkerCount>
          </xsl:if>
        </xsl:if>
        <xsl:for-each select=""Operational/Bunkers"">
          <Bunkers>
            <xsl:for-each select=""Bunker"">
              <Bunker>
                <xsl:if test=""Grade"">
                  <xsl:variable name=""var:v36"" select=""string(Grade/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v36)='true'"">
                    <Grade>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </Grade>
                  </xsl:if>
                  <xsl:if test=""string($var:v36)='false'"">
                    <Grade>
                      <xsl:value-of select=""Grade/text()"" />
                    </Grade>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""ArrQuantity"">
                  <xsl:variable name=""var:v37"" select=""string(ArrQuantity/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v37)='true'"">
                    <ArrQuantity>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </ArrQuantity>
                  </xsl:if>
                  <xsl:if test=""string($var:v37)='false'"">
                    <ArrQuantity>
                      <xsl:value-of select=""ArrQuantity/text()"" />
                    </ArrQuantity>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""TakenQuantity"">
                  <xsl:variable name=""var:v38"" select=""string(TakenQuantity/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v38)='true'"">
                    <TakenQuantity>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </TakenQuantity>
                  </xsl:if>
                  <xsl:if test=""string($var:v38)='false'"">
                    <TakenQuantity>
                      <xsl:value-of select=""TakenQuantity/text()"" />
                    </TakenQuantity>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""DepQuantity"">
                  <xsl:variable name=""var:v39"" select=""string(DepQuantity/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v39)='true'"">
                    <DepQuantity>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </DepQuantity>
                  </xsl:if>
                  <xsl:if test=""string($var:v39)='false'"">
                    <DepQuantity>
                      <xsl:value-of select=""DepQuantity/text()"" />
                    </DepQuantity>
                  </xsl:if>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Bunker>
            </xsl:for-each>
            <xsl:value-of select=""./text()"" />
          </Bunkers>
        </xsl:for-each>
        <xsl:if test=""Operational/StatementCount"">
          <xsl:variable name=""var:v40"" select=""string(Operational/StatementCount/@xsi:nil) = 'true'"" />
          <xsl:if test=""string($var:v40)='true'"">
            <StatementCount>
              <xsl:attribute name=""xsi:nil"">
                <xsl:value-of select=""'true'"" />
              </xsl:attribute>
            </StatementCount>
          </xsl:if>
          <xsl:if test=""string($var:v40)='false'"">
            <StatementCount>
              <xsl:value-of select=""Operational/StatementCount/text()"" />
            </StatementCount>
          </xsl:if>
        </xsl:if>
        <xsl:for-each select=""Operational/Statements"">
          <Statements>
            <xsl:for-each select=""Sof"">
              <Sof>
                <xsl:if test=""SN_KeyCargo"">
                  <xsl:variable name=""var:v41"" select=""string(SN_KeyCargo/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v41)='true'"">
                    <SN_KeyCargo>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""string($var:v41)='false'"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""SN_KeyCargo/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""SofLabel"">
                  <xsl:variable name=""var:v42"" select=""string(SofLabel/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v42)='true'"">
                    <SofLabel>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </SofLabel>
                  </xsl:if>
                  <xsl:if test=""string($var:v42)='false'"">
                    <SofLabel>
                      <xsl:value-of select=""SofLabel/text()"" />
                    </SofLabel>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""SofDateTime"">
                  <xsl:variable name=""var:v43"" select=""string(SofDateTime/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v43)='true'"">
                    <SofDateTime>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </SofDateTime>
                  </xsl:if>
                  <xsl:if test=""string($var:v43)='false'"">
                    <SofDateTime>
                      <xsl:value-of select=""SofDateTime/text()"" />
                    </SofDateTime>
                  </xsl:if>
                </xsl:if>
                <SofEndDate>
                  <xsl:value-of select=""SofEndDate/text()"" />
                </SofEndDate>
                <xsl:if test=""SofComments"">
                  <xsl:variable name=""var:v44"" select=""string(SofComments/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v44)='true'"">
                    <SofComments>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </SofComments>
                  </xsl:if>
                  <xsl:if test=""string($var:v44)='false'"">
                    <SofComments>
                      <xsl:value-of select=""SofComments/text()"" />
                    </SofComments>
                  </xsl:if>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Sof>
            </xsl:for-each>
            <xsl:value-of select=""./text()"" />
          </Statements>
        </xsl:for-each>
        <EventCount>
          <xsl:value-of select=""Operational/EventCount/text()"" />
        </EventCount>
        <Events>
          <xsl:for-each select=""Operational/Events"">
            <xsl:for-each select=""Event"">
              <Event>
                <EventLabel>
                  <xsl:value-of select=""EventLabel/text()"" />
                </EventLabel>
                <EventDateTime>
                  <xsl:value-of select=""EventDateTime/text()"" />
                </EventDateTime>
                <xsl:if test=""EventComments"">
                  <xsl:variable name=""var:v45"" select=""string(EventComments/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v45)='true'"">
                    <EventComments>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </EventComments>
                  </xsl:if>
                  <xsl:if test=""string($var:v45)='false'"">
                    <EventComments>
                      <xsl:value-of select=""EventComments/text()"" />
                    </EventComments>
                  </xsl:if>
                </xsl:if>
                <xsl:if test=""EventUtcOffset"">
                  <xsl:variable name=""var:v46"" select=""string(EventUtcOffset/@xsi:nil) = 'true'"" />
                  <xsl:if test=""string($var:v46)='true'"">
                    <EventUtcOffset>
                      <xsl:attribute name=""xsi:nil"">
                        <xsl:value-of select=""'true'"" />
                      </xsl:attribute>
                    </EventUtcOffset>
                  </xsl:if>
                  <xsl:if test=""string($var:v46)='false'"">
                    <EventUtcOffset>
                      <xsl:value-of select=""EventUtcOffset/text()"" />
                    </EventUtcOffset>
                  </xsl:if>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Event>
            </xsl:for-each>
          </xsl:for-each>
        </Events>
        <DocumentCount>
          <xsl:value-of select=""Operational/DocumentCount/text()"" />
        </DocumentCount>
        <Documents>
          <xsl:for-each select=""Operational/Documents/Document"">
            <xsl:variable name=""var:v47"" select=""string(./@xsi:nil) = 'true'"" />
            <xsl:if test=""string($var:v47)='true'"">
              <Document>
                <xsl:attribute name=""xsi:nil"">
                  <xsl:value-of select=""'true'"" />
                </xsl:attribute>
              </Document>
            </xsl:if>
            <xsl:if test=""string($var:v47)='false'"">
              <Document>
                <xsl:value-of select=""./text()"" />
              </Document>
            </xsl:if>
          </xsl:for-each>
          <xsl:value-of select=""Operational/Documents/text()"" />
        </Documents>
      </Operational>
    </ns0:YourIssNotification>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.JSW.OperationResponse.Schema.Schema_JSW_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.JSW.OperationResponse.Schema.Schema_JSW_OperationUpdate _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.JSW.OperationResponse.Schema.Schema_JSW_OperationUpdate";
                return _TrgSchemas;
            }
        }
    }
}

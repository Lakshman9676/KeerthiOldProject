namespace Inchcape.YourISS.Integration.Generic.FinalDA.Pipelines
{
    using System;
    using System.Collections.Generic;
    using Microsoft.BizTalk.PipelineOM;
    using Microsoft.BizTalk.Component;
    using Microsoft.BizTalk.Component.Interop;
    
    
    public sealed class DASplitReceivePipeline : Microsoft.BizTalk.PipelineOM.ReceivePipeline
    {
        
        private const string _strPipeline = "<?xml version=\"1.0\" encoding=\"utf-16\"?><Document xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instanc"+
"e\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" MajorVersion=\"1\" MinorVersion=\"0\">  <Description /> "+
" <CategoryId>f66b9f5e-43ff-4f5f-ba46-885348ae1b4e</CategoryId>  <FriendlyName>Receive</FriendlyName>"+
"  <Stages>    <Stage>      <PolicyFileStage _locAttrData=\"Name\" _locID=\"1\" Name=\"Decode\" minOccurs=\""+
"0\" maxOccurs=\"-1\" execMethod=\"All\" stageId=\"9d0e4103-4cce-4536-83fa-4a5040674ad6\" />      <Component"+
"s />    </Stage>    <Stage>      <PolicyFileStage _locAttrData=\"Name\" _locID=\"2\" Name=\"Disassemble\" "+
"minOccurs=\"0\" maxOccurs=\"-1\" execMethod=\"FirstMatch\" stageId=\"9d0e4105-4cce-4536-83fa-4a5040674ad6\" "+
"/>      <Components>        <Component>          <Name>Inchcape.YourISS.Integration.Generic.FinalDA."+
"PipeLineComponent.SplitFinalDA,Inchcape.YourISS.Integration.Generic.FinalDA.PipeLineComponent, Versi"+
"on=1.0.0.0, Culture=neutral, PublicKeyToken=27a25d2756ab8f87</Name>          <ComponentName>SplitFin"+
"alDAPipeline</ComponentName>          <Description>Pipeline component to split up the incoming Final"+
"DAs from YourISS</Description>          <Version>1.0.0.0</Version>          <Properties>            "+
"<Property Name=\"DAs\">              <Value xsi:type=\"xsd:string\">http://Inchcape.Generic.BT.SplittedF"+
"inalDA.Schema</Value>            </Property>            <Property Name=\"Namespace\">              <Va"+
"lue xsi:type=\"xsd:string\">DAS</Value>            </Property>            <Property Name=\"BatchSize\"> "+
"             <Value xsi:type=\"xsd:int\">0</Value>            </Property>          </Properties>      "+
"    <CachedDisplayName>SplitFinalDAPipeline</CachedDisplayName>          <CachedIsManaged>true</Cach"+
"edIsManaged>        </Component>      </Components>    </Stage>    <Stage>      <PolicyFileStage _lo"+
"cAttrData=\"Name\" _locID=\"3\" Name=\"Validate\" minOccurs=\"0\" maxOccurs=\"-1\" execMethod=\"All\" stageId=\"9"+
"d0e410d-4cce-4536-83fa-4a5040674ad6\" />      <Components />    </Stage>    <Stage>      <PolicyFileS"+
"tage _locAttrData=\"Name\" _locID=\"4\" Name=\"ResolveParty\" minOccurs=\"0\" maxOccurs=\"-1\" execMethod=\"All"+
"\" stageId=\"9d0e410e-4cce-4536-83fa-4a5040674ad6\" />      <Components />    </Stage>  </Stages></Docu"+
"ment>";
        
        private const string _versionDependentGuid = "61d6a78b-11a9-46db-9554-0c9000852036";
        
        public DASplitReceivePipeline()
        {
            Microsoft.BizTalk.PipelineOM.Stage stage = this.AddStage(new System.Guid("9d0e4105-4cce-4536-83fa-4a5040674ad6"), Microsoft.BizTalk.PipelineOM.ExecutionMode.firstRecognized);
            IBaseComponent comp0 = Microsoft.BizTalk.PipelineOM.PipelineManager.CreateComponent("Inchcape.YourISS.Integration.Generic.FinalDA.PipeLineComponent.SplitFinalDA,Inchcape.YourISS.Integration.Generic.FinalDA.PipeLineComponent, Version=1.0.0.0, Culture=neutral, PublicKeyToken=27a25d2756ab8f87");;
            if (comp0 is IPersistPropertyBag)
            {
                string comp0XmlProperties = "<?xml version=\"1.0\" encoding=\"utf-16\"?><PropertyBag xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-inst"+
"ance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">  <Properties>    <Property Name=\"DAs\">      <Val"+
"ue xsi:type=\"xsd:string\">http://Inchcape.Generic.BT.SplittedFinalDA.Schema</Value>    </Property>   "+
" <Property Name=\"Namespace\">      <Value xsi:type=\"xsd:string\">DAS</Value>    </Property>    <Proper"+
"ty Name=\"BatchSize\">      <Value xsi:type=\"xsd:int\">0</Value>    </Property>  </Properties></Propert"+
"yBag>";
                PropertyBag pb = PropertyBag.DeserializeFromXml(comp0XmlProperties);;
                ((IPersistPropertyBag)(comp0)).Load(pb, 0);
            }
            this.AddComponent(stage, comp0);
        }
        
        public override string XmlContent
        {
            get
            {
                return _strPipeline;
            }
        }
        
        public override System.Guid VersionDependentGuid
        {
            get
            {
                return new System.Guid(_versionDependentGuid);
            }
        }
    }
}

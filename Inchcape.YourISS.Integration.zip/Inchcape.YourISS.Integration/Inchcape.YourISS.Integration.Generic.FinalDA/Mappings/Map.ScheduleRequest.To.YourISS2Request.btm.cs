namespace Inchcape.YourISS.Integration.Generic.FinalDA.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.TypedPolling_ProcessFinalDA+TypedPollingResultSet0", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.TypedPolling_ProcessFinalDA.TypedPollingResultSet0))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.FinalDAYourISS2SPInBoundProcedure_Integration+SpuGetDAs", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.FinalDAYourISS2SPInBoundProcedure_Integration.SpuGetDAs))]
    public sealed class Map_ScheduleRequest_To_YourISS2Request : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:ns4=""http://schemas.datacontract.org/2004/07/System.Data"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/Procedures/Integration"" xmlns:s0=""http://schemas.microsoft.com/Sql/2008/05/TypedPolling/ProcessFinalDA"" xmlns:ns3=""http://schemas.microsoft.com/2003/10/Serialization/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:TypedPollingResultSet0"" />
  </xsl:template>
  <xsl:template match=""/s0:TypedPollingResultSet0"">
    <ns0:SpuGetDAs>
      <xsl:if test=""s0:AccountID"">
        <xsl:variable name=""var:v1"" select=""string(s0:AccountID/@xsi:nil) = 'true'"" />
        <xsl:if test=""string($var:v1)='true'"">
          <ns0:HubPrincipalKey>
            <xsl:attribute name=""xsi:nil"">
              <xsl:value-of select=""'true'"" />
            </xsl:attribute>
          </ns0:HubPrincipalKey>
        </xsl:if>
        <xsl:if test=""string($var:v1)='false'"">
          <ns0:HubPrincipalKey>
            <xsl:value-of select=""s0:AccountID/text()"" />
          </ns0:HubPrincipalKey>
        </xsl:if>
      </xsl:if>
      <xsl:if test=""s0:ScheduleStartDate"">
        <xsl:variable name=""var:v2"" select=""string(s0:ScheduleStartDate/@xsi:nil) = 'true'"" />
        <xsl:if test=""string($var:v2)='true'"">
          <ns0:FromDateTime>
            <xsl:attribute name=""xsi:nil"">
              <xsl:value-of select=""'true'"" />
            </xsl:attribute>
          </ns0:FromDateTime>
        </xsl:if>
        <xsl:if test=""string($var:v2)='false'"">
          <ns0:FromDateTime>
            <xsl:value-of select=""s0:ScheduleStartDate/text()"" />
          </ns0:FromDateTime>
        </xsl:if>
      </xsl:if>
      <xsl:if test=""s0:ScheduleEndDate"">
        <xsl:variable name=""var:v3"" select=""string(s0:ScheduleEndDate/@xsi:nil) = 'true'"" />
        <xsl:if test=""string($var:v3)='true'"">
          <ns0:ToDateTime>
            <xsl:attribute name=""xsi:nil"">
              <xsl:value-of select=""'true'"" />
            </xsl:attribute>
          </ns0:ToDateTime>
        </xsl:if>
        <xsl:if test=""string($var:v3)='false'"">
          <ns0:ToDateTime>
            <xsl:value-of select=""s0:ScheduleEndDate/text()"" />
          </ns0:ToDateTime>
        </xsl:if>
      </xsl:if>
    </ns0:SpuGetDAs>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.TypedPolling_ProcessFinalDA+TypedPollingResultSet0";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.TypedPolling_ProcessFinalDA.TypedPollingResultSet0 _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.FinalDAYourISS2SPInBoundProcedure_Integration+SpuGetDAs";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.FinalDAYourISS2SPInBoundProcedure_Integration.SpuGetDAs _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.TypedPolling_ProcessFinalDA+TypedPollingResultSet0";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.FinalDAYourISS2SPInBoundProcedure_Integration+SpuGetDAs";
                return _TrgSchemas;
            }
        }
    }
}

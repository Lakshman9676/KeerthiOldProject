namespace Inchcape.YourISS.Integration.Generic.FinalDA.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_SplittedFinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_SplittedFinalDA))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_Documents", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_Documents))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA))]
    public sealed class Map_YourISS2FinalDA_To_ShipnetFinalDA : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s2 s1 s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schema.SplittedFinalDA"" xmlns:s1=""http://Inchcape.YourISS.Integration.Generic.Schema.Documents"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;DisbursementAccount&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;Save&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(InputMessagePart_0/s0:DA/Header/PortCallNumber/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v13"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <xsl:variable name=""var:v14"" select=""string(InputMessagePart_0/s0:DA/Header/PortCallNumber/text())"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat($var:v14 , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v28"" select=""userCSharp:StringConcat(&quot;ISS&quot;)"" />
    <xsl:variable name=""var:v51"" select=""InputMessagePart_0/s0:DA/Header[1]/DACurrency/text()"" />
    <xsl:variable name=""var:v52"" select=""userCSharp:StringConcat(&quot;1&quot;)"" />
    <xsl:variable name=""var:v81"" select=""count(/s2:Root/InputMessagePart_1/s1:Documents/Document)"" />
    <ns0:YourIssNotification>
      <ns0:MessageHeader>
        <ns0:MessageType>
          <xsl:value-of select=""$var:v1"" />
        </ns0:MessageType>
        <ns0:Action>
          <xsl:value-of select=""$var:v2"" />
        </ns0:Action>
        <ns0:CreatedDate>
          <xsl:value-of select=""$var:v3"" />
        </ns0:CreatedDate>
        <xsl:variable name=""var:v5"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v6"" select=""ScriptNS1:DBLookup(0 , string($var:v4) , string($var:v5) , &quot;PortCall.PortCalls&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v7"" select=""ScriptNS1:DBValueExtract(string($var:v6) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(1 , string($var:v7) , string($var:v5) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v10"" select=""userCSharp:StringFind(string($var:v9) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v11"" select=""userCSharp:MathSubtract(string($var:v10) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v12"" select=""userCSharp:StringSubstring(string($var:v9) , &quot;1&quot; , string($var:v11))"" />
        <ns0:ShipNetReference>
          <xsl:value-of select=""$var:v12"" />
        </ns0:ShipNetReference>
        <ns0:SourceApplication>
          <xsl:value-of select=""$var:v13"" />
        </ns0:SourceApplication>
      </ns0:MessageHeader>
      <ns0:DisbursementAccount>
        <ns0:Stage>
          <xsl:value-of select=""InputMessagePart_0/s0:DA/Header/DATypeFlag/text()"" />
        </ns0:Stage>
        <xsl:variable name=""var:v16"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v17"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v16) , &quot;PortCall.PortCalls&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v18"" select=""ScriptNS1:DBValueExtract(string($var:v17) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v19"" select=""ScriptNS1:DBLookup(1 , string($var:v18) , string($var:v16) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v20"" select=""ScriptNS1:DBValueExtract(string($var:v19) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v21"" select=""userCSharp:StringFind(string($var:v20) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v22"" select=""userCSharp:MathAdd(string($var:v21) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v23"" select=""userCSharp:StringSize(string($var:v20))"" />
        <xsl:variable name=""var:v24"" select=""userCSharp:StringSubstring(string($var:v20) , string($var:v22) , string($var:v23))"" />
        <xsl:variable name=""var:v25"" select=""userCSharp:StringFind(string($var:v24) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v26"" select=""userCSharp:MathSubtract(string($var:v25) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v27"" select=""userCSharp:StringSubstring(string($var:v24) , &quot;1&quot; , string($var:v26))"" />
        <ns0:SN_DANo>
          <xsl:value-of select=""$var:v27"" />
        </ns0:SN_DANo>
        <ns0:SN_DaType>
          <xsl:value-of select=""$var:v28"" />
        </ns0:SN_DaType>
        <xsl:variable name=""var:v29"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v30"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v29) , &quot;PortCall.PortCalls&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v31"" select=""ScriptNS1:DBValueExtract(string($var:v30) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v32"" select=""ScriptNS1:DBLookup(1 , string($var:v31) , string($var:v29) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v33"" select=""ScriptNS1:DBValueExtract(string($var:v32) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v34"" select=""userCSharp:StringFind(string($var:v33) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v35"" select=""userCSharp:MathAdd(string($var:v34) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v36"" select=""userCSharp:StringSize(string($var:v33))"" />
        <xsl:variable name=""var:v37"" select=""userCSharp:StringSubstring(string($var:v33) , string($var:v35) , string($var:v36))"" />
        <xsl:variable name=""var:v38"" select=""userCSharp:StringFind(string($var:v37) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v39"" select=""userCSharp:MathAdd(string($var:v38) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v40"" select=""userCSharp:StringSize(string($var:v37))"" />
        <xsl:variable name=""var:v41"" select=""userCSharp:StringSubstring(string($var:v37) , string($var:v39) , string($var:v40))"" />
        <xsl:variable name=""var:v42"" select=""userCSharp:StringFind(string($var:v41) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v43"" select=""userCSharp:MathAdd(string($var:v42) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v44"" select=""userCSharp:StringSize(string($var:v41))"" />
        <xsl:variable name=""var:v45"" select=""userCSharp:StringSubstring(string($var:v41) , string($var:v43) , string($var:v44))"" />
        <ns0:SN_VoyageNumber>
          <xsl:value-of select=""$var:v45"" />
        </ns0:SN_VoyageNumber>
        <xsl:variable name=""var:v46"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v47"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v46) , &quot;PortCall.PortCalls&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v48"" select=""ScriptNS1:DBValueExtract(string($var:v47) , &quot;FlowStatusId&quot;)"" />
        <xsl:variable name=""var:v49"" select=""ScriptNS1:DBLookup(2 , string($var:v48) , string($var:v46) , &quot;[Master].[HubPrincipalStatuses]&quot; , &quot;id&quot;)"" />
        <xsl:variable name=""var:v50"" select=""ScriptNS1:DBValueExtract(string($var:v49) , &quot;Name&quot;)"" />
        <ns0:WorkflowStatus>
          <xsl:value-of select=""$var:v50"" />
        </ns0:WorkflowStatus>
        <ns0:DaDate>
          <xsl:value-of select=""InputMessagePart_0/s0:DA/Header/DADate/text()"" />
        </ns0:DaDate>
        <ns0:InvoiceNo>
          <xsl:value-of select=""InputMessagePart_0/s0:DA/Header/DANumber/text()"" />
        </ns0:InvoiceNo>
        <ns0:InvoiceDate>
          <xsl:value-of select=""$var:v3"" />
        </ns0:InvoiceDate>
        <ns0:DaCurrencyCode>
          <xsl:value-of select=""$var:v51"" />
        </ns0:DaCurrencyCode>
        <ns0:YourIssCurrencyCode>
          <xsl:value-of select=""$var:v51"" />
        </ns0:YourIssCurrencyCode>
        <ns0:YourIssExchangeRate>
          <xsl:value-of select=""$var:v52"" />
        </ns0:YourIssExchangeRate>
        <xsl:for-each select=""InputMessagePart_0/s0:DA"">
          <xsl:variable name=""var:v53"" select=""userCSharp:InitCumulativeSum(0)"" />
          <xsl:for-each select=""Details/Detail"">
            <xsl:variable name=""var:v54"" select=""userCSharp:GetDALineCount(string(IsActive/text()))"" />
            <xsl:variable name=""var:v55"" select=""userCSharp:AddToCumulativeSum(0,string($var:v54),&quot;2&quot;)"" />
          </xsl:for-each>
          <xsl:variable name=""var:v56"" select=""userCSharp:GetCumulativeSum(0)"" />
          <xsl:variable name=""var:v57"" select=""userCSharp:LogicalGt(string($var:v56) , &quot;0&quot;)"" />
          <xsl:if test=""string($var:v57)='true'"">
            <xsl:variable name=""var:v58"" select=""string($var:v56)"" />
            <ns0:DaLineCount>
              <xsl:value-of select=""$var:v58"" />
            </ns0:DaLineCount>
          </xsl:if>
        </xsl:for-each>
        <ns0:Lines>
          <xsl:for-each select=""InputMessagePart_0/s0:DA/Details/Detail"">
            <xsl:variable name=""var:v59"" select=""string(IsActive/text())"" />
            <xsl:variable name=""var:v60"" select=""userCSharp:LogicalEq($var:v59 , &quot;1&quot;)"" />
            <xsl:if test=""$var:v60"">
              <xsl:variable name=""var:v61"" select=""userCSharp:StringTrimLeft(string(../../Header/HubPrincipalKey/text()))"" />
              <xsl:variable name=""var:v62"" select=""userCSharp:StringTrimRight(string($var:v61))"" />
              <xsl:variable name=""var:v63"" select=""userCSharp:StringConcat(string($var:v62) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v70"" select=""string(../../Header/HubPrincipalKey/text())"" />
              <xsl:variable name=""var:v71"" select=""userCSharp:StringTrimLeft($var:v70)"" />
              <xsl:variable name=""var:v72"" select=""userCSharp:StringTrimRight(string($var:v71))"" />
              <xsl:variable name=""var:v73"" select=""userCSharp:StringConcat(string($var:v72) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v77"" select=""string(ISSServiceId/text())"" />
              <ns0:DaLine>
                <xsl:variable name=""var:v64"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v65"" select=""ScriptNS1:DBLookup(3 , string($var:v63) , string($var:v64) , &quot;Master.HubPrincipals&quot; , &quot;cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v66"" select=""ScriptNS1:DBValueExtract(string($var:v65) , &quot;id&quot;)"" />
                <xsl:variable name=""var:v67"" select=""userCSharp:StringConcat(string($var:v66) , &quot;|&quot; , string(ISSServiceId/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v68"" select=""ScriptNS1:DBLookup(4 , string($var:v67) , string($var:v64) , &quot;master.HubPrincipalServiceMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ cast(ISSServiceId as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v69"" select=""ScriptNS1:DBValueExtract(string($var:v68) , &quot;Code&quot;)"" />
                <ns0:ServiceLineCode>
                  <xsl:value-of select=""$var:v69"" />
                </ns0:ServiceLineCode>
                <xsl:variable name=""var:v74"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v75"" select=""ScriptNS1:DBLookup(3 , string($var:v73) , string($var:v74) , &quot;Master.HubPrincipals&quot; , &quot;cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v76"" select=""ScriptNS1:DBValueExtract(string($var:v75) , &quot;id&quot;)"" />
                <xsl:variable name=""var:v78"" select=""userCSharp:StringConcat(string($var:v76) , &quot;|&quot; , $var:v77 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v79"" select=""ScriptNS1:DBLookup(4 , string($var:v78) , string($var:v74) , &quot;master.HubPrincipalServiceMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ cast(ISSServiceId as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v80"" select=""ScriptNS1:DBValueExtract(string($var:v79) , &quot;Name&quot;)"" />
                <ns0:ServiceLineName>
                  <xsl:value-of select=""$var:v80"" />
                </ns0:ServiceLineName>
                <ns0:Amount>
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""../../Header/DACurrency/text()"" />
                  </ns0:CurrencyCode>
                  <ns0:Amount>
                    <xsl:value-of select=""DACurrencyAmount/text()"" />
                  </ns0:Amount>
                </ns0:Amount>
                <ns0:YourIssAmount>
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""../../Header/DACurrency/text()"" />
                  </ns0:CurrencyCode>
                  <ns0:Amount>
                    <xsl:value-of select=""DACurrencyAmount/text()"" />
                  </ns0:Amount>
                </ns0:YourIssAmount>
              </ns0:DaLine>
            </xsl:if>
          </xsl:for-each>
        </ns0:Lines>
        <ns0:DocumentCount>
          <xsl:value-of select=""$var:v81"" />
        </ns0:DocumentCount>
        <ns0:Documents>
          <xsl:for-each select=""InputMessagePart_1/s1:Documents/Document"">
            <ns0:Document>
              <xsl:value-of select=""./text()"" />
            </ns0:Document>
          </xsl:for-each>
          <xsl:value-of select=""InputMessagePart_1/s1:Documents/text()"" />
        </ns0:Documents>
      </ns0:DisbursementAccount>
    </ns0:YourIssNotification>
    <xsl:variable name=""var:v82"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public string StringTrimRight(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimEnd(null);
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringConcat(string param0, string param1, string param2, string param3, string param4)
{
   return param0 + param1 + param2 + param3 + param4;
}


public int StringFind(string str, string strFind)
{
	if (str == null || strFind == null || strFind == """")
	{
		return 0;
	}
	return (str.IndexOf(strFind) + 1);
}


public string MathSubtract(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	bool first = true;
	foreach (string obj in listValues)
	{
		if (first)
		{
			first = false;
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret = d;
			}
			else
			{
				return """";
			}
		}
		else
		{
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret -= d;
			}
			else
			{
				return """";
			}
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string StringSubstring(string str, string left, string right)
{
	string retval = """";
	double dleft = 0;
	double dright = 0;
	if (str != null && IsNumeric(left, ref dleft) && IsNumeric(right, ref dright))
	{
		int lt = (int)dleft;
		int rt = (int)dright;
		lt--; rt--;
		if (lt >= 0 && rt >= lt && lt < str.Length)
		{
			if (rt < str.Length)
			{
				retval = str.Substring(lt, rt-lt+1);
			}
			else
			{
				retval = str.Substring(lt, str.Length-lt);
			}
		}
	}
	return retval;
}


public string MathAdd(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	foreach (string obj in listValues)
	{
	double d = 0;
		if (IsNumeric(obj, ref d))
		{
			ret += d;
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public int StringSize(string str)
{
	if (str == null)
	{
		return 0;
	}
	return str.Length;
}


public string StringConcat(string param0)
{
   return param0;
}


public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public int GetDALineCount ( string  IsActive  )
{
  
       if  (    IsActive  ==""1""  ) 
           return 1;
       else return 0;
}

public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public bool LogicalGt(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 > d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) > 0;
	}
	return ret;
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_SplittedFinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_SplittedFinalDA _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_Documents";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_Documents _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_SplittedFinalDA";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_Documents";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
                return _TrgSchemas;
            }
        }
    }
}

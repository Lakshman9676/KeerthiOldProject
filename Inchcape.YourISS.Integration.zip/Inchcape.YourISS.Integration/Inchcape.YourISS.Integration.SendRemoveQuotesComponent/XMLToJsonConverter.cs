﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.BizTalk.Component.Interop;
using System.Diagnostics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Inchcape.YourISS.Integration.PipeLineComponent
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Encoder)]
    [System.Runtime.InteropServices.Guid("B0BD3E25-C6D2-4BA9-9985-6EF783800B55")]
    public class XMLToJsonConverter : IBaseComponent, IComponentUI, IComponent, IPersistPropertyBag
    {
        public string Description
        {
            get
            {
                return "Pipeline component used to remove the double quotes in Json";
            }
        }

        public string Name
        {
            get
            {
                return "XMLToJsonConverterPipeline";
            }
        }

        public string Version
        {
            get
            {
                return "1.0.0.0";
            }
        }

        public IntPtr Icon
        {
            get
            {
                return new System.IntPtr();
            }
        }

        public System.Collections.IEnumerator Validate(object projectSystem)
        {
            return null;
        }


        public void GetClassID(out Guid classID)
        {
            classID = new Guid("7662071B-9801-48A5-82F6-AA3A8657CCF3");
        }

        public void InitNew()
        {
        }

        //public System.Collections.IEnumerator Validate(object projectSystem)
        //{
        //    return null;
        //}

        public void Load(IPropertyBag propertyBag, int errorLog)
        {

        }

        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {

        }

        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {
            string xmlString;
            System.Diagnostics.EventLog.WriteEntry("Application", "XMLToJsonConverter Pipeline – Entered Execute()");
            //System.Diagnostics.EventLog.WriteEntry("Application", "XMLToJsonConverter Pipeline – RootNode:" + RootNode);
            var originalStream = pInMsg.BodyPart.GetOriginalDataStream();
            using (TextReader reader = new StreamReader(originalStream))
            {
                xmlString = reader.ReadToEnd();
                //json = _Prefix + json + _Suffix;

            }
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);

            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Read XML Data: " + xmlString);
            System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Serializing JSON to XML…");

            string jsonText = JsonConvert.SerializeXmlNode(xmlDoc);


            var portCallString = JObject.Parse(jsonText).SelectToken("FinanceDetail").ToString();

            JObject data = JObject.Parse(portCallString.ToString());
            string portCallNumber = data["portCall"].ToString();

            string removedString = portCallString.Replace("\"" + portCallNumber + "\"", portCallNumber);

            try
            {
                var output = Encoding.ASCII.GetBytes(removedString);
                var memoryStream = new MemoryStream();
                memoryStream.Write(output, 0, output.Length);
                memoryStream.Position = 0;
                pInMsg.BodyPart.Data = memoryStream;

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "JsonToXmlConverter Pipeline – Exception:" + ex.Message);
            }
            pInMsg.BodyPart.Data.Position = 0;

            return pInMsg;

        }

    }
}

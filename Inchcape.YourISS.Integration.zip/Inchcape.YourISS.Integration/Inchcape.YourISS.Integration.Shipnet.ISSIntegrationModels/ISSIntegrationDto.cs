﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.EnterpriseServices;
using System.Runtime.Serialization;

namespace Inchcape.YourISS.Integration.Shipnet.ISSIntegrationModels
{
    [DataContract(Name = "ISSIntegrationDto", Namespace = "http://iss-shipping.com/marine/integration")]
    public class ISSIntegrationDto
    {

        [DataMember]
        public string Version { get; set; }
        [DataMember]
        public string MessageVersion { get; set; }
        [DataMember]
        public string Header { get; set; }
        [DataMember]
        public string SourceIntegrationSystem { get; set; }
        [DataMember]
        public string DestinationIntegrationSystem { get; set; }
        [DataMember]
        public Guid  AccountId { get; set; }
        [DataMember]
        public string Method { get; set; }
        [DataMember]
        public byte[] Body { get; set; }
        [DataMember]
        public DateTime DateCreate { get; set; }
        [DataMember]
        public Guid MessageId { get; set; }
        
    }

    [Serializable]
    [DataContract(Name = "Response", Namespace = "http://iss-shipping.com/marine/integration" )]
    public class Response
    {
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember(Name="AckBy", IsRequired = false)]
        public string AckBy { get; set; }
        [DataMember(Name = "AckNo", IsRequired = false)]
        public string AckNo { get; set; }
    }
}

namespace Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Schema.Schema_PDA_CE_Documents", typeof(global::Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Schema.Schema_PDA_CE_Documents))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA))]
    public sealed class Map_YourISSProformaCloseEst_To_GenericProformaCloseEst : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s3 s1 s2 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Schema.YourISS.ProformaCloseEstimate"" xmlns:s3=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schemas.FinalDA"" xmlns:s1=""http://Inchcape.YourISS.Integration.PDA.CE.Schema.Documents"" xmlns:s2=""http://Inchcape.YourISS.Integration.Generic.Schema.ProformaCloseEstimateAppt"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s3:Root"" />
  </xsl:template>
  <xsl:template match=""/s3:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;DisbursementAccount&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;Save&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(InputMessagePart_1/s2:ProformaCloseEstAppt/ApptNumber/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <xsl:variable name=""var:v17"" select=""string(InputMessagePart_1/s2:ProformaCloseEstAppt/ApptNumber/text())"" />
    <xsl:variable name=""var:v18"" select=""userCSharp:StringConcat($var:v17 , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v33"" select=""userCSharp:StringConcat(&quot;ISS&quot;)"" />
    <xsl:variable name=""var:v60"" select=""InputMessagePart_0/s0:YourIss2Finance/services[1]/HomeCurrency/text()"" />
    <xsl:variable name=""var:v61"" select=""userCSharp:StringConcat(&quot;1&quot;)"" />
    <ns0:YourIssNotification>
      <ns0:MessageHeader>
        <ns0:MessageType>
          <xsl:value-of select=""$var:v1"" />
        </ns0:MessageType>
        <ns0:Action>
          <xsl:value-of select=""$var:v2"" />
        </ns0:Action>
        <ns0:CreatedDate>
          <xsl:value-of select=""$var:v3"" />
        </ns0:CreatedDate>
        <xsl:variable name=""var:v5"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v6"" select=""ScriptNS1:DBLookup(0 , string($var:v4) , string($var:v5) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v7"" select=""ScriptNS1:DBValueExtract(string($var:v6) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(1 , string($var:v7) , string($var:v5) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v10"" select=""ScriptNS1:DBLookup(2 , string($var:v9) , string($var:v5) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v11"" select=""ScriptNS1:DBValueExtract(string($var:v10) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v12"" select=""userCSharp:StringFind(string($var:v11) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v13"" select=""userCSharp:MathSubtract(string($var:v12) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v14"" select=""userCSharp:StringSubstring(string($var:v11) , &quot;1&quot; , string($var:v13))"" />
        <ns0:ShipNetReference>
          <xsl:value-of select=""$var:v14"" />
        </ns0:ShipNetReference>
        <ns0:SourceApplication>
          <xsl:value-of select=""$var:v15"" />
        </ns0:SourceApplication>
      </ns0:MessageHeader>
      <ns0:DisbursementAccount>
        <xsl:variable name=""var:v16"" select=""userCSharp:GetStage(string(InputMessagePart_1/s2:ProformaCloseEstAppt/MsgType/text()))"" />
        <ns0:Stage>
          <xsl:value-of select=""$var:v16"" />
        </ns0:Stage>
        <xsl:variable name=""var:v19"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v20"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v19) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v21"" select=""ScriptNS1:DBValueExtract(string($var:v20) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v22"" select=""ScriptNS1:DBLookup(1 , string($var:v21) , string($var:v19) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v23"" select=""ScriptNS1:DBValueExtract(string($var:v22) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v24"" select=""ScriptNS1:DBLookup(2 , string($var:v23) , string($var:v19) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v25"" select=""ScriptNS1:DBValueExtract(string($var:v24) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v26"" select=""userCSharp:StringFind(string($var:v25) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v27"" select=""userCSharp:MathAdd(string($var:v26) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v28"" select=""userCSharp:StringSize(string($var:v25))"" />
        <xsl:variable name=""var:v29"" select=""userCSharp:StringSubstring(string($var:v25) , string($var:v27) , string($var:v28))"" />
        <xsl:variable name=""var:v30"" select=""userCSharp:StringFind(string($var:v29) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v31"" select=""userCSharp:MathSubtract(string($var:v30) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v32"" select=""userCSharp:StringSubstring(string($var:v29) , &quot;1&quot; , string($var:v31))"" />
        <ns0:SN_DANo>
          <xsl:value-of select=""$var:v32"" />
        </ns0:SN_DANo>
        <ns0:SN_DaType>
          <xsl:value-of select=""$var:v33"" />
        </ns0:SN_DaType>
        <xsl:variable name=""var:v34"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v35"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v34) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v36"" select=""ScriptNS1:DBValueExtract(string($var:v35) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v37"" select=""ScriptNS1:DBLookup(1 , string($var:v36) , string($var:v34) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v38"" select=""ScriptNS1:DBValueExtract(string($var:v37) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v39"" select=""ScriptNS1:DBLookup(2 , string($var:v38) , string($var:v34) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v40"" select=""ScriptNS1:DBValueExtract(string($var:v39) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v41"" select=""userCSharp:StringFind(string($var:v40) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v42"" select=""userCSharp:MathAdd(string($var:v41) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v43"" select=""userCSharp:StringSize(string($var:v40))"" />
        <xsl:variable name=""var:v44"" select=""userCSharp:StringSubstring(string($var:v40) , string($var:v42) , string($var:v43))"" />
        <xsl:variable name=""var:v45"" select=""userCSharp:StringFind(string($var:v44) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v46"" select=""userCSharp:MathAdd(string($var:v45) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v47"" select=""userCSharp:StringSize(string($var:v44))"" />
        <xsl:variable name=""var:v48"" select=""userCSharp:StringSubstring(string($var:v44) , string($var:v46) , string($var:v47))"" />
        <xsl:variable name=""var:v49"" select=""userCSharp:StringFind(string($var:v48) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v50"" select=""userCSharp:MathAdd(string($var:v49) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v51"" select=""userCSharp:StringSize(string($var:v48))"" />
        <xsl:variable name=""var:v52"" select=""userCSharp:StringSubstring(string($var:v48) , string($var:v50) , string($var:v51))"" />
        <ns0:SN_VoyageNumber>
          <xsl:value-of select=""$var:v52"" />
        </ns0:SN_VoyageNumber>
        <xsl:variable name=""var:v53"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v54"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v53) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v55"" select=""ScriptNS1:DBValueExtract(string($var:v54) , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v56"" select=""ScriptNS1:DBLookup(1 , string($var:v55) , string($var:v53) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v57"" select=""ScriptNS1:DBValueExtract(string($var:v56) , &quot;FlowStatusId&quot;)"" />
        <xsl:variable name=""var:v58"" select=""ScriptNS1:DBLookup(3 , string($var:v57) , string($var:v53) , &quot;[Master].[HubPrincipalStatuses]&quot; , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v59"" select=""ScriptNS1:DBValueExtract(string($var:v58) , &quot;Name&quot;)"" />
        <ns0:WorkflowStatus>
          <xsl:value-of select=""$var:v59"" />
        </ns0:WorkflowStatus>
        <ns0:DaDate>
          <xsl:value-of select=""$var:v3"" />
        </ns0:DaDate>
        <ns0:DaCurrencyCode>
          <xsl:value-of select=""$var:v60"" />
        </ns0:DaCurrencyCode>
        <ns0:YourIssCurrencyCode>
          <xsl:value-of select=""$var:v60"" />
        </ns0:YourIssCurrencyCode>
        <ns0:YourIssExchangeRate>
          <xsl:value-of select=""$var:v61"" />
        </ns0:YourIssExchangeRate>
        <xsl:variable name=""var:v62"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v63"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v62) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v64"" select=""ScriptNS1:DBValueExtract(string($var:v63) , &quot;PrefundingReceived&quot;)"" />
        <xsl:variable name=""var:v65"" select=""userCSharp:PrefundingReceived(string($var:v64))"" />
        <ns0:AdvancePayment>
          <xsl:value-of select=""$var:v65"" />
        </ns0:AdvancePayment>
        <xsl:variable name=""var:v66"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v67"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v66) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v68"" select=""ScriptNS1:DBValueExtract(string($var:v67) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v69"" select=""userCSharp:StringConcat(string($var:v68) , &quot;|&quot; , &quot;1&quot;)"" />
        <xsl:variable name=""var:v70"" select=""ScriptNS1:DBLookup(4 , string($var:v69) , string($var:v66) , &quot;Appointment.AppointmentCostCenters&quot; , &quot;cast ( AppointmentId  as varchar(20) ) + '|' + cast ( isactive as varchar(1)  )&quot;)"" />
        <xsl:variable name=""var:v71"" select=""ScriptNS1:DBValueExtract(string($var:v70) , &quot;Number&quot;)"" />
        <ns0:CostCentreId>
          <xsl:value-of select=""$var:v71"" />
        </ns0:CostCentreId>
        <ns0:PerformingAgent>
          <xsl:variable name=""var:v72"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v73"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v72) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v74"" select=""ScriptNS1:DBValueExtract(string($var:v73) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v75"" select=""userCSharp:StringConcat(string($var:v74) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v76"" select=""ScriptNS1:DBLookup(5 , string($var:v75) , string($var:v72) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v77"" select=""ScriptNS1:DBValueExtract(string($var:v76) , &quot;Name&quot;)"" />
          <ns0:Name>
            <xsl:value-of select=""$var:v77"" />
          </ns0:Name>
          <xsl:variable name=""var:v78"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v79"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v78) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v80"" select=""ScriptNS1:DBValueExtract(string($var:v79) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v81"" select=""userCSharp:StringConcat(string($var:v80) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v82"" select=""ScriptNS1:DBLookup(5 , string($var:v81) , string($var:v78) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v83"" select=""ScriptNS1:DBValueExtract(string($var:v82) , &quot;MailingAddressId&quot;)"" />
          <xsl:variable name=""var:v84"" select=""userCSharp:StringConcat(string($var:v83) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v85"" select=""ScriptNS1:DBLookup(6 , string($var:v84) , string($var:v78) , &quot;Master.Addresses&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast (  isactive as varchar (1) )&quot;)"" />
          <xsl:variable name=""var:v86"" select=""ScriptNS1:DBValueExtract(string($var:v85) , &quot;CountryId&quot;)"" />
          <xsl:variable name=""var:v87"" select=""ScriptNS1:DBLookup(7 , string($var:v86) , string($var:v78) , &quot;Master.Countries&quot; , &quot;cast ( id as varchar(20) )&quot;)"" />
          <xsl:variable name=""var:v88"" select=""ScriptNS1:DBValueExtract(string($var:v87) , &quot;Code&quot;)"" />
          <ns0:CountryCode>
            <xsl:value-of select=""$var:v88"" />
          </ns0:CountryCode>
          <xsl:variable name=""var:v89"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v90"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v89) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v91"" select=""ScriptNS1:DBValueExtract(string($var:v90) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v92"" select=""userCSharp:StringConcat(string($var:v91) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v93"" select=""ScriptNS1:DBLookup(5 , string($var:v92) , string($var:v89) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v94"" select=""ScriptNS1:DBValueExtract(string($var:v93) , &quot;Code&quot;)"" />
          <ns0:ISS_AgentCode>
            <xsl:value-of select=""$var:v94"" />
          </ns0:ISS_AgentCode>
          <xsl:variable name=""var:v95"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v96"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v95) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v97"" select=""ScriptNS1:DBValueExtract(string($var:v96) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v98"" select=""userCSharp:StringConcat(string($var:v97) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v99"" select=""ScriptNS1:DBLookup(5 , string($var:v98) , string($var:v95) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v100"" select=""ScriptNS1:DBValueExtract(string($var:v99) , &quot;MailingAddressId&quot;)"" />
          <xsl:variable name=""var:v101"" select=""userCSharp:StringConcat(string($var:v100) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v102"" select=""ScriptNS1:DBLookup(6 , string($var:v101) , string($var:v95) , &quot;Master.Addresses&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast (  isactive as varchar (1) )&quot;)"" />
          <xsl:variable name=""var:v103"" select=""ScriptNS1:DBValueExtract(string($var:v102) , &quot;AddressLine1&quot;)"" />
          <ns0:AddressLine1>
            <xsl:value-of select=""$var:v103"" />
          </ns0:AddressLine1>
          <xsl:variable name=""var:v104"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v105"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v104) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v106"" select=""ScriptNS1:DBValueExtract(string($var:v105) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v107"" select=""userCSharp:StringConcat(string($var:v106) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v108"" select=""ScriptNS1:DBLookup(5 , string($var:v107) , string($var:v104) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v109"" select=""ScriptNS1:DBValueExtract(string($var:v108) , &quot;MailingAddressId&quot;)"" />
          <xsl:variable name=""var:v110"" select=""userCSharp:StringConcat(string($var:v109) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v111"" select=""ScriptNS1:DBLookup(6 , string($var:v110) , string($var:v104) , &quot;Master.Addresses&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast (  isactive as varchar (1) )&quot;)"" />
          <xsl:variable name=""var:v112"" select=""ScriptNS1:DBValueExtract(string($var:v111) , &quot;AddressLine2&quot;)"" />
          <ns0:AddressLine2>
            <xsl:value-of select=""$var:v112"" />
          </ns0:AddressLine2>
          <xsl:variable name=""var:v113"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v114"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v113) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v115"" select=""ScriptNS1:DBValueExtract(string($var:v114) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v116"" select=""userCSharp:StringConcat(string($var:v115) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v117"" select=""ScriptNS1:DBLookup(5 , string($var:v116) , string($var:v113) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v118"" select=""ScriptNS1:DBValueExtract(string($var:v117) , &quot;MailingAddressId&quot;)"" />
          <xsl:variable name=""var:v119"" select=""userCSharp:StringConcat(string($var:v118) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v120"" select=""ScriptNS1:DBLookup(6 , string($var:v119) , string($var:v113) , &quot;Master.Addresses&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast (  isactive as varchar (1) )&quot;)"" />
          <xsl:variable name=""var:v121"" select=""ScriptNS1:DBValueExtract(string($var:v120) , &quot;AddressLine3&quot;)"" />
          <ns0:AddressLine3>
            <xsl:value-of select=""$var:v121"" />
          </ns0:AddressLine3>
          <xsl:variable name=""var:v122"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v123"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v122) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v124"" select=""ScriptNS1:DBValueExtract(string($var:v123) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v125"" select=""userCSharp:StringConcat(string($var:v124) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v126"" select=""ScriptNS1:DBLookup(5 , string($var:v125) , string($var:v122) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v127"" select=""ScriptNS1:DBValueExtract(string($var:v126) , &quot;EmailAddress&quot;)"" />
          <ns0:Email>
            <xsl:value-of select=""$var:v127"" />
          </ns0:Email>
          <xsl:variable name=""var:v128"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v129"" select=""ScriptNS1:DBLookup(0 , string($var:v18) , string($var:v128) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v130"" select=""ScriptNS1:DBValueExtract(string($var:v129) , &quot;PerformingAgentId&quot;)"" />
          <xsl:variable name=""var:v131"" select=""userCSharp:StringConcat(string($var:v130) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v132"" select=""ScriptNS1:DBLookup(5 , string($var:v131) , string($var:v128) , &quot;Master.Companies&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast ( isActive as varchar(10)  )&quot;)"" />
          <xsl:variable name=""var:v133"" select=""ScriptNS1:DBValueExtract(string($var:v132) , &quot;MailingAddressId&quot;)"" />
          <xsl:variable name=""var:v134"" select=""userCSharp:StringConcat(string($var:v133) , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v135"" select=""ScriptNS1:DBLookup(6 , string($var:v134) , string($var:v128) , &quot;Master.Addresses&quot; , &quot;cast ( id as varchar(20) ) + '|' + cast (  isactive as varchar (1) )&quot;)"" />
          <xsl:variable name=""var:v136"" select=""ScriptNS1:DBValueExtract(string($var:v135) , &quot;Telephone&quot;)"" />
          <ns0:Phone>
            <xsl:value-of select=""$var:v136"" />
          </ns0:Phone>
        </ns0:PerformingAgent>
        <xsl:for-each select=""InputMessagePart_0"">
          <xsl:variable name=""var:v137"" select=""userCSharp:InitCumulativeSum(0)"" />
          <xsl:for-each select=""s0:YourIss2Finance/services"">
            <xsl:variable name=""var:v138"" select=""userCSharp:GetDALineCount(string(IsActive/text()))"" />
            <xsl:variable name=""var:v139"" select=""userCSharp:AddToCumulativeSum(0,string($var:v138),&quot;2&quot;)"" />
          </xsl:for-each>
          <xsl:variable name=""var:v140"" select=""userCSharp:GetCumulativeSum(0)"" />
          <xsl:variable name=""var:v141"" select=""userCSharp:LogicalGt(string($var:v140) , &quot;0&quot;)"" />
          <xsl:if test=""string($var:v141)='true'"">
            <xsl:variable name=""var:v142"" select=""string($var:v140)"" />
            <ns0:DaLineCount>
              <xsl:value-of select=""$var:v142"" />
            </ns0:DaLineCount>
          </xsl:if>
        </xsl:for-each>
        <ns0:Lines>
          <xsl:for-each select=""InputMessagePart_0/s0:YourIss2Finance/services"">
            <xsl:variable name=""var:v143"" select=""string(IsActive/text())"" />
            <xsl:variable name=""var:v144"" select=""userCSharp:LogicalEq($var:v143 , &quot;true&quot;)"" />
            <xsl:if test=""$var:v144"">
              <xsl:variable name=""var:v145"" select=""userCSharp:StringConcat(string(../../../InputMessagePart_1/s2:ProformaCloseEstAppt/ApptNumber/text()) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v161"" select=""string(../../../InputMessagePart_1/s2:ProformaCloseEstAppt/ApptNumber/text())"" />
              <xsl:variable name=""var:v162"" select=""userCSharp:StringConcat($var:v161 , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v175"" select=""string(IssService/Id/text())"" />
              <ns0:DaLine>
                <xsl:variable name=""var:v146"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v147"" select=""ScriptNS1:DBLookup(0 , string($var:v145) , string($var:v146) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v148"" select=""ScriptNS1:DBValueExtract(string($var:v147) , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v149"" select=""ScriptNS1:DBLookup(1 , string($var:v148) , string($var:v146) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v150"" select=""ScriptNS1:DBValueExtract(string($var:v149) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v151"" select=""ScriptNS1:DBLookup(2 , string($var:v150) , string($var:v146) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v152"" select=""ScriptNS1:DBValueExtract(string($var:v151) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v153"" select=""userCSharp:StringTrimLeft(string($var:v152))"" />
                <xsl:variable name=""var:v154"" select=""userCSharp:StringTrimRight(string($var:v153))"" />
                <xsl:variable name=""var:v155"" select=""userCSharp:StringConcat(string($var:v154) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v156"" select=""ScriptNS1:DBLookup(8 , string($var:v155) , string($var:v146) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v157"" select=""ScriptNS1:DBValueExtract(string($var:v156) , &quot;id&quot;)"" />
                <xsl:variable name=""var:v158"" select=""userCSharp:StringConcat(string($var:v157) , &quot;|&quot; , string(IssService/Id/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v159"" select=""ScriptNS1:DBLookup(9 , string($var:v158) , string($var:v146) , &quot;master.HubPrincipalServiceMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ cast(ISSServiceId as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v160"" select=""ScriptNS1:DBValueExtract(string($var:v159) , &quot;Code&quot;)"" />
                <ns0:ServiceLineCode>
                  <xsl:value-of select=""$var:v160"" />
                </ns0:ServiceLineCode>
                <xsl:variable name=""var:v163"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v164"" select=""ScriptNS1:DBLookup(0 , string($var:v162) , string($var:v163) , &quot;Appointment.Appointments&quot; , &quot; cast(Number as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v165"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v166"" select=""ScriptNS1:DBLookup(1 , string($var:v165) , string($var:v163) , &quot;PortCall.PortCalls&quot; , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v167"" select=""ScriptNS1:DBValueExtract(string($var:v166) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v168"" select=""ScriptNS1:DBLookup(2 , string($var:v167) , string($var:v163) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v169"" select=""ScriptNS1:DBValueExtract(string($var:v168) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v170"" select=""userCSharp:StringTrimLeft(string($var:v169))"" />
                <xsl:variable name=""var:v171"" select=""userCSharp:StringTrimRight(string($var:v170))"" />
                <xsl:variable name=""var:v172"" select=""userCSharp:StringConcat(string($var:v171) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v173"" select=""ScriptNS1:DBLookup(8 , string($var:v172) , string($var:v163) , &quot;Master.HubPrincipals&quot; , &quot; cast(HubPrincipalKey as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v174"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;id&quot;)"" />
                <xsl:variable name=""var:v176"" select=""userCSharp:StringConcat(string($var:v174) , &quot;|&quot; , $var:v175 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v177"" select=""ScriptNS1:DBLookup(9 , string($var:v176) , string($var:v163) , &quot;master.HubPrincipalServiceMap&quot; , &quot;  cast(HubPrincipalId as varchar(40)) +'|'+ cast(ISSServiceId as varchar(40)) + '|' + cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v178"" select=""ScriptNS1:DBValueExtract(string($var:v177) , &quot;Name&quot;)"" />
                <ns0:ServiceLineName>
                  <xsl:value-of select=""$var:v178"" />
                </ns0:ServiceLineName>
                <ns0:Comment>
                  <xsl:value-of select=""Comment/text()"" />
                </ns0:Comment>
                <ns0:Amount>
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""HomeCurrency/text()"" />
                  </ns0:CurrencyCode>
                  <ns0:Amount>
                    <xsl:value-of select=""LocalAmount/text()"" />
                  </ns0:Amount>
                </ns0:Amount>
                <ns0:YourIssAmount>
                  <ns0:CurrencyCode>
                    <xsl:value-of select=""HomeCurrency/text()"" />
                  </ns0:CurrencyCode>
                  <ns0:Amount>
                    <xsl:value-of select=""LocalAmount/text()"" />
                  </ns0:Amount>
                </ns0:YourIssAmount>
              </ns0:DaLine>
            </xsl:if>
          </xsl:for-each>
        </ns0:Lines>
      </ns0:DisbursementAccount>
    </ns0:YourIssNotification>
    <xsl:variable name=""var:v179"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public string StringTrimRight(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimEnd(null);
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringConcat(string param0, string param1, string param2, string param3, string param4)
{
   return param0 + param1 + param2 + param3 + param4;
}


public int StringFind(string str, string strFind)
{
	if (str == null || strFind == null || strFind == """")
	{
		return 0;
	}
	return (str.IndexOf(strFind) + 1);
}


public string MathSubtract(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	bool first = true;
	foreach (string obj in listValues)
	{
		if (first)
		{
			first = false;
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret = d;
			}
			else
			{
				return """";
			}
		}
		else
		{
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret -= d;
			}
			else
			{
				return """";
			}
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string StringSubstring(string str, string left, string right)
{
	string retval = """";
	double dleft = 0;
	double dright = 0;
	if (str != null && IsNumeric(left, ref dleft) && IsNumeric(right, ref dright))
	{
		int lt = (int)dleft;
		int rt = (int)dright;
		lt--; rt--;
		if (lt >= 0 && rt >= lt && lt < str.Length)
		{
			if (rt < str.Length)
			{
				retval = str.Substring(lt, rt-lt+1);
			}
			else
			{
				retval = str.Substring(lt, str.Length-lt);
			}
		}
	}
	return retval;
}


public string MathAdd(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	foreach (string obj in listValues)
	{
	double d = 0;
		if (IsNumeric(obj, ref d))
		{
			ret += d;
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public int StringSize(string str)
{
	if (str == null)
	{
		return 0;
	}
	return str.Length;
}


public string StringConcat(string param0)
{
   return param0;
}


public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public int GetDALineCount ( string  IsActive  )
{
  
       if  (    IsActive  ==""true""  ) 
           return 1;
       else return 0;
}

public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public bool LogicalGt(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 > d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) > 0;
	}
	return ret;
}


public string GetStage ( string msgtype )
{
     if  (  msgtype  == ""Proforma-Services""   )
          return ""PDA"";
     else
         return ""UDA"";
}

public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public decimal PrefundingReceived ( string strPrefundingReceived )
{
         decimal PrefundingReceived = 0 ;
         decimal.TryParse (  strPrefundingReceived  ,  out  PrefundingReceived   ); 

         return PrefundingReceived ;
}

public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt _srcSchemaTypeReference1 = null;
        
        private const string _strSrcSchemasList2 = @"Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Schema.Schema_PDA_CE_Documents";
        
        private const global::Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Schema.Schema_PDA_CE_Documents _srcSchemaTypeReference2 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [3];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
                _SrcSchemas[1] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
                _SrcSchemas[2] = @"Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Schema.Schema_PDA_CE_Documents";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_FinalDA";
                return _TrgSchemas;
            }
        }
    }
}

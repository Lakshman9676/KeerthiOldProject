namespace Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate))]
    public sealed class Map_ProformaToApptUpdatedProforma : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Schema.YourISS.ProformaCloseEstimate"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/ns0:YourIss2Finance"" />
  </xsl:template>
  <xsl:template match=""/ns0:YourIss2Finance"">
    <ns0:YourIss2Finance>
      <xsl:for-each select=""services"">
        <services>
          <IssService>
            <Id>
              <xsl:value-of select=""IssService/Id/text()"" />
            </Id>
            <Code>
              <xsl:value-of select=""IssService/Code/text()"" />
            </Code>
            <Name>
              <xsl:value-of select=""IssService/Name/text()"" />
            </Name>
          </IssService>
          <DaCurrency>
            <xsl:value-of select=""DaCurrency/text()"" />
          </DaCurrency>
          <HomeCurrency>
            <xsl:value-of select=""HomeCurrency/text()"" />
          </HomeCurrency>
          <ExchangeRate>
            <xsl:value-of select=""ExchangeRate/text()"" />
          </ExchangeRate>
          <Amount>
            <xsl:value-of select=""Amount/text()"" />
          </Amount>
          <LocalAmount>
            <xsl:value-of select=""LocalAmount/text()"" />
          </LocalAmount>
          <Comment>
            <xsl:value-of select=""Comment/text()"" />
          </Comment>
          <IsActive>
            <xsl:value-of select=""IsActive/text()"" />
          </IsActive>
        </services>
      </xsl:for-each>
    </ns0:YourIss2Finance>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_ProformaCloseEstimate";
                return _TrgSchemas;
            }
        }
    }
}

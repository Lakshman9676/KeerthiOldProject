namespace Inchcape.YourISS.Integration.Generic.ProformaCloseEst.Map {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt))]
    public sealed class Map_AppTemToApp : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schema.ProformaCloseEstimateAppt"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/ns0:ProformaCloseEstAppt"" />
  </xsl:template>
  <xsl:template match=""/ns0:ProformaCloseEstAppt"">
    <ns0:ProformaCloseEstAppt>
      <ApptNumber>
        <xsl:value-of select=""ApptNumber/text()"" />
      </ApptNumber>
      <MsgType>
        <xsl:value-of select=""MsgType/text()"" />
      </MsgType>
    </ns0:ProformaCloseEstAppt>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_ProformaCloseEstimateAppt";
                return _TrgSchemas;
            }
        }
    }
}

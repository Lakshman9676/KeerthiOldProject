﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Inchcape.YourISS.Integration.DocumentBTService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class DocumentBizService : IDocumentBizService
    {
        public string GetDocumentData(string yiss2DocPath)
        {
            String yiss2DocStreamBT = string.Empty;

            try
            {
                YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();
                yiss2DocStreamBT = obj.GetDocumentData(yiss2DocPath);
                string abc = yiss2DocStreamBT;
            }
            catch (Exception exp)
            {

            }
            finally
            {

            }

            return yiss2DocStreamBT;
        }

        public byte[] GetFirstChk(string yiss2DocPath, ref int ChunkCount, ref int ChunkSize)
        {

            YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();

            return obj.GetFirstChk(yiss2DocPath, ref ChunkCount, ref ChunkSize);
        }

        public byte[] GetFileChunk(string yiss2DocPath, int ChunkNo, int ChunkSize)
        {
            YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();

            return obj.GetFileChunk(yiss2DocPath, ChunkNo, ChunkSize);
        }

        public int ValidateIntegrationSystem(Guid AccountId)
        {
            int count = 0;
            try
            {
                YISS2DocAppService.DocumentSyncClient obj = new YISS2DocAppService.DocumentSyncClient();
                count = obj.ValidateIntegrationSystem(AccountId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return count;
        }
    }
}

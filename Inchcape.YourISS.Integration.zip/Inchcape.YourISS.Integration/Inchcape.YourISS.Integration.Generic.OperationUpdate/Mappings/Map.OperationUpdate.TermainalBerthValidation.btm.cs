namespace Inchcape.YourISS.Integration.Generic.OperationUpdate.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_Generic_OpsUpd_TerminalBerthMappingValidation", typeof(global::Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_Generic_OpsUpd_TerminalBerthMappingValidation))]
    public sealed class Map_OperationUpdate_TermainalBerthValidation : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.OperationUpdate.TerminalBerthValidation"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIss2Appointment"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIss2Appointment"">
    <xsl:variable name=""var:v29"" select=""userCSharp:StringConcat(string(Id/text()))"" />
    <ns0:TerminalCargoValidation>
      <xsl:for-each select=""Cargoes"">
        <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(string(../Id/text()))"" />
        <xsl:variable name=""var:v9"" select=""string(Rotation/Poi/Id/text())"" />
        <xsl:variable name=""var:v15"" select=""userCSharp:LogicalExistence(boolean(Rotation/Berth/Id))"" />
        <xsl:variable name=""var:v16"" select=""string(../Id/text())"" />
        <xsl:variable name=""var:v17"" select=""userCSharp:StringConcat($var:v16)"" />
        <Cargoes>
          <xsl:if test=""RefCode"">
            <RefCode>
              <xsl:value-of select=""RefCode/text()"" />
            </RefCode>
          </xsl:if>
          <Rotation>
            <Poi>
              <xsl:if test=""Rotation/Poi/Id"">
                <Id>
                  <xsl:value-of select=""Rotation/Poi/Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Rotation/Poi/Name"">
                <Name>
                  <xsl:value-of select=""Rotation/Poi/Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Rotation/Poi/Code"">
                <Code>
                  <xsl:value-of select=""Rotation/Poi/Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:variable name=""var:v1"" select=""userCSharp:PoiID(string(Rotation/Poi/Id/text()))"" />
              <xsl:variable name=""var:v3"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
              <xsl:variable name=""var:v4"" select=""ScriptNS1:DBLookup(0 , string($var:v2) , string($var:v3) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (portcallid as varchar(20))&quot;)"" />
              <xsl:variable name=""var:v5"" select=""ScriptNS1:DBValueExtract(string($var:v4) , &quot;HubPrincipalKey&quot;)"" />
              <xsl:variable name=""var:v6"" select=""userCSharp:StringConcat(string($var:v5) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v7"" select=""ScriptNS1:DBLookup(1 , string($var:v6) , string($var:v3) , &quot;Master.HubPrincipals&quot; , &quot;cast (HubPrincipalKey as varchar(70))+'|'+cast (isActive as varchar(5))&quot;)"" />
              <xsl:variable name=""var:v8"" select=""ScriptNS1:DBValueExtract(string($var:v7) , &quot;Id&quot;)"" />
              <xsl:variable name=""var:v10"" select=""userCSharp:StringConcat(string($var:v8) , &quot;|&quot; , string(../Port/Id/text()) , &quot;|&quot; , $var:v9 , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v11"" select=""ScriptNS1:DBLookup(2 , string($var:v10) , string($var:v3) , &quot;Master.HubPrincipalPOIMap&quot; , &quot;cast (HubPrincipalId as varchar(20))+'|'+cast (PortId as varchar(20))+'|'+cast (POIId as varchar(20))+'|'+cast (isActive as varchar(5))&quot;)"" />
              <xsl:variable name=""var:v12"" select=""ScriptNS1:DBValueExtract(string($var:v11) , &quot;Id&quot;)"" />
              <xsl:variable name=""var:v13"" select=""userCSharp:CheckNullValidation(string($var:v12))"" />
              <xsl:variable name=""var:v14"" select=""userCSharp:Validate(string($var:v1) , string($var:v13))"" />
              <ValidationResult>
                <xsl:value-of select=""$var:v14"" />
              </ValidationResult>
            </Poi>
            <Berth>
              <xsl:if test=""Rotation/Berth/Id"">
                <Id>
                  <xsl:value-of select=""Rotation/Berth/Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Rotation/Berth/Name"">
                <Name>
                  <xsl:value-of select=""Rotation/Berth/Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Rotation/Berth/Code"">
                <Code>
                  <xsl:value-of select=""Rotation/Berth/Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:variable name=""var:v18"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
              <xsl:variable name=""var:v19"" select=""ScriptNS1:DBLookup(0 , string($var:v17) , string($var:v18) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (portcallid as varchar(20))&quot;)"" />
              <xsl:variable name=""var:v20"" select=""ScriptNS1:DBValueExtract(string($var:v19) , &quot;HubPrincipalKey&quot;)"" />
              <xsl:variable name=""var:v21"" select=""userCSharp:StringConcat(string($var:v20) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v22"" select=""ScriptNS1:DBLookup(1 , string($var:v21) , string($var:v18) , &quot;Master.HubPrincipals&quot; , &quot;cast (HubPrincipalKey as varchar(70))+'|'+cast (isActive as varchar(5))&quot;)"" />
              <xsl:variable name=""var:v23"" select=""ScriptNS1:DBValueExtract(string($var:v22) , &quot;Id&quot;)"" />
              <xsl:variable name=""var:v24"" select=""userCSharp:StringConcat(string($var:v23) , &quot;|&quot; , string(Rotation/Berth/Id/text()) , &quot;|&quot; , string(Rotation/Berth/Code/text()) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v25"" select=""ScriptNS1:DBLookup(3 , string($var:v24) , string($var:v18) , &quot;Master.HubPrincipalBerthMap&quot; , &quot;cast (HubPrincipalId as varchar(20))+'|'+cast (BerthId as varchar(20))+'|'+cast (Code as varchar(40))+'|'+cast (isActive as varchar(5))&quot;)"" />
              <xsl:variable name=""var:v26"" select=""ScriptNS1:DBValueExtract(string($var:v25) , &quot;Id&quot;)"" />
              <xsl:variable name=""var:v27"" select=""userCSharp:CheckNullValidation(string($var:v26))"" />
              <xsl:variable name=""var:v28"" select=""userCSharp:Validate(string($var:v15) , string($var:v27))"" />
              <ValidationResult>
                <xsl:value-of select=""$var:v28"" />
              </ValidationResult>
            </Berth>
            <xsl:if test=""Rotation"">
              <xsl:value-of select=""Rotation/text()"" />
            </xsl:if>
          </Rotation>
        </Cargoes>
      </xsl:for-each>
      <xsl:if test=""Port/Code"">
        <PortCode>
          <xsl:value-of select=""Port/Code/text()"" />
        </PortCode>
      </xsl:if>
      <xsl:variable name=""var:v30"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
      <xsl:variable name=""var:v31"" select=""ScriptNS1:DBLookup(0 , string($var:v29) , string($var:v30) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;cast (portcallid as varchar(20))&quot;)"" />
      <xsl:variable name=""var:v32"" select=""ScriptNS1:DBValueExtract(string($var:v31) , &quot;HubPrincipalKey&quot;)"" />
      <xsl:variable name=""var:v33"" select=""userCSharp:StringConcat(string($var:v32) , &quot;|&quot; , &quot;1&quot;)"" />
      <xsl:variable name=""var:v34"" select=""ScriptNS1:DBLookup(1 , string($var:v33) , string($var:v30) , &quot;Master.HubPrincipals&quot; , &quot;cast (HubPrincipalKey as varchar(70))+'|'+cast (isActive as varchar(5))&quot;)"" />
      <xsl:variable name=""var:v35"" select=""ScriptNS1:DBValueExtract(string($var:v34) , &quot;Code&quot;)"" />
      <HubPrincipal>
        <xsl:value-of select=""$var:v35"" />
      </HubPrincipal>
    </ns0:TerminalCargoValidation>
    <xsl:variable name=""var:v36"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0, string param1, string param2, string param3, string param4, string param5, string param6)
{
   return param0 + param1 + param2 + param3 + param4 + param5 + param6;
}


public string StringConcat(string param0)
{
   return param0;
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string CheckNullValidation(string Id)
{
   if((Id != """") && (Id != null))
{ return ""Success"";}
  else
{return ""Failure"";}
}


public string Validate( string isExistence,    string CheckNull )
{
 

string retVal = """";
if ((CheckNull == ""Success"") && (isExistence ==""true""))
{
    retVal=""Success"";
}
if ((CheckNull != ""Success"") && (isExistence ==""true""))
{
    retVal=""Failure"";
}
if (isExistence == ""false"")
{
    retVal=""Success"";
}
return retVal;
}


public bool LogicalExistence(bool val)
{
	return val;
}


public string  PoiID ( string id )
{
      if (  id != """")
        return   ""true"" ;
     else
        return  ""false"" ;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_Generic_OpsUpd_TerminalBerthMappingValidation";
        
        private const global::Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_Generic_OpsUpd_TerminalBerthMappingValidation _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_Generic_OpsUpd_TerminalBerthMappingValidation";
                return _TrgSchemas;
            }
        }
    }
}

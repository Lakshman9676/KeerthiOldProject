namespace Inchcape.YourISS.Integration.Generic.OperationUpdate.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate))]
    public sealed class Map_OperationUpdate_YourISSToGeneric : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIss2Appointment"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIss2Appointment"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;OperationalUpdate&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;Save&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v13"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <xsl:variable name=""var:v14"" select=""string(Number/text())"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat($var:v14 , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v86"" select=""string(NextPort/Id/text())"" />
    <xsl:variable name=""var:v96"" select=""userCSharp:StringConcat(string(Appointments/Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v101"" select=""Rotations/Poi[1]/Name/text()"" />
    <xsl:variable name=""var:v102"" select=""userCSharp:LogicalEq(string($var:v101) , &quot;ANCHORAGE&quot;)"" />
    <xsl:variable name=""var:v104"" select=""userCSharp:LogicalNe(string($var:v101) , &quot;ANCHORAGE&quot;)"" />
    <ns0:YourIssNotification>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""$var:v1"" />
        </MessageType>
        <Action>
          <xsl:value-of select=""$var:v2"" />
        </Action>
        <CreatedDate>
          <xsl:value-of select=""$var:v3"" />
        </CreatedDate>
        <xsl:variable name=""var:v5"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v6"" select=""ScriptNS1:DBLookup(0 , string($var:v4) , string($var:v5) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v7"" select=""ScriptNS1:DBValueExtract(string($var:v6) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(1 , string($var:v7) , string($var:v5) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v10"" select=""userCSharp:StringFind(string($var:v9) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v11"" select=""userCSharp:MathSubtract(string($var:v10) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v12"" select=""userCSharp:StringSubstring(string($var:v9) , &quot;1&quot; , string($var:v11))"" />
        <ShipNetReference>
          <xsl:value-of select=""$var:v12"" />
        </ShipNetReference>
        <SourceApplication>
          <xsl:value-of select=""$var:v13"" />
        </SourceApplication>
      </MessageHeader>
      <Operational>
        <xsl:variable name=""var:v16"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v17"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v16) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v18"" select=""ScriptNS1:DBValueExtract(string($var:v17) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v19"" select=""ScriptNS1:DBLookup(1 , string($var:v18) , string($var:v16) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v20"" select=""ScriptNS1:DBValueExtract(string($var:v19) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v21"" select=""userCSharp:StringFind(string($var:v20) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v22"" select=""userCSharp:MathAdd(string($var:v21) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v23"" select=""userCSharp:StringSize(string($var:v20))"" />
        <xsl:variable name=""var:v24"" select=""userCSharp:StringSubstring(string($var:v20) , string($var:v22) , string($var:v23))"" />
        <xsl:variable name=""var:v25"" select=""userCSharp:StringFind(string($var:v24) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v26"" select=""userCSharp:MathSubtract(string($var:v25) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v27"" select=""userCSharp:StringSubstring(string($var:v24) , &quot;1&quot; , string($var:v26))"" />
        <SN_DANo>
          <xsl:value-of select=""$var:v27"" />
        </SN_DANo>
        <xsl:variable name=""var:v28"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v29"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v28) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v30"" select=""ScriptNS1:DBValueExtract(string($var:v29) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v31"" select=""ScriptNS1:DBLookup(1 , string($var:v30) , string($var:v28) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v32"" select=""ScriptNS1:DBValueExtract(string($var:v31) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v33"" select=""userCSharp:StringFind(string($var:v32) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v34"" select=""userCSharp:MathAdd(string($var:v33) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v35"" select=""userCSharp:StringSize(string($var:v32))"" />
        <xsl:variable name=""var:v36"" select=""userCSharp:StringSubstring(string($var:v32) , string($var:v34) , string($var:v35))"" />
        <xsl:variable name=""var:v37"" select=""userCSharp:StringFind(string($var:v36) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v38"" select=""userCSharp:MathAdd(string($var:v37) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v39"" select=""userCSharp:StringSize(string($var:v36))"" />
        <xsl:variable name=""var:v40"" select=""userCSharp:StringSubstring(string($var:v36) , string($var:v38) , string($var:v39))"" />
        <xsl:variable name=""var:v41"" select=""userCSharp:StringFind(string($var:v40) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v42"" select=""userCSharp:MathSubtract(string($var:v41) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v43"" select=""userCSharp:StringSubstring(string($var:v40) , &quot;1&quot; , string($var:v42))"" />
        <SN_KeyPosition>
          <xsl:value-of select=""$var:v43"" />
        </SN_KeyPosition>
        <xsl:variable name=""var:v44"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v45"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v44) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v46"" select=""ScriptNS1:DBValueExtract(string($var:v45) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v47"" select=""ScriptNS1:DBLookup(1 , string($var:v46) , string($var:v44) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v48"" select=""ScriptNS1:DBValueExtract(string($var:v47) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v49"" select=""userCSharp:StringFind(string($var:v48) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v50"" select=""userCSharp:MathAdd(string($var:v49) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v51"" select=""userCSharp:StringSize(string($var:v48))"" />
        <xsl:variable name=""var:v52"" select=""userCSharp:StringSubstring(string($var:v48) , string($var:v50) , string($var:v51))"" />
        <xsl:variable name=""var:v53"" select=""userCSharp:StringFind(string($var:v52) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v54"" select=""userCSharp:MathAdd(string($var:v53) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v55"" select=""userCSharp:StringSize(string($var:v52))"" />
        <xsl:variable name=""var:v56"" select=""userCSharp:StringSubstring(string($var:v52) , string($var:v54) , string($var:v55))"" />
        <xsl:variable name=""var:v57"" select=""userCSharp:StringFind(string($var:v56) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v58"" select=""userCSharp:MathAdd(string($var:v57) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v59"" select=""userCSharp:StringSize(string($var:v56))"" />
        <xsl:variable name=""var:v60"" select=""userCSharp:StringSubstring(string($var:v56) , string($var:v58) , string($var:v59))"" />
        <SN_VoyageNumber>
          <xsl:value-of select=""$var:v60"" />
        </SN_VoyageNumber>
        <xsl:if test=""Eta"">
          <ETA>
            <xsl:value-of select=""Eta/text()"" />
          </ETA>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Ets"">
          <ETS>
            <xsl:value-of select=""PortCallOperations/Ets/text()"" />
          </ETS>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Eosp"">
          <EOSP>
            <xsl:value-of select=""PortCallOperations/Eosp/text()"" />
          </EOSP>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Cosp"">
          <CommencedSeaPassage>
            <xsl:value-of select=""PortCallOperations/Cosp/text()"" />
          </CommencedSeaPassage>
        </xsl:if>
        <xsl:variable name=""var:v61"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v62"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v61) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v63"" select=""ScriptNS1:DBValueExtract(string($var:v62) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v64"" select=""ScriptNS1:DBLookup(2 , string($var:v63) , string($var:v61) , &quot;Operation.PortCallOperations&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v65"" select=""ScriptNS1:DBValueExtract(string($var:v64) , &quot;NextPortEta&quot;)"" />
        <xsl:variable name=""var:v66"" select=""userCSharp:IsNextEtaEmpty(string($var:v65))"" />
        <xsl:if test=""string($var:v66)='true'"">
          <xsl:variable name=""var:v67"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v68"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v67) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v69"" select=""ScriptNS1:DBValueExtract(string($var:v68) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v70"" select=""ScriptNS1:DBLookup(2 , string($var:v69) , string($var:v67) , &quot;Operation.PortCallOperations&quot; , &quot;PortCallId&quot;)"" />
          <xsl:variable name=""var:v71"" select=""ScriptNS1:DBValueExtract(string($var:v70) , &quot;NextPortEta&quot;)"" />
          <xsl:variable name=""var:v72"" select=""userCSharp:MyConcatETA(string($var:v71))"" />
          <EtaNextPort>
            <xsl:value-of select=""$var:v72"" />
          </EtaNextPort>
        </xsl:if>
        <xsl:variable name=""var:v73"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v74"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v73) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v75"" select=""ScriptNS1:DBValueExtract(string($var:v74) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v76"" select=""ScriptNS1:DBLookup(1 , string($var:v75) , string($var:v73) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v77"" select=""ScriptNS1:DBValueExtract(string($var:v76) , &quot;HubPrincipalId&quot;)"" />
        <xsl:variable name=""var:v78"" select=""userCSharp:StringConcat(string(NextPort/Id/text()) , &quot;|&quot; , string($var:v77))"" />
        <xsl:variable name=""var:v79"" select=""ScriptNS1:DBLookup(3 , string($var:v78) , string($var:v73) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(PortId  as varchar(10)) +'|'+ cast(HubPrincipalId  as varchar(10))&quot;)"" />
        <xsl:variable name=""var:v80"" select=""ScriptNS1:DBValueExtract(string($var:v79) , &quot;Code&quot;)"" />
        <NextPortCode>
          <xsl:value-of select=""$var:v80"" />
        </NextPortCode>
        <xsl:variable name=""var:v81"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v82"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v81) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v83"" select=""ScriptNS1:DBValueExtract(string($var:v82) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v84"" select=""ScriptNS1:DBLookup(1 , string($var:v83) , string($var:v81) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v85"" select=""ScriptNS1:DBValueExtract(string($var:v84) , &quot;HubPrincipalId&quot;)"" />
        <xsl:variable name=""var:v87"" select=""userCSharp:StringConcat($var:v86 , &quot;|&quot; , string($var:v85))"" />
        <xsl:variable name=""var:v88"" select=""ScriptNS1:DBLookup(3 , string($var:v87) , string($var:v81) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(PortId  as varchar(10)) +'|'+ cast(HubPrincipalId  as varchar(10))&quot;)"" />
        <xsl:variable name=""var:v89"" select=""ScriptNS1:DBValueExtract(string($var:v88) , &quot;Name&quot;)"" />
        <NextPortName>
          <xsl:value-of select=""$var:v89"" />
        </NextPortName>
        <xsl:variable name=""var:v90"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v91"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v90) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v92"" select=""ScriptNS1:DBValueExtract(string($var:v91) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v93"" select=""ScriptNS1:DBLookup(2 , string($var:v92) , string($var:v90) , &quot;Operation.PortCallOperations&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v94"" select=""ScriptNS1:DBValueExtract(string($var:v93) , &quot;CaptainName&quot;)"" />
        <Master>
          <xsl:value-of select=""$var:v94"" />
        </Master>
        <xsl:variable name=""var:v95"" select=""userCSharp:GetFlowStatus(string(FlowStatus/text()))"" />
        <WorkflowStatus>
          <xsl:value-of select=""$var:v95"" />
        </WorkflowStatus>
        <xsl:variable name=""var:v97"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v98"" select=""ScriptNS1:DBLookup(4 , string($var:v96) , string($var:v97) , &quot;Appointment.Appointments&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v99"" select=""ScriptNS1:DBValueExtract(string($var:v98) , &quot;IsPerformingAgentAccepted&quot;)"" />
        <xsl:variable name=""var:v100"" select=""userCSharp:IsNextEtaEmpty(string($var:v99))"" />
        <Agentacceptance>
          <xsl:value-of select=""$var:v100"" />
        </Agentacceptance>
        <xsl:if test=""string($var:v102)='true'"">
          <xsl:variable name=""var:v103"" select=""./Rotations[2]/Etb/text()"" />
          <ETB>
            <xsl:value-of select=""$var:v103"" />
          </ETB>
        </xsl:if>
        <xsl:if test=""string($var:v104)='true'"">
          <xsl:variable name=""var:v105"" select=""./Rotations[1]/Etb/text()"" />
          <ETB>
            <xsl:value-of select=""$var:v105"" />
          </ETB>
        </xsl:if>
        <xsl:variable name=""var:v106"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Cargoes"">
          <xsl:variable name=""var:v107"" select=""userCSharp:GetCargoCount(string(IsActive/text()))"" />
          <xsl:variable name=""var:v108"" select=""userCSharp:AddToCumulativeSum(0,string($var:v107),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v109"" select=""userCSharp:GetCumulativeSum(0)"" />
        <xsl:variable name=""var:v110"" select=""userCSharp:LogicalGt(string($var:v109) , &quot;0&quot;)"" />
        <xsl:if test=""string($var:v110)='true'"">
          <xsl:variable name=""var:v111"" select=""userCSharp:InitCumulativeSum(0)"" />
          <xsl:for-each select=""/s0:YourIss2Appointment/Cargoes"">
            <xsl:variable name=""var:v112"" select=""string(IsActive/text())"" />
            <xsl:variable name=""var:v113"" select=""userCSharp:GetCargoCount($var:v112)"" />
            <xsl:variable name=""var:v114"" select=""userCSharp:AddToCumulativeSum(0,string($var:v113),&quot;2&quot;)"" />
          </xsl:for-each>
          <xsl:variable name=""var:v115"" select=""userCSharp:GetCumulativeSum(0)"" />
          <CargoCount>
            <xsl:value-of select=""$var:v115"" />
          </CargoCount>
        </xsl:if>
        <xsl:variable name=""var:v116"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Cargoes"">
          <xsl:variable name=""var:v117"" select=""string(IsActive/text())"" />
          <xsl:variable name=""var:v118"" select=""userCSharp:GetCargoCount($var:v117)"" />
          <xsl:variable name=""var:v119"" select=""userCSharp:AddToCumulativeSum(0,string($var:v118),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v120"" select=""userCSharp:GetCumulativeSum(0)"" />
        <xsl:variable name=""var:v121"" select=""userCSharp:LogicalGt(string($var:v120) , &quot;0&quot;)"" />
        <xsl:if test=""$var:v121"">
          <Cargoes>
            <xsl:for-each select=""Cargoes"">
              <xsl:variable name=""var:v122"" select=""string(IsActive/text())"" />
              <xsl:variable name=""var:v123"" select=""userCSharp:LogicalEq($var:v122 , &quot;true&quot;)"" />
              <xsl:if test=""$var:v123"">
                <xsl:variable name=""var:v126"" select=""false()"" />
                <xsl:variable name=""var:v127"" select=""userCSharp:LogicalNot(string($var:v126))"" />
                <xsl:variable name=""var:v134"" select=""userCSharp:LogicalEq(string(../Drafts/Name/text()) , &quot;Arrival&quot;)"" />
                <xsl:variable name=""var:v145"" select=""string(../Number/text())"" />
                <xsl:variable name=""var:v146"" select=""userCSharp:StringConcat($var:v145 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v162"" select=""string(RefCode/text())"" />
                <Cargo>
                  <xsl:if test=""RefCode"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""RefCode/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""Rotation/Poi/Name"">
                    <Terminal>
                      <xsl:value-of select=""Rotation/Poi/Name/text()"" />
                    </Terminal>
                  </xsl:if>
                  <xsl:if test=""Rotation/Berth/Name"">
                    <Berth>
                      <xsl:value-of select=""Rotation/Berth/Name/text()"" />
                    </Berth>
                  </xsl:if>
                  <xsl:variable name=""var:v124"" select=""userCSharp:GetBLFigures(string(BillOfLadingQuantity/text()))"" />
                  <xsl:variable name=""var:v125"" select=""userCSharp:LogicalEq(string($var:v124) , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v128"" select=""userCSharp:LogicalAnd(string($var:v125) , string($var:v127))"" />
                  <xsl:if test=""string($var:v128)='true'"">
                    <xsl:variable name=""var:v129"" select=""BillOfLadingQuantity/text()"" />
                    <BlFigures>
                      <xsl:value-of select=""$var:v129"" />
                    </BlFigures>
                  </xsl:if>
                  <xsl:variable name=""var:v130"" select=""userCSharp:GetShipFig(string(VesselQuantity/text()))"" />
                  <xsl:variable name=""var:v131"" select=""userCSharp:LogicalEq(string($var:v130) , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v132"" select=""userCSharp:LogicalAnd(string($var:v131) , string($var:v127))"" />
                  <xsl:if test=""string($var:v132)='true'"">
                    <xsl:variable name=""var:v133"" select=""VesselQuantity/text()"" />
                    <ShipFigures>
                      <xsl:value-of select=""$var:v133"" />
                    </ShipFigures>
                  </xsl:if>
                  <xsl:if test=""string($var:v134)='true'"">
                    <xsl:variable name=""var:v135"" select=""userCSharp:StringConcat(string(../Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v136"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v137"" select=""ScriptNS1:DBLookup(0 , string($var:v135) , string($var:v136) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v138"" select=""ScriptNS1:DBValueExtract(string($var:v137) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v139"" select=""ScriptNS1:DBLookup(1 , string($var:v138) , string($var:v136) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v140"" select=""ScriptNS1:DBValueExtract(string($var:v139) , &quot;HubPrincipalId&quot;)"" />
                    <xsl:variable name=""var:v141"" select=""userCSharp:StringConcat(string(UnitOfMeasure/Id/text()) , &quot;|&quot; , string($var:v140))"" />
                    <xsl:variable name=""var:v142"" select=""ScriptNS1:DBLookup(5 , string($var:v141) , string($var:v136) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(UnitOfMeasureId  as varchar(10)) +'|'+ cast(HubPrincipalId as varchar(10))&quot;)"" />
                    <xsl:variable name=""var:v143"" select=""ScriptNS1:DBValueExtract(string($var:v142) , &quot;Code&quot;)"" />
                    <xsl:variable name=""var:v144"" select=""userCSharp:StringSubstring(string($var:v143) , &quot;1&quot; , &quot;1&quot;)"" />
                    <DraftIn>
                      <xsl:value-of select=""$var:v144"" />
                    </DraftIn>
                  </xsl:if>
                  <xsl:for-each select=""../Drafts"">

      <xsl:variable name=""DraftArrivalName1"" select=""./Name/text()"" />
      
     <xsl:if test=""$DraftArrivalName1='Arrival'"">
         <xsl:variable name=""DraftArrivalIsActive1"" select=""./isActive/text()"" />
         <xsl:variable name=""DraftArrivalfwd"" select=""./Aft/text()"" />
                  <ArrDraftAft>
                                 <xsl:value-of select=""$DraftArrivalfwd"" /> 
                     </ArrDraftAft>
                      <ArrDraftMid>
                                 <xsl:value-of select=""./Mean/text()"" /> 
                     </ArrDraftMid>
                      <ArrDraftFwd>
                                 <xsl:value-of select=""./Fwd/text()"" /> 
                     </ArrDraftFwd>

    </xsl:if>

   </xsl:for-each>
                  <xsl:for-each select=""../Drafts"">

      <xsl:variable name=""DraftDepName"" select=""./Name/text()"" />
      
     <xsl:if test=""$DraftDepName='Departure'"">
         <xsl:variable name=""DraftDepIsActive"" select=""./isActive/text()"" />
                  <DepDraftAft>
                                 <xsl:value-of select=""./Aft/text()"" /> 
                     </DepDraftAft>
                      <DepDraftMid>
                                 <xsl:value-of select=""./Mean/text()"" /> 
                     </DepDraftMid>
                      <DepDraftFwd>
                                 <xsl:value-of select=""./Fwd/text()"" /> 
                     </DepDraftFwd>

    </xsl:if>

   </xsl:for-each>
                  <xsl:if test=""ShipperReceiver"">
                    <Shipper>
                      <xsl:value-of select=""ShipperReceiver/text()"" />
                    </Shipper>
                  </xsl:if>
                  <xsl:if test=""ShipperReceiver"">
                    <Receiver>
                      <xsl:value-of select=""ShipperReceiver/text()"" />
                    </Receiver>
                  </xsl:if>
                  <xsl:variable name=""var:v147"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v148"" select=""ScriptNS1:DBLookup(0 , string($var:v146) , string($var:v147) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                  <xsl:variable name=""var:v149"" select=""ScriptNS1:DBValueExtract(string($var:v148) , &quot;Id&quot;)"" />
                  <xsl:variable name=""var:v150"" select=""userCSharp:StringConcat(string($var:v149) , &quot;|&quot; , string(RefCode/text()))"" />
                  <xsl:variable name=""var:v151"" select=""ScriptNS1:DBLookup(6 , string($var:v150) , string($var:v147) , &quot;Operation.Cargoes&quot; , &quot;cast ( PortCallId as varchar(20) ) + '|' + cast ( RefCode  as varchar(20) )&quot;)"" />
                  <xsl:variable name=""var:v152"" select=""ScriptNS1:DBValueExtract(string($var:v151) , &quot;BillOfLadingDate&quot;)"" />
                  <xsl:variable name=""var:v153"" select=""userCSharp:IsBLDate(string($var:v152))"" />
                  <xsl:if test=""string($var:v153)='true'"">
                    <xsl:variable name=""var:v154"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v155"" select=""ScriptNS1:DBLookup(0 , string($var:v146) , string($var:v154) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v156"" select=""ScriptNS1:DBValueExtract(string($var:v155) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v157"" select=""string(RefCode/text())"" />
                    <xsl:variable name=""var:v158"" select=""userCSharp:StringConcat(string($var:v156) , &quot;|&quot; , $var:v157)"" />
                    <xsl:variable name=""var:v159"" select=""ScriptNS1:DBLookup(6 , string($var:v158) , string($var:v154) , &quot;Operation.Cargoes&quot; , &quot;cast ( PortCallId as varchar(20) ) + '|' + cast ( RefCode  as varchar(20) )&quot;)"" />
                    <xsl:variable name=""var:v160"" select=""ScriptNS1:DBValueExtract(string($var:v159) , &quot;BillOfLadingDate&quot;)"" />
                    <xsl:variable name=""var:v161"" select=""userCSharp:BLDate(string($var:v160))"" />
                    <BlDate>
                      <xsl:value-of select=""$var:v161"" />
                    </BlDate>
                  </xsl:if>
                  <xsl:variable name=""var:v163"" select=""ScriptNS0:CargoDocumentCount(string(../Id/text()) , $var:v162)"" />
                  <DocumentCount>
                    <xsl:value-of select=""$var:v163"" />
                  </DocumentCount>
                </Cargo>
              </xsl:if>
            </xsl:for-each>
          </Cargoes>
        </xsl:if>
        <xsl:variable name=""var:v164"" select=""userCSharp:InitCumulativeSum(1)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Bunkers"">
          <xsl:variable name=""var:v165"" select=""string(../Number/text())"" />
          <xsl:variable name=""var:v166"" select=""userCSharp:StringConcat($var:v165 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v167"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v168"" select=""ScriptNS1:DBLookup(0 , string($var:v166) , string($var:v167) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v169"" select=""ScriptNS1:DBValueExtract(string($var:v168) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v170"" select=""ScriptNS1:DBLookup(1 , string($var:v169) , string($var:v167) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
          <xsl:variable name=""var:v171"" select=""ScriptNS1:DBValueExtract(string($var:v170) , &quot;HubPrincipalKey&quot;)"" />
          <xsl:variable name=""var:v172"" select=""ScriptNS0:GetBizConnectionString()"" />
          <xsl:variable name=""var:v173"" select=""ScriptNS1:DBLookup(7 , string($var:v171) , string($var:v172) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
          <xsl:variable name=""var:v174"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;LSFO&quot;)"" />
          <xsl:variable name=""var:v175"" select=""userCSharp:GetLSFO(string(Lsfo/text()) , string($var:v174))"" />
          <xsl:variable name=""var:v176"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;HFO&quot;)"" />
          <xsl:variable name=""var:v177"" select=""userCSharp:GetHFO(string(Hfo/text()) , string($var:v176))"" />
          <xsl:variable name=""var:v178"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;LSGO&quot;)"" />
          <xsl:variable name=""var:v179"" select=""userCSharp:GetLSGO(string(Lsgo/text()) , string($var:v178))"" />
          <xsl:variable name=""var:v180"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;DO&quot;)"" />
          <xsl:variable name=""var:v181"" select=""userCSharp:GetMDO(string(Mdo/text()) , string($var:v180))"" />
          <xsl:variable name=""var:v182"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;GO&quot;)"" />
          <xsl:variable name=""var:v183"" select=""userCSharp:GetMGO(string(Mgo/text()) , string($var:v182))"" />
          <xsl:variable name=""var:v184"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;LO&quot;)"" />
          <xsl:variable name=""var:v185"" select=""userCSharp:GetLO(string(Lo/text()) , string($var:v184))"" />
          <xsl:variable name=""var:v186"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;FwCrew&quot;)"" />
          <xsl:variable name=""var:v187"" select=""userCSharp:GetFWCREW(string(FwCrew/text()) , string($var:v186))"" />
          <xsl:variable name=""var:v188"" select=""ScriptNS1:DBValueExtract(string($var:v173) , &quot;FwShip&quot;)"" />
          <xsl:variable name=""var:v189"" select=""userCSharp:GetFWSHIP(string(FwShip/text()) , string($var:v188))"" />
          <xsl:variable name=""var:v190"" select=""userCSharp:GetBunKetCountSum(string($var:v175) , string($var:v177) , string($var:v179) , string($var:v181) , string($var:v183) , string($var:v185) , string($var:v187) , string($var:v189))"" />
          <xsl:variable name=""var:v191"" select=""userCSharp:AddToCumulativeSum(1,string($var:v190),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v192"" select=""userCSharp:GetCumulativeSum(1)"" />
        <xsl:variable name=""var:v193"" select=""userCSharp:LogicalGt(string($var:v192) , &quot;0&quot;)"" />
        <xsl:if test=""string($var:v193)='true'"">
          <xsl:variable name=""var:v194"" select=""userCSharp:InitCumulativeSum(1)"" />
          <xsl:for-each select=""/s0:YourIss2Appointment/Bunkers"">
            <xsl:variable name=""var:v195"" select=""string(../Number/text())"" />
            <xsl:variable name=""var:v196"" select=""userCSharp:StringConcat($var:v195 , &quot;|&quot; , &quot;1&quot;)"" />
            <xsl:variable name=""var:v197"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
            <xsl:variable name=""var:v198"" select=""ScriptNS1:DBLookup(0 , string($var:v196) , string($var:v197) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
            <xsl:variable name=""var:v199"" select=""ScriptNS1:DBValueExtract(string($var:v198) , &quot;Id&quot;)"" />
            <xsl:variable name=""var:v200"" select=""ScriptNS1:DBLookup(1 , string($var:v199) , string($var:v197) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
            <xsl:variable name=""var:v201"" select=""ScriptNS1:DBValueExtract(string($var:v200) , &quot;HubPrincipalKey&quot;)"" />
            <xsl:variable name=""var:v202"" select=""ScriptNS0:GetBizConnectionString()"" />
            <xsl:variable name=""var:v203"" select=""ScriptNS1:DBLookup(7 , string($var:v201) , string($var:v202) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
            <xsl:variable name=""var:v204"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;LSFO&quot;)"" />
            <xsl:variable name=""var:v205"" select=""string(Lsfo/text())"" />
            <xsl:variable name=""var:v206"" select=""userCSharp:GetLSFO($var:v205 , string($var:v204))"" />
            <xsl:variable name=""var:v207"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;HFO&quot;)"" />
            <xsl:variable name=""var:v208"" select=""string(Hfo/text())"" />
            <xsl:variable name=""var:v209"" select=""userCSharp:GetHFO($var:v208 , string($var:v207))"" />
            <xsl:variable name=""var:v210"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;LSGO&quot;)"" />
            <xsl:variable name=""var:v211"" select=""string(Lsgo/text())"" />
            <xsl:variable name=""var:v212"" select=""userCSharp:GetLSGO($var:v211 , string($var:v210))"" />
            <xsl:variable name=""var:v213"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;DO&quot;)"" />
            <xsl:variable name=""var:v214"" select=""string(Mdo/text())"" />
            <xsl:variable name=""var:v215"" select=""userCSharp:GetMDO($var:v214 , string($var:v213))"" />
            <xsl:variable name=""var:v216"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;GO&quot;)"" />
            <xsl:variable name=""var:v217"" select=""string(Mgo/text())"" />
            <xsl:variable name=""var:v218"" select=""userCSharp:GetMGO($var:v217 , string($var:v216))"" />
            <xsl:variable name=""var:v219"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;LO&quot;)"" />
            <xsl:variable name=""var:v220"" select=""string(Lo/text())"" />
            <xsl:variable name=""var:v221"" select=""userCSharp:GetLO($var:v220 , string($var:v219))"" />
            <xsl:variable name=""var:v222"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;FwCrew&quot;)"" />
            <xsl:variable name=""var:v223"" select=""string(FwCrew/text())"" />
            <xsl:variable name=""var:v224"" select=""userCSharp:GetFWCREW($var:v223 , string($var:v222))"" />
            <xsl:variable name=""var:v225"" select=""ScriptNS1:DBValueExtract(string($var:v203) , &quot;FwShip&quot;)"" />
            <xsl:variable name=""var:v226"" select=""string(FwShip/text())"" />
            <xsl:variable name=""var:v227"" select=""userCSharp:GetFWSHIP($var:v226 , string($var:v225))"" />
            <xsl:variable name=""var:v228"" select=""userCSharp:GetBunKetCountSum(string($var:v206) , string($var:v209) , string($var:v212) , string($var:v215) , string($var:v218) , string($var:v221) , string($var:v224) , string($var:v227))"" />
            <xsl:variable name=""var:v229"" select=""userCSharp:AddToCumulativeSum(1,string($var:v228),&quot;2&quot;)"" />
          </xsl:for-each>
          <xsl:variable name=""var:v230"" select=""userCSharp:GetCumulativeSum(1)"" />
          <BunkerCount>
            <xsl:value-of select=""$var:v230"" />
          </BunkerCount>
        </xsl:if>
        <xsl:variable name=""var:v231"" select=""userCSharp:InitCumulativeSum(1)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Bunkers"">
          <xsl:variable name=""var:v232"" select=""string(../Number/text())"" />
          <xsl:variable name=""var:v233"" select=""userCSharp:StringConcat($var:v232 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v234"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v235"" select=""ScriptNS1:DBLookup(0 , string($var:v233) , string($var:v234) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v236"" select=""ScriptNS1:DBValueExtract(string($var:v235) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v237"" select=""ScriptNS1:DBLookup(1 , string($var:v236) , string($var:v234) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
          <xsl:variable name=""var:v238"" select=""ScriptNS1:DBValueExtract(string($var:v237) , &quot;HubPrincipalKey&quot;)"" />
          <xsl:variable name=""var:v239"" select=""ScriptNS0:GetBizConnectionString()"" />
          <xsl:variable name=""var:v240"" select=""ScriptNS1:DBLookup(7 , string($var:v238) , string($var:v239) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
          <xsl:variable name=""var:v241"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;LSFO&quot;)"" />
          <xsl:variable name=""var:v242"" select=""string(Lsfo/text())"" />
          <xsl:variable name=""var:v243"" select=""userCSharp:GetLSFO($var:v242 , string($var:v241))"" />
          <xsl:variable name=""var:v244"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;HFO&quot;)"" />
          <xsl:variable name=""var:v245"" select=""string(Hfo/text())"" />
          <xsl:variable name=""var:v246"" select=""userCSharp:GetHFO($var:v245 , string($var:v244))"" />
          <xsl:variable name=""var:v247"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;LSGO&quot;)"" />
          <xsl:variable name=""var:v248"" select=""string(Lsgo/text())"" />
          <xsl:variable name=""var:v249"" select=""userCSharp:GetLSGO($var:v248 , string($var:v247))"" />
          <xsl:variable name=""var:v250"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;DO&quot;)"" />
          <xsl:variable name=""var:v251"" select=""string(Mdo/text())"" />
          <xsl:variable name=""var:v252"" select=""userCSharp:GetMDO($var:v251 , string($var:v250))"" />
          <xsl:variable name=""var:v253"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;GO&quot;)"" />
          <xsl:variable name=""var:v254"" select=""string(Mgo/text())"" />
          <xsl:variable name=""var:v255"" select=""userCSharp:GetMGO($var:v254 , string($var:v253))"" />
          <xsl:variable name=""var:v256"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;LO&quot;)"" />
          <xsl:variable name=""var:v257"" select=""string(Lo/text())"" />
          <xsl:variable name=""var:v258"" select=""userCSharp:GetLO($var:v257 , string($var:v256))"" />
          <xsl:variable name=""var:v259"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;FwCrew&quot;)"" />
          <xsl:variable name=""var:v260"" select=""string(FwCrew/text())"" />
          <xsl:variable name=""var:v261"" select=""userCSharp:GetFWCREW($var:v260 , string($var:v259))"" />
          <xsl:variable name=""var:v262"" select=""ScriptNS1:DBValueExtract(string($var:v240) , &quot;FwShip&quot;)"" />
          <xsl:variable name=""var:v263"" select=""string(FwShip/text())"" />
          <xsl:variable name=""var:v264"" select=""userCSharp:GetFWSHIP($var:v263 , string($var:v262))"" />
          <xsl:variable name=""var:v265"" select=""userCSharp:GetBunKetCountSum(string($var:v243) , string($var:v246) , string($var:v249) , string($var:v252) , string($var:v255) , string($var:v258) , string($var:v261) , string($var:v264))"" />
          <xsl:variable name=""var:v266"" select=""userCSharp:AddToCumulativeSum(1,string($var:v265),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v267"" select=""userCSharp:GetCumulativeSum(1)"" />
        <xsl:variable name=""var:v268"" select=""userCSharp:LogicalGt(string($var:v267) , &quot;0&quot;)"" />
        <xsl:if test=""$var:v268"">
          <Bunkers>
            <xsl:for-each select=""Bunkers"">
              <xsl:for-each select=""Lsfo"">
                <xsl:variable name=""var:v269"" select=""userCSharp:StringConcat(string(../../Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v270"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v271"" select=""ScriptNS1:DBLookup(0 , string($var:v269) , string($var:v270) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v272"" select=""ScriptNS1:DBValueExtract(string($var:v271) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v273"" select=""ScriptNS1:DBLookup(1 , string($var:v272) , string($var:v270) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v274"" select=""ScriptNS1:DBValueExtract(string($var:v273) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v275"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v276"" select=""ScriptNS1:DBLookup(7 , string($var:v274) , string($var:v275) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v277"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v278"" select=""userCSharp:GetLSFO(string(./text()) , string($var:v277))"" />
                <xsl:variable name=""var:v279"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v280"" select=""userCSharp:GetHFO(string(../Hfo/text()) , string($var:v279))"" />
                <xsl:variable name=""var:v281"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v282"" select=""userCSharp:GetLSGO(string(../Lsgo/text()) , string($var:v281))"" />
                <xsl:variable name=""var:v283"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v284"" select=""userCSharp:GetMDO(string(../Mdo/text()) , string($var:v283))"" />
                <xsl:variable name=""var:v285"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v286"" select=""userCSharp:GetMGO(string(../Mgo/text()) , string($var:v285))"" />
                <xsl:variable name=""var:v287"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v288"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v289"" select=""ScriptNS1:DBValueExtract(string($var:v276) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v290"" select=""userCSharp:GetLO(string(../Lo/text()) , string($var:v287))"" />
                <xsl:variable name=""var:v291"" select=""userCSharp:GetFWCREW(string(../FwCrew/text()) , string($var:v288))"" />
                <xsl:variable name=""var:v292"" select=""userCSharp:GetFWSHIP(string(../FwShip/text()) , string($var:v289))"" />
                <xsl:variable name=""var:v293"" select=""$var:v278"" />
                <xsl:variable name=""var:v294"" select=""userCSharp:LogicalEq(string($var:v293) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v294"">
                  <xsl:variable name=""var:v295"" select=""string(../../Number/text())"" />
                  <xsl:variable name=""var:v296"" select=""userCSharp:StringConcat($var:v295 , &quot;|&quot; , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v305"" select=""string(./text())"" />
                  <xsl:variable name=""var:v308"" select=""string(../Hfo/text())"" />
                  <xsl:variable name=""var:v311"" select=""string(../Lsgo/text())"" />
                  <xsl:variable name=""var:v314"" select=""string(../Mdo/text())"" />
                  <xsl:variable name=""var:v317"" select=""string(../Mgo/text())"" />
                  <xsl:variable name=""var:v322"" select=""string(../Lo/text())"" />
                  <xsl:variable name=""var:v324"" select=""string(../FwCrew/text())"" />
                  <xsl:variable name=""var:v326"" select=""string(../FwShip/text())"" />
                  <xsl:variable name=""var:v379"" select=""userCSharp:LogicalEq(string(../Name/text()) , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v430"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v431"" select=""userCSharp:LogicalEq($var:v430 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v457"" select=""userCSharp:LogicalEq($var:v430 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v297"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v298"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v297) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v299"" select=""ScriptNS1:DBValueExtract(string($var:v298) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v300"" select=""ScriptNS1:DBLookup(1 , string($var:v299) , string($var:v297) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v301"" select=""ScriptNS1:DBValueExtract(string($var:v300) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v302"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v303"" select=""ScriptNS1:DBLookup(7 , string($var:v301) , string($var:v302) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v304"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v306"" select=""userCSharp:GetLSFO($var:v305 , string($var:v304))"" />
                    <xsl:variable name=""var:v307"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v309"" select=""userCSharp:GetHFO($var:v308 , string($var:v307))"" />
                    <xsl:variable name=""var:v310"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v312"" select=""userCSharp:GetLSGO($var:v311 , string($var:v310))"" />
                    <xsl:variable name=""var:v313"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v315"" select=""userCSharp:GetMDO($var:v314 , string($var:v313))"" />
                    <xsl:variable name=""var:v316"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v318"" select=""userCSharp:GetMGO($var:v317 , string($var:v316))"" />
                    <xsl:variable name=""var:v319"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v320"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v321"" select=""ScriptNS1:DBValueExtract(string($var:v303) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v323"" select=""userCSharp:GetLO($var:v322 , string($var:v319))"" />
                    <xsl:variable name=""var:v325"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v320))"" />
                    <xsl:variable name=""var:v327"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v321))"" />
                    <xsl:variable name=""var:v328"" select=""$var:v306"" />
                    <xsl:variable name=""var:v329"" select=""userCSharp:LogicalEq(string($var:v328) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v329)='true'"">
                      <xsl:variable name=""var:v330"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v331"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v330) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v332"" select=""ScriptNS1:DBValueExtract(string($var:v331) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v333"" select=""ScriptNS1:DBLookup(1 , string($var:v332) , string($var:v330) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v334"" select=""ScriptNS1:DBValueExtract(string($var:v333) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v335"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v336"" select=""ScriptNS1:DBLookup(7 , string($var:v334) , string($var:v335) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v337"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v338"" select=""userCSharp:GetLSFO($var:v305 , string($var:v337))"" />
                      <xsl:variable name=""var:v339"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v340"" select=""userCSharp:GetHFO($var:v308 , string($var:v339))"" />
                      <xsl:variable name=""var:v341"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v342"" select=""userCSharp:GetLSGO($var:v311 , string($var:v341))"" />
                      <xsl:variable name=""var:v343"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v344"" select=""userCSharp:GetMDO($var:v314 , string($var:v343))"" />
                      <xsl:variable name=""var:v345"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v346"" select=""userCSharp:GetMGO($var:v317 , string($var:v345))"" />
                      <xsl:variable name=""var:v347"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v348"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v349"" select=""ScriptNS1:DBValueExtract(string($var:v336) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v350"" select=""userCSharp:GetLO($var:v322 , string($var:v347))"" />
                      <xsl:variable name=""var:v351"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v348))"" />
                      <xsl:variable name=""var:v352"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v349))"" />
                      <xsl:variable name=""var:v353"" select=""$var:v337"" />
                      <Grade>
                        <xsl:value-of select=""$var:v353"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v354"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v355"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v354) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v356"" select=""ScriptNS1:DBValueExtract(string($var:v355) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v357"" select=""ScriptNS1:DBLookup(1 , string($var:v356) , string($var:v354) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v358"" select=""ScriptNS1:DBValueExtract(string($var:v357) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v359"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v360"" select=""ScriptNS1:DBLookup(7 , string($var:v358) , string($var:v359) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v361"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v362"" select=""userCSharp:GetLSFO($var:v305 , string($var:v361))"" />
                    <xsl:variable name=""var:v363"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v364"" select=""userCSharp:GetHFO($var:v308 , string($var:v363))"" />
                    <xsl:variable name=""var:v365"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v366"" select=""userCSharp:GetLSGO($var:v311 , string($var:v365))"" />
                    <xsl:variable name=""var:v367"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v368"" select=""userCSharp:GetMDO($var:v314 , string($var:v367))"" />
                    <xsl:variable name=""var:v369"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v370"" select=""userCSharp:GetMGO($var:v317 , string($var:v369))"" />
                    <xsl:variable name=""var:v371"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v372"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v373"" select=""ScriptNS1:DBValueExtract(string($var:v360) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v374"" select=""userCSharp:GetLO($var:v322 , string($var:v371))"" />
                    <xsl:variable name=""var:v375"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v372))"" />
                    <xsl:variable name=""var:v376"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v373))"" />
                    <xsl:variable name=""var:v377"" select=""$var:v362"" />
                    <xsl:variable name=""var:v378"" select=""userCSharp:LogicalEq(string($var:v377) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v380"" select=""userCSharp:LogicalAnd(string($var:v378) , string($var:v379))"" />
                    <xsl:if test=""string($var:v380)='true'"">
                      <xsl:variable name=""var:v381"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v382"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v381) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v383"" select=""ScriptNS1:DBValueExtract(string($var:v382) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v384"" select=""ScriptNS1:DBLookup(1 , string($var:v383) , string($var:v381) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v385"" select=""ScriptNS1:DBValueExtract(string($var:v384) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v386"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v387"" select=""ScriptNS1:DBLookup(7 , string($var:v385) , string($var:v386) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v388"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v389"" select=""userCSharp:GetLSFO($var:v305 , string($var:v388))"" />
                      <xsl:variable name=""var:v390"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v391"" select=""userCSharp:GetHFO($var:v308 , string($var:v390))"" />
                      <xsl:variable name=""var:v392"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v393"" select=""userCSharp:GetLSGO($var:v311 , string($var:v392))"" />
                      <xsl:variable name=""var:v394"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v395"" select=""userCSharp:GetMDO($var:v314 , string($var:v394))"" />
                      <xsl:variable name=""var:v396"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v397"" select=""userCSharp:GetMGO($var:v317 , string($var:v396))"" />
                      <xsl:variable name=""var:v398"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v399"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v400"" select=""ScriptNS1:DBValueExtract(string($var:v387) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v401"" select=""userCSharp:GetLO($var:v322 , string($var:v398))"" />
                      <xsl:variable name=""var:v402"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v399))"" />
                      <xsl:variable name=""var:v403"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v400))"" />
                      <xsl:variable name=""var:v404"" select=""."" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v404"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v405"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v406"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v405) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v407"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v408"" select=""ScriptNS1:DBLookup(1 , string($var:v407) , string($var:v405) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v409"" select=""ScriptNS1:DBValueExtract(string($var:v408) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v410"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v411"" select=""ScriptNS1:DBLookup(7 , string($var:v409) , string($var:v410) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v412"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v413"" select=""userCSharp:GetLSFO($var:v305 , string($var:v412))"" />
                    <xsl:variable name=""var:v414"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v415"" select=""userCSharp:GetHFO($var:v308 , string($var:v414))"" />
                    <xsl:variable name=""var:v416"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v417"" select=""userCSharp:GetLSGO($var:v311 , string($var:v416))"" />
                    <xsl:variable name=""var:v418"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v419"" select=""userCSharp:GetMDO($var:v314 , string($var:v418))"" />
                    <xsl:variable name=""var:v420"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v421"" select=""userCSharp:GetMGO($var:v317 , string($var:v420))"" />
                    <xsl:variable name=""var:v422"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v423"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v424"" select=""ScriptNS1:DBValueExtract(string($var:v411) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v425"" select=""userCSharp:GetLO($var:v322 , string($var:v422))"" />
                    <xsl:variable name=""var:v426"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v423))"" />
                    <xsl:variable name=""var:v427"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v424))"" />
                    <xsl:variable name=""var:v428"" select=""$var:v413"" />
                    <xsl:variable name=""var:v429"" select=""userCSharp:LogicalEq(string($var:v428) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v432"" select=""userCSharp:LogicalAnd(string($var:v429) , string($var:v431))"" />
                    <xsl:if test=""string($var:v432)='true'"">
                      <xsl:variable name=""var:v433"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v434"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v433) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v435"" select=""ScriptNS1:DBValueExtract(string($var:v434) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v436"" select=""ScriptNS1:DBLookup(1 , string($var:v435) , string($var:v433) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v437"" select=""ScriptNS1:DBValueExtract(string($var:v436) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v438"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v439"" select=""ScriptNS1:DBLookup(7 , string($var:v437) , string($var:v438) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v440"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v441"" select=""userCSharp:GetLSFO($var:v305 , string($var:v440))"" />
                      <xsl:variable name=""var:v442"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v443"" select=""userCSharp:GetHFO($var:v308 , string($var:v442))"" />
                      <xsl:variable name=""var:v444"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v445"" select=""userCSharp:GetLSGO($var:v311 , string($var:v444))"" />
                      <xsl:variable name=""var:v446"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v447"" select=""userCSharp:GetMDO($var:v314 , string($var:v446))"" />
                      <xsl:variable name=""var:v448"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v449"" select=""userCSharp:GetMGO($var:v317 , string($var:v448))"" />
                      <xsl:variable name=""var:v450"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v451"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v452"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v453"" select=""userCSharp:GetLO($var:v322 , string($var:v450))"" />
                      <xsl:variable name=""var:v454"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v451))"" />
                      <xsl:variable name=""var:v455"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v452))"" />
                      <xsl:variable name=""var:v456"" select=""."" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v456"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v458"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v459"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v458) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v460"" select=""ScriptNS1:DBValueExtract(string($var:v459) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v461"" select=""ScriptNS1:DBLookup(1 , string($var:v460) , string($var:v458) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v462"" select=""ScriptNS1:DBValueExtract(string($var:v461) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v463"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v464"" select=""ScriptNS1:DBLookup(7 , string($var:v462) , string($var:v463) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v465"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v466"" select=""userCSharp:GetLSFO($var:v305 , string($var:v465))"" />
                    <xsl:variable name=""var:v467"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v468"" select=""userCSharp:GetHFO($var:v308 , string($var:v467))"" />
                    <xsl:variable name=""var:v469"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v470"" select=""userCSharp:GetLSGO($var:v311 , string($var:v469))"" />
                    <xsl:variable name=""var:v471"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v472"" select=""userCSharp:GetMDO($var:v314 , string($var:v471))"" />
                    <xsl:variable name=""var:v473"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v474"" select=""userCSharp:GetMGO($var:v317 , string($var:v473))"" />
                    <xsl:variable name=""var:v475"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v476"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v477"" select=""ScriptNS1:DBValueExtract(string($var:v464) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v478"" select=""userCSharp:GetLO($var:v322 , string($var:v475))"" />
                    <xsl:variable name=""var:v479"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v476))"" />
                    <xsl:variable name=""var:v480"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v477))"" />
                    <xsl:variable name=""var:v481"" select=""$var:v466"" />
                    <xsl:variable name=""var:v482"" select=""userCSharp:LogicalEq(string($var:v481) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v483"" select=""userCSharp:LogicalAnd(string($var:v457) , string($var:v482))"" />
                    <xsl:if test=""string($var:v483)='true'"">
                      <xsl:variable name=""var:v484"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v485"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v484) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v486"" select=""ScriptNS1:DBValueExtract(string($var:v485) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v487"" select=""ScriptNS1:DBLookup(1 , string($var:v486) , string($var:v484) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v488"" select=""ScriptNS1:DBValueExtract(string($var:v487) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v489"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v490"" select=""ScriptNS1:DBLookup(7 , string($var:v488) , string($var:v489) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v491"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v492"" select=""userCSharp:GetLSFO($var:v305 , string($var:v491))"" />
                      <xsl:variable name=""var:v493"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v494"" select=""userCSharp:GetHFO($var:v308 , string($var:v493))"" />
                      <xsl:variable name=""var:v495"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v496"" select=""userCSharp:GetLSGO($var:v311 , string($var:v495))"" />
                      <xsl:variable name=""var:v497"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v498"" select=""userCSharp:GetMDO($var:v314 , string($var:v497))"" />
                      <xsl:variable name=""var:v499"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v500"" select=""userCSharp:GetMGO($var:v317 , string($var:v499))"" />
                      <xsl:variable name=""var:v501"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v502"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v503"" select=""ScriptNS1:DBValueExtract(string($var:v490) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v504"" select=""userCSharp:GetLO($var:v322 , string($var:v501))"" />
                      <xsl:variable name=""var:v505"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v502))"" />
                      <xsl:variable name=""var:v506"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v503))"" />
                      <xsl:variable name=""var:v507"" select=""."" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v507"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v508"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v509"" select=""ScriptNS1:DBLookup(0 , string($var:v296) , string($var:v508) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v510"" select=""ScriptNS1:DBValueExtract(string($var:v509) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v511"" select=""ScriptNS1:DBLookup(1 , string($var:v510) , string($var:v508) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v512"" select=""ScriptNS1:DBValueExtract(string($var:v511) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v513"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v514"" select=""ScriptNS1:DBLookup(7 , string($var:v512) , string($var:v513) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v515"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v516"" select=""userCSharp:GetLSFO($var:v305 , string($var:v515))"" />
                    <xsl:variable name=""var:v517"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v518"" select=""userCSharp:GetHFO($var:v308 , string($var:v517))"" />
                    <xsl:variable name=""var:v519"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v520"" select=""userCSharp:GetLSGO($var:v311 , string($var:v519))"" />
                    <xsl:variable name=""var:v521"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v522"" select=""userCSharp:GetMDO($var:v314 , string($var:v521))"" />
                    <xsl:variable name=""var:v523"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v524"" select=""userCSharp:GetMGO($var:v317 , string($var:v523))"" />
                    <xsl:variable name=""var:v525"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v526"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v527"" select=""ScriptNS1:DBValueExtract(string($var:v514) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v528"" select=""userCSharp:GetLO($var:v322 , string($var:v525))"" />
                    <xsl:variable name=""var:v529"" select=""userCSharp:GetFWCREW($var:v324 , string($var:v526))"" />
                    <xsl:variable name=""var:v530"" select=""userCSharp:GetFWSHIP($var:v326 , string($var:v527))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v531"" select=""string(../../Number/text())"" />
                <xsl:variable name=""var:v532"" select=""userCSharp:StringConcat($var:v531 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v533"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v534"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v533) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v535"" select=""ScriptNS1:DBValueExtract(string($var:v534) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v536"" select=""ScriptNS1:DBLookup(1 , string($var:v535) , string($var:v533) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v537"" select=""ScriptNS1:DBValueExtract(string($var:v536) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v538"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v539"" select=""ScriptNS1:DBLookup(7 , string($var:v537) , string($var:v538) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v540"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v541"" select=""string(./text())"" />
                <xsl:variable name=""var:v542"" select=""userCSharp:GetLSFO($var:v541 , string($var:v540))"" />
                <xsl:variable name=""var:v543"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v544"" select=""string(../Hfo/text())"" />
                <xsl:variable name=""var:v545"" select=""userCSharp:GetHFO($var:v544 , string($var:v543))"" />
                <xsl:variable name=""var:v546"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v547"" select=""string(../Lsgo/text())"" />
                <xsl:variable name=""var:v548"" select=""userCSharp:GetLSGO($var:v547 , string($var:v546))"" />
                <xsl:variable name=""var:v549"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v550"" select=""string(../Mdo/text())"" />
                <xsl:variable name=""var:v551"" select=""userCSharp:GetMDO($var:v550 , string($var:v549))"" />
                <xsl:variable name=""var:v552"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v553"" select=""string(../Mgo/text())"" />
                <xsl:variable name=""var:v554"" select=""userCSharp:GetMGO($var:v553 , string($var:v552))"" />
                <xsl:variable name=""var:v555"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v556"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v557"" select=""ScriptNS1:DBValueExtract(string($var:v539) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v558"" select=""string(../Lo/text())"" />
                <xsl:variable name=""var:v559"" select=""userCSharp:GetLO($var:v558 , string($var:v555))"" />
                <xsl:variable name=""var:v560"" select=""string(../FwCrew/text())"" />
                <xsl:variable name=""var:v561"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v556))"" />
                <xsl:variable name=""var:v562"" select=""string(../FwShip/text())"" />
                <xsl:variable name=""var:v563"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v557))"" />
                <xsl:variable name=""var:v564"" select=""$var:v545"" />
                <xsl:variable name=""var:v565"" select=""userCSharp:LogicalEq(string($var:v564) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v565"">
                  <xsl:variable name=""var:v640"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v641"" select=""userCSharp:LogicalEq($var:v640 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v692"" select=""userCSharp:LogicalEq($var:v640 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v718"" select=""userCSharp:LogicalEq($var:v640 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v566"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v567"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v566) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v568"" select=""ScriptNS1:DBValueExtract(string($var:v567) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v569"" select=""ScriptNS1:DBLookup(1 , string($var:v568) , string($var:v566) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v570"" select=""ScriptNS1:DBValueExtract(string($var:v569) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v571"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v572"" select=""ScriptNS1:DBLookup(7 , string($var:v570) , string($var:v571) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v573"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v574"" select=""userCSharp:GetLSFO($var:v541 , string($var:v573))"" />
                    <xsl:variable name=""var:v575"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v576"" select=""userCSharp:GetHFO($var:v544 , string($var:v575))"" />
                    <xsl:variable name=""var:v577"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v578"" select=""userCSharp:GetLSGO($var:v547 , string($var:v577))"" />
                    <xsl:variable name=""var:v579"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v580"" select=""userCSharp:GetMDO($var:v550 , string($var:v579))"" />
                    <xsl:variable name=""var:v581"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v582"" select=""userCSharp:GetMGO($var:v553 , string($var:v581))"" />
                    <xsl:variable name=""var:v583"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v584"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v585"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v586"" select=""userCSharp:GetLO($var:v558 , string($var:v583))"" />
                    <xsl:variable name=""var:v587"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v584))"" />
                    <xsl:variable name=""var:v588"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v585))"" />
                    <xsl:variable name=""var:v589"" select=""$var:v576"" />
                    <xsl:variable name=""var:v590"" select=""userCSharp:LogicalEq(string($var:v589) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v590)='true'"">
                      <xsl:variable name=""var:v591"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v592"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v591) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v593"" select=""ScriptNS1:DBValueExtract(string($var:v592) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v594"" select=""ScriptNS1:DBLookup(1 , string($var:v593) , string($var:v591) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v595"" select=""ScriptNS1:DBValueExtract(string($var:v594) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v596"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v597"" select=""ScriptNS1:DBLookup(7 , string($var:v595) , string($var:v596) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v598"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v599"" select=""userCSharp:GetLSFO($var:v541 , string($var:v598))"" />
                      <xsl:variable name=""var:v600"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v601"" select=""userCSharp:GetHFO($var:v544 , string($var:v600))"" />
                      <xsl:variable name=""var:v602"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v603"" select=""userCSharp:GetLSGO($var:v547 , string($var:v602))"" />
                      <xsl:variable name=""var:v604"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v605"" select=""userCSharp:GetMDO($var:v550 , string($var:v604))"" />
                      <xsl:variable name=""var:v606"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v607"" select=""userCSharp:GetMGO($var:v553 , string($var:v606))"" />
                      <xsl:variable name=""var:v608"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v609"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v610"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v611"" select=""userCSharp:GetLO($var:v558 , string($var:v608))"" />
                      <xsl:variable name=""var:v612"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v609))"" />
                      <xsl:variable name=""var:v613"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v610))"" />
                      <xsl:variable name=""var:v614"" select=""$var:v600"" />
                      <Grade>
                        <xsl:value-of select=""$var:v614"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v615"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v616"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v615) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v617"" select=""ScriptNS1:DBValueExtract(string($var:v616) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v618"" select=""ScriptNS1:DBLookup(1 , string($var:v617) , string($var:v615) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v619"" select=""ScriptNS1:DBValueExtract(string($var:v618) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v620"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v621"" select=""ScriptNS1:DBLookup(7 , string($var:v619) , string($var:v620) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v622"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v623"" select=""userCSharp:GetLSFO($var:v541 , string($var:v622))"" />
                    <xsl:variable name=""var:v624"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v625"" select=""userCSharp:GetHFO($var:v544 , string($var:v624))"" />
                    <xsl:variable name=""var:v626"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v627"" select=""userCSharp:GetLSGO($var:v547 , string($var:v626))"" />
                    <xsl:variable name=""var:v628"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v629"" select=""userCSharp:GetMDO($var:v550 , string($var:v628))"" />
                    <xsl:variable name=""var:v630"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v631"" select=""userCSharp:GetMGO($var:v553 , string($var:v630))"" />
                    <xsl:variable name=""var:v632"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v633"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v634"" select=""ScriptNS1:DBValueExtract(string($var:v621) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v635"" select=""userCSharp:GetLO($var:v558 , string($var:v632))"" />
                    <xsl:variable name=""var:v636"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v633))"" />
                    <xsl:variable name=""var:v637"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v634))"" />
                    <xsl:variable name=""var:v638"" select=""$var:v625"" />
                    <xsl:variable name=""var:v639"" select=""userCSharp:LogicalEq(string($var:v638) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v642"" select=""userCSharp:LogicalAnd(string($var:v639) , string($var:v641))"" />
                    <xsl:if test=""string($var:v642)='true'"">
                      <xsl:variable name=""var:v643"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v644"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v643) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v645"" select=""ScriptNS1:DBValueExtract(string($var:v644) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v646"" select=""ScriptNS1:DBLookup(1 , string($var:v645) , string($var:v643) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v647"" select=""ScriptNS1:DBValueExtract(string($var:v646) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v648"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v649"" select=""ScriptNS1:DBLookup(7 , string($var:v647) , string($var:v648) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v650"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v651"" select=""userCSharp:GetLSFO($var:v541 , string($var:v650))"" />
                      <xsl:variable name=""var:v652"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v653"" select=""userCSharp:GetHFO($var:v544 , string($var:v652))"" />
                      <xsl:variable name=""var:v654"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v655"" select=""userCSharp:GetLSGO($var:v547 , string($var:v654))"" />
                      <xsl:variable name=""var:v656"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v657"" select=""userCSharp:GetMDO($var:v550 , string($var:v656))"" />
                      <xsl:variable name=""var:v658"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v659"" select=""userCSharp:GetMGO($var:v553 , string($var:v658))"" />
                      <xsl:variable name=""var:v660"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v661"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v662"" select=""ScriptNS1:DBValueExtract(string($var:v649) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v663"" select=""userCSharp:GetLO($var:v558 , string($var:v660))"" />
                      <xsl:variable name=""var:v664"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v661))"" />
                      <xsl:variable name=""var:v665"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v662))"" />
                      <xsl:variable name=""var:v666"" select=""../Hfo"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v666"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v667"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v668"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v667) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v669"" select=""ScriptNS1:DBValueExtract(string($var:v668) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v670"" select=""ScriptNS1:DBLookup(1 , string($var:v669) , string($var:v667) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v671"" select=""ScriptNS1:DBValueExtract(string($var:v670) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v672"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v673"" select=""ScriptNS1:DBLookup(7 , string($var:v671) , string($var:v672) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v674"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v675"" select=""userCSharp:GetLSFO($var:v541 , string($var:v674))"" />
                    <xsl:variable name=""var:v676"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v677"" select=""userCSharp:GetHFO($var:v544 , string($var:v676))"" />
                    <xsl:variable name=""var:v678"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v679"" select=""userCSharp:GetLSGO($var:v547 , string($var:v678))"" />
                    <xsl:variable name=""var:v680"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v681"" select=""userCSharp:GetMDO($var:v550 , string($var:v680))"" />
                    <xsl:variable name=""var:v682"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v683"" select=""userCSharp:GetMGO($var:v553 , string($var:v682))"" />
                    <xsl:variable name=""var:v684"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v685"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v686"" select=""ScriptNS1:DBValueExtract(string($var:v673) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v687"" select=""userCSharp:GetLO($var:v558 , string($var:v684))"" />
                    <xsl:variable name=""var:v688"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v685))"" />
                    <xsl:variable name=""var:v689"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v686))"" />
                    <xsl:variable name=""var:v690"" select=""$var:v677"" />
                    <xsl:variable name=""var:v691"" select=""userCSharp:LogicalEq(string($var:v690) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v693"" select=""userCSharp:LogicalAnd(string($var:v691) , string($var:v692))"" />
                    <xsl:if test=""string($var:v693)='true'"">
                      <xsl:variable name=""var:v694"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v695"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v694) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v696"" select=""ScriptNS1:DBValueExtract(string($var:v695) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v697"" select=""ScriptNS1:DBLookup(1 , string($var:v696) , string($var:v694) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v698"" select=""ScriptNS1:DBValueExtract(string($var:v697) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v699"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v700"" select=""ScriptNS1:DBLookup(7 , string($var:v698) , string($var:v699) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v701"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v702"" select=""userCSharp:GetLSFO($var:v541 , string($var:v701))"" />
                      <xsl:variable name=""var:v703"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v704"" select=""userCSharp:GetHFO($var:v544 , string($var:v703))"" />
                      <xsl:variable name=""var:v705"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v706"" select=""userCSharp:GetLSGO($var:v547 , string($var:v705))"" />
                      <xsl:variable name=""var:v707"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v708"" select=""userCSharp:GetMDO($var:v550 , string($var:v707))"" />
                      <xsl:variable name=""var:v709"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v710"" select=""userCSharp:GetMGO($var:v553 , string($var:v709))"" />
                      <xsl:variable name=""var:v711"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v712"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v713"" select=""ScriptNS1:DBValueExtract(string($var:v700) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v714"" select=""userCSharp:GetLO($var:v558 , string($var:v711))"" />
                      <xsl:variable name=""var:v715"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v712))"" />
                      <xsl:variable name=""var:v716"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v713))"" />
                      <xsl:variable name=""var:v717"" select=""../Hfo"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v717"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v719"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v720"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v719) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v721"" select=""ScriptNS1:DBValueExtract(string($var:v720) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v722"" select=""ScriptNS1:DBLookup(1 , string($var:v721) , string($var:v719) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v723"" select=""ScriptNS1:DBValueExtract(string($var:v722) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v724"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v725"" select=""ScriptNS1:DBLookup(7 , string($var:v723) , string($var:v724) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v726"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v727"" select=""userCSharp:GetLSFO($var:v541 , string($var:v726))"" />
                    <xsl:variable name=""var:v728"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v729"" select=""userCSharp:GetHFO($var:v544 , string($var:v728))"" />
                    <xsl:variable name=""var:v730"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v731"" select=""userCSharp:GetLSGO($var:v547 , string($var:v730))"" />
                    <xsl:variable name=""var:v732"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v733"" select=""userCSharp:GetMDO($var:v550 , string($var:v732))"" />
                    <xsl:variable name=""var:v734"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v735"" select=""userCSharp:GetMGO($var:v553 , string($var:v734))"" />
                    <xsl:variable name=""var:v736"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v737"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v738"" select=""ScriptNS1:DBValueExtract(string($var:v725) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v739"" select=""userCSharp:GetLO($var:v558 , string($var:v736))"" />
                    <xsl:variable name=""var:v740"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v737))"" />
                    <xsl:variable name=""var:v741"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v738))"" />
                    <xsl:variable name=""var:v742"" select=""$var:v729"" />
                    <xsl:variable name=""var:v743"" select=""userCSharp:LogicalEq(string($var:v742) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v744"" select=""userCSharp:LogicalAnd(string($var:v718) , string($var:v743))"" />
                    <xsl:if test=""string($var:v744)='true'"">
                      <xsl:variable name=""var:v745"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v746"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v745) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v747"" select=""ScriptNS1:DBValueExtract(string($var:v746) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v748"" select=""ScriptNS1:DBLookup(1 , string($var:v747) , string($var:v745) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v749"" select=""ScriptNS1:DBValueExtract(string($var:v748) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v750"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v751"" select=""ScriptNS1:DBLookup(7 , string($var:v749) , string($var:v750) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v752"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v753"" select=""userCSharp:GetLSFO($var:v541 , string($var:v752))"" />
                      <xsl:variable name=""var:v754"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v755"" select=""userCSharp:GetHFO($var:v544 , string($var:v754))"" />
                      <xsl:variable name=""var:v756"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v757"" select=""userCSharp:GetLSGO($var:v547 , string($var:v756))"" />
                      <xsl:variable name=""var:v758"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v759"" select=""userCSharp:GetMDO($var:v550 , string($var:v758))"" />
                      <xsl:variable name=""var:v760"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v761"" select=""userCSharp:GetMGO($var:v553 , string($var:v760))"" />
                      <xsl:variable name=""var:v762"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v763"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v764"" select=""ScriptNS1:DBValueExtract(string($var:v751) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v765"" select=""userCSharp:GetLO($var:v558 , string($var:v762))"" />
                      <xsl:variable name=""var:v766"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v763))"" />
                      <xsl:variable name=""var:v767"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v764))"" />
                      <xsl:variable name=""var:v768"" select=""../Hfo"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v768"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v769"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v770"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v769) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v771"" select=""ScriptNS1:DBValueExtract(string($var:v770) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v772"" select=""ScriptNS1:DBLookup(1 , string($var:v771) , string($var:v769) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v773"" select=""ScriptNS1:DBValueExtract(string($var:v772) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v774"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v775"" select=""ScriptNS1:DBLookup(7 , string($var:v773) , string($var:v774) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v776"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v777"" select=""userCSharp:GetLSFO($var:v541 , string($var:v776))"" />
                    <xsl:variable name=""var:v778"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v779"" select=""userCSharp:GetHFO($var:v544 , string($var:v778))"" />
                    <xsl:variable name=""var:v780"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v781"" select=""userCSharp:GetLSGO($var:v547 , string($var:v780))"" />
                    <xsl:variable name=""var:v782"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v783"" select=""userCSharp:GetMDO($var:v550 , string($var:v782))"" />
                    <xsl:variable name=""var:v784"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v785"" select=""userCSharp:GetMGO($var:v553 , string($var:v784))"" />
                    <xsl:variable name=""var:v786"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v787"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v788"" select=""ScriptNS1:DBValueExtract(string($var:v775) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v789"" select=""userCSharp:GetLO($var:v558 , string($var:v786))"" />
                    <xsl:variable name=""var:v790"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v787))"" />
                    <xsl:variable name=""var:v791"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v788))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v792"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v793"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v792) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v794"" select=""ScriptNS1:DBValueExtract(string($var:v793) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v795"" select=""ScriptNS1:DBLookup(1 , string($var:v794) , string($var:v792) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v796"" select=""ScriptNS1:DBValueExtract(string($var:v795) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v797"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v798"" select=""ScriptNS1:DBLookup(7 , string($var:v796) , string($var:v797) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v799"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v800"" select=""userCSharp:GetLSFO($var:v541 , string($var:v799))"" />
                <xsl:variable name=""var:v801"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v802"" select=""userCSharp:GetHFO($var:v544 , string($var:v801))"" />
                <xsl:variable name=""var:v803"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v804"" select=""userCSharp:GetLSGO($var:v547 , string($var:v803))"" />
                <xsl:variable name=""var:v805"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v806"" select=""userCSharp:GetMDO($var:v550 , string($var:v805))"" />
                <xsl:variable name=""var:v807"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v808"" select=""userCSharp:GetMGO($var:v553 , string($var:v807))"" />
                <xsl:variable name=""var:v809"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v810"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v811"" select=""ScriptNS1:DBValueExtract(string($var:v798) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v812"" select=""userCSharp:GetLO($var:v558 , string($var:v809))"" />
                <xsl:variable name=""var:v813"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v810))"" />
                <xsl:variable name=""var:v814"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v811))"" />
                <xsl:variable name=""var:v815"" select=""$var:v806"" />
                <xsl:variable name=""var:v816"" select=""userCSharp:LogicalEq(string($var:v815) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v816"">
                  <xsl:variable name=""var:v891"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v892"" select=""userCSharp:LogicalEq($var:v891 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v943"" select=""userCSharp:LogicalEq($var:v891 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v969"" select=""userCSharp:LogicalEq($var:v891 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v817"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v818"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v817) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v819"" select=""ScriptNS1:DBValueExtract(string($var:v818) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v820"" select=""ScriptNS1:DBLookup(1 , string($var:v819) , string($var:v817) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v821"" select=""ScriptNS1:DBValueExtract(string($var:v820) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v822"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v823"" select=""ScriptNS1:DBLookup(7 , string($var:v821) , string($var:v822) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v824"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v825"" select=""userCSharp:GetLSFO($var:v541 , string($var:v824))"" />
                    <xsl:variable name=""var:v826"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v827"" select=""userCSharp:GetHFO($var:v544 , string($var:v826))"" />
                    <xsl:variable name=""var:v828"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v829"" select=""userCSharp:GetLSGO($var:v547 , string($var:v828))"" />
                    <xsl:variable name=""var:v830"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v831"" select=""userCSharp:GetMDO($var:v550 , string($var:v830))"" />
                    <xsl:variable name=""var:v832"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v833"" select=""userCSharp:GetMGO($var:v553 , string($var:v832))"" />
                    <xsl:variable name=""var:v834"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v835"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v836"" select=""ScriptNS1:DBValueExtract(string($var:v823) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v837"" select=""userCSharp:GetLO($var:v558 , string($var:v834))"" />
                    <xsl:variable name=""var:v838"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v835))"" />
                    <xsl:variable name=""var:v839"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v836))"" />
                    <xsl:variable name=""var:v840"" select=""$var:v831"" />
                    <xsl:variable name=""var:v841"" select=""userCSharp:LogicalEq(string($var:v840) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v841)='true'"">
                      <xsl:variable name=""var:v842"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v843"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v842) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v844"" select=""ScriptNS1:DBValueExtract(string($var:v843) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v845"" select=""ScriptNS1:DBLookup(1 , string($var:v844) , string($var:v842) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v846"" select=""ScriptNS1:DBValueExtract(string($var:v845) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v847"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v848"" select=""ScriptNS1:DBLookup(7 , string($var:v846) , string($var:v847) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v849"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v850"" select=""userCSharp:GetLSFO($var:v541 , string($var:v849))"" />
                      <xsl:variable name=""var:v851"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v852"" select=""userCSharp:GetHFO($var:v544 , string($var:v851))"" />
                      <xsl:variable name=""var:v853"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v854"" select=""userCSharp:GetLSGO($var:v547 , string($var:v853))"" />
                      <xsl:variable name=""var:v855"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v856"" select=""userCSharp:GetMDO($var:v550 , string($var:v855))"" />
                      <xsl:variable name=""var:v857"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v858"" select=""userCSharp:GetMGO($var:v553 , string($var:v857))"" />
                      <xsl:variable name=""var:v859"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v860"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v861"" select=""ScriptNS1:DBValueExtract(string($var:v848) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v862"" select=""userCSharp:GetLO($var:v558 , string($var:v859))"" />
                      <xsl:variable name=""var:v863"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v860))"" />
                      <xsl:variable name=""var:v864"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v861))"" />
                      <xsl:variable name=""var:v865"" select=""$var:v855"" />
                      <Grade>
                        <xsl:value-of select=""$var:v865"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v866"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v867"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v866) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v868"" select=""ScriptNS1:DBValueExtract(string($var:v867) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v869"" select=""ScriptNS1:DBLookup(1 , string($var:v868) , string($var:v866) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v870"" select=""ScriptNS1:DBValueExtract(string($var:v869) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v871"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v872"" select=""ScriptNS1:DBLookup(7 , string($var:v870) , string($var:v871) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v873"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v874"" select=""userCSharp:GetLSFO($var:v541 , string($var:v873))"" />
                    <xsl:variable name=""var:v875"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v876"" select=""userCSharp:GetHFO($var:v544 , string($var:v875))"" />
                    <xsl:variable name=""var:v877"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v878"" select=""userCSharp:GetLSGO($var:v547 , string($var:v877))"" />
                    <xsl:variable name=""var:v879"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v880"" select=""userCSharp:GetMDO($var:v550 , string($var:v879))"" />
                    <xsl:variable name=""var:v881"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v882"" select=""userCSharp:GetMGO($var:v553 , string($var:v881))"" />
                    <xsl:variable name=""var:v883"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v884"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v885"" select=""ScriptNS1:DBValueExtract(string($var:v872) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v886"" select=""userCSharp:GetLO($var:v558 , string($var:v883))"" />
                    <xsl:variable name=""var:v887"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v884))"" />
                    <xsl:variable name=""var:v888"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v885))"" />
                    <xsl:variable name=""var:v889"" select=""$var:v880"" />
                    <xsl:variable name=""var:v890"" select=""userCSharp:LogicalEq(string($var:v889) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v893"" select=""userCSharp:LogicalAnd(string($var:v890) , string($var:v892))"" />
                    <xsl:if test=""string($var:v893)='true'"">
                      <xsl:variable name=""var:v894"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v895"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v894) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v896"" select=""ScriptNS1:DBValueExtract(string($var:v895) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v897"" select=""ScriptNS1:DBLookup(1 , string($var:v896) , string($var:v894) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v898"" select=""ScriptNS1:DBValueExtract(string($var:v897) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v899"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v900"" select=""ScriptNS1:DBLookup(7 , string($var:v898) , string($var:v899) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v901"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v902"" select=""userCSharp:GetLSFO($var:v541 , string($var:v901))"" />
                      <xsl:variable name=""var:v903"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v904"" select=""userCSharp:GetHFO($var:v544 , string($var:v903))"" />
                      <xsl:variable name=""var:v905"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v906"" select=""userCSharp:GetLSGO($var:v547 , string($var:v905))"" />
                      <xsl:variable name=""var:v907"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v908"" select=""userCSharp:GetMDO($var:v550 , string($var:v907))"" />
                      <xsl:variable name=""var:v909"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v910"" select=""userCSharp:GetMGO($var:v553 , string($var:v909))"" />
                      <xsl:variable name=""var:v911"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v912"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v913"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v914"" select=""userCSharp:GetLO($var:v558 , string($var:v911))"" />
                      <xsl:variable name=""var:v915"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v912))"" />
                      <xsl:variable name=""var:v916"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v913))"" />
                      <xsl:variable name=""var:v917"" select=""../Mdo"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v917"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v918"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v919"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v918) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v920"" select=""ScriptNS1:DBValueExtract(string($var:v919) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v921"" select=""ScriptNS1:DBLookup(1 , string($var:v920) , string($var:v918) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v922"" select=""ScriptNS1:DBValueExtract(string($var:v921) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v923"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v924"" select=""ScriptNS1:DBLookup(7 , string($var:v922) , string($var:v923) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v925"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v926"" select=""userCSharp:GetLSFO($var:v541 , string($var:v925))"" />
                    <xsl:variable name=""var:v927"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v928"" select=""userCSharp:GetHFO($var:v544 , string($var:v927))"" />
                    <xsl:variable name=""var:v929"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v930"" select=""userCSharp:GetLSGO($var:v547 , string($var:v929))"" />
                    <xsl:variable name=""var:v931"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v932"" select=""userCSharp:GetMDO($var:v550 , string($var:v931))"" />
                    <xsl:variable name=""var:v933"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v934"" select=""userCSharp:GetMGO($var:v553 , string($var:v933))"" />
                    <xsl:variable name=""var:v935"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v936"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v937"" select=""ScriptNS1:DBValueExtract(string($var:v924) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v938"" select=""userCSharp:GetLO($var:v558 , string($var:v935))"" />
                    <xsl:variable name=""var:v939"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v936))"" />
                    <xsl:variable name=""var:v940"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v937))"" />
                    <xsl:variable name=""var:v941"" select=""$var:v932"" />
                    <xsl:variable name=""var:v942"" select=""userCSharp:LogicalEq(string($var:v941) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v944"" select=""userCSharp:LogicalAnd(string($var:v942) , string($var:v943))"" />
                    <xsl:if test=""string($var:v944)='true'"">
                      <xsl:variable name=""var:v945"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v946"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v945) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v947"" select=""ScriptNS1:DBValueExtract(string($var:v946) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v948"" select=""ScriptNS1:DBLookup(1 , string($var:v947) , string($var:v945) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v949"" select=""ScriptNS1:DBValueExtract(string($var:v948) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v950"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v951"" select=""ScriptNS1:DBLookup(7 , string($var:v949) , string($var:v950) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v952"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v953"" select=""userCSharp:GetLSFO($var:v541 , string($var:v952))"" />
                      <xsl:variable name=""var:v954"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v955"" select=""userCSharp:GetHFO($var:v544 , string($var:v954))"" />
                      <xsl:variable name=""var:v956"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v957"" select=""userCSharp:GetLSGO($var:v547 , string($var:v956))"" />
                      <xsl:variable name=""var:v958"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v959"" select=""userCSharp:GetMDO($var:v550 , string($var:v958))"" />
                      <xsl:variable name=""var:v960"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v961"" select=""userCSharp:GetMGO($var:v553 , string($var:v960))"" />
                      <xsl:variable name=""var:v962"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v963"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v964"" select=""ScriptNS1:DBValueExtract(string($var:v951) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v965"" select=""userCSharp:GetLO($var:v558 , string($var:v962))"" />
                      <xsl:variable name=""var:v966"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v963))"" />
                      <xsl:variable name=""var:v967"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v964))"" />
                      <xsl:variable name=""var:v968"" select=""../Mdo"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v968"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v970"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v971"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v970) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v972"" select=""ScriptNS1:DBValueExtract(string($var:v971) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v973"" select=""ScriptNS1:DBLookup(1 , string($var:v972) , string($var:v970) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v974"" select=""ScriptNS1:DBValueExtract(string($var:v973) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v975"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v976"" select=""ScriptNS1:DBLookup(7 , string($var:v974) , string($var:v975) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v977"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v978"" select=""userCSharp:GetLSFO($var:v541 , string($var:v977))"" />
                    <xsl:variable name=""var:v979"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v980"" select=""userCSharp:GetHFO($var:v544 , string($var:v979))"" />
                    <xsl:variable name=""var:v981"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v982"" select=""userCSharp:GetLSGO($var:v547 , string($var:v981))"" />
                    <xsl:variable name=""var:v983"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v984"" select=""userCSharp:GetMDO($var:v550 , string($var:v983))"" />
                    <xsl:variable name=""var:v985"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v986"" select=""userCSharp:GetMGO($var:v553 , string($var:v985))"" />
                    <xsl:variable name=""var:v987"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v988"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v989"" select=""ScriptNS1:DBValueExtract(string($var:v976) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v990"" select=""userCSharp:GetLO($var:v558 , string($var:v987))"" />
                    <xsl:variable name=""var:v991"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v988))"" />
                    <xsl:variable name=""var:v992"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v989))"" />
                    <xsl:variable name=""var:v993"" select=""$var:v984"" />
                    <xsl:variable name=""var:v994"" select=""userCSharp:LogicalEq(string($var:v993) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v995"" select=""userCSharp:LogicalAnd(string($var:v969) , string($var:v994))"" />
                    <xsl:if test=""string($var:v995)='true'"">
                      <xsl:variable name=""var:v996"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v997"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v996) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v998"" select=""ScriptNS1:DBValueExtract(string($var:v997) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v999"" select=""ScriptNS1:DBLookup(1 , string($var:v998) , string($var:v996) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1000"" select=""ScriptNS1:DBValueExtract(string($var:v999) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1001"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1002"" select=""ScriptNS1:DBLookup(7 , string($var:v1000) , string($var:v1001) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1003"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1004"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1003))"" />
                      <xsl:variable name=""var:v1005"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1006"" select=""userCSharp:GetHFO($var:v544 , string($var:v1005))"" />
                      <xsl:variable name=""var:v1007"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1008"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1007))"" />
                      <xsl:variable name=""var:v1009"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1010"" select=""userCSharp:GetMDO($var:v550 , string($var:v1009))"" />
                      <xsl:variable name=""var:v1011"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1012"" select=""userCSharp:GetMGO($var:v553 , string($var:v1011))"" />
                      <xsl:variable name=""var:v1013"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1014"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1015"" select=""ScriptNS1:DBValueExtract(string($var:v1002) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1016"" select=""userCSharp:GetLO($var:v558 , string($var:v1013))"" />
                      <xsl:variable name=""var:v1017"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1014))"" />
                      <xsl:variable name=""var:v1018"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1015))"" />
                      <xsl:variable name=""var:v1019"" select=""../Mdo"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1019"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1020"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1021"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1020) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1022"" select=""ScriptNS1:DBValueExtract(string($var:v1021) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1023"" select=""ScriptNS1:DBLookup(1 , string($var:v1022) , string($var:v1020) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1024"" select=""ScriptNS1:DBValueExtract(string($var:v1023) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1025"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1026"" select=""ScriptNS1:DBLookup(7 , string($var:v1024) , string($var:v1025) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1027"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1028"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1027))"" />
                    <xsl:variable name=""var:v1029"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1030"" select=""userCSharp:GetHFO($var:v544 , string($var:v1029))"" />
                    <xsl:variable name=""var:v1031"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1032"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1031))"" />
                    <xsl:variable name=""var:v1033"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1034"" select=""userCSharp:GetMDO($var:v550 , string($var:v1033))"" />
                    <xsl:variable name=""var:v1035"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1036"" select=""userCSharp:GetMGO($var:v553 , string($var:v1035))"" />
                    <xsl:variable name=""var:v1037"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1038"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1039"" select=""ScriptNS1:DBValueExtract(string($var:v1026) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1040"" select=""userCSharp:GetLO($var:v558 , string($var:v1037))"" />
                    <xsl:variable name=""var:v1041"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1038))"" />
                    <xsl:variable name=""var:v1042"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1039))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1043"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1044"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1043) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1045"" select=""ScriptNS1:DBValueExtract(string($var:v1044) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1046"" select=""ScriptNS1:DBLookup(1 , string($var:v1045) , string($var:v1043) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1047"" select=""ScriptNS1:DBValueExtract(string($var:v1046) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1048"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1049"" select=""ScriptNS1:DBLookup(7 , string($var:v1047) , string($var:v1048) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1050"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1051"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1050))"" />
                <xsl:variable name=""var:v1052"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1053"" select=""userCSharp:GetHFO($var:v544 , string($var:v1052))"" />
                <xsl:variable name=""var:v1054"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1055"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1054))"" />
                <xsl:variable name=""var:v1056"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1057"" select=""userCSharp:GetMDO($var:v550 , string($var:v1056))"" />
                <xsl:variable name=""var:v1058"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1059"" select=""userCSharp:GetMGO($var:v553 , string($var:v1058))"" />
                <xsl:variable name=""var:v1060"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1061"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1062"" select=""ScriptNS1:DBValueExtract(string($var:v1049) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1063"" select=""userCSharp:GetLO($var:v558 , string($var:v1060))"" />
                <xsl:variable name=""var:v1064"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1061))"" />
                <xsl:variable name=""var:v1065"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1062))"" />
                <xsl:variable name=""var:v1066"" select=""$var:v1059"" />
                <xsl:variable name=""var:v1067"" select=""userCSharp:LogicalEq(string($var:v1066) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1067"">
                  <xsl:variable name=""var:v1142"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1143"" select=""userCSharp:LogicalEq($var:v1142 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1194"" select=""userCSharp:LogicalEq($var:v1142 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1220"" select=""userCSharp:LogicalEq($var:v1142 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1068"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1069"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1068) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1070"" select=""ScriptNS1:DBValueExtract(string($var:v1069) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1071"" select=""ScriptNS1:DBLookup(1 , string($var:v1070) , string($var:v1068) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1072"" select=""ScriptNS1:DBValueExtract(string($var:v1071) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1073"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1074"" select=""ScriptNS1:DBLookup(7 , string($var:v1072) , string($var:v1073) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1075"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1076"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1075))"" />
                    <xsl:variable name=""var:v1077"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1078"" select=""userCSharp:GetHFO($var:v544 , string($var:v1077))"" />
                    <xsl:variable name=""var:v1079"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1080"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1079))"" />
                    <xsl:variable name=""var:v1081"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1082"" select=""userCSharp:GetMDO($var:v550 , string($var:v1081))"" />
                    <xsl:variable name=""var:v1083"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1084"" select=""userCSharp:GetMGO($var:v553 , string($var:v1083))"" />
                    <xsl:variable name=""var:v1085"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1086"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1087"" select=""ScriptNS1:DBValueExtract(string($var:v1074) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1088"" select=""userCSharp:GetLO($var:v558 , string($var:v1085))"" />
                    <xsl:variable name=""var:v1089"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1086))"" />
                    <xsl:variable name=""var:v1090"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1087))"" />
                    <xsl:variable name=""var:v1091"" select=""$var:v1084"" />
                    <xsl:variable name=""var:v1092"" select=""userCSharp:LogicalEq(string($var:v1091) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v1092)='true'"">
                      <xsl:variable name=""var:v1093"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1094"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1093) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1095"" select=""ScriptNS1:DBValueExtract(string($var:v1094) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1096"" select=""ScriptNS1:DBLookup(1 , string($var:v1095) , string($var:v1093) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1097"" select=""ScriptNS1:DBValueExtract(string($var:v1096) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1098"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1099"" select=""ScriptNS1:DBLookup(7 , string($var:v1097) , string($var:v1098) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1100"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1101"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1100))"" />
                      <xsl:variable name=""var:v1102"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1103"" select=""userCSharp:GetHFO($var:v544 , string($var:v1102))"" />
                      <xsl:variable name=""var:v1104"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1105"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1104))"" />
                      <xsl:variable name=""var:v1106"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1107"" select=""userCSharp:GetMDO($var:v550 , string($var:v1106))"" />
                      <xsl:variable name=""var:v1108"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1109"" select=""userCSharp:GetMGO($var:v553 , string($var:v1108))"" />
                      <xsl:variable name=""var:v1110"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1111"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1112"" select=""ScriptNS1:DBValueExtract(string($var:v1099) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1113"" select=""userCSharp:GetLO($var:v558 , string($var:v1110))"" />
                      <xsl:variable name=""var:v1114"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1111))"" />
                      <xsl:variable name=""var:v1115"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1112))"" />
                      <xsl:variable name=""var:v1116"" select=""$var:v1108"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1116"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1117"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1118"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1117) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1119"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1120"" select=""ScriptNS1:DBLookup(1 , string($var:v1119) , string($var:v1117) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1121"" select=""ScriptNS1:DBValueExtract(string($var:v1120) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1122"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1123"" select=""ScriptNS1:DBLookup(7 , string($var:v1121) , string($var:v1122) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1124"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1125"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1124))"" />
                    <xsl:variable name=""var:v1126"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1127"" select=""userCSharp:GetHFO($var:v544 , string($var:v1126))"" />
                    <xsl:variable name=""var:v1128"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1129"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1128))"" />
                    <xsl:variable name=""var:v1130"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1131"" select=""userCSharp:GetMDO($var:v550 , string($var:v1130))"" />
                    <xsl:variable name=""var:v1132"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1133"" select=""userCSharp:GetMGO($var:v553 , string($var:v1132))"" />
                    <xsl:variable name=""var:v1134"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1135"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1136"" select=""ScriptNS1:DBValueExtract(string($var:v1123) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1137"" select=""userCSharp:GetLO($var:v558 , string($var:v1134))"" />
                    <xsl:variable name=""var:v1138"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1135))"" />
                    <xsl:variable name=""var:v1139"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1136))"" />
                    <xsl:variable name=""var:v1140"" select=""$var:v1133"" />
                    <xsl:variable name=""var:v1141"" select=""userCSharp:LogicalEq(string($var:v1140) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1144"" select=""userCSharp:LogicalAnd(string($var:v1141) , string($var:v1143))"" />
                    <xsl:if test=""string($var:v1144)='true'"">
                      <xsl:variable name=""var:v1145"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1146"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1145) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1147"" select=""ScriptNS1:DBValueExtract(string($var:v1146) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1148"" select=""ScriptNS1:DBLookup(1 , string($var:v1147) , string($var:v1145) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1149"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1150"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1151"" select=""ScriptNS1:DBLookup(7 , string($var:v1149) , string($var:v1150) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1152"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1153"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1152))"" />
                      <xsl:variable name=""var:v1154"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1155"" select=""userCSharp:GetHFO($var:v544 , string($var:v1154))"" />
                      <xsl:variable name=""var:v1156"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1157"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1156))"" />
                      <xsl:variable name=""var:v1158"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1159"" select=""userCSharp:GetMDO($var:v550 , string($var:v1158))"" />
                      <xsl:variable name=""var:v1160"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1161"" select=""userCSharp:GetMGO($var:v553 , string($var:v1160))"" />
                      <xsl:variable name=""var:v1162"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1163"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1164"" select=""ScriptNS1:DBValueExtract(string($var:v1151) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1165"" select=""userCSharp:GetLO($var:v558 , string($var:v1162))"" />
                      <xsl:variable name=""var:v1166"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1163))"" />
                      <xsl:variable name=""var:v1167"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1164))"" />
                      <xsl:variable name=""var:v1168"" select=""../Mgo"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1168"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1169"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1170"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1169) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1171"" select=""ScriptNS1:DBValueExtract(string($var:v1170) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1172"" select=""ScriptNS1:DBLookup(1 , string($var:v1171) , string($var:v1169) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1173"" select=""ScriptNS1:DBValueExtract(string($var:v1172) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1174"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1175"" select=""ScriptNS1:DBLookup(7 , string($var:v1173) , string($var:v1174) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1176"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1177"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1176))"" />
                    <xsl:variable name=""var:v1178"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1179"" select=""userCSharp:GetHFO($var:v544 , string($var:v1178))"" />
                    <xsl:variable name=""var:v1180"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1181"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1180))"" />
                    <xsl:variable name=""var:v1182"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1183"" select=""userCSharp:GetMDO($var:v550 , string($var:v1182))"" />
                    <xsl:variable name=""var:v1184"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1185"" select=""userCSharp:GetMGO($var:v553 , string($var:v1184))"" />
                    <xsl:variable name=""var:v1186"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1187"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1188"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1189"" select=""userCSharp:GetLO($var:v558 , string($var:v1186))"" />
                    <xsl:variable name=""var:v1190"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1187))"" />
                    <xsl:variable name=""var:v1191"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1188))"" />
                    <xsl:variable name=""var:v1192"" select=""$var:v1185"" />
                    <xsl:variable name=""var:v1193"" select=""userCSharp:LogicalEq(string($var:v1192) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1195"" select=""userCSharp:LogicalAnd(string($var:v1193) , string($var:v1194))"" />
                    <xsl:if test=""string($var:v1195)='true'"">
                      <xsl:variable name=""var:v1196"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1197"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1196) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1198"" select=""ScriptNS1:DBValueExtract(string($var:v1197) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1199"" select=""ScriptNS1:DBLookup(1 , string($var:v1198) , string($var:v1196) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1200"" select=""ScriptNS1:DBValueExtract(string($var:v1199) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1201"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1202"" select=""ScriptNS1:DBLookup(7 , string($var:v1200) , string($var:v1201) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1203"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1204"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1203))"" />
                      <xsl:variable name=""var:v1205"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1206"" select=""userCSharp:GetHFO($var:v544 , string($var:v1205))"" />
                      <xsl:variable name=""var:v1207"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1208"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1207))"" />
                      <xsl:variable name=""var:v1209"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1210"" select=""userCSharp:GetMDO($var:v550 , string($var:v1209))"" />
                      <xsl:variable name=""var:v1211"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1212"" select=""userCSharp:GetMGO($var:v553 , string($var:v1211))"" />
                      <xsl:variable name=""var:v1213"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1214"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1215"" select=""ScriptNS1:DBValueExtract(string($var:v1202) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1216"" select=""userCSharp:GetLO($var:v558 , string($var:v1213))"" />
                      <xsl:variable name=""var:v1217"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1214))"" />
                      <xsl:variable name=""var:v1218"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1215))"" />
                      <xsl:variable name=""var:v1219"" select=""../Mgo"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1219"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1221"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1222"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1221) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1223"" select=""ScriptNS1:DBValueExtract(string($var:v1222) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1224"" select=""ScriptNS1:DBLookup(1 , string($var:v1223) , string($var:v1221) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1225"" select=""ScriptNS1:DBValueExtract(string($var:v1224) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1226"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1227"" select=""ScriptNS1:DBLookup(7 , string($var:v1225) , string($var:v1226) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1228"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1229"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1228))"" />
                    <xsl:variable name=""var:v1230"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1231"" select=""userCSharp:GetHFO($var:v544 , string($var:v1230))"" />
                    <xsl:variable name=""var:v1232"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1233"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1232))"" />
                    <xsl:variable name=""var:v1234"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1235"" select=""userCSharp:GetMDO($var:v550 , string($var:v1234))"" />
                    <xsl:variable name=""var:v1236"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1237"" select=""userCSharp:GetMGO($var:v553 , string($var:v1236))"" />
                    <xsl:variable name=""var:v1238"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1239"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1240"" select=""ScriptNS1:DBValueExtract(string($var:v1227) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1241"" select=""userCSharp:GetLO($var:v558 , string($var:v1238))"" />
                    <xsl:variable name=""var:v1242"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1239))"" />
                    <xsl:variable name=""var:v1243"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1240))"" />
                    <xsl:variable name=""var:v1244"" select=""$var:v1237"" />
                    <xsl:variable name=""var:v1245"" select=""userCSharp:LogicalEq(string($var:v1244) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1246"" select=""userCSharp:LogicalAnd(string($var:v1220) , string($var:v1245))"" />
                    <xsl:if test=""string($var:v1246)='true'"">
                      <xsl:variable name=""var:v1247"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1248"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1247) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1249"" select=""ScriptNS1:DBValueExtract(string($var:v1248) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1250"" select=""ScriptNS1:DBLookup(1 , string($var:v1249) , string($var:v1247) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1251"" select=""ScriptNS1:DBValueExtract(string($var:v1250) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1252"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1253"" select=""ScriptNS1:DBLookup(7 , string($var:v1251) , string($var:v1252) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1254"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1255"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1254))"" />
                      <xsl:variable name=""var:v1256"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1257"" select=""userCSharp:GetHFO($var:v544 , string($var:v1256))"" />
                      <xsl:variable name=""var:v1258"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1259"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1258))"" />
                      <xsl:variable name=""var:v1260"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1261"" select=""userCSharp:GetMDO($var:v550 , string($var:v1260))"" />
                      <xsl:variable name=""var:v1262"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1263"" select=""userCSharp:GetMGO($var:v553 , string($var:v1262))"" />
                      <xsl:variable name=""var:v1264"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1265"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1266"" select=""ScriptNS1:DBValueExtract(string($var:v1253) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1267"" select=""userCSharp:GetLO($var:v558 , string($var:v1264))"" />
                      <xsl:variable name=""var:v1268"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1265))"" />
                      <xsl:variable name=""var:v1269"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1266))"" />
                      <xsl:variable name=""var:v1270"" select=""../Mgo"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1270"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1271"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1272"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1271) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1273"" select=""ScriptNS1:DBValueExtract(string($var:v1272) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1274"" select=""ScriptNS1:DBLookup(1 , string($var:v1273) , string($var:v1271) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1275"" select=""ScriptNS1:DBValueExtract(string($var:v1274) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1276"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1277"" select=""ScriptNS1:DBLookup(7 , string($var:v1275) , string($var:v1276) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1278"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1279"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1278))"" />
                    <xsl:variable name=""var:v1280"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1281"" select=""userCSharp:GetHFO($var:v544 , string($var:v1280))"" />
                    <xsl:variable name=""var:v1282"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1283"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1282))"" />
                    <xsl:variable name=""var:v1284"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1285"" select=""userCSharp:GetMDO($var:v550 , string($var:v1284))"" />
                    <xsl:variable name=""var:v1286"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1287"" select=""userCSharp:GetMGO($var:v553 , string($var:v1286))"" />
                    <xsl:variable name=""var:v1288"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1289"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1290"" select=""ScriptNS1:DBValueExtract(string($var:v1277) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1291"" select=""userCSharp:GetLO($var:v558 , string($var:v1288))"" />
                    <xsl:variable name=""var:v1292"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1289))"" />
                    <xsl:variable name=""var:v1293"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1290))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1294"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1295"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1294) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1296"" select=""ScriptNS1:DBValueExtract(string($var:v1295) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1297"" select=""ScriptNS1:DBLookup(1 , string($var:v1296) , string($var:v1294) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1298"" select=""ScriptNS1:DBValueExtract(string($var:v1297) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1299"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1300"" select=""ScriptNS1:DBLookup(7 , string($var:v1298) , string($var:v1299) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1301"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1302"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1301))"" />
                <xsl:variable name=""var:v1303"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1304"" select=""userCSharp:GetHFO($var:v544 , string($var:v1303))"" />
                <xsl:variable name=""var:v1305"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1306"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1305))"" />
                <xsl:variable name=""var:v1307"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1308"" select=""userCSharp:GetMDO($var:v550 , string($var:v1307))"" />
                <xsl:variable name=""var:v1309"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1310"" select=""userCSharp:GetMGO($var:v553 , string($var:v1309))"" />
                <xsl:variable name=""var:v1311"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1312"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1313"" select=""ScriptNS1:DBValueExtract(string($var:v1300) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1314"" select=""userCSharp:GetLO($var:v558 , string($var:v1311))"" />
                <xsl:variable name=""var:v1315"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1312))"" />
                <xsl:variable name=""var:v1316"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1313))"" />
                <xsl:variable name=""var:v1317"" select=""$var:v1306"" />
                <xsl:variable name=""var:v1318"" select=""userCSharp:LogicalEq(string($var:v1317) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1318"">
                  <xsl:variable name=""var:v1393"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1394"" select=""userCSharp:LogicalEq($var:v1393 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1445"" select=""userCSharp:LogicalEq($var:v1393 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1471"" select=""userCSharp:LogicalEq($var:v1393 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1319"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1320"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1319) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1321"" select=""ScriptNS1:DBValueExtract(string($var:v1320) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1322"" select=""ScriptNS1:DBLookup(1 , string($var:v1321) , string($var:v1319) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1323"" select=""ScriptNS1:DBValueExtract(string($var:v1322) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1324"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1325"" select=""ScriptNS1:DBLookup(7 , string($var:v1323) , string($var:v1324) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1326"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1327"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1326))"" />
                    <xsl:variable name=""var:v1328"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1329"" select=""userCSharp:GetHFO($var:v544 , string($var:v1328))"" />
                    <xsl:variable name=""var:v1330"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1331"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1330))"" />
                    <xsl:variable name=""var:v1332"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1333"" select=""userCSharp:GetMDO($var:v550 , string($var:v1332))"" />
                    <xsl:variable name=""var:v1334"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1335"" select=""userCSharp:GetMGO($var:v553 , string($var:v1334))"" />
                    <xsl:variable name=""var:v1336"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1337"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1338"" select=""ScriptNS1:DBValueExtract(string($var:v1325) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1339"" select=""userCSharp:GetLO($var:v558 , string($var:v1336))"" />
                    <xsl:variable name=""var:v1340"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1337))"" />
                    <xsl:variable name=""var:v1341"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1338))"" />
                    <xsl:variable name=""var:v1342"" select=""$var:v1331"" />
                    <xsl:variable name=""var:v1343"" select=""userCSharp:LogicalEq(string($var:v1342) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v1343)='true'"">
                      <xsl:variable name=""var:v1344"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1345"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1344) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1346"" select=""ScriptNS1:DBValueExtract(string($var:v1345) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1347"" select=""ScriptNS1:DBLookup(1 , string($var:v1346) , string($var:v1344) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1348"" select=""ScriptNS1:DBValueExtract(string($var:v1347) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1349"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1350"" select=""ScriptNS1:DBLookup(7 , string($var:v1348) , string($var:v1349) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1351"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1352"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1351))"" />
                      <xsl:variable name=""var:v1353"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1354"" select=""userCSharp:GetHFO($var:v544 , string($var:v1353))"" />
                      <xsl:variable name=""var:v1355"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1356"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1355))"" />
                      <xsl:variable name=""var:v1357"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1358"" select=""userCSharp:GetMDO($var:v550 , string($var:v1357))"" />
                      <xsl:variable name=""var:v1359"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1360"" select=""userCSharp:GetMGO($var:v553 , string($var:v1359))"" />
                      <xsl:variable name=""var:v1361"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1362"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1363"" select=""ScriptNS1:DBValueExtract(string($var:v1350) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1364"" select=""userCSharp:GetLO($var:v558 , string($var:v1361))"" />
                      <xsl:variable name=""var:v1365"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1362))"" />
                      <xsl:variable name=""var:v1366"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1363))"" />
                      <xsl:variable name=""var:v1367"" select=""$var:v1355"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1367"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1368"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1369"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1368) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1370"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1371"" select=""ScriptNS1:DBLookup(1 , string($var:v1370) , string($var:v1368) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1372"" select=""ScriptNS1:DBValueExtract(string($var:v1371) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1373"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1374"" select=""ScriptNS1:DBLookup(7 , string($var:v1372) , string($var:v1373) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1375"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1376"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1375))"" />
                    <xsl:variable name=""var:v1377"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1378"" select=""userCSharp:GetHFO($var:v544 , string($var:v1377))"" />
                    <xsl:variable name=""var:v1379"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1380"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1379))"" />
                    <xsl:variable name=""var:v1381"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1382"" select=""userCSharp:GetMDO($var:v550 , string($var:v1381))"" />
                    <xsl:variable name=""var:v1383"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1384"" select=""userCSharp:GetMGO($var:v553 , string($var:v1383))"" />
                    <xsl:variable name=""var:v1385"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1386"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1387"" select=""ScriptNS1:DBValueExtract(string($var:v1374) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1388"" select=""userCSharp:GetLO($var:v558 , string($var:v1385))"" />
                    <xsl:variable name=""var:v1389"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1386))"" />
                    <xsl:variable name=""var:v1390"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1387))"" />
                    <xsl:variable name=""var:v1391"" select=""$var:v1380"" />
                    <xsl:variable name=""var:v1392"" select=""userCSharp:LogicalEq(string($var:v1391) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1395"" select=""userCSharp:LogicalAnd(string($var:v1392) , string($var:v1394))"" />
                    <xsl:if test=""string($var:v1395)='true'"">
                      <xsl:variable name=""var:v1396"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1397"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1396) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1398"" select=""ScriptNS1:DBValueExtract(string($var:v1397) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1399"" select=""ScriptNS1:DBLookup(1 , string($var:v1398) , string($var:v1396) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1400"" select=""ScriptNS1:DBValueExtract(string($var:v1399) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1401"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1402"" select=""ScriptNS1:DBLookup(7 , string($var:v1400) , string($var:v1401) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1403"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1404"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1403))"" />
                      <xsl:variable name=""var:v1405"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1406"" select=""userCSharp:GetHFO($var:v544 , string($var:v1405))"" />
                      <xsl:variable name=""var:v1407"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1408"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1407))"" />
                      <xsl:variable name=""var:v1409"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1410"" select=""userCSharp:GetMDO($var:v550 , string($var:v1409))"" />
                      <xsl:variable name=""var:v1411"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1412"" select=""userCSharp:GetMGO($var:v553 , string($var:v1411))"" />
                      <xsl:variable name=""var:v1413"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1414"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1415"" select=""ScriptNS1:DBValueExtract(string($var:v1402) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1416"" select=""userCSharp:GetLO($var:v558 , string($var:v1413))"" />
                      <xsl:variable name=""var:v1417"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1414))"" />
                      <xsl:variable name=""var:v1418"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1415))"" />
                      <xsl:variable name=""var:v1419"" select=""../Lsgo"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1419"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1420"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1421"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1420) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1422"" select=""ScriptNS1:DBValueExtract(string($var:v1421) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1423"" select=""ScriptNS1:DBLookup(1 , string($var:v1422) , string($var:v1420) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1424"" select=""ScriptNS1:DBValueExtract(string($var:v1423) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1425"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1426"" select=""ScriptNS1:DBLookup(7 , string($var:v1424) , string($var:v1425) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1427"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1428"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1427))"" />
                    <xsl:variable name=""var:v1429"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1430"" select=""userCSharp:GetHFO($var:v544 , string($var:v1429))"" />
                    <xsl:variable name=""var:v1431"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1432"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1431))"" />
                    <xsl:variable name=""var:v1433"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1434"" select=""userCSharp:GetMDO($var:v550 , string($var:v1433))"" />
                    <xsl:variable name=""var:v1435"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1436"" select=""userCSharp:GetMGO($var:v553 , string($var:v1435))"" />
                    <xsl:variable name=""var:v1437"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1438"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1439"" select=""ScriptNS1:DBValueExtract(string($var:v1426) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1440"" select=""userCSharp:GetLO($var:v558 , string($var:v1437))"" />
                    <xsl:variable name=""var:v1441"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1438))"" />
                    <xsl:variable name=""var:v1442"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1439))"" />
                    <xsl:variable name=""var:v1443"" select=""$var:v1432"" />
                    <xsl:variable name=""var:v1444"" select=""userCSharp:LogicalEq(string($var:v1443) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1446"" select=""userCSharp:LogicalAnd(string($var:v1444) , string($var:v1445))"" />
                    <xsl:if test=""string($var:v1446)='true'"">
                      <xsl:variable name=""var:v1447"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1448"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1447) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1449"" select=""ScriptNS1:DBValueExtract(string($var:v1448) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1450"" select=""ScriptNS1:DBLookup(1 , string($var:v1449) , string($var:v1447) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1451"" select=""ScriptNS1:DBValueExtract(string($var:v1450) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1452"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1453"" select=""ScriptNS1:DBLookup(7 , string($var:v1451) , string($var:v1452) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1454"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1455"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1454))"" />
                      <xsl:variable name=""var:v1456"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1457"" select=""userCSharp:GetHFO($var:v544 , string($var:v1456))"" />
                      <xsl:variable name=""var:v1458"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1459"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1458))"" />
                      <xsl:variable name=""var:v1460"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1461"" select=""userCSharp:GetMDO($var:v550 , string($var:v1460))"" />
                      <xsl:variable name=""var:v1462"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1463"" select=""userCSharp:GetMGO($var:v553 , string($var:v1462))"" />
                      <xsl:variable name=""var:v1464"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1465"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1466"" select=""ScriptNS1:DBValueExtract(string($var:v1453) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1467"" select=""userCSharp:GetLO($var:v558 , string($var:v1464))"" />
                      <xsl:variable name=""var:v1468"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1465))"" />
                      <xsl:variable name=""var:v1469"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1466))"" />
                      <xsl:variable name=""var:v1470"" select=""../Lsgo"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1470"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1472"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1473"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1472) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1474"" select=""ScriptNS1:DBValueExtract(string($var:v1473) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1475"" select=""ScriptNS1:DBLookup(1 , string($var:v1474) , string($var:v1472) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1476"" select=""ScriptNS1:DBValueExtract(string($var:v1475) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1477"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1478"" select=""ScriptNS1:DBLookup(7 , string($var:v1476) , string($var:v1477) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1479"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1480"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1479))"" />
                    <xsl:variable name=""var:v1481"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1482"" select=""userCSharp:GetHFO($var:v544 , string($var:v1481))"" />
                    <xsl:variable name=""var:v1483"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1484"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1483))"" />
                    <xsl:variable name=""var:v1485"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1486"" select=""userCSharp:GetMDO($var:v550 , string($var:v1485))"" />
                    <xsl:variable name=""var:v1487"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1488"" select=""userCSharp:GetMGO($var:v553 , string($var:v1487))"" />
                    <xsl:variable name=""var:v1489"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1490"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1491"" select=""ScriptNS1:DBValueExtract(string($var:v1478) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1492"" select=""userCSharp:GetLO($var:v558 , string($var:v1489))"" />
                    <xsl:variable name=""var:v1493"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1490))"" />
                    <xsl:variable name=""var:v1494"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1491))"" />
                    <xsl:variable name=""var:v1495"" select=""$var:v1484"" />
                    <xsl:variable name=""var:v1496"" select=""userCSharp:LogicalEq(string($var:v1495) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1497"" select=""userCSharp:LogicalAnd(string($var:v1471) , string($var:v1496))"" />
                    <xsl:if test=""string($var:v1497)='true'"">
                      <xsl:variable name=""var:v1498"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1499"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1498) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1500"" select=""ScriptNS1:DBValueExtract(string($var:v1499) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1501"" select=""ScriptNS1:DBLookup(1 , string($var:v1500) , string($var:v1498) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1502"" select=""ScriptNS1:DBValueExtract(string($var:v1501) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1503"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1504"" select=""ScriptNS1:DBLookup(7 , string($var:v1502) , string($var:v1503) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1505"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1506"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1505))"" />
                      <xsl:variable name=""var:v1507"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1508"" select=""userCSharp:GetHFO($var:v544 , string($var:v1507))"" />
                      <xsl:variable name=""var:v1509"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1510"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1509))"" />
                      <xsl:variable name=""var:v1511"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1512"" select=""userCSharp:GetMDO($var:v550 , string($var:v1511))"" />
                      <xsl:variable name=""var:v1513"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1514"" select=""userCSharp:GetMGO($var:v553 , string($var:v1513))"" />
                      <xsl:variable name=""var:v1515"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1516"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1517"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1518"" select=""userCSharp:GetLO($var:v558 , string($var:v1515))"" />
                      <xsl:variable name=""var:v1519"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1516))"" />
                      <xsl:variable name=""var:v1520"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1517))"" />
                      <xsl:variable name=""var:v1521"" select=""../Lsgo"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1521"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1522"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1523"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1522) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1524"" select=""ScriptNS1:DBValueExtract(string($var:v1523) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1525"" select=""ScriptNS1:DBLookup(1 , string($var:v1524) , string($var:v1522) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1526"" select=""ScriptNS1:DBValueExtract(string($var:v1525) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1527"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1528"" select=""ScriptNS1:DBLookup(7 , string($var:v1526) , string($var:v1527) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1529"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1530"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1529))"" />
                    <xsl:variable name=""var:v1531"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1532"" select=""userCSharp:GetHFO($var:v544 , string($var:v1531))"" />
                    <xsl:variable name=""var:v1533"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1534"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1533))"" />
                    <xsl:variable name=""var:v1535"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1536"" select=""userCSharp:GetMDO($var:v550 , string($var:v1535))"" />
                    <xsl:variable name=""var:v1537"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1538"" select=""userCSharp:GetMGO($var:v553 , string($var:v1537))"" />
                    <xsl:variable name=""var:v1539"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1540"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1541"" select=""ScriptNS1:DBValueExtract(string($var:v1528) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1542"" select=""userCSharp:GetLO($var:v558 , string($var:v1539))"" />
                    <xsl:variable name=""var:v1543"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1540))"" />
                    <xsl:variable name=""var:v1544"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1541))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1545"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1546"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1545) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1547"" select=""ScriptNS1:DBValueExtract(string($var:v1546) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1548"" select=""ScriptNS1:DBLookup(1 , string($var:v1547) , string($var:v1545) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1549"" select=""ScriptNS1:DBValueExtract(string($var:v1548) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1550"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1551"" select=""ScriptNS1:DBLookup(7 , string($var:v1549) , string($var:v1550) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1552"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1553"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1552))"" />
                <xsl:variable name=""var:v1554"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1555"" select=""userCSharp:GetHFO($var:v544 , string($var:v1554))"" />
                <xsl:variable name=""var:v1556"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1557"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1556))"" />
                <xsl:variable name=""var:v1558"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1559"" select=""userCSharp:GetMDO($var:v550 , string($var:v1558))"" />
                <xsl:variable name=""var:v1560"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1561"" select=""userCSharp:GetMGO($var:v553 , string($var:v1560))"" />
                <xsl:variable name=""var:v1562"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1563"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1564"" select=""ScriptNS1:DBValueExtract(string($var:v1551) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1565"" select=""userCSharp:GetLO($var:v558 , string($var:v1562))"" />
                <xsl:variable name=""var:v1566"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1563))"" />
                <xsl:variable name=""var:v1567"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1564))"" />
                <xsl:variable name=""var:v1568"" select=""$var:v1565"" />
                <xsl:variable name=""var:v1569"" select=""userCSharp:LogicalEq(string($var:v1568) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1569"">
                  <xsl:variable name=""var:v1644"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1645"" select=""userCSharp:LogicalEq($var:v1644 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1696"" select=""userCSharp:LogicalEq($var:v1644 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1722"" select=""userCSharp:LogicalEq($var:v1644 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1570"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1571"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1570) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1572"" select=""ScriptNS1:DBValueExtract(string($var:v1571) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1573"" select=""ScriptNS1:DBLookup(1 , string($var:v1572) , string($var:v1570) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1574"" select=""ScriptNS1:DBValueExtract(string($var:v1573) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1575"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1576"" select=""ScriptNS1:DBLookup(7 , string($var:v1574) , string($var:v1575) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1577"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1578"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1577))"" />
                    <xsl:variable name=""var:v1579"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1580"" select=""userCSharp:GetHFO($var:v544 , string($var:v1579))"" />
                    <xsl:variable name=""var:v1581"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1582"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1581))"" />
                    <xsl:variable name=""var:v1583"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1584"" select=""userCSharp:GetMDO($var:v550 , string($var:v1583))"" />
                    <xsl:variable name=""var:v1585"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1586"" select=""userCSharp:GetMGO($var:v553 , string($var:v1585))"" />
                    <xsl:variable name=""var:v1587"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1588"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1589"" select=""ScriptNS1:DBValueExtract(string($var:v1576) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1590"" select=""userCSharp:GetLO($var:v558 , string($var:v1587))"" />
                    <xsl:variable name=""var:v1591"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1588))"" />
                    <xsl:variable name=""var:v1592"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1589))"" />
                    <xsl:variable name=""var:v1593"" select=""$var:v1590"" />
                    <xsl:variable name=""var:v1594"" select=""userCSharp:LogicalEq(string($var:v1593) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v1594)='true'"">
                      <xsl:variable name=""var:v1595"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1596"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1595) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1597"" select=""ScriptNS1:DBValueExtract(string($var:v1596) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1598"" select=""ScriptNS1:DBLookup(1 , string($var:v1597) , string($var:v1595) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1599"" select=""ScriptNS1:DBValueExtract(string($var:v1598) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1600"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1601"" select=""ScriptNS1:DBLookup(7 , string($var:v1599) , string($var:v1600) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1602"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1603"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1602))"" />
                      <xsl:variable name=""var:v1604"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1605"" select=""userCSharp:GetHFO($var:v544 , string($var:v1604))"" />
                      <xsl:variable name=""var:v1606"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1607"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1606))"" />
                      <xsl:variable name=""var:v1608"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1609"" select=""userCSharp:GetMDO($var:v550 , string($var:v1608))"" />
                      <xsl:variable name=""var:v1610"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1611"" select=""userCSharp:GetMGO($var:v553 , string($var:v1610))"" />
                      <xsl:variable name=""var:v1612"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1613"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1614"" select=""ScriptNS1:DBValueExtract(string($var:v1601) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1615"" select=""userCSharp:GetLO($var:v558 , string($var:v1612))"" />
                      <xsl:variable name=""var:v1616"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1613))"" />
                      <xsl:variable name=""var:v1617"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1614))"" />
                      <xsl:variable name=""var:v1618"" select=""$var:v1612"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1618"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1619"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1620"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1619) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1621"" select=""ScriptNS1:DBValueExtract(string($var:v1620) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1622"" select=""ScriptNS1:DBLookup(1 , string($var:v1621) , string($var:v1619) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1623"" select=""ScriptNS1:DBValueExtract(string($var:v1622) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1624"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1625"" select=""ScriptNS1:DBLookup(7 , string($var:v1623) , string($var:v1624) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1626"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1627"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1626))"" />
                    <xsl:variable name=""var:v1628"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1629"" select=""userCSharp:GetHFO($var:v544 , string($var:v1628))"" />
                    <xsl:variable name=""var:v1630"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1631"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1630))"" />
                    <xsl:variable name=""var:v1632"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1633"" select=""userCSharp:GetMDO($var:v550 , string($var:v1632))"" />
                    <xsl:variable name=""var:v1634"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1635"" select=""userCSharp:GetMGO($var:v553 , string($var:v1634))"" />
                    <xsl:variable name=""var:v1636"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1637"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1638"" select=""ScriptNS1:DBValueExtract(string($var:v1625) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1639"" select=""userCSharp:GetLO($var:v558 , string($var:v1636))"" />
                    <xsl:variable name=""var:v1640"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1637))"" />
                    <xsl:variable name=""var:v1641"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1638))"" />
                    <xsl:variable name=""var:v1642"" select=""$var:v1639"" />
                    <xsl:variable name=""var:v1643"" select=""userCSharp:LogicalEq(string($var:v1642) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1646"" select=""userCSharp:LogicalAnd(string($var:v1643) , string($var:v1645))"" />
                    <xsl:if test=""string($var:v1646)='true'"">
                      <xsl:variable name=""var:v1647"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1648"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1647) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1649"" select=""ScriptNS1:DBValueExtract(string($var:v1648) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1650"" select=""ScriptNS1:DBLookup(1 , string($var:v1649) , string($var:v1647) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1651"" select=""ScriptNS1:DBValueExtract(string($var:v1650) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1652"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1653"" select=""ScriptNS1:DBLookup(7 , string($var:v1651) , string($var:v1652) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1654"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1655"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1654))"" />
                      <xsl:variable name=""var:v1656"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1657"" select=""userCSharp:GetHFO($var:v544 , string($var:v1656))"" />
                      <xsl:variable name=""var:v1658"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1659"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1658))"" />
                      <xsl:variable name=""var:v1660"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1661"" select=""userCSharp:GetMDO($var:v550 , string($var:v1660))"" />
                      <xsl:variable name=""var:v1662"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1663"" select=""userCSharp:GetMGO($var:v553 , string($var:v1662))"" />
                      <xsl:variable name=""var:v1664"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1665"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1666"" select=""ScriptNS1:DBValueExtract(string($var:v1653) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1667"" select=""userCSharp:GetLO($var:v558 , string($var:v1664))"" />
                      <xsl:variable name=""var:v1668"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1665))"" />
                      <xsl:variable name=""var:v1669"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1666))"" />
                      <xsl:variable name=""var:v1670"" select=""../Lo"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1670"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1671"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1672"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1671) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1673"" select=""ScriptNS1:DBValueExtract(string($var:v1672) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1674"" select=""ScriptNS1:DBLookup(1 , string($var:v1673) , string($var:v1671) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1675"" select=""ScriptNS1:DBValueExtract(string($var:v1674) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1676"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1677"" select=""ScriptNS1:DBLookup(7 , string($var:v1675) , string($var:v1676) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1678"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1679"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1678))"" />
                    <xsl:variable name=""var:v1680"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1681"" select=""userCSharp:GetHFO($var:v544 , string($var:v1680))"" />
                    <xsl:variable name=""var:v1682"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1683"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1682))"" />
                    <xsl:variable name=""var:v1684"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1685"" select=""userCSharp:GetMDO($var:v550 , string($var:v1684))"" />
                    <xsl:variable name=""var:v1686"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1687"" select=""userCSharp:GetMGO($var:v553 , string($var:v1686))"" />
                    <xsl:variable name=""var:v1688"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1689"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1690"" select=""ScriptNS1:DBValueExtract(string($var:v1677) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1691"" select=""userCSharp:GetLO($var:v558 , string($var:v1688))"" />
                    <xsl:variable name=""var:v1692"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1689))"" />
                    <xsl:variable name=""var:v1693"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1690))"" />
                    <xsl:variable name=""var:v1694"" select=""$var:v1691"" />
                    <xsl:variable name=""var:v1695"" select=""userCSharp:LogicalEq(string($var:v1694) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1697"" select=""userCSharp:LogicalAnd(string($var:v1695) , string($var:v1696))"" />
                    <xsl:if test=""string($var:v1697)='true'"">
                      <xsl:variable name=""var:v1698"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1699"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1698) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1700"" select=""ScriptNS1:DBValueExtract(string($var:v1699) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1701"" select=""ScriptNS1:DBLookup(1 , string($var:v1700) , string($var:v1698) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1702"" select=""ScriptNS1:DBValueExtract(string($var:v1701) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1703"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1704"" select=""ScriptNS1:DBLookup(7 , string($var:v1702) , string($var:v1703) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1705"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1706"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1705))"" />
                      <xsl:variable name=""var:v1707"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1708"" select=""userCSharp:GetHFO($var:v544 , string($var:v1707))"" />
                      <xsl:variable name=""var:v1709"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1710"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1709))"" />
                      <xsl:variable name=""var:v1711"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1712"" select=""userCSharp:GetMDO($var:v550 , string($var:v1711))"" />
                      <xsl:variable name=""var:v1713"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1714"" select=""userCSharp:GetMGO($var:v553 , string($var:v1713))"" />
                      <xsl:variable name=""var:v1715"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1716"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1717"" select=""ScriptNS1:DBValueExtract(string($var:v1704) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1718"" select=""userCSharp:GetLO($var:v558 , string($var:v1715))"" />
                      <xsl:variable name=""var:v1719"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1716))"" />
                      <xsl:variable name=""var:v1720"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1717))"" />
                      <xsl:variable name=""var:v1721"" select=""../Lo"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1721"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1723"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1724"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1723) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1725"" select=""ScriptNS1:DBValueExtract(string($var:v1724) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1726"" select=""ScriptNS1:DBLookup(1 , string($var:v1725) , string($var:v1723) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1727"" select=""ScriptNS1:DBValueExtract(string($var:v1726) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1728"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1729"" select=""ScriptNS1:DBLookup(7 , string($var:v1727) , string($var:v1728) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1730"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1731"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1730))"" />
                    <xsl:variable name=""var:v1732"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1733"" select=""userCSharp:GetHFO($var:v544 , string($var:v1732))"" />
                    <xsl:variable name=""var:v1734"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1735"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1734))"" />
                    <xsl:variable name=""var:v1736"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1737"" select=""userCSharp:GetMDO($var:v550 , string($var:v1736))"" />
                    <xsl:variable name=""var:v1738"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1739"" select=""userCSharp:GetMGO($var:v553 , string($var:v1738))"" />
                    <xsl:variable name=""var:v1740"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1741"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1742"" select=""ScriptNS1:DBValueExtract(string($var:v1729) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1743"" select=""userCSharp:GetLO($var:v558 , string($var:v1740))"" />
                    <xsl:variable name=""var:v1744"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1741))"" />
                    <xsl:variable name=""var:v1745"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1742))"" />
                    <xsl:variable name=""var:v1746"" select=""$var:v1743"" />
                    <xsl:variable name=""var:v1747"" select=""userCSharp:LogicalEq(string($var:v1746) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1748"" select=""userCSharp:LogicalAnd(string($var:v1722) , string($var:v1747))"" />
                    <xsl:if test=""string($var:v1748)='true'"">
                      <xsl:variable name=""var:v1749"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1750"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1749) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1751"" select=""ScriptNS1:DBValueExtract(string($var:v1750) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1752"" select=""ScriptNS1:DBLookup(1 , string($var:v1751) , string($var:v1749) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1753"" select=""ScriptNS1:DBValueExtract(string($var:v1752) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1754"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1755"" select=""ScriptNS1:DBLookup(7 , string($var:v1753) , string($var:v1754) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1756"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1757"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1756))"" />
                      <xsl:variable name=""var:v1758"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1759"" select=""userCSharp:GetHFO($var:v544 , string($var:v1758))"" />
                      <xsl:variable name=""var:v1760"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1761"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1760))"" />
                      <xsl:variable name=""var:v1762"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1763"" select=""userCSharp:GetMDO($var:v550 , string($var:v1762))"" />
                      <xsl:variable name=""var:v1764"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1765"" select=""userCSharp:GetMGO($var:v553 , string($var:v1764))"" />
                      <xsl:variable name=""var:v1766"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1767"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1768"" select=""ScriptNS1:DBValueExtract(string($var:v1755) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1769"" select=""userCSharp:GetLO($var:v558 , string($var:v1766))"" />
                      <xsl:variable name=""var:v1770"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1767))"" />
                      <xsl:variable name=""var:v1771"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1768))"" />
                      <xsl:variable name=""var:v1772"" select=""../Lo"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1772"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1773"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1774"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1773) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1775"" select=""ScriptNS1:DBValueExtract(string($var:v1774) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1776"" select=""ScriptNS1:DBLookup(1 , string($var:v1775) , string($var:v1773) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1777"" select=""ScriptNS1:DBValueExtract(string($var:v1776) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1778"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1779"" select=""ScriptNS1:DBLookup(7 , string($var:v1777) , string($var:v1778) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1780"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1781"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1780))"" />
                    <xsl:variable name=""var:v1782"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1783"" select=""userCSharp:GetHFO($var:v544 , string($var:v1782))"" />
                    <xsl:variable name=""var:v1784"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1785"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1784))"" />
                    <xsl:variable name=""var:v1786"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1787"" select=""userCSharp:GetMDO($var:v550 , string($var:v1786))"" />
                    <xsl:variable name=""var:v1788"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1789"" select=""userCSharp:GetMGO($var:v553 , string($var:v1788))"" />
                    <xsl:variable name=""var:v1790"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1791"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1792"" select=""ScriptNS1:DBValueExtract(string($var:v1779) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1793"" select=""userCSharp:GetLO($var:v558 , string($var:v1790))"" />
                    <xsl:variable name=""var:v1794"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1791))"" />
                    <xsl:variable name=""var:v1795"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1792))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1796"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1797"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1796) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1798"" select=""ScriptNS1:DBValueExtract(string($var:v1797) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1799"" select=""ScriptNS1:DBLookup(1 , string($var:v1798) , string($var:v1796) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1800"" select=""ScriptNS1:DBValueExtract(string($var:v1799) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1801"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1802"" select=""ScriptNS1:DBLookup(7 , string($var:v1800) , string($var:v1801) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1803"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1804"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1803))"" />
                <xsl:variable name=""var:v1805"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1806"" select=""userCSharp:GetHFO($var:v544 , string($var:v1805))"" />
                <xsl:variable name=""var:v1807"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1808"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1807))"" />
                <xsl:variable name=""var:v1809"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1810"" select=""userCSharp:GetMDO($var:v550 , string($var:v1809))"" />
                <xsl:variable name=""var:v1811"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1812"" select=""userCSharp:GetMGO($var:v553 , string($var:v1811))"" />
                <xsl:variable name=""var:v1813"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1814"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1815"" select=""ScriptNS1:DBValueExtract(string($var:v1802) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1816"" select=""userCSharp:GetLO($var:v558 , string($var:v1813))"" />
                <xsl:variable name=""var:v1817"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1814))"" />
                <xsl:variable name=""var:v1818"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1815))"" />
                <xsl:variable name=""var:v1819"" select=""$var:v1817"" />
                <xsl:variable name=""var:v1820"" select=""userCSharp:LogicalEq(string($var:v1819) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1820"">
                  <xsl:variable name=""var:v1895"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1896"" select=""userCSharp:LogicalEq($var:v1895 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1947"" select=""userCSharp:LogicalEq($var:v1895 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1973"" select=""userCSharp:LogicalEq($var:v1895 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1821"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1822"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1821) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1823"" select=""ScriptNS1:DBValueExtract(string($var:v1822) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1824"" select=""ScriptNS1:DBLookup(1 , string($var:v1823) , string($var:v1821) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1825"" select=""ScriptNS1:DBValueExtract(string($var:v1824) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1826"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1827"" select=""ScriptNS1:DBLookup(7 , string($var:v1825) , string($var:v1826) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1828"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1829"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1828))"" />
                    <xsl:variable name=""var:v1830"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1831"" select=""userCSharp:GetHFO($var:v544 , string($var:v1830))"" />
                    <xsl:variable name=""var:v1832"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1833"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1832))"" />
                    <xsl:variable name=""var:v1834"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1835"" select=""userCSharp:GetMDO($var:v550 , string($var:v1834))"" />
                    <xsl:variable name=""var:v1836"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1837"" select=""userCSharp:GetMGO($var:v553 , string($var:v1836))"" />
                    <xsl:variable name=""var:v1838"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1839"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1840"" select=""ScriptNS1:DBValueExtract(string($var:v1827) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1841"" select=""userCSharp:GetLO($var:v558 , string($var:v1838))"" />
                    <xsl:variable name=""var:v1842"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1839))"" />
                    <xsl:variable name=""var:v1843"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1840))"" />
                    <xsl:variable name=""var:v1844"" select=""$var:v1842"" />
                    <xsl:variable name=""var:v1845"" select=""userCSharp:LogicalEq(string($var:v1844) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v1845)='true'"">
                      <xsl:variable name=""var:v1846"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1847"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1846) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1848"" select=""ScriptNS1:DBValueExtract(string($var:v1847) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1849"" select=""ScriptNS1:DBLookup(1 , string($var:v1848) , string($var:v1846) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1850"" select=""ScriptNS1:DBValueExtract(string($var:v1849) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1851"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1852"" select=""ScriptNS1:DBLookup(7 , string($var:v1850) , string($var:v1851) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1853"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1854"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1853))"" />
                      <xsl:variable name=""var:v1855"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1856"" select=""userCSharp:GetHFO($var:v544 , string($var:v1855))"" />
                      <xsl:variable name=""var:v1857"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1858"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1857))"" />
                      <xsl:variable name=""var:v1859"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1860"" select=""userCSharp:GetMDO($var:v550 , string($var:v1859))"" />
                      <xsl:variable name=""var:v1861"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1862"" select=""userCSharp:GetMGO($var:v553 , string($var:v1861))"" />
                      <xsl:variable name=""var:v1863"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1864"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1865"" select=""ScriptNS1:DBValueExtract(string($var:v1852) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1866"" select=""userCSharp:GetLO($var:v558 , string($var:v1863))"" />
                      <xsl:variable name=""var:v1867"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1864))"" />
                      <xsl:variable name=""var:v1868"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1865))"" />
                      <xsl:variable name=""var:v1869"" select=""$var:v1864"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1869"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1870"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1871"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1870) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1872"" select=""ScriptNS1:DBValueExtract(string($var:v1871) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1873"" select=""ScriptNS1:DBLookup(1 , string($var:v1872) , string($var:v1870) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1874"" select=""ScriptNS1:DBValueExtract(string($var:v1873) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1875"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1876"" select=""ScriptNS1:DBLookup(7 , string($var:v1874) , string($var:v1875) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1877"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1878"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1877))"" />
                    <xsl:variable name=""var:v1879"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1880"" select=""userCSharp:GetHFO($var:v544 , string($var:v1879))"" />
                    <xsl:variable name=""var:v1881"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1882"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1881))"" />
                    <xsl:variable name=""var:v1883"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1884"" select=""userCSharp:GetMDO($var:v550 , string($var:v1883))"" />
                    <xsl:variable name=""var:v1885"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1886"" select=""userCSharp:GetMGO($var:v553 , string($var:v1885))"" />
                    <xsl:variable name=""var:v1887"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1888"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1889"" select=""ScriptNS1:DBValueExtract(string($var:v1876) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1890"" select=""userCSharp:GetLO($var:v558 , string($var:v1887))"" />
                    <xsl:variable name=""var:v1891"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1888))"" />
                    <xsl:variable name=""var:v1892"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1889))"" />
                    <xsl:variable name=""var:v1893"" select=""$var:v1891"" />
                    <xsl:variable name=""var:v1894"" select=""userCSharp:LogicalEq(string($var:v1893) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1897"" select=""userCSharp:LogicalAnd(string($var:v1894) , string($var:v1896))"" />
                    <xsl:if test=""string($var:v1897)='true'"">
                      <xsl:variable name=""var:v1898"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1899"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1898) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1900"" select=""ScriptNS1:DBValueExtract(string($var:v1899) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1901"" select=""ScriptNS1:DBLookup(1 , string($var:v1900) , string($var:v1898) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1902"" select=""ScriptNS1:DBValueExtract(string($var:v1901) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1903"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1904"" select=""ScriptNS1:DBLookup(7 , string($var:v1902) , string($var:v1903) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1905"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1906"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1905))"" />
                      <xsl:variable name=""var:v1907"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1908"" select=""userCSharp:GetHFO($var:v544 , string($var:v1907))"" />
                      <xsl:variable name=""var:v1909"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1910"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1909))"" />
                      <xsl:variable name=""var:v1911"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1912"" select=""userCSharp:GetMDO($var:v550 , string($var:v1911))"" />
                      <xsl:variable name=""var:v1913"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1914"" select=""userCSharp:GetMGO($var:v553 , string($var:v1913))"" />
                      <xsl:variable name=""var:v1915"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1916"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1917"" select=""ScriptNS1:DBValueExtract(string($var:v1904) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1918"" select=""userCSharp:GetLO($var:v558 , string($var:v1915))"" />
                      <xsl:variable name=""var:v1919"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1916))"" />
                      <xsl:variable name=""var:v1920"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1917))"" />
                      <xsl:variable name=""var:v1921"" select=""../FwCrew"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1921"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1922"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1923"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1922) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1924"" select=""ScriptNS1:DBValueExtract(string($var:v1923) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1925"" select=""ScriptNS1:DBLookup(1 , string($var:v1924) , string($var:v1922) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1926"" select=""ScriptNS1:DBValueExtract(string($var:v1925) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1927"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1928"" select=""ScriptNS1:DBLookup(7 , string($var:v1926) , string($var:v1927) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1929"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1930"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1929))"" />
                    <xsl:variable name=""var:v1931"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1932"" select=""userCSharp:GetHFO($var:v544 , string($var:v1931))"" />
                    <xsl:variable name=""var:v1933"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1934"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1933))"" />
                    <xsl:variable name=""var:v1935"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1936"" select=""userCSharp:GetMDO($var:v550 , string($var:v1935))"" />
                    <xsl:variable name=""var:v1937"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1938"" select=""userCSharp:GetMGO($var:v553 , string($var:v1937))"" />
                    <xsl:variable name=""var:v1939"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1940"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1941"" select=""ScriptNS1:DBValueExtract(string($var:v1928) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1942"" select=""userCSharp:GetLO($var:v558 , string($var:v1939))"" />
                    <xsl:variable name=""var:v1943"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1940))"" />
                    <xsl:variable name=""var:v1944"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1941))"" />
                    <xsl:variable name=""var:v1945"" select=""$var:v1943"" />
                    <xsl:variable name=""var:v1946"" select=""userCSharp:LogicalEq(string($var:v1945) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1948"" select=""userCSharp:LogicalAnd(string($var:v1946) , string($var:v1947))"" />
                    <xsl:if test=""string($var:v1948)='true'"">
                      <xsl:variable name=""var:v1949"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v1950"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1949) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v1951"" select=""ScriptNS1:DBValueExtract(string($var:v1950) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v1952"" select=""ScriptNS1:DBLookup(1 , string($var:v1951) , string($var:v1949) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v1953"" select=""ScriptNS1:DBValueExtract(string($var:v1952) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v1954"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v1955"" select=""ScriptNS1:DBLookup(7 , string($var:v1953) , string($var:v1954) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v1956"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v1957"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1956))"" />
                      <xsl:variable name=""var:v1958"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v1959"" select=""userCSharp:GetHFO($var:v544 , string($var:v1958))"" />
                      <xsl:variable name=""var:v1960"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v1961"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1960))"" />
                      <xsl:variable name=""var:v1962"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v1963"" select=""userCSharp:GetMDO($var:v550 , string($var:v1962))"" />
                      <xsl:variable name=""var:v1964"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v1965"" select=""userCSharp:GetMGO($var:v553 , string($var:v1964))"" />
                      <xsl:variable name=""var:v1966"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v1967"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v1968"" select=""ScriptNS1:DBValueExtract(string($var:v1955) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v1969"" select=""userCSharp:GetLO($var:v558 , string($var:v1966))"" />
                      <xsl:variable name=""var:v1970"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1967))"" />
                      <xsl:variable name=""var:v1971"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1968))"" />
                      <xsl:variable name=""var:v1972"" select=""../FwCrew"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1972"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1974"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1975"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v1974) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1976"" select=""ScriptNS1:DBValueExtract(string($var:v1975) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1977"" select=""ScriptNS1:DBLookup(1 , string($var:v1976) , string($var:v1974) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1978"" select=""ScriptNS1:DBValueExtract(string($var:v1977) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1979"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1980"" select=""ScriptNS1:DBLookup(7 , string($var:v1978) , string($var:v1979) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1981"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1982"" select=""userCSharp:GetLSFO($var:v541 , string($var:v1981))"" />
                    <xsl:variable name=""var:v1983"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1984"" select=""userCSharp:GetHFO($var:v544 , string($var:v1983))"" />
                    <xsl:variable name=""var:v1985"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1986"" select=""userCSharp:GetLSGO($var:v547 , string($var:v1985))"" />
                    <xsl:variable name=""var:v1987"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1988"" select=""userCSharp:GetMDO($var:v550 , string($var:v1987))"" />
                    <xsl:variable name=""var:v1989"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1990"" select=""userCSharp:GetMGO($var:v553 , string($var:v1989))"" />
                    <xsl:variable name=""var:v1991"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1992"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1993"" select=""ScriptNS1:DBValueExtract(string($var:v1980) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1994"" select=""userCSharp:GetLO($var:v558 , string($var:v1991))"" />
                    <xsl:variable name=""var:v1995"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v1992))"" />
                    <xsl:variable name=""var:v1996"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v1993))"" />
                    <xsl:variable name=""var:v1997"" select=""$var:v1995"" />
                    <xsl:variable name=""var:v1998"" select=""userCSharp:LogicalEq(string($var:v1997) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1999"" select=""userCSharp:LogicalAnd(string($var:v1973) , string($var:v1998))"" />
                    <xsl:if test=""string($var:v1999)='true'"">
                      <xsl:variable name=""var:v2000"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v2001"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2000) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v2002"" select=""ScriptNS1:DBValueExtract(string($var:v2001) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v2003"" select=""ScriptNS1:DBLookup(1 , string($var:v2002) , string($var:v2000) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v2004"" select=""ScriptNS1:DBValueExtract(string($var:v2003) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v2005"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v2006"" select=""ScriptNS1:DBLookup(7 , string($var:v2004) , string($var:v2005) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v2007"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v2008"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2007))"" />
                      <xsl:variable name=""var:v2009"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v2010"" select=""userCSharp:GetHFO($var:v544 , string($var:v2009))"" />
                      <xsl:variable name=""var:v2011"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v2012"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2011))"" />
                      <xsl:variable name=""var:v2013"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v2014"" select=""userCSharp:GetMDO($var:v550 , string($var:v2013))"" />
                      <xsl:variable name=""var:v2015"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v2016"" select=""userCSharp:GetMGO($var:v553 , string($var:v2015))"" />
                      <xsl:variable name=""var:v2017"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v2018"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v2019"" select=""ScriptNS1:DBValueExtract(string($var:v2006) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v2020"" select=""userCSharp:GetLO($var:v558 , string($var:v2017))"" />
                      <xsl:variable name=""var:v2021"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2018))"" />
                      <xsl:variable name=""var:v2022"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2019))"" />
                      <xsl:variable name=""var:v2023"" select=""../FwCrew"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v2023"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v2024"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2025"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2024) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2026"" select=""ScriptNS1:DBValueExtract(string($var:v2025) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2027"" select=""ScriptNS1:DBLookup(1 , string($var:v2026) , string($var:v2024) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2028"" select=""ScriptNS1:DBValueExtract(string($var:v2027) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2029"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2030"" select=""ScriptNS1:DBLookup(7 , string($var:v2028) , string($var:v2029) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2031"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2032"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2031))"" />
                    <xsl:variable name=""var:v2033"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2034"" select=""userCSharp:GetHFO($var:v544 , string($var:v2033))"" />
                    <xsl:variable name=""var:v2035"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2036"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2035))"" />
                    <xsl:variable name=""var:v2037"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2038"" select=""userCSharp:GetMDO($var:v550 , string($var:v2037))"" />
                    <xsl:variable name=""var:v2039"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2040"" select=""userCSharp:GetMGO($var:v553 , string($var:v2039))"" />
                    <xsl:variable name=""var:v2041"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2042"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2043"" select=""ScriptNS1:DBValueExtract(string($var:v2030) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2044"" select=""userCSharp:GetLO($var:v558 , string($var:v2041))"" />
                    <xsl:variable name=""var:v2045"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2042))"" />
                    <xsl:variable name=""var:v2046"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2043))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v2047"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v2048"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2047) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v2049"" select=""ScriptNS1:DBValueExtract(string($var:v2048) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v2050"" select=""ScriptNS1:DBLookup(1 , string($var:v2049) , string($var:v2047) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v2051"" select=""ScriptNS1:DBValueExtract(string($var:v2050) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v2052"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v2053"" select=""ScriptNS1:DBLookup(7 , string($var:v2051) , string($var:v2052) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v2054"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v2055"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2054))"" />
                <xsl:variable name=""var:v2056"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v2057"" select=""userCSharp:GetHFO($var:v544 , string($var:v2056))"" />
                <xsl:variable name=""var:v2058"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v2059"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2058))"" />
                <xsl:variable name=""var:v2060"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v2061"" select=""userCSharp:GetMDO($var:v550 , string($var:v2060))"" />
                <xsl:variable name=""var:v2062"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v2063"" select=""userCSharp:GetMGO($var:v553 , string($var:v2062))"" />
                <xsl:variable name=""var:v2064"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v2065"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v2066"" select=""ScriptNS1:DBValueExtract(string($var:v2053) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v2067"" select=""userCSharp:GetLO($var:v558 , string($var:v2064))"" />
                <xsl:variable name=""var:v2068"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2065))"" />
                <xsl:variable name=""var:v2069"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2066))"" />
                <xsl:variable name=""var:v2070"" select=""$var:v2069"" />
                <xsl:variable name=""var:v2071"" select=""userCSharp:LogicalEq(string($var:v2070) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v2071"">
                  <xsl:variable name=""var:v2146"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v2147"" select=""userCSharp:LogicalEq($var:v2146 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v2198"" select=""userCSharp:LogicalEq($var:v2146 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v2224"" select=""userCSharp:LogicalEq($var:v2146 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v2072"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2073"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2072) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2074"" select=""ScriptNS1:DBValueExtract(string($var:v2073) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2075"" select=""ScriptNS1:DBLookup(1 , string($var:v2074) , string($var:v2072) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2076"" select=""ScriptNS1:DBValueExtract(string($var:v2075) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2077"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2078"" select=""ScriptNS1:DBLookup(7 , string($var:v2076) , string($var:v2077) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2079"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2080"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2079))"" />
                    <xsl:variable name=""var:v2081"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2082"" select=""userCSharp:GetHFO($var:v544 , string($var:v2081))"" />
                    <xsl:variable name=""var:v2083"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2084"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2083))"" />
                    <xsl:variable name=""var:v2085"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2086"" select=""userCSharp:GetMDO($var:v550 , string($var:v2085))"" />
                    <xsl:variable name=""var:v2087"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2088"" select=""userCSharp:GetMGO($var:v553 , string($var:v2087))"" />
                    <xsl:variable name=""var:v2089"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2090"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2091"" select=""ScriptNS1:DBValueExtract(string($var:v2078) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2092"" select=""userCSharp:GetLO($var:v558 , string($var:v2089))"" />
                    <xsl:variable name=""var:v2093"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2090))"" />
                    <xsl:variable name=""var:v2094"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2091))"" />
                    <xsl:variable name=""var:v2095"" select=""$var:v2094"" />
                    <xsl:variable name=""var:v2096"" select=""userCSharp:LogicalEq(string($var:v2095) , &quot;1&quot;)"" />
                    <xsl:if test=""string($var:v2096)='true'"">
                      <xsl:variable name=""var:v2097"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v2098"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2097) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v2099"" select=""ScriptNS1:DBValueExtract(string($var:v2098) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v2100"" select=""ScriptNS1:DBLookup(1 , string($var:v2099) , string($var:v2097) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v2101"" select=""ScriptNS1:DBValueExtract(string($var:v2100) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v2102"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v2103"" select=""ScriptNS1:DBLookup(7 , string($var:v2101) , string($var:v2102) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v2104"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v2105"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2104))"" />
                      <xsl:variable name=""var:v2106"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v2107"" select=""userCSharp:GetHFO($var:v544 , string($var:v2106))"" />
                      <xsl:variable name=""var:v2108"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v2109"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2108))"" />
                      <xsl:variable name=""var:v2110"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v2111"" select=""userCSharp:GetMDO($var:v550 , string($var:v2110))"" />
                      <xsl:variable name=""var:v2112"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v2113"" select=""userCSharp:GetMGO($var:v553 , string($var:v2112))"" />
                      <xsl:variable name=""var:v2114"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v2115"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v2116"" select=""ScriptNS1:DBValueExtract(string($var:v2103) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v2117"" select=""userCSharp:GetLO($var:v558 , string($var:v2114))"" />
                      <xsl:variable name=""var:v2118"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2115))"" />
                      <xsl:variable name=""var:v2119"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2116))"" />
                      <xsl:variable name=""var:v2120"" select=""$var:v2116"" />
                      <Grade>
                        <xsl:value-of select=""$var:v2120"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v2121"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2122"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2121) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2123"" select=""ScriptNS1:DBValueExtract(string($var:v2122) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2124"" select=""ScriptNS1:DBLookup(1 , string($var:v2123) , string($var:v2121) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2125"" select=""ScriptNS1:DBValueExtract(string($var:v2124) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2126"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2127"" select=""ScriptNS1:DBLookup(7 , string($var:v2125) , string($var:v2126) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2128"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2129"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2128))"" />
                    <xsl:variable name=""var:v2130"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2131"" select=""userCSharp:GetHFO($var:v544 , string($var:v2130))"" />
                    <xsl:variable name=""var:v2132"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2133"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2132))"" />
                    <xsl:variable name=""var:v2134"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2135"" select=""userCSharp:GetMDO($var:v550 , string($var:v2134))"" />
                    <xsl:variable name=""var:v2136"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2137"" select=""userCSharp:GetMGO($var:v553 , string($var:v2136))"" />
                    <xsl:variable name=""var:v2138"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2139"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2140"" select=""ScriptNS1:DBValueExtract(string($var:v2127) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2141"" select=""userCSharp:GetLO($var:v558 , string($var:v2138))"" />
                    <xsl:variable name=""var:v2142"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2139))"" />
                    <xsl:variable name=""var:v2143"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2140))"" />
                    <xsl:variable name=""var:v2144"" select=""$var:v2143"" />
                    <xsl:variable name=""var:v2145"" select=""userCSharp:LogicalEq(string($var:v2144) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v2148"" select=""userCSharp:LogicalAnd(string($var:v2145) , string($var:v2147))"" />
                    <xsl:if test=""string($var:v2148)='true'"">
                      <xsl:variable name=""var:v2149"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v2150"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2149) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v2151"" select=""ScriptNS1:DBValueExtract(string($var:v2150) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v2152"" select=""ScriptNS1:DBLookup(1 , string($var:v2151) , string($var:v2149) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v2153"" select=""ScriptNS1:DBValueExtract(string($var:v2152) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v2154"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v2155"" select=""ScriptNS1:DBLookup(7 , string($var:v2153) , string($var:v2154) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v2156"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v2157"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2156))"" />
                      <xsl:variable name=""var:v2158"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v2159"" select=""userCSharp:GetHFO($var:v544 , string($var:v2158))"" />
                      <xsl:variable name=""var:v2160"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v2161"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2160))"" />
                      <xsl:variable name=""var:v2162"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v2163"" select=""userCSharp:GetMDO($var:v550 , string($var:v2162))"" />
                      <xsl:variable name=""var:v2164"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v2165"" select=""userCSharp:GetMGO($var:v553 , string($var:v2164))"" />
                      <xsl:variable name=""var:v2166"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v2167"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v2168"" select=""ScriptNS1:DBValueExtract(string($var:v2155) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v2169"" select=""userCSharp:GetLO($var:v558 , string($var:v2166))"" />
                      <xsl:variable name=""var:v2170"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2167))"" />
                      <xsl:variable name=""var:v2171"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2168))"" />
                      <xsl:variable name=""var:v2172"" select=""../FwShip"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v2172"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v2173"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2174"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2173) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2175"" select=""ScriptNS1:DBValueExtract(string($var:v2174) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2176"" select=""ScriptNS1:DBLookup(1 , string($var:v2175) , string($var:v2173) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2177"" select=""ScriptNS1:DBValueExtract(string($var:v2176) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2178"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2179"" select=""ScriptNS1:DBLookup(7 , string($var:v2177) , string($var:v2178) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2180"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2181"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2180))"" />
                    <xsl:variable name=""var:v2182"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2183"" select=""userCSharp:GetHFO($var:v544 , string($var:v2182))"" />
                    <xsl:variable name=""var:v2184"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2185"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2184))"" />
                    <xsl:variable name=""var:v2186"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2187"" select=""userCSharp:GetMDO($var:v550 , string($var:v2186))"" />
                    <xsl:variable name=""var:v2188"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2189"" select=""userCSharp:GetMGO($var:v553 , string($var:v2188))"" />
                    <xsl:variable name=""var:v2190"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2191"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2192"" select=""ScriptNS1:DBValueExtract(string($var:v2179) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2193"" select=""userCSharp:GetLO($var:v558 , string($var:v2190))"" />
                    <xsl:variable name=""var:v2194"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2191))"" />
                    <xsl:variable name=""var:v2195"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2192))"" />
                    <xsl:variable name=""var:v2196"" select=""$var:v2195"" />
                    <xsl:variable name=""var:v2197"" select=""userCSharp:LogicalEq(string($var:v2196) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v2199"" select=""userCSharp:LogicalAnd(string($var:v2197) , string($var:v2198))"" />
                    <xsl:if test=""string($var:v2199)='true'"">
                      <xsl:variable name=""var:v2200"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v2201"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2200) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v2202"" select=""ScriptNS1:DBValueExtract(string($var:v2201) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v2203"" select=""ScriptNS1:DBLookup(1 , string($var:v2202) , string($var:v2200) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v2204"" select=""ScriptNS1:DBValueExtract(string($var:v2203) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v2205"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v2206"" select=""ScriptNS1:DBLookup(7 , string($var:v2204) , string($var:v2205) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v2207"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v2208"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2207))"" />
                      <xsl:variable name=""var:v2209"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v2210"" select=""userCSharp:GetHFO($var:v544 , string($var:v2209))"" />
                      <xsl:variable name=""var:v2211"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v2212"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2211))"" />
                      <xsl:variable name=""var:v2213"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v2214"" select=""userCSharp:GetMDO($var:v550 , string($var:v2213))"" />
                      <xsl:variable name=""var:v2215"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v2216"" select=""userCSharp:GetMGO($var:v553 , string($var:v2215))"" />
                      <xsl:variable name=""var:v2217"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v2218"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v2219"" select=""ScriptNS1:DBValueExtract(string($var:v2206) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v2220"" select=""userCSharp:GetLO($var:v558 , string($var:v2217))"" />
                      <xsl:variable name=""var:v2221"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2218))"" />
                      <xsl:variable name=""var:v2222"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2219))"" />
                      <xsl:variable name=""var:v2223"" select=""../FwShip"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v2223"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v2225"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2226"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2225) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2227"" select=""ScriptNS1:DBValueExtract(string($var:v2226) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2228"" select=""ScriptNS1:DBLookup(1 , string($var:v2227) , string($var:v2225) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2229"" select=""ScriptNS1:DBValueExtract(string($var:v2228) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2230"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2231"" select=""ScriptNS1:DBLookup(7 , string($var:v2229) , string($var:v2230) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2232"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2233"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2232))"" />
                    <xsl:variable name=""var:v2234"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2235"" select=""userCSharp:GetHFO($var:v544 , string($var:v2234))"" />
                    <xsl:variable name=""var:v2236"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2237"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2236))"" />
                    <xsl:variable name=""var:v2238"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2239"" select=""userCSharp:GetMDO($var:v550 , string($var:v2238))"" />
                    <xsl:variable name=""var:v2240"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2241"" select=""userCSharp:GetMGO($var:v553 , string($var:v2240))"" />
                    <xsl:variable name=""var:v2242"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2243"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2244"" select=""ScriptNS1:DBValueExtract(string($var:v2231) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2245"" select=""userCSharp:GetLO($var:v558 , string($var:v2242))"" />
                    <xsl:variable name=""var:v2246"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2243))"" />
                    <xsl:variable name=""var:v2247"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2244))"" />
                    <xsl:variable name=""var:v2248"" select=""$var:v2247"" />
                    <xsl:variable name=""var:v2249"" select=""userCSharp:LogicalEq(string($var:v2248) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v2250"" select=""userCSharp:LogicalAnd(string($var:v2224) , string($var:v2249))"" />
                    <xsl:if test=""string($var:v2250)='true'"">
                      <xsl:variable name=""var:v2251"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                      <xsl:variable name=""var:v2252"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2251) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                      <xsl:variable name=""var:v2253"" select=""ScriptNS1:DBValueExtract(string($var:v2252) , &quot;Id&quot;)"" />
                      <xsl:variable name=""var:v2254"" select=""ScriptNS1:DBLookup(1 , string($var:v2253) , string($var:v2251) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                      <xsl:variable name=""var:v2255"" select=""ScriptNS1:DBValueExtract(string($var:v2254) , &quot;HubPrincipalKey&quot;)"" />
                      <xsl:variable name=""var:v2256"" select=""ScriptNS0:GetBizConnectionString()"" />
                      <xsl:variable name=""var:v2257"" select=""ScriptNS1:DBLookup(7 , string($var:v2255) , string($var:v2256) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                      <xsl:variable name=""var:v2258"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;LSFO&quot;)"" />
                      <xsl:variable name=""var:v2259"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2258))"" />
                      <xsl:variable name=""var:v2260"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;HFO&quot;)"" />
                      <xsl:variable name=""var:v2261"" select=""userCSharp:GetHFO($var:v544 , string($var:v2260))"" />
                      <xsl:variable name=""var:v2262"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;LSGO&quot;)"" />
                      <xsl:variable name=""var:v2263"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2262))"" />
                      <xsl:variable name=""var:v2264"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;DO&quot;)"" />
                      <xsl:variable name=""var:v2265"" select=""userCSharp:GetMDO($var:v550 , string($var:v2264))"" />
                      <xsl:variable name=""var:v2266"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;GO&quot;)"" />
                      <xsl:variable name=""var:v2267"" select=""userCSharp:GetMGO($var:v553 , string($var:v2266))"" />
                      <xsl:variable name=""var:v2268"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;LO&quot;)"" />
                      <xsl:variable name=""var:v2269"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;FwCrew&quot;)"" />
                      <xsl:variable name=""var:v2270"" select=""ScriptNS1:DBValueExtract(string($var:v2257) , &quot;FwShip&quot;)"" />
                      <xsl:variable name=""var:v2271"" select=""userCSharp:GetLO($var:v558 , string($var:v2268))"" />
                      <xsl:variable name=""var:v2272"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2269))"" />
                      <xsl:variable name=""var:v2273"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2270))"" />
                      <xsl:variable name=""var:v2274"" select=""../FwShip"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v2274"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v2275"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v2276"" select=""ScriptNS1:DBLookup(0 , string($var:v532) , string($var:v2275) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v2277"" select=""ScriptNS1:DBValueExtract(string($var:v2276) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v2278"" select=""ScriptNS1:DBLookup(1 , string($var:v2277) , string($var:v2275) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v2279"" select=""ScriptNS1:DBValueExtract(string($var:v2278) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v2280"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v2281"" select=""ScriptNS1:DBLookup(7 , string($var:v2279) , string($var:v2280) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v2282"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v2283"" select=""userCSharp:GetLSFO($var:v541 , string($var:v2282))"" />
                    <xsl:variable name=""var:v2284"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v2285"" select=""userCSharp:GetHFO($var:v544 , string($var:v2284))"" />
                    <xsl:variable name=""var:v2286"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v2287"" select=""userCSharp:GetLSGO($var:v547 , string($var:v2286))"" />
                    <xsl:variable name=""var:v2288"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v2289"" select=""userCSharp:GetMDO($var:v550 , string($var:v2288))"" />
                    <xsl:variable name=""var:v2290"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v2291"" select=""userCSharp:GetMGO($var:v553 , string($var:v2290))"" />
                    <xsl:variable name=""var:v2292"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v2293"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v2294"" select=""ScriptNS1:DBValueExtract(string($var:v2281) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v2295"" select=""userCSharp:GetLO($var:v558 , string($var:v2292))"" />
                    <xsl:variable name=""var:v2296"" select=""userCSharp:GetFWCREW($var:v560 , string($var:v2293))"" />
                    <xsl:variable name=""var:v2297"" select=""userCSharp:GetFWSHIP($var:v562 , string($var:v2294))"" />
                  </Bunker>
                </xsl:if>
              </xsl:for-each>
            </xsl:for-each>
          </Bunkers>
        </xsl:if>
        <Statements>
          <xsl:for-each select=""OperationEvents"">
            <xsl:for-each select=""Event"">
              <xsl:variable name=""var:v2298"" select=""string(../Name/text())"" />
              <xsl:variable name=""var:v2299"" select=""userCSharp:Format_EventDate(string(../StartDate/text()) , $var:v2298)"" />
              <xsl:variable name=""var:v2300"" select=""userCSharp:StringConcat(string(../../Id/text()) , &quot;|&quot; , string(Id/text()) , &quot;|&quot; , string($var:v2299) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v2301"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
              <xsl:variable name=""var:v2302"" select=""ScriptNS1:DBLookup(8 , string($var:v2300) , string($var:v2301) , &quot;Operation.OperationEvents&quot; , &quot;cast (portcallid as varchar (10)) + '|' +   cast ( HubprincipalEventMapId as varchar(10))  + '|' +    convert(varchar(30), EventDate, 121) + '|' +   cast ( IsActive as varchar(1)  )&quot;)"" />
              <xsl:variable name=""var:v2303"" select=""ScriptNS1:DBValueExtract(string($var:v2302) , &quot;ShowOnSOF&quot;)"" />
              <xsl:variable name=""var:v2304"" select=""userCSharp:LogicalEq(string($var:v2303) , &quot;True&quot;)"" />
              <xsl:if test=""$var:v2304"">
                <xsl:variable name=""var:v2305"" select=""userCSharp:LogicalNe(string(../EndDate/text()) , &quot;&quot;)"" />
                <Sof>
                  <xsl:if test=""../RefCode"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""../RefCode/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""Name"">
                    <SofLabel>
                      <xsl:value-of select=""Name/text()"" />
                    </SofLabel>
                  </xsl:if>
                  <xsl:if test=""../StartDate"">
                    <SofDateTime>
                      <xsl:value-of select=""../StartDate/text()"" />
                    </SofDateTime>
                  </xsl:if>
                  <xsl:if test=""string($var:v2305)='true'"">
                    <xsl:variable name=""var:v2306"" select=""../EndDate/text()"" />
                    <SofEndDate>
                      <xsl:value-of select=""$var:v2306"" />
                    </SofEndDate>
                  </xsl:if>
                  <xsl:if test=""../Comments"">
                    <SofComments>
                      <xsl:value-of select=""../Comments/text()"" />
                    </SofComments>
                  </xsl:if>
                </Sof>
              </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </Statements>
        <Events>
          <xsl:for-each select=""OperationEvents"">
            <xsl:for-each select=""Event"">
              <xsl:variable name=""var:v2307"" select=""string(../StartDate/text())"" />
              <xsl:variable name=""var:v2308"" select=""string(../Name/text())"" />
              <xsl:variable name=""var:v2309"" select=""userCSharp:Format_EventDate($var:v2307 , $var:v2308)"" />
              <xsl:variable name=""var:v2310"" select=""string(../../Id/text())"" />
              <xsl:variable name=""var:v2311"" select=""string(Id/text())"" />
              <xsl:variable name=""var:v2312"" select=""userCSharp:StringConcat($var:v2310 , &quot;|&quot; , $var:v2311 , &quot;|&quot; , string($var:v2309) , &quot;|&quot; , &quot;1&quot;)"" />
              <xsl:variable name=""var:v2313"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
              <xsl:variable name=""var:v2314"" select=""ScriptNS1:DBLookup(8 , string($var:v2312) , string($var:v2313) , &quot;Operation.OperationEvents&quot; , &quot;cast (portcallid as varchar (10)) + '|' +   cast ( HubprincipalEventMapId as varchar(10))  + '|' +    convert(varchar(30), EventDate, 121) + '|' +   cast ( IsActive as varchar(1)  )&quot;)"" />
              <xsl:variable name=""var:v2315"" select=""ScriptNS1:DBValueExtract(string($var:v2314) , &quot;ShowOnSOF&quot;)"" />
              <xsl:variable name=""var:v2316"" select=""userCSharp:LogicalEq(string($var:v2315) , &quot;False&quot;)"" />
              <xsl:if test=""$var:v2316"">
                <Event>
                  <xsl:if test=""Name"">
                    <EventLabel>
                      <xsl:value-of select=""Name/text()"" />
                    </EventLabel>
                  </xsl:if>
                  <xsl:if test=""../StartDate"">
                    <EventDateTime>
                      <xsl:value-of select=""../StartDate/text()"" />
                    </EventDateTime>
                  </xsl:if>
                  <xsl:if test=""../Comments"">
                    <EventComments>
                      <xsl:value-of select=""../Comments/text()"" />
                    </EventComments>
                  </xsl:if>
                </Event>
              </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </Events>
      </Operational>
    </ns0:YourIssNotification>
    <xsl:variable name=""var:v2317"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringSubstring(string str, string left, string right)
{
	string retval = """";
	double dleft = 0;
	double dright = 0;
	if (str != null && IsNumeric(left, ref dleft) && IsNumeric(right, ref dright))
	{
		int lt = (int)dleft;
		int rt = (int)dright;
		lt--; rt--;
		if (lt >= 0 && rt >= lt && lt < str.Length)
		{
			if (rt < str.Length)
			{
				retval = str.Substring(lt, rt-lt+1);
			}
			else
			{
				retval = str.Substring(lt, str.Length-lt);
			}
		}
	}
	return retval;
}


public int StringFind(string str, string strFind)
{
	if (str == null || strFind == null || strFind == """")
	{
		return 0;
	}
	return (str.IndexOf(strFind) + 1);
}


public int StringSize(string str)
{
	if (str == null)
	{
		return 0;
	}
	return str.Length;
}


public string MathAdd(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	foreach (string obj in listValues)
	{
	double d = 0;
		if (IsNumeric(obj, ref d))
		{
			ret += d;
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string MathSubtract(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	bool first = true;
	foreach (string obj in listValues)
	{
		if (first)
		{
			first = false;
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret = d;
			}
			else
			{
				return """";
			}
		}
		else
		{
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret -= d;
			}
			else
			{
				return """";
			}
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public int GetCargoCount ( string  IsActive  )
{
  
       if  (    IsActive  ==""true""  ) 
           return 1;
       else return 0;
}

public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public bool LogicalGt(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 > d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) > 0;
	}
	return ret;
}


public int GetLSFO (  string  strvalue , string LSFO_Code )
{
    
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0  &&  LSFO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetHFO (  string  strvalue , string HFO_Code )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   && HFO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetLSGO (  string  strvalue   , string LSGO_Code  )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&     LSGO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetMDO (  string strvalue   , string DO_Code   )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&   DO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetMGO (  string  strvalue  , string GO_Code )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&  GO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetBunKetCountSum (
int LSFO,
int HFO,
int LSGO,
int MDO,
int MGO,
int LO,
int FWCREW,
int FWSHIP
)
{

     return LSFO + HFO + LSGO + MDO + MGO  + LO + FWCREW  + FWSHIP ;
}

public bool LogicalAnd(string param0, string param1)
{
	return ValToBool(param0) && ValToBool(param1);
	return false;
}


public bool LogicalNot(string val)
{
	return !ValToBool(val);
}


public int GetBLFigures ( string strBLQty )
{
        decimal BLqty = 0;
        decimal.TryParse (  strBLQty  , out  BLqty );
        
        if (   strBLQty  != """" &&  strBLQty    != null  )        
            return 1;
        else
            return 0;
}

public int GetShipFig ( string strVessalQty )
{
        decimal   VessalQty   = 0 ;
        decimal.TryParse (  strVessalQty  , out   VessalQty   );
        if  (   strVessalQty    != """"   &&    strVessalQty    != null  )
             return 1;
        else
           return 0;
}

public bool LogicalNe(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 != d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) != 0;
	}
	return ret;
}


public int GetLO (  string strvalue   , string LO_Code   )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&   LO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetFWCREW (  string strvalue   , string FWCREW_Code   )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&   FWCREW_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetFWSHIP (  string strvalue   , string FWSHIP_Code   )
{
     
      int value = 0;
      Int32.TryParse (  strvalue  ,  out value) ;

     if (     value !=  0   &&   FWSHIP_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public string GetFlowStatus (string  strflow)
    {
        return strflow.Substring(strflow.LastIndexOf("" - "") + 2).Trim();
    }

public string StringConcat(string param0, string param1, string param2, string param3, string param4, string param5, string param6)
{
   return param0 + param1 + param2 + param3 + param4 + param5 + param6;
}


 public string Format_EventDate(string strEventDate, string strEventName)
        {
            if (strEventDate != null && strEventDate != """")
            {
                if (strEventName == ""Delay"")
                {
                    DateTime dt = Convert.ToDateTime(strEventDate).ToUniversalTime();
                    return dt.ToString(""yyyy-MM-dd HH:mm:ss.fff"");

                }
                else
                {
                    DateTime dt = DateTime.Parse(strEventDate);
                    return dt.ToString(""yyyy-MM-dd HH:mm:ss.fff"");
                }
            }
            else
                return """";
        } 

public bool IsNextEtaEmpty ( string  NextETA  )
{
        if  (   NextETA == null ||    NextETA == """"  )
            return false;
         else
                 return true;
} 

public string MyConcatETA(string ETANextPt)
{
string ETANextP = """";
  if  (   ETANextPt != null ||    ETANextPt != """"  )
{
	DateTime dt1 = DateTime.Parse(ETANextPt);
          ETANextP = string.Format(""{0:s}"", dt1);
}
return ETANextP;
}


public string BLDate(string strBLDate )
{
string BLDate= """";
  if  (   strBLDate  != null ||    strBLDate   != """"  )
{
	DateTime dt1 = DateTime.Parse( strBLDate  );
          BLDate = string.Format(""{0:s}"", dt1);
}
return BLDate  ;
}
  

public bool IsBLDate ( string  strBLDate  )
{
        if  (    strBLDate    == null ||   strBLDate     == """"  )
            return false;
         else
                 return true;
} 

public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool ValToBool(string val)
{
	if (val != null)
	{
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		val = val.Trim();
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		double d = 0;
		if (IsNumeric(val, ref d))
		{
			return (d > 0);
		}
	}
	return false;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
                return _TrgSchemas;
            }
        }
    }
}

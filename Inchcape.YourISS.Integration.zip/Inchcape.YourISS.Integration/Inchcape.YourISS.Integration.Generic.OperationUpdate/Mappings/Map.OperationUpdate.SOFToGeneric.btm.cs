namespace Inchcape.YourISS.Integration.Generic.OperationUpdate.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_YourISS_OperationUpdate_SofAndEvents", typeof(global::Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_YourISS_OperationUpdate_SofAndEvents))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate))]
    public sealed class Map_OperationUpdate_SOFToGeneric : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0 ScriptNS1"" version=""1.0"" xmlns:s0=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISSNew"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schemas.Generic.OperationUpdate"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:ScriptNS1=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:YourIss2Appointment"" />
  </xsl:template>
  <xsl:template match=""/s0:YourIss2Appointment"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;OperationalUpdate&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;Save&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v13"" select=""userCSharp:StringConcat(&quot;YourIss2&quot;)"" />
    <xsl:variable name=""var:v14"" select=""string(Number/text())"" />
    <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat($var:v14 , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v82"" select=""string(NextPort/Id/text())"" />
    <xsl:variable name=""var:v92"" select=""userCSharp:StringConcat(string(Appointments/Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
    <xsl:variable name=""var:v97"" select=""Rotations/Poi[1]/Name/text()"" />
    <xsl:variable name=""var:v98"" select=""userCSharp:LogicalEq(string($var:v97) , &quot;ANCHORAGE&quot;)"" />
    <xsl:variable name=""var:v99"" select=""./Rotations[2]/Etb/text()"" />
    <xsl:variable name=""var:v101"" select=""userCSharp:LogicalNe(string($var:v97) , &quot;ANCHORAGE&quot;)"" />
    <xsl:variable name=""var:v102"" select=""./Rotations[1]/Etb/text()"" />
    <ns0:YourIssNotification>
      <MessageHeader>
        <MessageType>
          <xsl:value-of select=""$var:v1"" />
        </MessageType>
        <Action>
          <xsl:value-of select=""$var:v2"" />
        </Action>
        <CreatedDate>
          <xsl:value-of select=""$var:v3"" />
        </CreatedDate>
        <xsl:variable name=""var:v5"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v6"" select=""ScriptNS1:DBLookup(0 , string($var:v4) , string($var:v5) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v7"" select=""ScriptNS1:DBValueExtract(string($var:v6) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v8"" select=""ScriptNS1:DBLookup(1 , string($var:v7) , string($var:v5) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v9"" select=""ScriptNS1:DBValueExtract(string($var:v8) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v10"" select=""userCSharp:StringFind(string($var:v9) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v11"" select=""userCSharp:MathSubtract(string($var:v10) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v12"" select=""userCSharp:StringSubstring(string($var:v9) , &quot;1&quot; , string($var:v11))"" />
        <ShipNetReference>
          <xsl:value-of select=""$var:v12"" />
        </ShipNetReference>
        <SourceApplication>
          <xsl:value-of select=""$var:v13"" />
        </SourceApplication>
      </MessageHeader>
      <Operational>
        <xsl:variable name=""var:v16"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v17"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v16) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v18"" select=""ScriptNS1:DBValueExtract(string($var:v17) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v19"" select=""ScriptNS1:DBLookup(1 , string($var:v18) , string($var:v16) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v20"" select=""ScriptNS1:DBValueExtract(string($var:v19) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v21"" select=""userCSharp:StringFind(string($var:v20) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v22"" select=""userCSharp:MathAdd(string($var:v21) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v23"" select=""userCSharp:StringSize(string($var:v20))"" />
        <xsl:variable name=""var:v24"" select=""userCSharp:StringSubstring(string($var:v20) , string($var:v22) , string($var:v23))"" />
        <xsl:variable name=""var:v25"" select=""userCSharp:StringFind(string($var:v24) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v26"" select=""userCSharp:MathSubtract(string($var:v25) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v27"" select=""userCSharp:StringSubstring(string($var:v24) , &quot;1&quot; , string($var:v26))"" />
        <SN_DANo>
          <xsl:value-of select=""$var:v27"" />
        </SN_DANo>
        <xsl:variable name=""var:v28"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v29"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v28) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v30"" select=""ScriptNS1:DBValueExtract(string($var:v29) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v31"" select=""ScriptNS1:DBLookup(1 , string($var:v30) , string($var:v28) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v32"" select=""ScriptNS1:DBValueExtract(string($var:v31) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v33"" select=""userCSharp:StringFind(string($var:v32) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v34"" select=""userCSharp:MathAdd(string($var:v33) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v35"" select=""userCSharp:StringSize(string($var:v32))"" />
        <xsl:variable name=""var:v36"" select=""userCSharp:StringSubstring(string($var:v32) , string($var:v34) , string($var:v35))"" />
        <xsl:variable name=""var:v37"" select=""userCSharp:StringFind(string($var:v36) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v38"" select=""userCSharp:MathAdd(string($var:v37) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v39"" select=""userCSharp:StringSize(string($var:v36))"" />
        <xsl:variable name=""var:v40"" select=""userCSharp:StringSubstring(string($var:v36) , string($var:v38) , string($var:v39))"" />
        <xsl:variable name=""var:v41"" select=""userCSharp:StringFind(string($var:v40) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v42"" select=""userCSharp:MathSubtract(string($var:v41) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v43"" select=""userCSharp:StringSubstring(string($var:v40) , &quot;1&quot; , string($var:v42))"" />
        <SN_KeyPosition>
          <xsl:value-of select=""$var:v43"" />
        </SN_KeyPosition>
        <xsl:variable name=""var:v44"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v45"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v44) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v46"" select=""ScriptNS1:DBValueExtract(string($var:v45) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v47"" select=""ScriptNS1:DBLookup(1 , string($var:v46) , string($var:v44) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v48"" select=""ScriptNS1:DBValueExtract(string($var:v47) , &quot;ReferenceCode&quot;)"" />
        <xsl:variable name=""var:v49"" select=""userCSharp:StringFind(string($var:v48) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v50"" select=""userCSharp:MathAdd(string($var:v49) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v51"" select=""userCSharp:StringSize(string($var:v48))"" />
        <xsl:variable name=""var:v52"" select=""userCSharp:StringSubstring(string($var:v48) , string($var:v50) , string($var:v51))"" />
        <xsl:variable name=""var:v53"" select=""userCSharp:StringFind(string($var:v52) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v54"" select=""userCSharp:MathAdd(string($var:v53) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v55"" select=""userCSharp:StringSize(string($var:v52))"" />
        <xsl:variable name=""var:v56"" select=""userCSharp:StringSubstring(string($var:v52) , string($var:v54) , string($var:v55))"" />
        <xsl:variable name=""var:v57"" select=""userCSharp:StringFind(string($var:v56) , &quot;|&quot;)"" />
        <xsl:variable name=""var:v58"" select=""userCSharp:MathAdd(string($var:v57) , &quot;1&quot;)"" />
        <xsl:variable name=""var:v59"" select=""userCSharp:StringSize(string($var:v56))"" />
        <xsl:variable name=""var:v60"" select=""userCSharp:StringSubstring(string($var:v56) , string($var:v58) , string($var:v59))"" />
        <SN_VoyageNumber>
          <xsl:value-of select=""$var:v60"" />
        </SN_VoyageNumber>
        <xsl:if test=""Eta"">
          <ETA>
            <xsl:value-of select=""Eta/text()"" />
          </ETA>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Ets"">
          <ETS>
            <xsl:value-of select=""PortCallOperations/Ets/text()"" />
          </ETS>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Eosp"">
          <EOSP>
            <xsl:value-of select=""PortCallOperations/Eosp/text()"" />
          </EOSP>
        </xsl:if>
        <xsl:if test=""PortCallOperations/Cosp"">
          <CommencedSeaPassage>
            <xsl:value-of select=""PortCallOperations/Cosp/text()"" />
          </CommencedSeaPassage>
        </xsl:if>
        <xsl:variable name=""var:v61"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v62"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v61) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v63"" select=""ScriptNS1:DBValueExtract(string($var:v62) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v64"" select=""ScriptNS1:DBLookup(2 , string($var:v63) , string($var:v61) , &quot;Operation.PortCallOperations&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v65"" select=""ScriptNS1:DBValueExtract(string($var:v64) , &quot;NextPortEta&quot;)"" />
        <xsl:variable name=""var:v66"" select=""userCSharp:IsNextEtaEmpty(string($var:v65))"" />
        <xsl:variable name=""var:v67"" select=""userCSharp:MyConcatETA(string($var:v65))"" />
        <xsl:if test=""string($var:v66)='true'"">
          <xsl:variable name=""var:v68"" select=""string($var:v67)"" />
          <EtaNextPort>
            <xsl:value-of select=""$var:v68"" />
          </EtaNextPort>
        </xsl:if>
        <xsl:variable name=""var:v69"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v70"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v69) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v71"" select=""ScriptNS1:DBValueExtract(string($var:v70) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v72"" select=""ScriptNS1:DBLookup(1 , string($var:v71) , string($var:v69) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v73"" select=""ScriptNS1:DBValueExtract(string($var:v72) , &quot;HubPrincipalId&quot;)"" />
        <xsl:variable name=""var:v74"" select=""userCSharp:StringConcat(string(NextPort/Id/text()) , &quot;|&quot; , string($var:v73))"" />
        <xsl:variable name=""var:v75"" select=""ScriptNS1:DBLookup(3 , string($var:v74) , string($var:v69) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(PortId  as varchar(10)) +'|'+ cast(HubPrincipalId  as varchar(10))&quot;)"" />
        <xsl:variable name=""var:v76"" select=""ScriptNS1:DBValueExtract(string($var:v75) , &quot;Code&quot;)"" />
        <NextPortCode>
          <xsl:value-of select=""$var:v76"" />
        </NextPortCode>
        <xsl:variable name=""var:v77"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v78"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v77) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v79"" select=""ScriptNS1:DBValueExtract(string($var:v78) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v80"" select=""ScriptNS1:DBLookup(1 , string($var:v79) , string($var:v77) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v81"" select=""ScriptNS1:DBValueExtract(string($var:v80) , &quot;HubPrincipalId&quot;)"" />
        <xsl:variable name=""var:v83"" select=""userCSharp:StringConcat($var:v82 , &quot;|&quot; , string($var:v81))"" />
        <xsl:variable name=""var:v84"" select=""ScriptNS1:DBLookup(3 , string($var:v83) , string($var:v77) , &quot;Master.HubPrincipalPortMap&quot; , &quot;cast(PortId  as varchar(10)) +'|'+ cast(HubPrincipalId  as varchar(10))&quot;)"" />
        <xsl:variable name=""var:v85"" select=""ScriptNS1:DBValueExtract(string($var:v84) , &quot;Name&quot;)"" />
        <NextPortName>
          <xsl:value-of select=""$var:v85"" />
        </NextPortName>
        <xsl:variable name=""var:v86"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v87"" select=""ScriptNS1:DBLookup(0 , string($var:v15) , string($var:v86) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v88"" select=""ScriptNS1:DBValueExtract(string($var:v87) , &quot;Id&quot;)"" />
        <xsl:variable name=""var:v89"" select=""ScriptNS1:DBLookup(2 , string($var:v88) , string($var:v86) , &quot;Operation.PortCallOperations&quot; , &quot;PortCallId&quot;)"" />
        <xsl:variable name=""var:v90"" select=""ScriptNS1:DBValueExtract(string($var:v89) , &quot;CaptainName&quot;)"" />
        <Master>
          <xsl:value-of select=""$var:v90"" />
        </Master>
        <xsl:variable name=""var:v91"" select=""userCSharp:GetFlowStatus(string(FlowStatus/text()))"" />
        <WorkflowStatus>
          <xsl:value-of select=""$var:v91"" />
        </WorkflowStatus>
        <xsl:variable name=""var:v93"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
        <xsl:variable name=""var:v94"" select=""ScriptNS1:DBLookup(4 , string($var:v92) , string($var:v93) , &quot;Appointment.Appointments&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
        <xsl:variable name=""var:v95"" select=""ScriptNS1:DBValueExtract(string($var:v94) , &quot;IsPerformingAgentAccepted&quot;)"" />
        <xsl:variable name=""var:v96"" select=""userCSharp:IsNextEtaEmpty(string($var:v95))"" />
        <Agentacceptance>
          <xsl:value-of select=""$var:v96"" />
        </Agentacceptance>
        <xsl:if test=""string($var:v98)='true'"">
          <xsl:variable name=""var:v100"" select=""string($var:v99)"" />
          <ETB>
            <xsl:value-of select=""$var:v100"" />
          </ETB>
        </xsl:if>
        <xsl:if test=""string($var:v101)='true'"">
          <xsl:variable name=""var:v103"" select=""string($var:v102)"" />
          <ETB>
            <xsl:value-of select=""$var:v103"" />
          </ETB>
        </xsl:if>
        <xsl:variable name=""var:v104"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Cargoes"">
          <xsl:variable name=""var:v105"" select=""userCSharp:GetCargoCount(string(IsActive/text()))"" />
          <xsl:variable name=""var:v106"" select=""userCSharp:AddToCumulativeSum(0,string($var:v105),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v107"" select=""userCSharp:GetCumulativeSum(0)"" />
        <xsl:variable name=""var:v108"" select=""userCSharp:LogicalGt(string($var:v107) , &quot;0&quot;)"" />
        <xsl:if test=""string($var:v108)='true'"">
          <xsl:variable name=""var:v109"" select=""string($var:v107)"" />
          <CargoCount>
            <xsl:value-of select=""$var:v109"" />
          </CargoCount>
        </xsl:if>
        <xsl:variable name=""var:v110"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Cargoes"">
          <xsl:variable name=""var:v111"" select=""string(IsActive/text())"" />
          <xsl:variable name=""var:v112"" select=""userCSharp:GetCargoCount($var:v111)"" />
          <xsl:variable name=""var:v113"" select=""userCSharp:AddToCumulativeSum(0,string($var:v112),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v114"" select=""userCSharp:GetCumulativeSum(0)"" />
        <xsl:variable name=""var:v115"" select=""userCSharp:LogicalGt(string($var:v114) , &quot;0&quot;)"" />
        <xsl:if test=""$var:v115"">
          <Cargoes>
            <xsl:for-each select=""Cargoes"">
              <xsl:variable name=""var:v116"" select=""string(IsActive/text())"" />
              <xsl:variable name=""var:v117"" select=""userCSharp:LogicalEq($var:v116 , &quot;true&quot;)"" />
              <xsl:if test=""$var:v117"">
                <xsl:variable name=""var:v122"" select=""false()"" />
                <xsl:variable name=""var:v123"" select=""userCSharp:LogicalNot(string($var:v122))"" />
                <xsl:variable name=""var:v130"" select=""userCSharp:LogicalEq(string(../Drafts/Name/text()) , &quot;Arrival&quot;)"" />
                <xsl:variable name=""var:v131"" select=""userCSharp:StringConcat(string(../Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v142"" select=""string(../Number/text())"" />
                <xsl:variable name=""var:v143"" select=""userCSharp:StringConcat($var:v142 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v153"" select=""string(RefCode/text())"" />
                <Cargo>
                  <xsl:if test=""RefCode"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""RefCode/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""Rotation/IsActive/text()='true'"">
                    <xsl:variable name=""var:v118"" select=""Rotation/Poi/Name/text()"" />
                    <Terminal>
                      <xsl:value-of select=""$var:v118"" />
                    </Terminal>
                  </xsl:if>
                  <xsl:if test=""Rotation/IsActive/text()='true'"">
                    <xsl:variable name=""var:v119"" select=""Rotation/Berth/Name/text()"" />
                    <Berth>
                      <xsl:value-of select=""$var:v119"" />
                    </Berth>
                  </xsl:if>
                  <xsl:variable name=""var:v120"" select=""userCSharp:GetBLFigures(string(BillOfLadingQuantity/text()))"" />
                  <xsl:variable name=""var:v121"" select=""userCSharp:LogicalEq(string($var:v120) , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v124"" select=""userCSharp:LogicalAnd(string($var:v121) , string($var:v123))"" />
                  <xsl:if test=""string($var:v124)='true'"">
                    <xsl:variable name=""var:v125"" select=""BillOfLadingQuantity/text()"" />
                    <BlFigures>
                      <xsl:value-of select=""$var:v125"" />
                    </BlFigures>
                  </xsl:if>
                  <xsl:variable name=""var:v126"" select=""userCSharp:GetShipFig(string(VesselQuantity/text()))"" />
                  <xsl:variable name=""var:v127"" select=""userCSharp:LogicalEq(string($var:v126) , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v128"" select=""userCSharp:LogicalAnd(string($var:v127) , string($var:v123))"" />
                  <xsl:if test=""string($var:v128)='true'"">
                    <xsl:variable name=""var:v129"" select=""VesselQuantity/text()"" />
                    <ShipFigures>
                      <xsl:value-of select=""$var:v129"" />
                    </ShipFigures>
                  </xsl:if>
                  <xsl:variable name=""var:v132"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v133"" select=""ScriptNS1:DBLookup(0 , string($var:v131) , string($var:v132) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                  <xsl:variable name=""var:v134"" select=""ScriptNS1:DBValueExtract(string($var:v133) , &quot;Id&quot;)"" />
                  <xsl:variable name=""var:v135"" select=""ScriptNS1:DBLookup(1 , string($var:v134) , string($var:v132) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                  <xsl:variable name=""var:v136"" select=""ScriptNS1:DBValueExtract(string($var:v135) , &quot;HubPrincipalId&quot;)"" />
                  <xsl:variable name=""var:v137"" select=""userCSharp:StringConcat(string(UnitOfMeasure/Id/text()) , &quot;|&quot; , string($var:v136))"" />
                  <xsl:variable name=""var:v138"" select=""ScriptNS1:DBLookup(5 , string($var:v137) , string($var:v132) , &quot;Master.HubPrincipalUnitOfMeasureMap&quot; , &quot;cast(UnitOfMeasureId  as varchar(10)) +'|'+ cast(HubPrincipalId as varchar(10))&quot;)"" />
                  <xsl:variable name=""var:v139"" select=""ScriptNS1:DBValueExtract(string($var:v138) , &quot;Code&quot;)"" />
                  <xsl:variable name=""var:v140"" select=""userCSharp:StringSubstring(string($var:v139) , &quot;1&quot; , &quot;1&quot;)"" />
                  <xsl:if test=""string($var:v130)='true'"">
                    <xsl:variable name=""var:v141"" select=""string($var:v140)"" />
                    <DraftIn>
                      <xsl:value-of select=""$var:v141"" />
                    </DraftIn>
                  </xsl:if>
                  <xsl:for-each select=""../Drafts"">

      <xsl:variable name=""DraftArrivalName1"" select=""./Name/text()"" />
      
     <xsl:if test=""$DraftArrivalName1='Arrival'"">
         <xsl:variable name=""DraftArrivalIsActive1"" select=""./isActive/text()"" />
         <xsl:variable name=""DraftArrivalfwd"" select=""./Aft/text()"" />
                  <ArrDraftAft>
                                 <xsl:value-of select=""$DraftArrivalfwd"" /> 
                     </ArrDraftAft>
                      <ArrDraftMid>
                                 <xsl:value-of select=""./Mean/text()"" /> 
                     </ArrDraftMid>
                      <ArrDraftFwd>
                                 <xsl:value-of select=""./Fwd/text()"" /> 
                     </ArrDraftFwd>

    </xsl:if>

   </xsl:for-each>
                  <xsl:for-each select=""../Drafts"">

      <xsl:variable name=""DraftDepName"" select=""./Name/text()"" />
      
     <xsl:if test=""$DraftDepName='Departure'"">
         <xsl:variable name=""DraftDepIsActive"" select=""./isActive/text()"" />
                  <DepDraftAft>
                                 <xsl:value-of select=""./Aft/text()"" /> 
                     </DepDraftAft>
                      <DepDraftMid>
                                 <xsl:value-of select=""./Mean/text()"" /> 
                     </DepDraftMid>
                      <DepDraftFwd>
                                 <xsl:value-of select=""./Fwd/text()"" /> 
                     </DepDraftFwd>

    </xsl:if>

   </xsl:for-each>
                  <xsl:if test=""ShipperReceiver"">
                    <Shipper>
                      <xsl:value-of select=""ShipperReceiver/text()"" />
                    </Shipper>
                  </xsl:if>
                  <xsl:if test=""ShipperReceiver"">
                    <Receiver>
                      <xsl:value-of select=""ShipperReceiver/text()"" />
                    </Receiver>
                  </xsl:if>
                  <xsl:variable name=""var:v144"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                  <xsl:variable name=""var:v145"" select=""ScriptNS1:DBLookup(0 , string($var:v143) , string($var:v144) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                  <xsl:variable name=""var:v146"" select=""ScriptNS1:DBValueExtract(string($var:v145) , &quot;Id&quot;)"" />
                  <xsl:variable name=""var:v147"" select=""userCSharp:StringConcat(string($var:v146) , &quot;|&quot; , string(RefCode/text()))"" />
                  <xsl:variable name=""var:v148"" select=""ScriptNS1:DBLookup(6 , string($var:v147) , string($var:v144) , &quot;Operation.Cargoes&quot; , &quot;cast ( PortCallId as varchar(20) ) + '|' + cast ( RefCode  as varchar(20) )&quot;)"" />
                  <xsl:variable name=""var:v149"" select=""ScriptNS1:DBValueExtract(string($var:v148) , &quot;BillOfLadingDate&quot;)"" />
                  <xsl:variable name=""var:v150"" select=""userCSharp:IsBLDate(string($var:v149))"" />
                  <xsl:variable name=""var:v151"" select=""userCSharp:BLDate(string($var:v149))"" />
                  <xsl:if test=""string($var:v150)='true'"">
                    <xsl:variable name=""var:v152"" select=""string($var:v151)"" />
                    <BlDate>
                      <xsl:value-of select=""$var:v152"" />
                    </BlDate>
                  </xsl:if>
                  <xsl:variable name=""var:v154"" select=""ScriptNS0:CargoDocumentCount(string(../Id/text()) , $var:v153)"" />
                  <DocumentCount>
                    <xsl:value-of select=""$var:v154"" />
                  </DocumentCount>
                </Cargo>
              </xsl:if>
            </xsl:for-each>
          </Cargoes>
        </xsl:if>
        <xsl:variable name=""var:v155"" select=""userCSharp:InitCumulativeSum(1)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Bunkers"">
          <xsl:variable name=""var:v156"" select=""string(../Number/text())"" />
          <xsl:variable name=""var:v157"" select=""userCSharp:StringConcat($var:v156 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v158"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v159"" select=""ScriptNS1:DBLookup(0 , string($var:v157) , string($var:v158) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v160"" select=""ScriptNS1:DBValueExtract(string($var:v159) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v161"" select=""ScriptNS1:DBLookup(1 , string($var:v160) , string($var:v158) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
          <xsl:variable name=""var:v162"" select=""ScriptNS1:DBValueExtract(string($var:v161) , &quot;HubPrincipalKey&quot;)"" />
          <xsl:variable name=""var:v163"" select=""ScriptNS0:GetBizConnectionString()"" />
          <xsl:variable name=""var:v164"" select=""ScriptNS1:DBLookup(7 , string($var:v162) , string($var:v163) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
          <xsl:variable name=""var:v165"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;LSFO&quot;)"" />
          <xsl:variable name=""var:v166"" select=""userCSharp:GetLSFO(string(Lsfo/text()) , string($var:v165))"" />
          <xsl:variable name=""var:v167"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;HFO&quot;)"" />
          <xsl:variable name=""var:v168"" select=""userCSharp:GetHFO(string(Hfo/text()) , string($var:v167))"" />
          <xsl:variable name=""var:v169"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;LSGO&quot;)"" />
          <xsl:variable name=""var:v170"" select=""userCSharp:GetLSGO(string(Lsgo/text()) , string($var:v169))"" />
          <xsl:variable name=""var:v171"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;DO&quot;)"" />
          <xsl:variable name=""var:v172"" select=""userCSharp:GetMDO(string(Mdo/text()) , string($var:v171))"" />
          <xsl:variable name=""var:v173"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;GO&quot;)"" />
          <xsl:variable name=""var:v174"" select=""userCSharp:GetMGO(string(Mgo/text()) , string($var:v173))"" />
          <xsl:variable name=""var:v175"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;LO&quot;)"" />
          <xsl:variable name=""var:v176"" select=""userCSharp:GetLO(string(Lo/text()) , string($var:v175))"" />
          <xsl:variable name=""var:v177"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;FwCrew&quot;)"" />
          <xsl:variable name=""var:v178"" select=""userCSharp:GetFWCREW(string(FwCrew/text()) , string($var:v177))"" />
          <xsl:variable name=""var:v179"" select=""ScriptNS1:DBValueExtract(string($var:v164) , &quot;FwShip&quot;)"" />
          <xsl:variable name=""var:v180"" select=""userCSharp:GetFWSHIP(string(FwShip/text()) , string($var:v179))"" />
          <xsl:variable name=""var:v181"" select=""userCSharp:GetBunKetCountSum(string($var:v166) , string($var:v168) , string($var:v170) , string($var:v172) , string($var:v174) , string($var:v176) , string($var:v178) , string($var:v180))"" />
          <xsl:variable name=""var:v182"" select=""userCSharp:AddToCumulativeSum(1,string($var:v181),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v183"" select=""userCSharp:GetCumulativeSum(1)"" />
        <xsl:variable name=""var:v184"" select=""userCSharp:LogicalGt(string($var:v183) , &quot;0&quot;)"" />
        <xsl:if test=""string($var:v184)='true'"">
          <xsl:variable name=""var:v185"" select=""string($var:v183)"" />
          <BunkerCount>
            <xsl:value-of select=""$var:v185"" />
          </BunkerCount>
        </xsl:if>
        <xsl:variable name=""var:v186"" select=""userCSharp:InitCumulativeSum(1)"" />
        <xsl:for-each select=""/s0:YourIss2Appointment/Bunkers"">
          <xsl:variable name=""var:v187"" select=""string(../Number/text())"" />
          <xsl:variable name=""var:v188"" select=""userCSharp:StringConcat($var:v187 , &quot;|&quot; , &quot;1&quot;)"" />
          <xsl:variable name=""var:v189"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
          <xsl:variable name=""var:v190"" select=""ScriptNS1:DBLookup(0 , string($var:v188) , string($var:v189) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
          <xsl:variable name=""var:v191"" select=""ScriptNS1:DBValueExtract(string($var:v190) , &quot;Id&quot;)"" />
          <xsl:variable name=""var:v192"" select=""ScriptNS1:DBLookup(1 , string($var:v191) , string($var:v189) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
          <xsl:variable name=""var:v193"" select=""ScriptNS1:DBValueExtract(string($var:v192) , &quot;HubPrincipalKey&quot;)"" />
          <xsl:variable name=""var:v194"" select=""ScriptNS0:GetBizConnectionString()"" />
          <xsl:variable name=""var:v195"" select=""ScriptNS1:DBLookup(7 , string($var:v193) , string($var:v194) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
          <xsl:variable name=""var:v196"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;LSFO&quot;)"" />
          <xsl:variable name=""var:v197"" select=""string(Lsfo/text())"" />
          <xsl:variable name=""var:v198"" select=""userCSharp:GetLSFO($var:v197 , string($var:v196))"" />
          <xsl:variable name=""var:v199"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;HFO&quot;)"" />
          <xsl:variable name=""var:v200"" select=""string(Hfo/text())"" />
          <xsl:variable name=""var:v201"" select=""userCSharp:GetHFO($var:v200 , string($var:v199))"" />
          <xsl:variable name=""var:v202"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;LSGO&quot;)"" />
          <xsl:variable name=""var:v203"" select=""string(Lsgo/text())"" />
          <xsl:variable name=""var:v204"" select=""userCSharp:GetLSGO($var:v203 , string($var:v202))"" />
          <xsl:variable name=""var:v205"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;DO&quot;)"" />
          <xsl:variable name=""var:v206"" select=""string(Mdo/text())"" />
          <xsl:variable name=""var:v207"" select=""userCSharp:GetMDO($var:v206 , string($var:v205))"" />
          <xsl:variable name=""var:v208"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;GO&quot;)"" />
          <xsl:variable name=""var:v209"" select=""string(Mgo/text())"" />
          <xsl:variable name=""var:v210"" select=""userCSharp:GetMGO($var:v209 , string($var:v208))"" />
          <xsl:variable name=""var:v211"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;LO&quot;)"" />
          <xsl:variable name=""var:v212"" select=""string(Lo/text())"" />
          <xsl:variable name=""var:v213"" select=""userCSharp:GetLO($var:v212 , string($var:v211))"" />
          <xsl:variable name=""var:v214"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;FwCrew&quot;)"" />
          <xsl:variable name=""var:v215"" select=""string(FwCrew/text())"" />
          <xsl:variable name=""var:v216"" select=""userCSharp:GetFWCREW($var:v215 , string($var:v214))"" />
          <xsl:variable name=""var:v217"" select=""ScriptNS1:DBValueExtract(string($var:v195) , &quot;FwShip&quot;)"" />
          <xsl:variable name=""var:v218"" select=""string(FwShip/text())"" />
          <xsl:variable name=""var:v219"" select=""userCSharp:GetFWSHIP($var:v218 , string($var:v217))"" />
          <xsl:variable name=""var:v220"" select=""userCSharp:GetBunKetCountSum(string($var:v198) , string($var:v201) , string($var:v204) , string($var:v207) , string($var:v210) , string($var:v213) , string($var:v216) , string($var:v219))"" />
          <xsl:variable name=""var:v221"" select=""userCSharp:AddToCumulativeSum(1,string($var:v220),&quot;2&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v222"" select=""userCSharp:GetCumulativeSum(1)"" />
        <xsl:variable name=""var:v223"" select=""userCSharp:LogicalGt(string($var:v222) , &quot;0&quot;)"" />
        <xsl:if test=""$var:v223"">
          <Bunkers>
            <xsl:for-each select=""Bunkers"">
              <xsl:for-each select=""Lsfo"">
                <xsl:variable name=""var:v224"" select=""userCSharp:StringConcat(string(../../Number/text()) , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v225"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v226"" select=""ScriptNS1:DBLookup(0 , string($var:v224) , string($var:v225) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v227"" select=""ScriptNS1:DBValueExtract(string($var:v226) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v228"" select=""ScriptNS1:DBLookup(1 , string($var:v227) , string($var:v225) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v229"" select=""ScriptNS1:DBValueExtract(string($var:v228) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v230"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v231"" select=""ScriptNS1:DBLookup(7 , string($var:v229) , string($var:v230) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v232"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v233"" select=""userCSharp:GetLSFO(string(./text()) , string($var:v232))"" />
                <xsl:variable name=""var:v234"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v235"" select=""userCSharp:GetHFO(string(../Hfo/text()) , string($var:v234))"" />
                <xsl:variable name=""var:v236"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v237"" select=""userCSharp:GetLSGO(string(../Lsgo/text()) , string($var:v236))"" />
                <xsl:variable name=""var:v238"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v239"" select=""userCSharp:GetMDO(string(../Mdo/text()) , string($var:v238))"" />
                <xsl:variable name=""var:v240"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v241"" select=""userCSharp:GetMGO(string(../Mgo/text()) , string($var:v240))"" />
                <xsl:variable name=""var:v242"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v243"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v244"" select=""ScriptNS1:DBValueExtract(string($var:v231) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v245"" select=""userCSharp:GetLO(string(../Lo/text()) , string($var:v242))"" />
                <xsl:variable name=""var:v246"" select=""userCSharp:GetFWCREW(string(../FwCrew/text()) , string($var:v243))"" />
                <xsl:variable name=""var:v247"" select=""userCSharp:GetFWSHIP(string(../FwShip/text()) , string($var:v244))"" />
                <xsl:variable name=""var:v248"" select=""$var:v233"" />
                <xsl:variable name=""var:v249"" select=""userCSharp:LogicalEq(string($var:v248) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v249"">
                  <xsl:variable name=""var:v250"" select=""string(../../Number/text())"" />
                  <xsl:variable name=""var:v251"" select=""userCSharp:StringConcat($var:v250 , &quot;|&quot; , &quot;1&quot;)"" />
                  <xsl:variable name=""var:v260"" select=""string(./text())"" />
                  <xsl:variable name=""var:v263"" select=""string(../Hfo/text())"" />
                  <xsl:variable name=""var:v266"" select=""string(../Lsgo/text())"" />
                  <xsl:variable name=""var:v269"" select=""string(../Mdo/text())"" />
                  <xsl:variable name=""var:v272"" select=""string(../Mgo/text())"" />
                  <xsl:variable name=""var:v277"" select=""string(../Lo/text())"" />
                  <xsl:variable name=""var:v279"" select=""string(../FwCrew/text())"" />
                  <xsl:variable name=""var:v281"" select=""string(../FwShip/text())"" />
                  <xsl:variable name=""var:v312"" select=""userCSharp:LogicalEq(string(../Name/text()) , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v341"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v342"" select=""userCSharp:LogicalEq($var:v341 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v346"" select=""userCSharp:LogicalEq($var:v341 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v252"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v253"" select=""ScriptNS1:DBLookup(0 , string($var:v251) , string($var:v252) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v254"" select=""ScriptNS1:DBValueExtract(string($var:v253) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v255"" select=""ScriptNS1:DBLookup(1 , string($var:v254) , string($var:v252) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v256"" select=""ScriptNS1:DBValueExtract(string($var:v255) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v257"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v258"" select=""ScriptNS1:DBLookup(7 , string($var:v256) , string($var:v257) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v259"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v261"" select=""userCSharp:GetLSFO($var:v260 , string($var:v259))"" />
                    <xsl:variable name=""var:v262"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v264"" select=""userCSharp:GetHFO($var:v263 , string($var:v262))"" />
                    <xsl:variable name=""var:v265"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v267"" select=""userCSharp:GetLSGO($var:v266 , string($var:v265))"" />
                    <xsl:variable name=""var:v268"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v270"" select=""userCSharp:GetMDO($var:v269 , string($var:v268))"" />
                    <xsl:variable name=""var:v271"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v273"" select=""userCSharp:GetMGO($var:v272 , string($var:v271))"" />
                    <xsl:variable name=""var:v274"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v275"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v276"" select=""ScriptNS1:DBValueExtract(string($var:v258) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v278"" select=""userCSharp:GetLO($var:v277 , string($var:v274))"" />
                    <xsl:variable name=""var:v280"" select=""userCSharp:GetFWCREW($var:v279 , string($var:v275))"" />
                    <xsl:variable name=""var:v282"" select=""userCSharp:GetFWSHIP($var:v281 , string($var:v276))"" />
                    <xsl:variable name=""var:v283"" select=""$var:v261"" />
                    <xsl:variable name=""var:v284"" select=""userCSharp:LogicalEq(string($var:v283) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v285"" select=""$var:v259"" />
                    <xsl:if test=""string($var:v284)='true'"">
                      <xsl:variable name=""var:v286"" select=""string($var:v285)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v286"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v287"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v288"" select=""ScriptNS1:DBLookup(0 , string($var:v251) , string($var:v287) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v289"" select=""ScriptNS1:DBValueExtract(string($var:v288) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v290"" select=""ScriptNS1:DBLookup(1 , string($var:v289) , string($var:v287) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v291"" select=""ScriptNS1:DBValueExtract(string($var:v290) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v292"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v293"" select=""ScriptNS1:DBLookup(7 , string($var:v291) , string($var:v292) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v294"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v295"" select=""userCSharp:GetLSFO($var:v260 , string($var:v294))"" />
                    <xsl:variable name=""var:v296"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v297"" select=""userCSharp:GetHFO($var:v263 , string($var:v296))"" />
                    <xsl:variable name=""var:v298"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v299"" select=""userCSharp:GetLSGO($var:v266 , string($var:v298))"" />
                    <xsl:variable name=""var:v300"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v301"" select=""userCSharp:GetMDO($var:v269 , string($var:v300))"" />
                    <xsl:variable name=""var:v302"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v303"" select=""userCSharp:GetMGO($var:v272 , string($var:v302))"" />
                    <xsl:variable name=""var:v304"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v305"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v306"" select=""ScriptNS1:DBValueExtract(string($var:v293) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v307"" select=""userCSharp:GetLO($var:v277 , string($var:v304))"" />
                    <xsl:variable name=""var:v308"" select=""userCSharp:GetFWCREW($var:v279 , string($var:v305))"" />
                    <xsl:variable name=""var:v309"" select=""userCSharp:GetFWSHIP($var:v281 , string($var:v306))"" />
                    <xsl:variable name=""var:v310"" select=""$var:v295"" />
                    <xsl:variable name=""var:v311"" select=""userCSharp:LogicalEq(string($var:v310) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v313"" select=""userCSharp:LogicalAnd(string($var:v311) , string($var:v312))"" />
                    <xsl:variable name=""var:v314"" select=""."" />
                    <xsl:if test=""string($var:v313)='true'"">
                      <xsl:variable name=""var:v315"" select=""string($var:v314)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v315"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v316"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v317"" select=""ScriptNS1:DBLookup(0 , string($var:v251) , string($var:v316) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v318"" select=""ScriptNS1:DBValueExtract(string($var:v317) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v319"" select=""ScriptNS1:DBLookup(1 , string($var:v318) , string($var:v316) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v320"" select=""ScriptNS1:DBValueExtract(string($var:v319) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v321"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v322"" select=""ScriptNS1:DBLookup(7 , string($var:v320) , string($var:v321) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v323"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v324"" select=""userCSharp:GetLSFO($var:v260 , string($var:v323))"" />
                    <xsl:variable name=""var:v325"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v326"" select=""userCSharp:GetHFO($var:v263 , string($var:v325))"" />
                    <xsl:variable name=""var:v327"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v328"" select=""userCSharp:GetLSGO($var:v266 , string($var:v327))"" />
                    <xsl:variable name=""var:v329"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v330"" select=""userCSharp:GetMDO($var:v269 , string($var:v329))"" />
                    <xsl:variable name=""var:v331"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v332"" select=""userCSharp:GetMGO($var:v272 , string($var:v331))"" />
                    <xsl:variable name=""var:v333"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v334"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v335"" select=""ScriptNS1:DBValueExtract(string($var:v322) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v336"" select=""userCSharp:GetLO($var:v277 , string($var:v333))"" />
                    <xsl:variable name=""var:v337"" select=""userCSharp:GetFWCREW($var:v279 , string($var:v334))"" />
                    <xsl:variable name=""var:v338"" select=""userCSharp:GetFWSHIP($var:v281 , string($var:v335))"" />
                    <xsl:variable name=""var:v339"" select=""$var:v324"" />
                    <xsl:variable name=""var:v340"" select=""userCSharp:LogicalEq(string($var:v339) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v343"" select=""userCSharp:LogicalAnd(string($var:v340) , string($var:v342))"" />
                    <xsl:variable name=""var:v344"" select=""."" />
                    <xsl:if test=""string($var:v343)='true'"">
                      <xsl:variable name=""var:v345"" select=""string($var:v344)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v345"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v347"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v348"" select=""ScriptNS1:DBLookup(0 , string($var:v251) , string($var:v347) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v349"" select=""ScriptNS1:DBValueExtract(string($var:v348) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v350"" select=""ScriptNS1:DBLookup(1 , string($var:v349) , string($var:v347) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v351"" select=""ScriptNS1:DBValueExtract(string($var:v350) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v352"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v353"" select=""ScriptNS1:DBLookup(7 , string($var:v351) , string($var:v352) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v354"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v355"" select=""userCSharp:GetLSFO($var:v260 , string($var:v354))"" />
                    <xsl:variable name=""var:v356"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v357"" select=""userCSharp:GetHFO($var:v263 , string($var:v356))"" />
                    <xsl:variable name=""var:v358"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v359"" select=""userCSharp:GetLSGO($var:v266 , string($var:v358))"" />
                    <xsl:variable name=""var:v360"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v361"" select=""userCSharp:GetMDO($var:v269 , string($var:v360))"" />
                    <xsl:variable name=""var:v362"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v363"" select=""userCSharp:GetMGO($var:v272 , string($var:v362))"" />
                    <xsl:variable name=""var:v364"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v365"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v366"" select=""ScriptNS1:DBValueExtract(string($var:v353) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v367"" select=""userCSharp:GetLO($var:v277 , string($var:v364))"" />
                    <xsl:variable name=""var:v368"" select=""userCSharp:GetFWCREW($var:v279 , string($var:v365))"" />
                    <xsl:variable name=""var:v369"" select=""userCSharp:GetFWSHIP($var:v281 , string($var:v366))"" />
                    <xsl:variable name=""var:v370"" select=""$var:v355"" />
                    <xsl:variable name=""var:v371"" select=""userCSharp:LogicalEq(string($var:v370) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v372"" select=""userCSharp:LogicalAnd(string($var:v346) , string($var:v371))"" />
                    <xsl:variable name=""var:v373"" select=""."" />
                    <xsl:if test=""string($var:v372)='true'"">
                      <xsl:variable name=""var:v374"" select=""string($var:v373)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v374"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v375"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v376"" select=""ScriptNS1:DBLookup(0 , string($var:v251) , string($var:v375) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v377"" select=""ScriptNS1:DBValueExtract(string($var:v376) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v378"" select=""ScriptNS1:DBLookup(1 , string($var:v377) , string($var:v375) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v379"" select=""ScriptNS1:DBValueExtract(string($var:v378) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v380"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v381"" select=""ScriptNS1:DBLookup(7 , string($var:v379) , string($var:v380) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v382"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v383"" select=""userCSharp:GetLSFO($var:v260 , string($var:v382))"" />
                    <xsl:variable name=""var:v384"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v385"" select=""userCSharp:GetHFO($var:v263 , string($var:v384))"" />
                    <xsl:variable name=""var:v386"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v387"" select=""userCSharp:GetLSGO($var:v266 , string($var:v386))"" />
                    <xsl:variable name=""var:v388"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v389"" select=""userCSharp:GetMDO($var:v269 , string($var:v388))"" />
                    <xsl:variable name=""var:v390"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v391"" select=""userCSharp:GetMGO($var:v272 , string($var:v390))"" />
                    <xsl:variable name=""var:v392"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v393"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v394"" select=""ScriptNS1:DBValueExtract(string($var:v381) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v395"" select=""userCSharp:GetLO($var:v277 , string($var:v392))"" />
                    <xsl:variable name=""var:v396"" select=""userCSharp:GetFWCREW($var:v279 , string($var:v393))"" />
                    <xsl:variable name=""var:v397"" select=""userCSharp:GetFWSHIP($var:v281 , string($var:v394))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v398"" select=""string(../../Number/text())"" />
                <xsl:variable name=""var:v399"" select=""userCSharp:StringConcat($var:v398 , &quot;|&quot; , &quot;1&quot;)"" />
                <xsl:variable name=""var:v400"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v401"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v400) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v402"" select=""ScriptNS1:DBValueExtract(string($var:v401) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v403"" select=""ScriptNS1:DBLookup(1 , string($var:v402) , string($var:v400) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v404"" select=""ScriptNS1:DBValueExtract(string($var:v403) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v405"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v406"" select=""ScriptNS1:DBLookup(7 , string($var:v404) , string($var:v405) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v407"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v408"" select=""string(./text())"" />
                <xsl:variable name=""var:v409"" select=""userCSharp:GetLSFO($var:v408 , string($var:v407))"" />
                <xsl:variable name=""var:v410"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v411"" select=""string(../Hfo/text())"" />
                <xsl:variable name=""var:v412"" select=""userCSharp:GetHFO($var:v411 , string($var:v410))"" />
                <xsl:variable name=""var:v413"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v414"" select=""string(../Lsgo/text())"" />
                <xsl:variable name=""var:v415"" select=""userCSharp:GetLSGO($var:v414 , string($var:v413))"" />
                <xsl:variable name=""var:v416"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v417"" select=""string(../Mdo/text())"" />
                <xsl:variable name=""var:v418"" select=""userCSharp:GetMDO($var:v417 , string($var:v416))"" />
                <xsl:variable name=""var:v419"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v420"" select=""string(../Mgo/text())"" />
                <xsl:variable name=""var:v421"" select=""userCSharp:GetMGO($var:v420 , string($var:v419))"" />
                <xsl:variable name=""var:v422"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v423"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v424"" select=""ScriptNS1:DBValueExtract(string($var:v406) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v425"" select=""string(../Lo/text())"" />
                <xsl:variable name=""var:v426"" select=""userCSharp:GetLO($var:v425 , string($var:v422))"" />
                <xsl:variable name=""var:v427"" select=""string(../FwCrew/text())"" />
                <xsl:variable name=""var:v428"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v423))"" />
                <xsl:variable name=""var:v429"" select=""string(../FwShip/text())"" />
                <xsl:variable name=""var:v430"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v424))"" />
                <xsl:variable name=""var:v431"" select=""$var:v412"" />
                <xsl:variable name=""var:v432"" select=""userCSharp:LogicalEq(string($var:v431) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v432"">
                  <xsl:variable name=""var:v485"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v486"" select=""userCSharp:LogicalEq($var:v485 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v515"" select=""userCSharp:LogicalEq($var:v485 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v519"" select=""userCSharp:LogicalEq($var:v485 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v433"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v434"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v433) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v435"" select=""ScriptNS1:DBValueExtract(string($var:v434) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v436"" select=""ScriptNS1:DBLookup(1 , string($var:v435) , string($var:v433) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v437"" select=""ScriptNS1:DBValueExtract(string($var:v436) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v438"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v439"" select=""ScriptNS1:DBLookup(7 , string($var:v437) , string($var:v438) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v440"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v441"" select=""userCSharp:GetLSFO($var:v408 , string($var:v440))"" />
                    <xsl:variable name=""var:v442"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v443"" select=""userCSharp:GetHFO($var:v411 , string($var:v442))"" />
                    <xsl:variable name=""var:v444"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v445"" select=""userCSharp:GetLSGO($var:v414 , string($var:v444))"" />
                    <xsl:variable name=""var:v446"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v447"" select=""userCSharp:GetMDO($var:v417 , string($var:v446))"" />
                    <xsl:variable name=""var:v448"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v449"" select=""userCSharp:GetMGO($var:v420 , string($var:v448))"" />
                    <xsl:variable name=""var:v450"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v451"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v452"" select=""ScriptNS1:DBValueExtract(string($var:v439) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v453"" select=""userCSharp:GetLO($var:v425 , string($var:v450))"" />
                    <xsl:variable name=""var:v454"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v451))"" />
                    <xsl:variable name=""var:v455"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v452))"" />
                    <xsl:variable name=""var:v456"" select=""$var:v443"" />
                    <xsl:variable name=""var:v457"" select=""userCSharp:LogicalEq(string($var:v456) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v458"" select=""$var:v442"" />
                    <xsl:if test=""string($var:v457)='true'"">
                      <xsl:variable name=""var:v459"" select=""string($var:v458)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v459"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v460"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v461"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v460) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v462"" select=""ScriptNS1:DBValueExtract(string($var:v461) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v463"" select=""ScriptNS1:DBLookup(1 , string($var:v462) , string($var:v460) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v464"" select=""ScriptNS1:DBValueExtract(string($var:v463) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v465"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v466"" select=""ScriptNS1:DBLookup(7 , string($var:v464) , string($var:v465) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v467"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v468"" select=""userCSharp:GetLSFO($var:v408 , string($var:v467))"" />
                    <xsl:variable name=""var:v469"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v470"" select=""userCSharp:GetHFO($var:v411 , string($var:v469))"" />
                    <xsl:variable name=""var:v471"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v472"" select=""userCSharp:GetLSGO($var:v414 , string($var:v471))"" />
                    <xsl:variable name=""var:v473"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v474"" select=""userCSharp:GetMDO($var:v417 , string($var:v473))"" />
                    <xsl:variable name=""var:v475"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v476"" select=""userCSharp:GetMGO($var:v420 , string($var:v475))"" />
                    <xsl:variable name=""var:v477"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v478"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v479"" select=""ScriptNS1:DBValueExtract(string($var:v466) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v480"" select=""userCSharp:GetLO($var:v425 , string($var:v477))"" />
                    <xsl:variable name=""var:v481"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v478))"" />
                    <xsl:variable name=""var:v482"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v479))"" />
                    <xsl:variable name=""var:v483"" select=""$var:v470"" />
                    <xsl:variable name=""var:v484"" select=""userCSharp:LogicalEq(string($var:v483) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v487"" select=""userCSharp:LogicalAnd(string($var:v484) , string($var:v486))"" />
                    <xsl:variable name=""var:v488"" select=""../Hfo"" />
                    <xsl:if test=""string($var:v487)='true'"">
                      <xsl:variable name=""var:v489"" select=""string($var:v488)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v489"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v490"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v491"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v490) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v492"" select=""ScriptNS1:DBValueExtract(string($var:v491) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v493"" select=""ScriptNS1:DBLookup(1 , string($var:v492) , string($var:v490) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v494"" select=""ScriptNS1:DBValueExtract(string($var:v493) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v495"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v496"" select=""ScriptNS1:DBLookup(7 , string($var:v494) , string($var:v495) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v497"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v498"" select=""userCSharp:GetLSFO($var:v408 , string($var:v497))"" />
                    <xsl:variable name=""var:v499"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v500"" select=""userCSharp:GetHFO($var:v411 , string($var:v499))"" />
                    <xsl:variable name=""var:v501"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v502"" select=""userCSharp:GetLSGO($var:v414 , string($var:v501))"" />
                    <xsl:variable name=""var:v503"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v504"" select=""userCSharp:GetMDO($var:v417 , string($var:v503))"" />
                    <xsl:variable name=""var:v505"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v506"" select=""userCSharp:GetMGO($var:v420 , string($var:v505))"" />
                    <xsl:variable name=""var:v507"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v508"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v509"" select=""ScriptNS1:DBValueExtract(string($var:v496) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v510"" select=""userCSharp:GetLO($var:v425 , string($var:v507))"" />
                    <xsl:variable name=""var:v511"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v508))"" />
                    <xsl:variable name=""var:v512"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v509))"" />
                    <xsl:variable name=""var:v513"" select=""$var:v500"" />
                    <xsl:variable name=""var:v514"" select=""userCSharp:LogicalEq(string($var:v513) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v516"" select=""userCSharp:LogicalAnd(string($var:v514) , string($var:v515))"" />
                    <xsl:variable name=""var:v517"" select=""../Hfo"" />
                    <xsl:if test=""string($var:v516)='true'"">
                      <xsl:variable name=""var:v518"" select=""string($var:v517)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v518"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v520"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v521"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v520) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v522"" select=""ScriptNS1:DBValueExtract(string($var:v521) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v523"" select=""ScriptNS1:DBLookup(1 , string($var:v522) , string($var:v520) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v524"" select=""ScriptNS1:DBValueExtract(string($var:v523) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v525"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v526"" select=""ScriptNS1:DBLookup(7 , string($var:v524) , string($var:v525) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v527"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v528"" select=""userCSharp:GetLSFO($var:v408 , string($var:v527))"" />
                    <xsl:variable name=""var:v529"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v530"" select=""userCSharp:GetHFO($var:v411 , string($var:v529))"" />
                    <xsl:variable name=""var:v531"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v532"" select=""userCSharp:GetLSGO($var:v414 , string($var:v531))"" />
                    <xsl:variable name=""var:v533"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v534"" select=""userCSharp:GetMDO($var:v417 , string($var:v533))"" />
                    <xsl:variable name=""var:v535"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v536"" select=""userCSharp:GetMGO($var:v420 , string($var:v535))"" />
                    <xsl:variable name=""var:v537"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v538"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v539"" select=""ScriptNS1:DBValueExtract(string($var:v526) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v540"" select=""userCSharp:GetLO($var:v425 , string($var:v537))"" />
                    <xsl:variable name=""var:v541"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v538))"" />
                    <xsl:variable name=""var:v542"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v539))"" />
                    <xsl:variable name=""var:v543"" select=""$var:v530"" />
                    <xsl:variable name=""var:v544"" select=""userCSharp:LogicalEq(string($var:v543) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v545"" select=""userCSharp:LogicalAnd(string($var:v519) , string($var:v544))"" />
                    <xsl:variable name=""var:v546"" select=""../Hfo"" />
                    <xsl:if test=""string($var:v545)='true'"">
                      <xsl:variable name=""var:v547"" select=""string($var:v546)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v547"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v548"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v549"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v548) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v550"" select=""ScriptNS1:DBValueExtract(string($var:v549) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v551"" select=""ScriptNS1:DBLookup(1 , string($var:v550) , string($var:v548) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v552"" select=""ScriptNS1:DBValueExtract(string($var:v551) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v553"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v554"" select=""ScriptNS1:DBLookup(7 , string($var:v552) , string($var:v553) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v555"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v556"" select=""userCSharp:GetLSFO($var:v408 , string($var:v555))"" />
                    <xsl:variable name=""var:v557"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v558"" select=""userCSharp:GetHFO($var:v411 , string($var:v557))"" />
                    <xsl:variable name=""var:v559"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v560"" select=""userCSharp:GetLSGO($var:v414 , string($var:v559))"" />
                    <xsl:variable name=""var:v561"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v562"" select=""userCSharp:GetMDO($var:v417 , string($var:v561))"" />
                    <xsl:variable name=""var:v563"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v564"" select=""userCSharp:GetMGO($var:v420 , string($var:v563))"" />
                    <xsl:variable name=""var:v565"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v566"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v567"" select=""ScriptNS1:DBValueExtract(string($var:v554) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v568"" select=""userCSharp:GetLO($var:v425 , string($var:v565))"" />
                    <xsl:variable name=""var:v569"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v566))"" />
                    <xsl:variable name=""var:v570"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v567))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v571"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v572"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v571) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v573"" select=""ScriptNS1:DBValueExtract(string($var:v572) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v574"" select=""ScriptNS1:DBLookup(1 , string($var:v573) , string($var:v571) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v575"" select=""ScriptNS1:DBValueExtract(string($var:v574) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v576"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v577"" select=""ScriptNS1:DBLookup(7 , string($var:v575) , string($var:v576) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v578"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v579"" select=""userCSharp:GetLSFO($var:v408 , string($var:v578))"" />
                <xsl:variable name=""var:v580"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v581"" select=""userCSharp:GetHFO($var:v411 , string($var:v580))"" />
                <xsl:variable name=""var:v582"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v583"" select=""userCSharp:GetLSGO($var:v414 , string($var:v582))"" />
                <xsl:variable name=""var:v584"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v585"" select=""userCSharp:GetMDO($var:v417 , string($var:v584))"" />
                <xsl:variable name=""var:v586"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v587"" select=""userCSharp:GetMGO($var:v420 , string($var:v586))"" />
                <xsl:variable name=""var:v588"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v589"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v590"" select=""ScriptNS1:DBValueExtract(string($var:v577) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v591"" select=""userCSharp:GetLO($var:v425 , string($var:v588))"" />
                <xsl:variable name=""var:v592"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v589))"" />
                <xsl:variable name=""var:v593"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v590))"" />
                <xsl:variable name=""var:v594"" select=""$var:v585"" />
                <xsl:variable name=""var:v595"" select=""userCSharp:LogicalEq(string($var:v594) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v595"">
                  <xsl:variable name=""var:v648"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v649"" select=""userCSharp:LogicalEq($var:v648 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v678"" select=""userCSharp:LogicalEq($var:v648 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v682"" select=""userCSharp:LogicalEq($var:v648 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v596"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v597"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v596) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v598"" select=""ScriptNS1:DBValueExtract(string($var:v597) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v599"" select=""ScriptNS1:DBLookup(1 , string($var:v598) , string($var:v596) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v600"" select=""ScriptNS1:DBValueExtract(string($var:v599) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v601"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v602"" select=""ScriptNS1:DBLookup(7 , string($var:v600) , string($var:v601) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v603"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v604"" select=""userCSharp:GetLSFO($var:v408 , string($var:v603))"" />
                    <xsl:variable name=""var:v605"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v606"" select=""userCSharp:GetHFO($var:v411 , string($var:v605))"" />
                    <xsl:variable name=""var:v607"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v608"" select=""userCSharp:GetLSGO($var:v414 , string($var:v607))"" />
                    <xsl:variable name=""var:v609"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v610"" select=""userCSharp:GetMDO($var:v417 , string($var:v609))"" />
                    <xsl:variable name=""var:v611"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v612"" select=""userCSharp:GetMGO($var:v420 , string($var:v611))"" />
                    <xsl:variable name=""var:v613"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v614"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v615"" select=""ScriptNS1:DBValueExtract(string($var:v602) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v616"" select=""userCSharp:GetLO($var:v425 , string($var:v613))"" />
                    <xsl:variable name=""var:v617"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v614))"" />
                    <xsl:variable name=""var:v618"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v615))"" />
                    <xsl:variable name=""var:v619"" select=""$var:v610"" />
                    <xsl:variable name=""var:v620"" select=""userCSharp:LogicalEq(string($var:v619) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v621"" select=""$var:v609"" />
                    <xsl:if test=""string($var:v620)='true'"">
                      <xsl:variable name=""var:v622"" select=""string($var:v621)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v622"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v623"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v624"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v623) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v625"" select=""ScriptNS1:DBValueExtract(string($var:v624) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v626"" select=""ScriptNS1:DBLookup(1 , string($var:v625) , string($var:v623) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v627"" select=""ScriptNS1:DBValueExtract(string($var:v626) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v628"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v629"" select=""ScriptNS1:DBLookup(7 , string($var:v627) , string($var:v628) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v630"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v631"" select=""userCSharp:GetLSFO($var:v408 , string($var:v630))"" />
                    <xsl:variable name=""var:v632"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v633"" select=""userCSharp:GetHFO($var:v411 , string($var:v632))"" />
                    <xsl:variable name=""var:v634"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v635"" select=""userCSharp:GetLSGO($var:v414 , string($var:v634))"" />
                    <xsl:variable name=""var:v636"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v637"" select=""userCSharp:GetMDO($var:v417 , string($var:v636))"" />
                    <xsl:variable name=""var:v638"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v639"" select=""userCSharp:GetMGO($var:v420 , string($var:v638))"" />
                    <xsl:variable name=""var:v640"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v641"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v642"" select=""ScriptNS1:DBValueExtract(string($var:v629) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v643"" select=""userCSharp:GetLO($var:v425 , string($var:v640))"" />
                    <xsl:variable name=""var:v644"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v641))"" />
                    <xsl:variable name=""var:v645"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v642))"" />
                    <xsl:variable name=""var:v646"" select=""$var:v637"" />
                    <xsl:variable name=""var:v647"" select=""userCSharp:LogicalEq(string($var:v646) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v650"" select=""userCSharp:LogicalAnd(string($var:v647) , string($var:v649))"" />
                    <xsl:variable name=""var:v651"" select=""../Mdo"" />
                    <xsl:if test=""string($var:v650)='true'"">
                      <xsl:variable name=""var:v652"" select=""string($var:v651)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v652"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v653"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v654"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v653) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v655"" select=""ScriptNS1:DBValueExtract(string($var:v654) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v656"" select=""ScriptNS1:DBLookup(1 , string($var:v655) , string($var:v653) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v657"" select=""ScriptNS1:DBValueExtract(string($var:v656) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v658"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v659"" select=""ScriptNS1:DBLookup(7 , string($var:v657) , string($var:v658) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v660"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v661"" select=""userCSharp:GetLSFO($var:v408 , string($var:v660))"" />
                    <xsl:variable name=""var:v662"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v663"" select=""userCSharp:GetHFO($var:v411 , string($var:v662))"" />
                    <xsl:variable name=""var:v664"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v665"" select=""userCSharp:GetLSGO($var:v414 , string($var:v664))"" />
                    <xsl:variable name=""var:v666"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v667"" select=""userCSharp:GetMDO($var:v417 , string($var:v666))"" />
                    <xsl:variable name=""var:v668"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v669"" select=""userCSharp:GetMGO($var:v420 , string($var:v668))"" />
                    <xsl:variable name=""var:v670"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v671"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v672"" select=""ScriptNS1:DBValueExtract(string($var:v659) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v673"" select=""userCSharp:GetLO($var:v425 , string($var:v670))"" />
                    <xsl:variable name=""var:v674"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v671))"" />
                    <xsl:variable name=""var:v675"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v672))"" />
                    <xsl:variable name=""var:v676"" select=""$var:v667"" />
                    <xsl:variable name=""var:v677"" select=""userCSharp:LogicalEq(string($var:v676) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v679"" select=""userCSharp:LogicalAnd(string($var:v677) , string($var:v678))"" />
                    <xsl:variable name=""var:v680"" select=""../Mdo"" />
                    <xsl:if test=""string($var:v679)='true'"">
                      <xsl:variable name=""var:v681"" select=""string($var:v680)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v681"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v683"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v684"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v683) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v685"" select=""ScriptNS1:DBValueExtract(string($var:v684) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v686"" select=""ScriptNS1:DBLookup(1 , string($var:v685) , string($var:v683) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v687"" select=""ScriptNS1:DBValueExtract(string($var:v686) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v688"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v689"" select=""ScriptNS1:DBLookup(7 , string($var:v687) , string($var:v688) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v690"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v691"" select=""userCSharp:GetLSFO($var:v408 , string($var:v690))"" />
                    <xsl:variable name=""var:v692"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v693"" select=""userCSharp:GetHFO($var:v411 , string($var:v692))"" />
                    <xsl:variable name=""var:v694"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v695"" select=""userCSharp:GetLSGO($var:v414 , string($var:v694))"" />
                    <xsl:variable name=""var:v696"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v697"" select=""userCSharp:GetMDO($var:v417 , string($var:v696))"" />
                    <xsl:variable name=""var:v698"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v699"" select=""userCSharp:GetMGO($var:v420 , string($var:v698))"" />
                    <xsl:variable name=""var:v700"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v701"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v702"" select=""ScriptNS1:DBValueExtract(string($var:v689) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v703"" select=""userCSharp:GetLO($var:v425 , string($var:v700))"" />
                    <xsl:variable name=""var:v704"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v701))"" />
                    <xsl:variable name=""var:v705"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v702))"" />
                    <xsl:variable name=""var:v706"" select=""$var:v697"" />
                    <xsl:variable name=""var:v707"" select=""userCSharp:LogicalEq(string($var:v706) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v708"" select=""userCSharp:LogicalAnd(string($var:v682) , string($var:v707))"" />
                    <xsl:variable name=""var:v709"" select=""../Mdo"" />
                    <xsl:if test=""string($var:v708)='true'"">
                      <xsl:variable name=""var:v710"" select=""string($var:v709)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v710"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v711"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v712"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v711) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v713"" select=""ScriptNS1:DBValueExtract(string($var:v712) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v714"" select=""ScriptNS1:DBLookup(1 , string($var:v713) , string($var:v711) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v715"" select=""ScriptNS1:DBValueExtract(string($var:v714) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v716"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v717"" select=""ScriptNS1:DBLookup(7 , string($var:v715) , string($var:v716) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v718"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v719"" select=""userCSharp:GetLSFO($var:v408 , string($var:v718))"" />
                    <xsl:variable name=""var:v720"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v721"" select=""userCSharp:GetHFO($var:v411 , string($var:v720))"" />
                    <xsl:variable name=""var:v722"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v723"" select=""userCSharp:GetLSGO($var:v414 , string($var:v722))"" />
                    <xsl:variable name=""var:v724"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v725"" select=""userCSharp:GetMDO($var:v417 , string($var:v724))"" />
                    <xsl:variable name=""var:v726"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v727"" select=""userCSharp:GetMGO($var:v420 , string($var:v726))"" />
                    <xsl:variable name=""var:v728"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v729"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v730"" select=""ScriptNS1:DBValueExtract(string($var:v717) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v731"" select=""userCSharp:GetLO($var:v425 , string($var:v728))"" />
                    <xsl:variable name=""var:v732"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v729))"" />
                    <xsl:variable name=""var:v733"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v730))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v734"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v735"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v734) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v736"" select=""ScriptNS1:DBValueExtract(string($var:v735) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v737"" select=""ScriptNS1:DBLookup(1 , string($var:v736) , string($var:v734) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v738"" select=""ScriptNS1:DBValueExtract(string($var:v737) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v739"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v740"" select=""ScriptNS1:DBLookup(7 , string($var:v738) , string($var:v739) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v741"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v742"" select=""userCSharp:GetLSFO($var:v408 , string($var:v741))"" />
                <xsl:variable name=""var:v743"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v744"" select=""userCSharp:GetHFO($var:v411 , string($var:v743))"" />
                <xsl:variable name=""var:v745"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v746"" select=""userCSharp:GetLSGO($var:v414 , string($var:v745))"" />
                <xsl:variable name=""var:v747"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v748"" select=""userCSharp:GetMDO($var:v417 , string($var:v747))"" />
                <xsl:variable name=""var:v749"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v750"" select=""userCSharp:GetMGO($var:v420 , string($var:v749))"" />
                <xsl:variable name=""var:v751"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v752"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v753"" select=""ScriptNS1:DBValueExtract(string($var:v740) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v754"" select=""userCSharp:GetLO($var:v425 , string($var:v751))"" />
                <xsl:variable name=""var:v755"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v752))"" />
                <xsl:variable name=""var:v756"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v753))"" />
                <xsl:variable name=""var:v757"" select=""$var:v750"" />
                <xsl:variable name=""var:v758"" select=""userCSharp:LogicalEq(string($var:v757) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v758"">
                  <xsl:variable name=""var:v811"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v812"" select=""userCSharp:LogicalEq($var:v811 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v841"" select=""userCSharp:LogicalEq($var:v811 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v845"" select=""userCSharp:LogicalEq($var:v811 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v759"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v760"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v759) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v761"" select=""ScriptNS1:DBValueExtract(string($var:v760) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v762"" select=""ScriptNS1:DBLookup(1 , string($var:v761) , string($var:v759) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v763"" select=""ScriptNS1:DBValueExtract(string($var:v762) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v764"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v765"" select=""ScriptNS1:DBLookup(7 , string($var:v763) , string($var:v764) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v766"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v767"" select=""userCSharp:GetLSFO($var:v408 , string($var:v766))"" />
                    <xsl:variable name=""var:v768"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v769"" select=""userCSharp:GetHFO($var:v411 , string($var:v768))"" />
                    <xsl:variable name=""var:v770"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v771"" select=""userCSharp:GetLSGO($var:v414 , string($var:v770))"" />
                    <xsl:variable name=""var:v772"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v773"" select=""userCSharp:GetMDO($var:v417 , string($var:v772))"" />
                    <xsl:variable name=""var:v774"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v775"" select=""userCSharp:GetMGO($var:v420 , string($var:v774))"" />
                    <xsl:variable name=""var:v776"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v777"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v778"" select=""ScriptNS1:DBValueExtract(string($var:v765) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v779"" select=""userCSharp:GetLO($var:v425 , string($var:v776))"" />
                    <xsl:variable name=""var:v780"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v777))"" />
                    <xsl:variable name=""var:v781"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v778))"" />
                    <xsl:variable name=""var:v782"" select=""$var:v775"" />
                    <xsl:variable name=""var:v783"" select=""userCSharp:LogicalEq(string($var:v782) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v784"" select=""$var:v774"" />
                    <xsl:if test=""string($var:v783)='true'"">
                      <xsl:variable name=""var:v785"" select=""string($var:v784)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v785"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v786"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v787"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v786) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v788"" select=""ScriptNS1:DBValueExtract(string($var:v787) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v789"" select=""ScriptNS1:DBLookup(1 , string($var:v788) , string($var:v786) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v790"" select=""ScriptNS1:DBValueExtract(string($var:v789) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v791"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v792"" select=""ScriptNS1:DBLookup(7 , string($var:v790) , string($var:v791) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v793"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v794"" select=""userCSharp:GetLSFO($var:v408 , string($var:v793))"" />
                    <xsl:variable name=""var:v795"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v796"" select=""userCSharp:GetHFO($var:v411 , string($var:v795))"" />
                    <xsl:variable name=""var:v797"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v798"" select=""userCSharp:GetLSGO($var:v414 , string($var:v797))"" />
                    <xsl:variable name=""var:v799"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v800"" select=""userCSharp:GetMDO($var:v417 , string($var:v799))"" />
                    <xsl:variable name=""var:v801"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v802"" select=""userCSharp:GetMGO($var:v420 , string($var:v801))"" />
                    <xsl:variable name=""var:v803"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v804"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v805"" select=""ScriptNS1:DBValueExtract(string($var:v792) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v806"" select=""userCSharp:GetLO($var:v425 , string($var:v803))"" />
                    <xsl:variable name=""var:v807"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v804))"" />
                    <xsl:variable name=""var:v808"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v805))"" />
                    <xsl:variable name=""var:v809"" select=""$var:v802"" />
                    <xsl:variable name=""var:v810"" select=""userCSharp:LogicalEq(string($var:v809) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v813"" select=""userCSharp:LogicalAnd(string($var:v810) , string($var:v812))"" />
                    <xsl:variable name=""var:v814"" select=""../Mgo"" />
                    <xsl:if test=""string($var:v813)='true'"">
                      <xsl:variable name=""var:v815"" select=""string($var:v814)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v815"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v816"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v817"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v816) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v818"" select=""ScriptNS1:DBValueExtract(string($var:v817) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v819"" select=""ScriptNS1:DBLookup(1 , string($var:v818) , string($var:v816) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v820"" select=""ScriptNS1:DBValueExtract(string($var:v819) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v821"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v822"" select=""ScriptNS1:DBLookup(7 , string($var:v820) , string($var:v821) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v823"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v824"" select=""userCSharp:GetLSFO($var:v408 , string($var:v823))"" />
                    <xsl:variable name=""var:v825"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v826"" select=""userCSharp:GetHFO($var:v411 , string($var:v825))"" />
                    <xsl:variable name=""var:v827"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v828"" select=""userCSharp:GetLSGO($var:v414 , string($var:v827))"" />
                    <xsl:variable name=""var:v829"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v830"" select=""userCSharp:GetMDO($var:v417 , string($var:v829))"" />
                    <xsl:variable name=""var:v831"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v832"" select=""userCSharp:GetMGO($var:v420 , string($var:v831))"" />
                    <xsl:variable name=""var:v833"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v834"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v835"" select=""ScriptNS1:DBValueExtract(string($var:v822) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v836"" select=""userCSharp:GetLO($var:v425 , string($var:v833))"" />
                    <xsl:variable name=""var:v837"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v834))"" />
                    <xsl:variable name=""var:v838"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v835))"" />
                    <xsl:variable name=""var:v839"" select=""$var:v832"" />
                    <xsl:variable name=""var:v840"" select=""userCSharp:LogicalEq(string($var:v839) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v842"" select=""userCSharp:LogicalAnd(string($var:v840) , string($var:v841))"" />
                    <xsl:variable name=""var:v843"" select=""../Mgo"" />
                    <xsl:if test=""string($var:v842)='true'"">
                      <xsl:variable name=""var:v844"" select=""string($var:v843)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v844"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v846"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v847"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v846) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v848"" select=""ScriptNS1:DBValueExtract(string($var:v847) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v849"" select=""ScriptNS1:DBLookup(1 , string($var:v848) , string($var:v846) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v850"" select=""ScriptNS1:DBValueExtract(string($var:v849) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v851"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v852"" select=""ScriptNS1:DBLookup(7 , string($var:v850) , string($var:v851) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v853"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v854"" select=""userCSharp:GetLSFO($var:v408 , string($var:v853))"" />
                    <xsl:variable name=""var:v855"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v856"" select=""userCSharp:GetHFO($var:v411 , string($var:v855))"" />
                    <xsl:variable name=""var:v857"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v858"" select=""userCSharp:GetLSGO($var:v414 , string($var:v857))"" />
                    <xsl:variable name=""var:v859"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v860"" select=""userCSharp:GetMDO($var:v417 , string($var:v859))"" />
                    <xsl:variable name=""var:v861"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v862"" select=""userCSharp:GetMGO($var:v420 , string($var:v861))"" />
                    <xsl:variable name=""var:v863"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v864"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v865"" select=""ScriptNS1:DBValueExtract(string($var:v852) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v866"" select=""userCSharp:GetLO($var:v425 , string($var:v863))"" />
                    <xsl:variable name=""var:v867"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v864))"" />
                    <xsl:variable name=""var:v868"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v865))"" />
                    <xsl:variable name=""var:v869"" select=""$var:v862"" />
                    <xsl:variable name=""var:v870"" select=""userCSharp:LogicalEq(string($var:v869) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v871"" select=""userCSharp:LogicalAnd(string($var:v845) , string($var:v870))"" />
                    <xsl:variable name=""var:v872"" select=""../Mgo"" />
                    <xsl:if test=""string($var:v871)='true'"">
                      <xsl:variable name=""var:v873"" select=""string($var:v872)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v873"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v874"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v875"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v874) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v876"" select=""ScriptNS1:DBValueExtract(string($var:v875) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v877"" select=""ScriptNS1:DBLookup(1 , string($var:v876) , string($var:v874) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v878"" select=""ScriptNS1:DBValueExtract(string($var:v877) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v879"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v880"" select=""ScriptNS1:DBLookup(7 , string($var:v878) , string($var:v879) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v881"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v882"" select=""userCSharp:GetLSFO($var:v408 , string($var:v881))"" />
                    <xsl:variable name=""var:v883"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v884"" select=""userCSharp:GetHFO($var:v411 , string($var:v883))"" />
                    <xsl:variable name=""var:v885"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v886"" select=""userCSharp:GetLSGO($var:v414 , string($var:v885))"" />
                    <xsl:variable name=""var:v887"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v888"" select=""userCSharp:GetMDO($var:v417 , string($var:v887))"" />
                    <xsl:variable name=""var:v889"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v890"" select=""userCSharp:GetMGO($var:v420 , string($var:v889))"" />
                    <xsl:variable name=""var:v891"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v892"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v893"" select=""ScriptNS1:DBValueExtract(string($var:v880) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v894"" select=""userCSharp:GetLO($var:v425 , string($var:v891))"" />
                    <xsl:variable name=""var:v895"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v892))"" />
                    <xsl:variable name=""var:v896"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v893))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v897"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v898"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v897) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v899"" select=""ScriptNS1:DBValueExtract(string($var:v898) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v900"" select=""ScriptNS1:DBLookup(1 , string($var:v899) , string($var:v897) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v901"" select=""ScriptNS1:DBValueExtract(string($var:v900) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v902"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v903"" select=""ScriptNS1:DBLookup(7 , string($var:v901) , string($var:v902) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v904"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v905"" select=""userCSharp:GetLSFO($var:v408 , string($var:v904))"" />
                <xsl:variable name=""var:v906"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v907"" select=""userCSharp:GetHFO($var:v411 , string($var:v906))"" />
                <xsl:variable name=""var:v908"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v909"" select=""userCSharp:GetLSGO($var:v414 , string($var:v908))"" />
                <xsl:variable name=""var:v910"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v911"" select=""userCSharp:GetMDO($var:v417 , string($var:v910))"" />
                <xsl:variable name=""var:v912"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v913"" select=""userCSharp:GetMGO($var:v420 , string($var:v912))"" />
                <xsl:variable name=""var:v914"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v915"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v916"" select=""ScriptNS1:DBValueExtract(string($var:v903) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v917"" select=""userCSharp:GetLO($var:v425 , string($var:v914))"" />
                <xsl:variable name=""var:v918"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v915))"" />
                <xsl:variable name=""var:v919"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v916))"" />
                <xsl:variable name=""var:v920"" select=""$var:v909"" />
                <xsl:variable name=""var:v921"" select=""userCSharp:LogicalEq(string($var:v920) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v921"">
                  <xsl:variable name=""var:v974"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v975"" select=""userCSharp:LogicalEq($var:v974 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1004"" select=""userCSharp:LogicalEq($var:v974 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1008"" select=""userCSharp:LogicalEq($var:v974 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v922"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v923"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v922) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v924"" select=""ScriptNS1:DBValueExtract(string($var:v923) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v925"" select=""ScriptNS1:DBLookup(1 , string($var:v924) , string($var:v922) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v926"" select=""ScriptNS1:DBValueExtract(string($var:v925) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v927"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v928"" select=""ScriptNS1:DBLookup(7 , string($var:v926) , string($var:v927) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v929"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v930"" select=""userCSharp:GetLSFO($var:v408 , string($var:v929))"" />
                    <xsl:variable name=""var:v931"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v932"" select=""userCSharp:GetHFO($var:v411 , string($var:v931))"" />
                    <xsl:variable name=""var:v933"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v934"" select=""userCSharp:GetLSGO($var:v414 , string($var:v933))"" />
                    <xsl:variable name=""var:v935"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v936"" select=""userCSharp:GetMDO($var:v417 , string($var:v935))"" />
                    <xsl:variable name=""var:v937"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v938"" select=""userCSharp:GetMGO($var:v420 , string($var:v937))"" />
                    <xsl:variable name=""var:v939"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v940"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v941"" select=""ScriptNS1:DBValueExtract(string($var:v928) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v942"" select=""userCSharp:GetLO($var:v425 , string($var:v939))"" />
                    <xsl:variable name=""var:v943"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v940))"" />
                    <xsl:variable name=""var:v944"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v941))"" />
                    <xsl:variable name=""var:v945"" select=""$var:v934"" />
                    <xsl:variable name=""var:v946"" select=""userCSharp:LogicalEq(string($var:v945) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v947"" select=""$var:v933"" />
                    <xsl:if test=""string($var:v946)='true'"">
                      <xsl:variable name=""var:v948"" select=""string($var:v947)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v948"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v949"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v950"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v949) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v951"" select=""ScriptNS1:DBValueExtract(string($var:v950) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v952"" select=""ScriptNS1:DBLookup(1 , string($var:v951) , string($var:v949) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v953"" select=""ScriptNS1:DBValueExtract(string($var:v952) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v954"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v955"" select=""ScriptNS1:DBLookup(7 , string($var:v953) , string($var:v954) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v956"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v957"" select=""userCSharp:GetLSFO($var:v408 , string($var:v956))"" />
                    <xsl:variable name=""var:v958"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v959"" select=""userCSharp:GetHFO($var:v411 , string($var:v958))"" />
                    <xsl:variable name=""var:v960"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v961"" select=""userCSharp:GetLSGO($var:v414 , string($var:v960))"" />
                    <xsl:variable name=""var:v962"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v963"" select=""userCSharp:GetMDO($var:v417 , string($var:v962))"" />
                    <xsl:variable name=""var:v964"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v965"" select=""userCSharp:GetMGO($var:v420 , string($var:v964))"" />
                    <xsl:variable name=""var:v966"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v967"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v968"" select=""ScriptNS1:DBValueExtract(string($var:v955) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v969"" select=""userCSharp:GetLO($var:v425 , string($var:v966))"" />
                    <xsl:variable name=""var:v970"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v967))"" />
                    <xsl:variable name=""var:v971"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v968))"" />
                    <xsl:variable name=""var:v972"" select=""$var:v961"" />
                    <xsl:variable name=""var:v973"" select=""userCSharp:LogicalEq(string($var:v972) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v976"" select=""userCSharp:LogicalAnd(string($var:v973) , string($var:v975))"" />
                    <xsl:variable name=""var:v977"" select=""../Lsgo"" />
                    <xsl:if test=""string($var:v976)='true'"">
                      <xsl:variable name=""var:v978"" select=""string($var:v977)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v978"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v979"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v980"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v979) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v981"" select=""ScriptNS1:DBValueExtract(string($var:v980) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v982"" select=""ScriptNS1:DBLookup(1 , string($var:v981) , string($var:v979) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v983"" select=""ScriptNS1:DBValueExtract(string($var:v982) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v984"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v985"" select=""ScriptNS1:DBLookup(7 , string($var:v983) , string($var:v984) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v986"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v987"" select=""userCSharp:GetLSFO($var:v408 , string($var:v986))"" />
                    <xsl:variable name=""var:v988"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v989"" select=""userCSharp:GetHFO($var:v411 , string($var:v988))"" />
                    <xsl:variable name=""var:v990"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v991"" select=""userCSharp:GetLSGO($var:v414 , string($var:v990))"" />
                    <xsl:variable name=""var:v992"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v993"" select=""userCSharp:GetMDO($var:v417 , string($var:v992))"" />
                    <xsl:variable name=""var:v994"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v995"" select=""userCSharp:GetMGO($var:v420 , string($var:v994))"" />
                    <xsl:variable name=""var:v996"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v997"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v998"" select=""ScriptNS1:DBValueExtract(string($var:v985) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v999"" select=""userCSharp:GetLO($var:v425 , string($var:v996))"" />
                    <xsl:variable name=""var:v1000"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v997))"" />
                    <xsl:variable name=""var:v1001"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v998))"" />
                    <xsl:variable name=""var:v1002"" select=""$var:v991"" />
                    <xsl:variable name=""var:v1003"" select=""userCSharp:LogicalEq(string($var:v1002) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1005"" select=""userCSharp:LogicalAnd(string($var:v1003) , string($var:v1004))"" />
                    <xsl:variable name=""var:v1006"" select=""../Lsgo"" />
                    <xsl:if test=""string($var:v1005)='true'"">
                      <xsl:variable name=""var:v1007"" select=""string($var:v1006)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1007"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1009"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1010"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1009) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1011"" select=""ScriptNS1:DBValueExtract(string($var:v1010) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1012"" select=""ScriptNS1:DBLookup(1 , string($var:v1011) , string($var:v1009) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1013"" select=""ScriptNS1:DBValueExtract(string($var:v1012) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1014"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1015"" select=""ScriptNS1:DBLookup(7 , string($var:v1013) , string($var:v1014) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1016"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1017"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1016))"" />
                    <xsl:variable name=""var:v1018"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1019"" select=""userCSharp:GetHFO($var:v411 , string($var:v1018))"" />
                    <xsl:variable name=""var:v1020"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1021"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1020))"" />
                    <xsl:variable name=""var:v1022"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1023"" select=""userCSharp:GetMDO($var:v417 , string($var:v1022))"" />
                    <xsl:variable name=""var:v1024"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1025"" select=""userCSharp:GetMGO($var:v420 , string($var:v1024))"" />
                    <xsl:variable name=""var:v1026"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1027"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1028"" select=""ScriptNS1:DBValueExtract(string($var:v1015) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1029"" select=""userCSharp:GetLO($var:v425 , string($var:v1026))"" />
                    <xsl:variable name=""var:v1030"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1027))"" />
                    <xsl:variable name=""var:v1031"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1028))"" />
                    <xsl:variable name=""var:v1032"" select=""$var:v1021"" />
                    <xsl:variable name=""var:v1033"" select=""userCSharp:LogicalEq(string($var:v1032) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1034"" select=""userCSharp:LogicalAnd(string($var:v1008) , string($var:v1033))"" />
                    <xsl:variable name=""var:v1035"" select=""../Lsgo"" />
                    <xsl:if test=""string($var:v1034)='true'"">
                      <xsl:variable name=""var:v1036"" select=""string($var:v1035)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1036"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1037"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1038"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1037) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1039"" select=""ScriptNS1:DBValueExtract(string($var:v1038) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1040"" select=""ScriptNS1:DBLookup(1 , string($var:v1039) , string($var:v1037) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1041"" select=""ScriptNS1:DBValueExtract(string($var:v1040) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1042"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1043"" select=""ScriptNS1:DBLookup(7 , string($var:v1041) , string($var:v1042) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1044"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1045"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1044))"" />
                    <xsl:variable name=""var:v1046"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1047"" select=""userCSharp:GetHFO($var:v411 , string($var:v1046))"" />
                    <xsl:variable name=""var:v1048"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1049"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1048))"" />
                    <xsl:variable name=""var:v1050"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1051"" select=""userCSharp:GetMDO($var:v417 , string($var:v1050))"" />
                    <xsl:variable name=""var:v1052"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1053"" select=""userCSharp:GetMGO($var:v420 , string($var:v1052))"" />
                    <xsl:variable name=""var:v1054"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1055"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1056"" select=""ScriptNS1:DBValueExtract(string($var:v1043) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1057"" select=""userCSharp:GetLO($var:v425 , string($var:v1054))"" />
                    <xsl:variable name=""var:v1058"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1055))"" />
                    <xsl:variable name=""var:v1059"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1056))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1060"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1061"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1060) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1062"" select=""ScriptNS1:DBValueExtract(string($var:v1061) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1063"" select=""ScriptNS1:DBLookup(1 , string($var:v1062) , string($var:v1060) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1064"" select=""ScriptNS1:DBValueExtract(string($var:v1063) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1065"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1066"" select=""ScriptNS1:DBLookup(7 , string($var:v1064) , string($var:v1065) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1067"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1068"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1067))"" />
                <xsl:variable name=""var:v1069"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1070"" select=""userCSharp:GetHFO($var:v411 , string($var:v1069))"" />
                <xsl:variable name=""var:v1071"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1072"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1071))"" />
                <xsl:variable name=""var:v1073"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1074"" select=""userCSharp:GetMDO($var:v417 , string($var:v1073))"" />
                <xsl:variable name=""var:v1075"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1076"" select=""userCSharp:GetMGO($var:v420 , string($var:v1075))"" />
                <xsl:variable name=""var:v1077"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1078"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1079"" select=""ScriptNS1:DBValueExtract(string($var:v1066) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1080"" select=""userCSharp:GetLO($var:v425 , string($var:v1077))"" />
                <xsl:variable name=""var:v1081"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1078))"" />
                <xsl:variable name=""var:v1082"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1079))"" />
                <xsl:variable name=""var:v1083"" select=""$var:v1080"" />
                <xsl:variable name=""var:v1084"" select=""userCSharp:LogicalEq(string($var:v1083) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1084"">
                  <xsl:variable name=""var:v1137"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1138"" select=""userCSharp:LogicalEq($var:v1137 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1167"" select=""userCSharp:LogicalEq($var:v1137 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1171"" select=""userCSharp:LogicalEq($var:v1137 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1085"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1086"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1085) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1087"" select=""ScriptNS1:DBValueExtract(string($var:v1086) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1088"" select=""ScriptNS1:DBLookup(1 , string($var:v1087) , string($var:v1085) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1089"" select=""ScriptNS1:DBValueExtract(string($var:v1088) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1090"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1091"" select=""ScriptNS1:DBLookup(7 , string($var:v1089) , string($var:v1090) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1092"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1093"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1092))"" />
                    <xsl:variable name=""var:v1094"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1095"" select=""userCSharp:GetHFO($var:v411 , string($var:v1094))"" />
                    <xsl:variable name=""var:v1096"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1097"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1096))"" />
                    <xsl:variable name=""var:v1098"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1099"" select=""userCSharp:GetMDO($var:v417 , string($var:v1098))"" />
                    <xsl:variable name=""var:v1100"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1101"" select=""userCSharp:GetMGO($var:v420 , string($var:v1100))"" />
                    <xsl:variable name=""var:v1102"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1103"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1104"" select=""ScriptNS1:DBValueExtract(string($var:v1091) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1105"" select=""userCSharp:GetLO($var:v425 , string($var:v1102))"" />
                    <xsl:variable name=""var:v1106"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1103))"" />
                    <xsl:variable name=""var:v1107"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1104))"" />
                    <xsl:variable name=""var:v1108"" select=""$var:v1105"" />
                    <xsl:variable name=""var:v1109"" select=""userCSharp:LogicalEq(string($var:v1108) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1110"" select=""$var:v1102"" />
                    <xsl:if test=""string($var:v1109)='true'"">
                      <xsl:variable name=""var:v1111"" select=""string($var:v1110)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1111"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1112"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1113"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1112) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1114"" select=""ScriptNS1:DBValueExtract(string($var:v1113) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1115"" select=""ScriptNS1:DBLookup(1 , string($var:v1114) , string($var:v1112) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1116"" select=""ScriptNS1:DBValueExtract(string($var:v1115) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1117"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1118"" select=""ScriptNS1:DBLookup(7 , string($var:v1116) , string($var:v1117) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1119"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1120"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1119))"" />
                    <xsl:variable name=""var:v1121"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1122"" select=""userCSharp:GetHFO($var:v411 , string($var:v1121))"" />
                    <xsl:variable name=""var:v1123"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1124"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1123))"" />
                    <xsl:variable name=""var:v1125"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1126"" select=""userCSharp:GetMDO($var:v417 , string($var:v1125))"" />
                    <xsl:variable name=""var:v1127"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1128"" select=""userCSharp:GetMGO($var:v420 , string($var:v1127))"" />
                    <xsl:variable name=""var:v1129"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1130"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1131"" select=""ScriptNS1:DBValueExtract(string($var:v1118) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1132"" select=""userCSharp:GetLO($var:v425 , string($var:v1129))"" />
                    <xsl:variable name=""var:v1133"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1130))"" />
                    <xsl:variable name=""var:v1134"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1131))"" />
                    <xsl:variable name=""var:v1135"" select=""$var:v1132"" />
                    <xsl:variable name=""var:v1136"" select=""userCSharp:LogicalEq(string($var:v1135) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1139"" select=""userCSharp:LogicalAnd(string($var:v1136) , string($var:v1138))"" />
                    <xsl:variable name=""var:v1140"" select=""../Lo"" />
                    <xsl:if test=""string($var:v1139)='true'"">
                      <xsl:variable name=""var:v1141"" select=""string($var:v1140)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1141"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1142"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1143"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1142) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1144"" select=""ScriptNS1:DBValueExtract(string($var:v1143) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1145"" select=""ScriptNS1:DBLookup(1 , string($var:v1144) , string($var:v1142) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1146"" select=""ScriptNS1:DBValueExtract(string($var:v1145) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1147"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1148"" select=""ScriptNS1:DBLookup(7 , string($var:v1146) , string($var:v1147) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1149"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1150"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1149))"" />
                    <xsl:variable name=""var:v1151"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1152"" select=""userCSharp:GetHFO($var:v411 , string($var:v1151))"" />
                    <xsl:variable name=""var:v1153"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1154"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1153))"" />
                    <xsl:variable name=""var:v1155"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1156"" select=""userCSharp:GetMDO($var:v417 , string($var:v1155))"" />
                    <xsl:variable name=""var:v1157"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1158"" select=""userCSharp:GetMGO($var:v420 , string($var:v1157))"" />
                    <xsl:variable name=""var:v1159"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1160"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1161"" select=""ScriptNS1:DBValueExtract(string($var:v1148) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1162"" select=""userCSharp:GetLO($var:v425 , string($var:v1159))"" />
                    <xsl:variable name=""var:v1163"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1160))"" />
                    <xsl:variable name=""var:v1164"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1161))"" />
                    <xsl:variable name=""var:v1165"" select=""$var:v1162"" />
                    <xsl:variable name=""var:v1166"" select=""userCSharp:LogicalEq(string($var:v1165) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1168"" select=""userCSharp:LogicalAnd(string($var:v1166) , string($var:v1167))"" />
                    <xsl:variable name=""var:v1169"" select=""../Lo"" />
                    <xsl:if test=""string($var:v1168)='true'"">
                      <xsl:variable name=""var:v1170"" select=""string($var:v1169)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1170"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1172"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1173"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1172) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1174"" select=""ScriptNS1:DBValueExtract(string($var:v1173) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1175"" select=""ScriptNS1:DBLookup(1 , string($var:v1174) , string($var:v1172) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1176"" select=""ScriptNS1:DBValueExtract(string($var:v1175) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1177"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1178"" select=""ScriptNS1:DBLookup(7 , string($var:v1176) , string($var:v1177) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1179"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1180"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1179))"" />
                    <xsl:variable name=""var:v1181"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1182"" select=""userCSharp:GetHFO($var:v411 , string($var:v1181))"" />
                    <xsl:variable name=""var:v1183"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1184"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1183))"" />
                    <xsl:variable name=""var:v1185"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1186"" select=""userCSharp:GetMDO($var:v417 , string($var:v1185))"" />
                    <xsl:variable name=""var:v1187"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1188"" select=""userCSharp:GetMGO($var:v420 , string($var:v1187))"" />
                    <xsl:variable name=""var:v1189"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1190"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1191"" select=""ScriptNS1:DBValueExtract(string($var:v1178) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1192"" select=""userCSharp:GetLO($var:v425 , string($var:v1189))"" />
                    <xsl:variable name=""var:v1193"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1190))"" />
                    <xsl:variable name=""var:v1194"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1191))"" />
                    <xsl:variable name=""var:v1195"" select=""$var:v1192"" />
                    <xsl:variable name=""var:v1196"" select=""userCSharp:LogicalEq(string($var:v1195) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1197"" select=""userCSharp:LogicalAnd(string($var:v1171) , string($var:v1196))"" />
                    <xsl:variable name=""var:v1198"" select=""../Lo"" />
                    <xsl:if test=""string($var:v1197)='true'"">
                      <xsl:variable name=""var:v1199"" select=""string($var:v1198)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1199"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1200"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1201"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1200) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1202"" select=""ScriptNS1:DBValueExtract(string($var:v1201) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1203"" select=""ScriptNS1:DBLookup(1 , string($var:v1202) , string($var:v1200) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1204"" select=""ScriptNS1:DBValueExtract(string($var:v1203) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1205"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1206"" select=""ScriptNS1:DBLookup(7 , string($var:v1204) , string($var:v1205) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1207"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1208"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1207))"" />
                    <xsl:variable name=""var:v1209"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1210"" select=""userCSharp:GetHFO($var:v411 , string($var:v1209))"" />
                    <xsl:variable name=""var:v1211"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1212"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1211))"" />
                    <xsl:variable name=""var:v1213"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1214"" select=""userCSharp:GetMDO($var:v417 , string($var:v1213))"" />
                    <xsl:variable name=""var:v1215"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1216"" select=""userCSharp:GetMGO($var:v420 , string($var:v1215))"" />
                    <xsl:variable name=""var:v1217"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1218"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1219"" select=""ScriptNS1:DBValueExtract(string($var:v1206) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1220"" select=""userCSharp:GetLO($var:v425 , string($var:v1217))"" />
                    <xsl:variable name=""var:v1221"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1218))"" />
                    <xsl:variable name=""var:v1222"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1219))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1223"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1224"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1223) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1225"" select=""ScriptNS1:DBValueExtract(string($var:v1224) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1226"" select=""ScriptNS1:DBLookup(1 , string($var:v1225) , string($var:v1223) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1227"" select=""ScriptNS1:DBValueExtract(string($var:v1226) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1228"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1229"" select=""ScriptNS1:DBLookup(7 , string($var:v1227) , string($var:v1228) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1230"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1231"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1230))"" />
                <xsl:variable name=""var:v1232"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1233"" select=""userCSharp:GetHFO($var:v411 , string($var:v1232))"" />
                <xsl:variable name=""var:v1234"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1235"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1234))"" />
                <xsl:variable name=""var:v1236"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1237"" select=""userCSharp:GetMDO($var:v417 , string($var:v1236))"" />
                <xsl:variable name=""var:v1238"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1239"" select=""userCSharp:GetMGO($var:v420 , string($var:v1238))"" />
                <xsl:variable name=""var:v1240"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1241"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1242"" select=""ScriptNS1:DBValueExtract(string($var:v1229) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1243"" select=""userCSharp:GetLO($var:v425 , string($var:v1240))"" />
                <xsl:variable name=""var:v1244"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1241))"" />
                <xsl:variable name=""var:v1245"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1242))"" />
                <xsl:variable name=""var:v1246"" select=""$var:v1244"" />
                <xsl:variable name=""var:v1247"" select=""userCSharp:LogicalEq(string($var:v1246) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1247"">
                  <xsl:variable name=""var:v1300"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1301"" select=""userCSharp:LogicalEq($var:v1300 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1330"" select=""userCSharp:LogicalEq($var:v1300 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1334"" select=""userCSharp:LogicalEq($var:v1300 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1248"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1249"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1248) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1250"" select=""ScriptNS1:DBValueExtract(string($var:v1249) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1251"" select=""ScriptNS1:DBLookup(1 , string($var:v1250) , string($var:v1248) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1252"" select=""ScriptNS1:DBValueExtract(string($var:v1251) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1253"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1254"" select=""ScriptNS1:DBLookup(7 , string($var:v1252) , string($var:v1253) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1255"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1256"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1255))"" />
                    <xsl:variable name=""var:v1257"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1258"" select=""userCSharp:GetHFO($var:v411 , string($var:v1257))"" />
                    <xsl:variable name=""var:v1259"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1260"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1259))"" />
                    <xsl:variable name=""var:v1261"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1262"" select=""userCSharp:GetMDO($var:v417 , string($var:v1261))"" />
                    <xsl:variable name=""var:v1263"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1264"" select=""userCSharp:GetMGO($var:v420 , string($var:v1263))"" />
                    <xsl:variable name=""var:v1265"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1266"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1267"" select=""ScriptNS1:DBValueExtract(string($var:v1254) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1268"" select=""userCSharp:GetLO($var:v425 , string($var:v1265))"" />
                    <xsl:variable name=""var:v1269"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1266))"" />
                    <xsl:variable name=""var:v1270"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1267))"" />
                    <xsl:variable name=""var:v1271"" select=""$var:v1269"" />
                    <xsl:variable name=""var:v1272"" select=""userCSharp:LogicalEq(string($var:v1271) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1273"" select=""$var:v1266"" />
                    <xsl:if test=""string($var:v1272)='true'"">
                      <xsl:variable name=""var:v1274"" select=""string($var:v1273)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1274"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1275"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1276"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1275) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1277"" select=""ScriptNS1:DBValueExtract(string($var:v1276) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1278"" select=""ScriptNS1:DBLookup(1 , string($var:v1277) , string($var:v1275) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1279"" select=""ScriptNS1:DBValueExtract(string($var:v1278) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1280"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1281"" select=""ScriptNS1:DBLookup(7 , string($var:v1279) , string($var:v1280) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1282"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1283"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1282))"" />
                    <xsl:variable name=""var:v1284"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1285"" select=""userCSharp:GetHFO($var:v411 , string($var:v1284))"" />
                    <xsl:variable name=""var:v1286"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1287"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1286))"" />
                    <xsl:variable name=""var:v1288"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1289"" select=""userCSharp:GetMDO($var:v417 , string($var:v1288))"" />
                    <xsl:variable name=""var:v1290"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1291"" select=""userCSharp:GetMGO($var:v420 , string($var:v1290))"" />
                    <xsl:variable name=""var:v1292"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1293"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1294"" select=""ScriptNS1:DBValueExtract(string($var:v1281) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1295"" select=""userCSharp:GetLO($var:v425 , string($var:v1292))"" />
                    <xsl:variable name=""var:v1296"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1293))"" />
                    <xsl:variable name=""var:v1297"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1294))"" />
                    <xsl:variable name=""var:v1298"" select=""$var:v1296"" />
                    <xsl:variable name=""var:v1299"" select=""userCSharp:LogicalEq(string($var:v1298) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1302"" select=""userCSharp:LogicalAnd(string($var:v1299) , string($var:v1301))"" />
                    <xsl:variable name=""var:v1303"" select=""../FwCrew"" />
                    <xsl:if test=""string($var:v1302)='true'"">
                      <xsl:variable name=""var:v1304"" select=""string($var:v1303)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1304"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1305"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1306"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1305) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1307"" select=""ScriptNS1:DBValueExtract(string($var:v1306) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1308"" select=""ScriptNS1:DBLookup(1 , string($var:v1307) , string($var:v1305) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1309"" select=""ScriptNS1:DBValueExtract(string($var:v1308) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1310"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1311"" select=""ScriptNS1:DBLookup(7 , string($var:v1309) , string($var:v1310) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1312"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1313"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1312))"" />
                    <xsl:variable name=""var:v1314"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1315"" select=""userCSharp:GetHFO($var:v411 , string($var:v1314))"" />
                    <xsl:variable name=""var:v1316"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1317"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1316))"" />
                    <xsl:variable name=""var:v1318"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1319"" select=""userCSharp:GetMDO($var:v417 , string($var:v1318))"" />
                    <xsl:variable name=""var:v1320"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1321"" select=""userCSharp:GetMGO($var:v420 , string($var:v1320))"" />
                    <xsl:variable name=""var:v1322"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1323"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1324"" select=""ScriptNS1:DBValueExtract(string($var:v1311) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1325"" select=""userCSharp:GetLO($var:v425 , string($var:v1322))"" />
                    <xsl:variable name=""var:v1326"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1323))"" />
                    <xsl:variable name=""var:v1327"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1324))"" />
                    <xsl:variable name=""var:v1328"" select=""$var:v1326"" />
                    <xsl:variable name=""var:v1329"" select=""userCSharp:LogicalEq(string($var:v1328) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1331"" select=""userCSharp:LogicalAnd(string($var:v1329) , string($var:v1330))"" />
                    <xsl:variable name=""var:v1332"" select=""../FwCrew"" />
                    <xsl:if test=""string($var:v1331)='true'"">
                      <xsl:variable name=""var:v1333"" select=""string($var:v1332)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1333"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1335"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1336"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1335) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1337"" select=""ScriptNS1:DBValueExtract(string($var:v1336) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1338"" select=""ScriptNS1:DBLookup(1 , string($var:v1337) , string($var:v1335) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1339"" select=""ScriptNS1:DBValueExtract(string($var:v1338) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1340"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1341"" select=""ScriptNS1:DBLookup(7 , string($var:v1339) , string($var:v1340) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1342"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1343"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1342))"" />
                    <xsl:variable name=""var:v1344"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1345"" select=""userCSharp:GetHFO($var:v411 , string($var:v1344))"" />
                    <xsl:variable name=""var:v1346"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1347"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1346))"" />
                    <xsl:variable name=""var:v1348"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1349"" select=""userCSharp:GetMDO($var:v417 , string($var:v1348))"" />
                    <xsl:variable name=""var:v1350"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1351"" select=""userCSharp:GetMGO($var:v420 , string($var:v1350))"" />
                    <xsl:variable name=""var:v1352"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1353"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1354"" select=""ScriptNS1:DBValueExtract(string($var:v1341) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1355"" select=""userCSharp:GetLO($var:v425 , string($var:v1352))"" />
                    <xsl:variable name=""var:v1356"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1353))"" />
                    <xsl:variable name=""var:v1357"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1354))"" />
                    <xsl:variable name=""var:v1358"" select=""$var:v1356"" />
                    <xsl:variable name=""var:v1359"" select=""userCSharp:LogicalEq(string($var:v1358) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1360"" select=""userCSharp:LogicalAnd(string($var:v1334) , string($var:v1359))"" />
                    <xsl:variable name=""var:v1361"" select=""../FwCrew"" />
                    <xsl:if test=""string($var:v1360)='true'"">
                      <xsl:variable name=""var:v1362"" select=""string($var:v1361)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1362"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1363"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1364"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1363) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1365"" select=""ScriptNS1:DBValueExtract(string($var:v1364) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1366"" select=""ScriptNS1:DBLookup(1 , string($var:v1365) , string($var:v1363) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1367"" select=""ScriptNS1:DBValueExtract(string($var:v1366) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1368"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1369"" select=""ScriptNS1:DBLookup(7 , string($var:v1367) , string($var:v1368) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1370"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1371"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1370))"" />
                    <xsl:variable name=""var:v1372"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1373"" select=""userCSharp:GetHFO($var:v411 , string($var:v1372))"" />
                    <xsl:variable name=""var:v1374"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1375"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1374))"" />
                    <xsl:variable name=""var:v1376"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1377"" select=""userCSharp:GetMDO($var:v417 , string($var:v1376))"" />
                    <xsl:variable name=""var:v1378"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1379"" select=""userCSharp:GetMGO($var:v420 , string($var:v1378))"" />
                    <xsl:variable name=""var:v1380"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1381"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1382"" select=""ScriptNS1:DBValueExtract(string($var:v1369) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1383"" select=""userCSharp:GetLO($var:v425 , string($var:v1380))"" />
                    <xsl:variable name=""var:v1384"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1381))"" />
                    <xsl:variable name=""var:v1385"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1382))"" />
                  </Bunker>
                </xsl:if>
                <xsl:variable name=""var:v1386"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                <xsl:variable name=""var:v1387"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1386) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                <xsl:variable name=""var:v1388"" select=""ScriptNS1:DBValueExtract(string($var:v1387) , &quot;Id&quot;)"" />
                <xsl:variable name=""var:v1389"" select=""ScriptNS1:DBLookup(1 , string($var:v1388) , string($var:v1386) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                <xsl:variable name=""var:v1390"" select=""ScriptNS1:DBValueExtract(string($var:v1389) , &quot;HubPrincipalKey&quot;)"" />
                <xsl:variable name=""var:v1391"" select=""ScriptNS0:GetBizConnectionString()"" />
                <xsl:variable name=""var:v1392"" select=""ScriptNS1:DBLookup(7 , string($var:v1390) , string($var:v1391) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                <xsl:variable name=""var:v1393"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;LSFO&quot;)"" />
                <xsl:variable name=""var:v1394"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1393))"" />
                <xsl:variable name=""var:v1395"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;HFO&quot;)"" />
                <xsl:variable name=""var:v1396"" select=""userCSharp:GetHFO($var:v411 , string($var:v1395))"" />
                <xsl:variable name=""var:v1397"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;LSGO&quot;)"" />
                <xsl:variable name=""var:v1398"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1397))"" />
                <xsl:variable name=""var:v1399"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;DO&quot;)"" />
                <xsl:variable name=""var:v1400"" select=""userCSharp:GetMDO($var:v417 , string($var:v1399))"" />
                <xsl:variable name=""var:v1401"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;GO&quot;)"" />
                <xsl:variable name=""var:v1402"" select=""userCSharp:GetMGO($var:v420 , string($var:v1401))"" />
                <xsl:variable name=""var:v1403"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;LO&quot;)"" />
                <xsl:variable name=""var:v1404"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;FwCrew&quot;)"" />
                <xsl:variable name=""var:v1405"" select=""ScriptNS1:DBValueExtract(string($var:v1392) , &quot;FwShip&quot;)"" />
                <xsl:variable name=""var:v1406"" select=""userCSharp:GetLO($var:v425 , string($var:v1403))"" />
                <xsl:variable name=""var:v1407"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1404))"" />
                <xsl:variable name=""var:v1408"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1405))"" />
                <xsl:variable name=""var:v1409"" select=""$var:v1408"" />
                <xsl:variable name=""var:v1410"" select=""userCSharp:LogicalEq(string($var:v1409) , &quot;1&quot;)"" />
                <xsl:if test=""$var:v1410"">
                  <xsl:variable name=""var:v1463"" select=""string(../Name/text())"" />
                  <xsl:variable name=""var:v1464"" select=""userCSharp:LogicalEq($var:v1463 , &quot;Arrival&quot;)"" />
                  <xsl:variable name=""var:v1493"" select=""userCSharp:LogicalEq($var:v1463 , &quot;Rotation&quot;)"" />
                  <xsl:variable name=""var:v1497"" select=""userCSharp:LogicalEq($var:v1463 , &quot;Departure&quot;)"" />
                  <Bunker>
                    <xsl:variable name=""var:v1411"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1412"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1411) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1413"" select=""ScriptNS1:DBValueExtract(string($var:v1412) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1414"" select=""ScriptNS1:DBLookup(1 , string($var:v1413) , string($var:v1411) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1415"" select=""ScriptNS1:DBValueExtract(string($var:v1414) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1416"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1417"" select=""ScriptNS1:DBLookup(7 , string($var:v1415) , string($var:v1416) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1418"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1419"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1418))"" />
                    <xsl:variable name=""var:v1420"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1421"" select=""userCSharp:GetHFO($var:v411 , string($var:v1420))"" />
                    <xsl:variable name=""var:v1422"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1423"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1422))"" />
                    <xsl:variable name=""var:v1424"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1425"" select=""userCSharp:GetMDO($var:v417 , string($var:v1424))"" />
                    <xsl:variable name=""var:v1426"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1427"" select=""userCSharp:GetMGO($var:v420 , string($var:v1426))"" />
                    <xsl:variable name=""var:v1428"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1429"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1430"" select=""ScriptNS1:DBValueExtract(string($var:v1417) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1431"" select=""userCSharp:GetLO($var:v425 , string($var:v1428))"" />
                    <xsl:variable name=""var:v1432"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1429))"" />
                    <xsl:variable name=""var:v1433"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1430))"" />
                    <xsl:variable name=""var:v1434"" select=""$var:v1433"" />
                    <xsl:variable name=""var:v1435"" select=""userCSharp:LogicalEq(string($var:v1434) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1436"" select=""$var:v1430"" />
                    <xsl:if test=""string($var:v1435)='true'"">
                      <xsl:variable name=""var:v1437"" select=""string($var:v1436)"" />
                      <Grade>
                        <xsl:value-of select=""$var:v1437"" />
                      </Grade>
                    </xsl:if>
                    <xsl:variable name=""var:v1438"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1439"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1438) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1440"" select=""ScriptNS1:DBValueExtract(string($var:v1439) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1441"" select=""ScriptNS1:DBLookup(1 , string($var:v1440) , string($var:v1438) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1442"" select=""ScriptNS1:DBValueExtract(string($var:v1441) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1443"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1444"" select=""ScriptNS1:DBLookup(7 , string($var:v1442) , string($var:v1443) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1445"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1446"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1445))"" />
                    <xsl:variable name=""var:v1447"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1448"" select=""userCSharp:GetHFO($var:v411 , string($var:v1447))"" />
                    <xsl:variable name=""var:v1449"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1450"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1449))"" />
                    <xsl:variable name=""var:v1451"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1452"" select=""userCSharp:GetMDO($var:v417 , string($var:v1451))"" />
                    <xsl:variable name=""var:v1453"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1454"" select=""userCSharp:GetMGO($var:v420 , string($var:v1453))"" />
                    <xsl:variable name=""var:v1455"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1456"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1457"" select=""ScriptNS1:DBValueExtract(string($var:v1444) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1458"" select=""userCSharp:GetLO($var:v425 , string($var:v1455))"" />
                    <xsl:variable name=""var:v1459"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1456))"" />
                    <xsl:variable name=""var:v1460"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1457))"" />
                    <xsl:variable name=""var:v1461"" select=""$var:v1460"" />
                    <xsl:variable name=""var:v1462"" select=""userCSharp:LogicalEq(string($var:v1461) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1465"" select=""userCSharp:LogicalAnd(string($var:v1462) , string($var:v1464))"" />
                    <xsl:variable name=""var:v1466"" select=""../FwShip"" />
                    <xsl:if test=""string($var:v1465)='true'"">
                      <xsl:variable name=""var:v1467"" select=""string($var:v1466)"" />
                      <ArrQuantity>
                        <xsl:value-of select=""$var:v1467"" />
                      </ArrQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1468"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1469"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1468) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1470"" select=""ScriptNS1:DBValueExtract(string($var:v1469) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1471"" select=""ScriptNS1:DBLookup(1 , string($var:v1470) , string($var:v1468) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1472"" select=""ScriptNS1:DBValueExtract(string($var:v1471) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1473"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1474"" select=""ScriptNS1:DBLookup(7 , string($var:v1472) , string($var:v1473) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1475"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1476"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1475))"" />
                    <xsl:variable name=""var:v1477"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1478"" select=""userCSharp:GetHFO($var:v411 , string($var:v1477))"" />
                    <xsl:variable name=""var:v1479"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1480"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1479))"" />
                    <xsl:variable name=""var:v1481"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1482"" select=""userCSharp:GetMDO($var:v417 , string($var:v1481))"" />
                    <xsl:variable name=""var:v1483"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1484"" select=""userCSharp:GetMGO($var:v420 , string($var:v1483))"" />
                    <xsl:variable name=""var:v1485"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1486"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1487"" select=""ScriptNS1:DBValueExtract(string($var:v1474) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1488"" select=""userCSharp:GetLO($var:v425 , string($var:v1485))"" />
                    <xsl:variable name=""var:v1489"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1486))"" />
                    <xsl:variable name=""var:v1490"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1487))"" />
                    <xsl:variable name=""var:v1491"" select=""$var:v1490"" />
                    <xsl:variable name=""var:v1492"" select=""userCSharp:LogicalEq(string($var:v1491) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1494"" select=""userCSharp:LogicalAnd(string($var:v1492) , string($var:v1493))"" />
                    <xsl:variable name=""var:v1495"" select=""../FwShip"" />
                    <xsl:if test=""string($var:v1494)='true'"">
                      <xsl:variable name=""var:v1496"" select=""string($var:v1495)"" />
                      <TakenQuantity>
                        <xsl:value-of select=""$var:v1496"" />
                      </TakenQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1498"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1499"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1498) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1500"" select=""ScriptNS1:DBValueExtract(string($var:v1499) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1501"" select=""ScriptNS1:DBLookup(1 , string($var:v1500) , string($var:v1498) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1502"" select=""ScriptNS1:DBValueExtract(string($var:v1501) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1503"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1504"" select=""ScriptNS1:DBLookup(7 , string($var:v1502) , string($var:v1503) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1505"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1506"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1505))"" />
                    <xsl:variable name=""var:v1507"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1508"" select=""userCSharp:GetHFO($var:v411 , string($var:v1507))"" />
                    <xsl:variable name=""var:v1509"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1510"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1509))"" />
                    <xsl:variable name=""var:v1511"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1512"" select=""userCSharp:GetMDO($var:v417 , string($var:v1511))"" />
                    <xsl:variable name=""var:v1513"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1514"" select=""userCSharp:GetMGO($var:v420 , string($var:v1513))"" />
                    <xsl:variable name=""var:v1515"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1516"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1517"" select=""ScriptNS1:DBValueExtract(string($var:v1504) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1518"" select=""userCSharp:GetLO($var:v425 , string($var:v1515))"" />
                    <xsl:variable name=""var:v1519"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1516))"" />
                    <xsl:variable name=""var:v1520"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1517))"" />
                    <xsl:variable name=""var:v1521"" select=""$var:v1520"" />
                    <xsl:variable name=""var:v1522"" select=""userCSharp:LogicalEq(string($var:v1521) , &quot;1&quot;)"" />
                    <xsl:variable name=""var:v1523"" select=""userCSharp:LogicalAnd(string($var:v1497) , string($var:v1522))"" />
                    <xsl:variable name=""var:v1524"" select=""../FwShip"" />
                    <xsl:if test=""string($var:v1523)='true'"">
                      <xsl:variable name=""var:v1525"" select=""string($var:v1524)"" />
                      <DepQuantity>
                        <xsl:value-of select=""$var:v1525"" />
                      </DepQuantity>
                    </xsl:if>
                    <xsl:variable name=""var:v1526"" select=""ScriptNS0:GetNYourIssConnectionString()"" />
                    <xsl:variable name=""var:v1527"" select=""ScriptNS1:DBLookup(0 , string($var:v399) , string($var:v1526) , &quot;PortCall.PortCalls&quot; , &quot;Number+'|'+ cast(IsActive as varchar(1))&quot;)"" />
                    <xsl:variable name=""var:v1528"" select=""ScriptNS1:DBValueExtract(string($var:v1527) , &quot;Id&quot;)"" />
                    <xsl:variable name=""var:v1529"" select=""ScriptNS1:DBLookup(1 , string($var:v1528) , string($var:v1526) , &quot;Appointment.HubPrincipalPortCallAppointmentMap&quot; , &quot;PortCallId&quot;)"" />
                    <xsl:variable name=""var:v1530"" select=""ScriptNS1:DBValueExtract(string($var:v1529) , &quot;HubPrincipalKey&quot;)"" />
                    <xsl:variable name=""var:v1531"" select=""ScriptNS0:GetBizConnectionString()"" />
                    <xsl:variable name=""var:v1532"" select=""ScriptNS1:DBLookup(7 , string($var:v1530) , string($var:v1531) , &quot;BunkersGridConfiguration&quot; , &quot;AccountID&quot;)"" />
                    <xsl:variable name=""var:v1533"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;LSFO&quot;)"" />
                    <xsl:variable name=""var:v1534"" select=""userCSharp:GetLSFO($var:v408 , string($var:v1533))"" />
                    <xsl:variable name=""var:v1535"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;HFO&quot;)"" />
                    <xsl:variable name=""var:v1536"" select=""userCSharp:GetHFO($var:v411 , string($var:v1535))"" />
                    <xsl:variable name=""var:v1537"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;LSGO&quot;)"" />
                    <xsl:variable name=""var:v1538"" select=""userCSharp:GetLSGO($var:v414 , string($var:v1537))"" />
                    <xsl:variable name=""var:v1539"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;DO&quot;)"" />
                    <xsl:variable name=""var:v1540"" select=""userCSharp:GetMDO($var:v417 , string($var:v1539))"" />
                    <xsl:variable name=""var:v1541"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;GO&quot;)"" />
                    <xsl:variable name=""var:v1542"" select=""userCSharp:GetMGO($var:v420 , string($var:v1541))"" />
                    <xsl:variable name=""var:v1543"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;LO&quot;)"" />
                    <xsl:variable name=""var:v1544"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;FwCrew&quot;)"" />
                    <xsl:variable name=""var:v1545"" select=""ScriptNS1:DBValueExtract(string($var:v1532) , &quot;FwShip&quot;)"" />
                    <xsl:variable name=""var:v1546"" select=""userCSharp:GetLO($var:v425 , string($var:v1543))"" />
                    <xsl:variable name=""var:v1547"" select=""userCSharp:GetFWCREW($var:v427 , string($var:v1544))"" />
                    <xsl:variable name=""var:v1548"" select=""userCSharp:GetFWSHIP($var:v429 , string($var:v1545))"" />
                  </Bunker>
                </xsl:if>
              </xsl:for-each>
            </xsl:for-each>
          </Bunkers>
        </xsl:if>
        <Statements>
          <xsl:for-each select=""OperationEvents"">
            <xsl:for-each select=""Event"">
              <xsl:variable name=""var:v1549"" select=""userCSharp:LogicalEq(string(IsSOF/text()) , &quot;True&quot;)"" />
              <xsl:if test=""$var:v1549"">
                <xsl:variable name=""var:v1550"" select=""userCSharp:LogicalNe(string(../EndDate/text()) , &quot;&quot;)"" />
                <Sof>
                  <xsl:if test=""../RefCode"">
                    <SN_KeyCargo>
                      <xsl:value-of select=""../RefCode/text()"" />
                    </SN_KeyCargo>
                  </xsl:if>
                  <xsl:if test=""Name"">
                    <SofLabel>
                      <xsl:value-of select=""Name/text()"" />
                    </SofLabel>
                  </xsl:if>
                  <xsl:if test=""../StartDate"">
                    <SofDateTime>
                      <xsl:value-of select=""../StartDate/text()"" />
                    </SofDateTime>
                  </xsl:if>
                  <xsl:if test=""string($var:v1550)='true'"">
                    <xsl:variable name=""var:v1551"" select=""../EndDate/text()"" />
                    <SofEndDate>
                      <xsl:value-of select=""$var:v1551"" />
                    </SofEndDate>
                  </xsl:if>
                  <xsl:if test=""../Comments"">
                    <SofComments>
                      <xsl:value-of select=""../Comments/text()"" />
                    </SofComments>
                  </xsl:if>
                </Sof>
              </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </Statements>
        <Events>
          <xsl:for-each select=""OperationEvents"">
            <xsl:for-each select=""Event"">
              <xsl:variable name=""var:v1552"" select=""string(IsSOF/text())"" />
              <xsl:variable name=""var:v1553"" select=""userCSharp:LogicalEq($var:v1552 , &quot;False&quot;)"" />
              <xsl:if test=""$var:v1553"">
                <Event>
                  <xsl:if test=""Name"">
                    <EventLabel>
                      <xsl:value-of select=""Name/text()"" />
                    </EventLabel>
                  </xsl:if>
                  <xsl:if test=""../StartDate"">
                    <EventDateTime>
                      <xsl:value-of select=""../StartDate/text()"" />
                    </EventDateTime>
                  </xsl:if>
                  <xsl:if test=""../Comments"">
                    <EventComments>
                      <xsl:value-of select=""../Comments/text()"" />
                    </EventComments>
                  </xsl:if>
                </Event>
              </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </Events>
      </Operational>
    </ns0:YourIssNotification>
    <xsl:variable name=""var:v1554"" select=""ScriptNS1:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string StringSubstring(string str, string left, string right)
{
	string retval = """";
	double dleft = 0;
	double dright = 0;
	if (str != null && IsNumeric(left, ref dleft) && IsNumeric(right, ref dright))
	{
		int lt = (int)dleft;
		int rt = (int)dright;
		lt--; rt--;
		if (lt >= 0 && rt >= lt && lt < str.Length)
		{
			if (rt < str.Length)
			{
				retval = str.Substring(lt, rt-lt+1);
			}
			else
			{
				retval = str.Substring(lt, str.Length-lt);
			}
		}
	}
	return retval;
}


public int StringFind(string str, string strFind)
{
	if (str == null || strFind == null || strFind == """")
	{
		return 0;
	}
	return (str.IndexOf(strFind) + 1);
}


public int StringSize(string str)
{
	if (str == null)
	{
		return 0;
	}
	return str.Length;
}


public string MathAdd(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	foreach (string obj in listValues)
	{
	double d = 0;
		if (IsNumeric(obj, ref d))
		{
			ret += d;
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string MathSubtract(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 0;
	bool first = true;
	foreach (string obj in listValues)
	{
		if (first)
		{
			first = false;
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret = d;
			}
			else
			{
				return """";
			}
		}
		else
		{
			double d = 0;
			if (IsNumeric(obj, ref d))
			{
				ret -= d;
			}
			else
			{
				return """";
			}
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public int GetCargoCount ( bool  IsActive  )
{
  
       if  (    IsActive  ==  true  ) 
           return 1;
       else return 0;
}

public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public bool LogicalGt(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 > d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) > 0;
	}
	return ret;
}


public int GetLSFO (  string  strvalue , string LSFO_Code )
{
    
     
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0  &&  LSFO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetHFO (  string  strvalue , string HFO_Code )
{
     
    
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   && HFO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetLSGO (  string  strvalue   , string LSGO_Code  )
{
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&     LSGO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetMDO (  string strvalue   , string DO_Code   )
{
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&   DO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetMGO (  string  strvalue  , string GO_Code )
{
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&  GO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetBunKetCountSum (
int LSFO,
int HFO,
int LSGO,
int MDO,
int MGO,
int LO,
int FWCREW,
int FWSHIP
)
{

     return LSFO + HFO + LSGO + MDO + MGO  + LO + FWCREW  + FWSHIP ;
}

public bool LogicalAnd(string param0, string param1)
{
	return ValToBool(param0) && ValToBool(param1);
	return false;
}


public bool LogicalNot(string val)
{
	return !ValToBool(val);
}


public int GetBLFigures ( string strBLQty )
{
        decimal BLqty = 0;
        decimal.TryParse (  strBLQty  , out  BLqty );
        
        if (   strBLQty  != """" &&  strBLQty    != null  )        
            return 1;
        else
            return 0;
}

public int GetShipFig ( string strVessalQty )
{
        decimal   VessalQty   = 0 ;
        decimal.TryParse (  strVessalQty  , out   VessalQty   );
        if  (   strVessalQty    != """"   &&    strVessalQty    != null  )
             return 1;
        else
           return 0;
}

public bool LogicalNe(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 != d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) != 0;
	}
	return ret;
}


public int GetLO (  string strvalue   , string LO_Code   )
{
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&   LO_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetFWCREW (  string strvalue   , string FWCREW_Code   )
{

            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&   FWCREW_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public int GetFWSHIP (  string strvalue   , string FWSHIP_Code   )
{
            decimal value = 0;
            Decimal.TryParse(strvalue, out value);

     if (     value !=  0   &&   FWSHIP_Code.Trim() != """"  )
              return 1;
       else
            return 0;
}

public bool IsNextEtaEmpty ( string  NextETA  )
{

    try 
{
        if  (   NextETA == null ||    NextETA == """"  )
            return false;
         else
                 return true;
  } catch (Exception exp ) { }
 return false;
} 

public string MyConcatETA(string ETANextPt)
{
try
{
string ETANextP = """";
  if  (   ETANextPt != null ||    ETANextPt != """"  )
{
	DateTime dt1 = DateTime.Parse(ETANextPt);
          ETANextP = string.Format(""{0:s}"", dt1);
}
return ETANextP;

}catch (Exception exp) { }

return """";
 
}


public string BLDate(string strBLDate )
{
try
{
string BLDate= """";
  if  (   strBLDate  != null ||    strBLDate   != """"  )
{
	DateTime dt1 = DateTime.Parse( strBLDate  );
          BLDate = string.Format(""{0:s}"", dt1);
}
return BLDate  ;
}catch(Exception exp){}

return """";
}
  

public bool IsBLDate ( string  strBLDate  )
{

   try
{
        if  (    strBLDate    == null ||   strBLDate     == """"  )
            return false;
         else
                 return true;
}catch (Exception exp) {}

return false;


} 

public string GetFlowStatus (string  strflow)
    {
        return strflow.Substring(strflow.LastIndexOf("" - "") + 2).Trim();
    }

public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool ValToBool(string val)
{
	if (val != null)
	{
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		val = val.Trim();
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		double d = 0;
		if (IsNumeric(val, ref d))
		{
			return (d > 0);
		}
	}
	return false;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Inchcape.YourISS.Integration.Generic.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=967fbbf56172f3c8"" ClassName=""Inchcape.YourISS.Integration.Generic.Common.Utilities"" />
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS1"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_YourISS_OperationUpdate_SofAndEvents";
        
        private const global::Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_YourISS_OperationUpdate_SofAndEvents _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.OperationUpdate.Schemas.Schema_YourISS_OperationUpdate_SofAndEvents";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.Generic.Schema_Generic_OperationUpdate";
                return _TrgSchemas;
            }
        }
    }
}

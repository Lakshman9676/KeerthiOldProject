namespace Inchcape.YourISS.Integration.Generic.OperationUpdate.Mappings {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate", typeof(global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate))]
    public sealed class Map_OperationUpdate_To_OperationUpdateActiveOnly : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var userCSharp"" version=""1.0"" xmlns:ns0=""http://Inchcape.YourISS.Integration.Generic.Schemas.YourISS"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/ns0:YourIss2Appointment"" />
  </xsl:template>
  <xsl:template match=""/ns0:YourIss2Appointment"">
    <ns0:YourIss2Appointment>
      <xsl:if test=""Number"">
        <Number>
          <xsl:value-of select=""Number/text()"" />
        </Number>
      </xsl:if>
      <xsl:for-each select=""Appointments"">
        <Appointments>
          <xsl:if test=""Number"">
            <Number>
              <xsl:value-of select=""Number/text()"" />
            </Number>
          </xsl:if>
          <xsl:for-each select=""Principal"">
            <Principal>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </Principal>
          </xsl:for-each>
          <xsl:for-each select=""PerformingAgent"">
            <PerformingAgent>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </PerformingAgent>
          </xsl:for-each>
          <xsl:for-each select=""MainCommodity"">
            <MainCommodity>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </MainCommodity>
          </xsl:for-each>
          <xsl:for-each select=""AgencyType"">
            <AgencyType>
              <xsl:if test=""Id"">
                <xsl:variable name=""var:v1"" select=""string(Id/@xsi:nil) = 'true'"" />
                <xsl:if test=""string($var:v1)='true'"">
                  <Id>
                    <xsl:attribute name=""xsi:nil"">
                      <xsl:value-of select=""'true'"" />
                    </xsl:attribute>
                  </Id>
                </xsl:if>
                <xsl:if test=""string($var:v1)='false'"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
              </xsl:if>
              <xsl:if test=""Name"">
                <xsl:variable name=""var:v2"" select=""string(Name/@xsi:nil) = 'true'"" />
                <xsl:if test=""string($var:v2)='true'"">
                  <Name>
                    <xsl:attribute name=""xsi:nil"">
                      <xsl:value-of select=""'true'"" />
                    </xsl:attribute>
                  </Name>
                </xsl:if>
                <xsl:if test=""string($var:v2)='false'"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </AgencyType>
          </xsl:for-each>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:for-each select=""Uri"">
            <Uri>
              <xsl:value-of select=""./text()"" />
            </Uri>
          </xsl:for-each>
          <xsl:value-of select=""./text()"" />
        </Appointments>
      </xsl:for-each>
      <xsl:if test=""Eta"">
        <Eta>
          <xsl:value-of select=""Eta/text()"" />
        </Eta>
      </xsl:if>
      <xsl:if test=""OkToSail"">
        <OkToSail>
          <xsl:value-of select=""OkToSail/text()"" />
        </OkToSail>
      </xsl:if>
      <xsl:if test=""PortCallAccepted"">
        <PortCallAccepted>
          <xsl:value-of select=""PortCallAccepted/text()"" />
        </PortCallAccepted>
      </xsl:if>
      <xsl:if test=""ControllingAgentAccepted"">
        <ControllingAgentAccepted>
          <xsl:value-of select=""ControllingAgentAccepted/text()"" />
        </ControllingAgentAccepted>
      </xsl:if>
      <xsl:if test=""IsPortOperationComplete"">
        <xsl:variable name=""var:v3"" select=""string(IsPortOperationComplete/@xsi:nil) = 'true'"" />
        <xsl:if test=""string($var:v3)='true'"">
          <IsPortOperationComplete>
            <xsl:attribute name=""xsi:nil"">
              <xsl:value-of select=""'true'"" />
            </xsl:attribute>
          </IsPortOperationComplete>
        </xsl:if>
        <xsl:if test=""string($var:v3)='false'"">
          <IsPortOperationComplete>
            <xsl:value-of select=""IsPortOperationComplete/text()"" />
          </IsPortOperationComplete>
        </xsl:if>
      </xsl:if>
      <xsl:if test=""PortOperationCompleteTime"">
        <xsl:variable name=""var:v4"" select=""string(PortOperationCompleteTime/@xsi:nil) = 'true'"" />
        <xsl:if test=""string($var:v4)='true'"">
          <PortOperationCompleteTime>
            <xsl:attribute name=""xsi:nil"">
              <xsl:value-of select=""'true'"" />
            </xsl:attribute>
          </PortOperationCompleteTime>
        </xsl:if>
        <xsl:if test=""string($var:v4)='false'"">
          <PortOperationCompleteTime>
            <xsl:value-of select=""PortOperationCompleteTime/text()"" />
          </PortOperationCompleteTime>
        </xsl:if>
      </xsl:if>
      <xsl:for-each select=""AccountingOffice"">
        <AccountingOffice>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </AccountingOffice>
      </xsl:for-each>
      <xsl:for-each select=""PortOperation"">
        <PortOperation>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </PortOperation>
      </xsl:for-each>
      <xsl:for-each select=""Port"">
        <Port>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Port>
      </xsl:for-each>
      <xsl:for-each select=""NextPort"">
        <NextPort>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </NextPort>
      </xsl:for-each>
      <xsl:for-each select=""PreviousPort"">
        <PreviousPort>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </PreviousPort>
      </xsl:for-each>
      <xsl:for-each select=""MainCommodity"">
        <MainCommodity>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Code"">
            <Code>
              <xsl:value-of select=""Code/text()"" />
            </Code>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </MainCommodity>
      </xsl:for-each>
      <xsl:for-each select=""Vessel"">
        <Vessel>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Imo"">
            <Imo>
              <xsl:value-of select=""Imo/text()"" />
            </Imo>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Vessel>
      </xsl:for-each>
      <xsl:if test=""FlowStatus"">
        <FlowStatus>
          <xsl:value-of select=""FlowStatus/text()"" />
        </FlowStatus>
      </xsl:if>
      <xsl:for-each select=""PortCallOperations"">
        <PortCallOperations>
          <xsl:if test=""Id"">
            <Id>
              <xsl:value-of select=""Id/text()"" />
            </Id>
          </xsl:if>
          <xsl:if test=""Ets"">
            <Ets>
              <xsl:value-of select=""Ets/text()"" />
            </Ets>
          </xsl:if>
          <xsl:if test=""Eosp"">
            <Eosp>
              <xsl:value-of select=""Eosp/text()"" />
            </Eosp>
          </xsl:if>
          <xsl:if test=""Cosp"">
            <Cosp>
              <xsl:value-of select=""Cosp/text()"" />
            </Cosp>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </PortCallOperations>
      </xsl:for-each>
      <xsl:for-each select=""Bunkers"">
        <Bunkers>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Lsfo"">
            <Lsfo>
              <xsl:value-of select=""Lsfo/text()"" />
            </Lsfo>
          </xsl:if>
          <xsl:if test=""Hfo"">
            <Hfo>
              <xsl:value-of select=""Hfo/text()"" />
            </Hfo>
          </xsl:if>
          <xsl:if test=""Lsgo"">
            <Lsgo>
              <xsl:value-of select=""Lsgo/text()"" />
            </Lsgo>
          </xsl:if>
          <xsl:if test=""Mdo"">
            <Mdo>
              <xsl:value-of select=""Mdo/text()"" />
            </Mdo>
          </xsl:if>
          <xsl:if test=""Mgo"">
            <Mgo>
              <xsl:value-of select=""Mgo/text()"" />
            </Mgo>
          </xsl:if>
          <xsl:if test=""Lo"">
            <Lo>
              <xsl:value-of select=""Lo/text()"" />
            </Lo>
          </xsl:if>
          <xsl:if test=""FwCrew"">
            <FwCrew>
              <xsl:value-of select=""FwCrew/text()"" />
            </FwCrew>
          </xsl:if>
          <xsl:if test=""FwShip"">
            <FwShip>
              <xsl:value-of select=""FwShip/text()"" />
            </FwShip>
          </xsl:if>
          <xsl:for-each select=""UnitOfMeasure"">
            <UnitOfMeasure>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </UnitOfMeasure>
          </xsl:for-each>
          <xsl:if test=""IsActive"">
            <IsActive>
              <xsl:value-of select=""IsActive/text()"" />
            </IsActive>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Bunkers>
      </xsl:for-each>
      <xsl:for-each select=""Drafts"">
        <Drafts>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""Fwd"">
            <Fwd>
              <xsl:value-of select=""Fwd/text()"" />
            </Fwd>
          </xsl:if>
          <xsl:if test=""Mean"">
            <Mean>
              <xsl:value-of select=""Mean/text()"" />
            </Mean>
          </xsl:if>
          <xsl:if test=""Aft"">
            <Aft>
              <xsl:value-of select=""Aft/text()"" />
            </Aft>
          </xsl:if>
          <xsl:for-each select=""UnitOfMeasure"">
            <UnitOfMeasure>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </UnitOfMeasure>
          </xsl:for-each>
          <xsl:if test=""IsActive"">
            <IsActive>
              <xsl:value-of select=""IsActive/text()"" />
            </IsActive>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Drafts>
      </xsl:for-each>
      <xsl:for-each select=""Tugs"">
        <Tugs>
          <xsl:if test=""Name"">
            <Name>
              <xsl:value-of select=""Name/text()"" />
            </Name>
          </xsl:if>
          <xsl:if test=""TugName"">
            <TugName>
              <xsl:value-of select=""TugName/text()"" />
            </TugName>
          </xsl:if>
          <xsl:if test=""Type"">
            <Type>
              <xsl:value-of select=""Type/text()"" />
            </Type>
          </xsl:if>
          <xsl:if test=""Total"">
            <Total>
              <xsl:value-of select=""Total/text()"" />
            </Total>
          </xsl:if>
          <xsl:if test=""Comments"">
            <Comments>
              <xsl:value-of select=""Comments/text()"" />
            </Comments>
          </xsl:if>
          <xsl:if test=""IsActive"">
            <IsActive>
              <xsl:value-of select=""IsActive/text()"" />
            </IsActive>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Tugs>
      </xsl:for-each>
      <xsl:for-each select=""Cargoes"">
        <xsl:variable name=""var:v5"" select=""userCSharp:LogicalEq(string(IsActive/text()) , &quot;true&quot;)"" />
        <xsl:if test=""$var:v5"">
          <Cargoes>
            <xsl:if test=""RefCode"">
              <RefCode>
                <xsl:value-of select=""RefCode/text()"" />
              </RefCode>
            </xsl:if>
            <xsl:for-each select=""Rotation"">
              <Rotation>
                <xsl:for-each select=""Poi"">
                  <Poi>
                    <xsl:if test=""Id"">
                      <Id>
                        <xsl:value-of select=""Id/text()"" />
                      </Id>
                    </xsl:if>
                    <xsl:if test=""Name"">
                      <Name>
                        <xsl:value-of select=""Name/text()"" />
                      </Name>
                    </xsl:if>
                    <xsl:if test=""Code"">
                      <Code>
                        <xsl:value-of select=""Code/text()"" />
                      </Code>
                    </xsl:if>
                    <xsl:value-of select=""./text()"" />
                  </Poi>
                </xsl:for-each>
                <xsl:for-each select=""Berth"">
                  <Berth>
                    <xsl:if test=""Id"">
                      <Id>
                        <xsl:value-of select=""Id/text()"" />
                      </Id>
                    </xsl:if>
                    <xsl:if test=""Name"">
                      <Name>
                        <xsl:value-of select=""Name/text()"" />
                      </Name>
                    </xsl:if>
                    <xsl:if test=""Code"">
                      <Code>
                        <xsl:value-of select=""Code/text()"" />
                      </Code>
                    </xsl:if>
                    <xsl:value-of select=""./text()"" />
                  </Berth>
                </xsl:for-each>
                <xsl:if test=""Etb"">
                  <Etb>
                    <xsl:value-of select=""Etb/text()"" />
                  </Etb>
                </xsl:if>
                <xsl:if test=""IsActive"">
                  <IsActive>
                    <xsl:value-of select=""IsActive/text()"" />
                  </IsActive>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Rotation>
            </xsl:for-each>
            <xsl:if test=""NominationQuantity"">
              <NominationQuantity>
                <xsl:value-of select=""NominationQuantity/text()"" />
              </NominationQuantity>
            </xsl:if>
            <xsl:if test=""ShipperReceiver"">
              <ShipperReceiver>
                <xsl:value-of select=""ShipperReceiver/text()"" />
              </ShipperReceiver>
            </xsl:if>
            <xsl:for-each select=""LaycanFrom"">
              <LaycanFrom>
                <xsl:value-of select=""./text()"" />
              </LaycanFrom>
            </xsl:for-each>
            <xsl:for-each select=""LaycanTo"">
              <LaycanTo>
                <xsl:value-of select=""./text()"" />
              </LaycanTo>
            </xsl:for-each>
            <xsl:for-each select=""CommodityDetail"">
              <CommodityDetail>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </CommodityDetail>
            </xsl:for-each>
            <xsl:for-each select=""UnitOfMeasure"">
              <UnitOfMeasure>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </UnitOfMeasure>
            </xsl:for-each>
            <xsl:for-each select=""CargoActivity"">
              <CargoActivity>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </CargoActivity>
            </xsl:for-each>
            <xsl:if test=""BillOfLadingQuantity"">
              <BillOfLadingQuantity>
                <xsl:value-of select=""BillOfLadingQuantity/text()"" />
              </BillOfLadingQuantity>
            </xsl:if>
            <xsl:if test=""ShoreQuantity"">
              <ShoreQuantity>
                <xsl:value-of select=""ShoreQuantity/text()"" />
              </ShoreQuantity>
            </xsl:if>
            <xsl:if test=""VesselQuantity"">
              <VesselQuantity>
                <xsl:value-of select=""VesselQuantity/text()"" />
              </VesselQuantity>
            </xsl:if>
            <xsl:if test=""Temperature"">
              <Temperature>
                <xsl:value-of select=""Temperature/text()"" />
              </Temperature>
            </xsl:if>
            <xsl:for-each select=""TankName"">
              <TankName>
                <xsl:value-of select=""./text()"" />
              </TankName>
            </xsl:for-each>
            <xsl:for-each select=""DailyCargoOperations"">
              <DailyCargoOperations>
                <xsl:if test=""StartOperationTime"">
                  <StartOperationTime>
                    <xsl:value-of select=""StartOperationTime/text()"" />
                  </StartOperationTime>
                </xsl:if>
                <xsl:for-each select=""EndOperationTime"">
                  <EndOperationTime>
                    <xsl:value-of select=""./text()"" />
                  </EndOperationTime>
                </xsl:for-each>
                <xsl:if test=""LdQuantity"">
                  <LdQuantity>
                    <xsl:value-of select=""LdQuantity/text()"" />
                  </LdQuantity>
                </xsl:if>
                <xsl:for-each select=""TankHatchNumber"">
                  <TankHatchNumber>
                    <xsl:value-of select=""./text()"" />
                  </TankHatchNumber>
                </xsl:for-each>
                <xsl:if test=""IsActive"">
                  <IsActive>
                    <xsl:value-of select=""IsActive/text()"" />
                  </IsActive>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </DailyCargoOperations>
            </xsl:for-each>
            <xsl:if test=""IsActive"">
              <IsActive>
                <xsl:value-of select=""IsActive/text()"" />
              </IsActive>
            </xsl:if>
            <xsl:value-of select=""./text()"" />
          </Cargoes>
        </xsl:if>
      </xsl:for-each>
      <xsl:for-each select=""Rotations"">
        <Rotations>
          <xsl:for-each select=""Poi"">
            <Poi>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </Poi>
          </xsl:for-each>
          <xsl:for-each select=""Berth"">
            <Berth>
              <xsl:if test=""Id"">
                <Id>
                  <xsl:value-of select=""Id/text()"" />
                </Id>
              </xsl:if>
              <xsl:if test=""Name"">
                <Name>
                  <xsl:value-of select=""Name/text()"" />
                </Name>
              </xsl:if>
              <xsl:if test=""Code"">
                <Code>
                  <xsl:value-of select=""Code/text()"" />
                </Code>
              </xsl:if>
              <xsl:value-of select=""./text()"" />
            </Berth>
          </xsl:for-each>
          <xsl:if test=""Etb"">
            <Etb>
              <xsl:value-of select=""Etb/text()"" />
            </Etb>
          </xsl:if>
          <xsl:if test=""IsActive"">
            <IsActive>
              <xsl:value-of select=""IsActive/text()"" />
            </IsActive>
          </xsl:if>
          <xsl:value-of select=""./text()"" />
        </Rotations>
      </xsl:for-each>
      <xsl:for-each select=""OperationEvents"">
        <xsl:variable name=""var:v6"" select=""string(IsActive/text())"" />
        <xsl:variable name=""var:v7"" select=""userCSharp:LogicalEq($var:v6 , &quot;true&quot;)"" />
        <xsl:if test=""$var:v7"">
          <OperationEvents>
            <xsl:if test=""Name"">
              <Name>
                <xsl:value-of select=""Name/text()"" />
              </Name>
            </xsl:if>
            <xsl:if test=""RefCode"">
              <RefCode>
                <xsl:value-of select=""RefCode/text()"" />
              </RefCode>
            </xsl:if>
            <xsl:if test=""Etb"">
              <Etb>
                <xsl:value-of select=""Etb/text()"" />
              </Etb>
            </xsl:if>
            <xsl:if test=""StartDate"">
              <StartDate>
                <xsl:value-of select=""StartDate/text()"" />
              </StartDate>
            </xsl:if>
            <xsl:if test=""EndDate"">
              <xsl:variable name=""var:v8"" select=""string(EndDate/@xsi:nil) = 'true'"" />
              <xsl:if test=""string($var:v8)='true'"">
                <EndDate>
                  <xsl:attribute name=""xsi:nil"">
                    <xsl:value-of select=""'true'"" />
                  </xsl:attribute>
                </EndDate>
              </xsl:if>
              <xsl:if test=""string($var:v8)='false'"">
                <EndDate>
                  <xsl:value-of select=""EndDate/text()"" />
                </EndDate>
              </xsl:if>
            </xsl:if>
            <xsl:if test=""Comments"">
              <Comments>
                <xsl:value-of select=""Comments/text()"" />
              </Comments>
            </xsl:if>
            <xsl:if test=""IsActive"">
              <IsActive>
                <xsl:value-of select=""IsActive/text()"" />
              </IsActive>
            </xsl:if>
            <xsl:for-each select=""Poi"">
              <Poi>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Poi>
            </xsl:for-each>
            <xsl:for-each select=""Berth"">
              <Berth>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Berth>
            </xsl:for-each>
            <xsl:for-each select=""Event"">
              <Event>
                <xsl:if test=""Id"">
                  <Id>
                    <xsl:value-of select=""Id/text()"" />
                  </Id>
                </xsl:if>
                <xsl:if test=""Name"">
                  <Name>
                    <xsl:value-of select=""Name/text()"" />
                  </Name>
                </xsl:if>
                <xsl:if test=""Code"">
                  <Code>
                    <xsl:value-of select=""Code/text()"" />
                  </Code>
                </xsl:if>
                <xsl:value-of select=""./text()"" />
              </Event>
            </xsl:for-each>
            <xsl:value-of select=""./text()"" />
          </OperationEvents>
        </xsl:if>
      </xsl:for-each>
      <xsl:if test=""Id"">
        <Id>
          <xsl:value-of select=""Id/text()"" />
        </Id>
      </xsl:if>
      <xsl:for-each select=""Uri"">
        <Uri>
          <xsl:value-of select=""./text()"" />
        </Uri>
      </xsl:for-each>
    </ns0:YourIss2Appointment>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
        
        private const global::Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Inchcape.YourISS.Integration.Generic.Schemas.YourISS.Schema_YourISS_OperationUpdate";
                return _TrgSchemas;
            }
        }
    }
}

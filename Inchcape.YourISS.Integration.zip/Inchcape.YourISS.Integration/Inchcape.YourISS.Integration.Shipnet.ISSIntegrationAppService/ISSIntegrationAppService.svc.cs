﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Inchcape.YourISS.Integration.Shipnet.ISSIntegrationModels;
using Microsoft.Win32;
using System.Security.Cryptography;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.IO.Compression;
using System.Xml;
using System.Configuration;

namespace Inchcape.YourISS.Integration.Shipnet.ISSIntegrationAppService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ISSIntegrationAppService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ISSIntegrationAppService.svc or ISSIntegrationAppService.svc.cs at the Solution Explorer and start debugging.
    public class ISSIntegrationAppService : IISSIntegrationAppService
    {
        public string SaveISSIntegrationMessage(ISSIntegrationDto RequestMsg)
        {
            System.Diagnostics.EventLog.WriteEntry("Application", "Inside App Integration");
            string result = "";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    string connectionString = GetControlDBConnectionString();
                    sqlConnection.ConnectionString = connectionString;
                    System.Diagnostics.EventLog.WriteEntry("Application", "ConnectionString - " + connectionString);
                    using (SqlCommand sqlCommand = new SqlCommand("spu_insert_Message_data", sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.CommandTimeout = 600;

                        sqlCommand.Parameters.Add("@AccountId", SqlDbType.UniqueIdentifier).Value = RequestMsg.AccountId;
                        sqlCommand.Parameters.Add("@MessageId", SqlDbType.UniqueIdentifier).Value = RequestMsg.MessageId;

                        sqlCommand.Parameters.Add("@Version", SqlDbType.Int).Value = RequestMsg.Version;
                        sqlCommand.Parameters.Add("@MessageVersion", SqlDbType.Int).Value = RequestMsg.MessageVersion;
                        sqlCommand.Parameters.Add("@SourceIntegrationSystem", SqlDbType.VarChar, 50).Value = RequestMsg.SourceIntegrationSystem;
                        sqlCommand.Parameters.Add("@DestinationIntegrationSystem", SqlDbType.VarChar, 50).Value = RequestMsg.DestinationIntegrationSystem;
                        System.Diagnostics.EventLog.WriteEntry("Application", "Before Get Unzip method");
                        // byte[] reqbytes;
                        // Encoding.ASCII.GetBytes(RequestMsg.Body, 1, RequestMsg.Body.Length , reqbytes, 1,System.Text.EncoderNLS);
                        string str = RequestMsg.Body.ToString();
                        byte[] bytes = new byte[str.Length * sizeof(char)];
                        System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);

                        System.Diagnostics.EventLog.WriteEntry("Application", "Body " + RequestMsg.Body);
                        //byte[] decompress = GetUnZippedBytes(RequestMsg.Body);
                        string decompressedXML = GetUnZippedBytes(RequestMsg.Body);
                        System.Diagnostics.EventLog.WriteEntry("Application", "AFter Get Unzip method");
                        System.Diagnostics.EventLog.WriteEntry("Application", "XML - " + decompressedXML);

                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(decompressedXML);

                        XmlNodeList xnListAction = doc.SelectNodes("/YourIssNotification/MessageHeader/Action");
                        XmlNode xnNodeAction = xnListAction[0];
                        string action = xnNodeAction.InnerText;
                        System.Diagnostics.EventLog.WriteEntry("Application", "action - " + action);

                        XmlNodeList xnListShipnetRef = doc.SelectNodes("/YourIssNotification/MessageHeader/ShipNetReference");
                        XmlNode xnNodeShipnetRef = xnListShipnetRef[0];
                        System.Diagnostics.EventLog.WriteEntry("Application", "ShipnetRef - " + xnNodeShipnetRef.InnerText);

                        string refNumber = string.Empty;
                        if (action.ToUpper() == "CREATE" || action.ToUpper() == "UPDATE")
                        {
                            XmlNodeList xnList = doc.SelectNodes("/YourIssNotification/PortCall/SN_KeyPosition");
                            XmlNode xnNode = xnList[0];
                            System.Diagnostics.EventLog.WriteEntry("Application", "SN_KeyPosition - " + xnNode.InnerText);
                            
                            XmlNodeList xnDAList = doc.SelectNodes("/YourIssNotification/PortCall/SN_DANo");
                            XmlNode xnDANode = xnDAList[0];
                            System.Diagnostics.EventLog.WriteEntry("Application", "SN_DANo - " + xnDANode.InnerText);

                            XmlNodeList xnVoyageNoList = doc.SelectNodes("/YourIssNotification/PortCall/SN_VoyageNumber");
                            XmlNode xnVoyageNo = xnVoyageNoList[0];
                            System.Diagnostics.EventLog.WriteEntry("Application", "SN_VoyageNumber - " + xnVoyageNo.InnerText);

                            refNumber = xnNodeShipnetRef.InnerText + "|" + xnDANode.InnerText + "|" + xnNode.InnerText + "|" + xnVoyageNo.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "refNumber - " + refNumber);

                            if (action.ToUpper() == "CREATE")
                                action = "PC";
                            else if (action.ToUpper() == "UPDATE")
                                action = "PU";
                        }
                        else if (action.ToUpper() == "CANCEL")
                        {
                            XmlNodeList xnList = doc.SelectNodes("/YourIssNotification/CancelPortCall/SN_KeyPosition");
                            XmlNode xnNode = xnList[0];
                            System.Diagnostics.EventLog.WriteEntry("Application", "SN_KeyPosition - " + xnNode.InnerText);
                            XmlNodeList xnDAList = doc.SelectNodes("/YourIssNotification/CancelPortCall/SN_DANo");
                            XmlNode xnDANode = xnDAList[0];
                            System.Diagnostics.EventLog.WriteEntry("Application", "SN_DANo - " + xnDANode.InnerText);
                            refNumber = xnNodeShipnetRef.InnerText + "|" + xnDANode.InnerText + "|" + xnNode.InnerText;
                            System.Diagnostics.EventLog.WriteEntry("Application", "refNumber - " + refNumber);
                            action = "CAN";
                        }

                        sqlCommand.Parameters.Add("@RequestData", SqlDbType.VarChar).Value = decompressedXML;
                        sqlCommand.Parameters.Add("@MessageDate", SqlDbType.DateTime).Value = RequestMsg.DateCreate;
                        sqlCommand.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 100).Value = refNumber;
                        sqlCommand.Parameters.Add("@Method", SqlDbType.VarChar, 50).Value = action;

                        sqlConnection.Open();

                        result = Convert.ToString(sqlCommand.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "App Server Error - " + ex.Message);
                throw new Exception(ex.Message);
            }
            return result.ToString();
        }

        public int ValidateIntegrationSystem(Guid AccountId)
        {
            int count = 0;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection())
                {

                    string connectionString = GetDecryptedConnectionString(ConfigurationManager.ConnectionStrings["ControlDBConnectionString"].ToString());
                    //string connectionString = @"Database=ERP_INTF; Server=ISSIDCBIZTALK\ISSIDCBIZTALK; uid=IDCBizTalkUser; pwd=Sh1pN3t05";

                    //string connectionString = GetControlDBConnectionString();
                    sqlConnection.ConnectionString = connectionString;
                    System.Diagnostics.EventLog.WriteEntry("Application", "ConnectionString - " + connectionString);
                    System.Diagnostics.EventLog.WriteEntry("Application", "AccountId - " + AccountId);
                    using (SqlCommand sqlCommand = new SqlCommand("SPU_Validate_IntegrationSystem", sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.CommandTimeout = 600;

                        sqlCommand.Parameters.Add("@HubPrincipalKey", SqlDbType.UniqueIdentifier).Value = AccountId;

                        sqlConnection.Open();

                        count = Convert.ToInt32(sqlCommand.ExecuteScalar());
                        System.Diagnostics.EventLog.WriteEntry("Application", "count - " + count);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", "Error - " + ex.Message);
                throw new Exception(ex.Message);
            }
            return count;
        }

        /******************************************************************************************************************************
        * Function Name    : GetBizConnectionString()
        * Parameters       : NA
        * Return Value     : string ConnectionString
        * Description      : Retrieves the Connection String configured in the Windows Registry "SOFTWARE\Wow6432Node\ISSAppsBPM" and retruns to the calling method         
        * Author           : 
        * Date Created     : 
        * Date Modified    :
        * Cooments         :
        * ******************************************************************************************************************************
        */
        public static string GetControlDBConnectionString()
        {
            string conString = "";
            try
            {

                //RegistryKey reg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\Shipnet", true);
                conString = GetDecryptedConnectionString(ConfigurationManager.ConnectionStrings["ControlDBConnectionString"].ToString());
                // System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetBizConnectionString  -->" + conString);
            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetControlDBConnectionString  Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetBizConnectionString-->{0}", exp.Message));
            }
            return conString;
        }

        #region GetDecryptedConnectionString
        /******************************************************************************************************************************
        * Function Name    : GetDecryptedConnectionString()
        * Parameters       : string encryptedConString
        * Return Value     : string decryptedConStr
        * Description      : Accepts the encrypted connection string and decrypts to original connection string and returns to the calling program 
        * Author           : 
        * Date Created     : 
        * Date Modified    :
        * Cooments         :
        * ******************************************************************************************************************************
        */
        public static string GetDecryptedConnectionString(string encryptedConString)
        {
            string initVector = "tu89geji340t89u2";
            string passPhrase = "a7jWXuhwl7DIOQV103uosr561nM48dfz012JJWMXUGAW23ufgzpebt";
            int keysize = 256;
            string decryptedConStr = "";
            try
            {

                byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
                byte[] cipherTextBytes = Convert.FromBase64String(encryptedConString);
                PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
                byte[] keyBytes = password.GetBytes(keysize / 8);
                RijndaelManaged symmetricKey = new RijndaelManaged();
                symmetricKey.Mode = CipherMode.CBC;
                ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
                MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
                CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                memoryStream.Close();
                cryptoStream.Close();
                decryptedConStr = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);


            }
            catch (Exception exp)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> Decryption  Exception -->" + exp.Message + exp.StackTrace);
                //Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager.ServiceComponent.TraceError(System.String.Format("Inchcape.YourISS.Marine.BT.P2P.Common:: ERROR in GetDecryptedConnectionString-->{0}", exp.Message));
            }

            return decryptedConStr;
        }
        #endregion

        private string GetUnZippedBytes(byte[] bytes)
        {

            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                {
                    //gs.CopyTo(mso);
                    CopyTo(gs, mso);
                }

                return System.Text.Encoding.UTF8.GetString(mso.ToArray());
            }


            /*
            if ( o.Length <= 0 )
                System.Diagnostics.EventLog.WriteEntry("Application", " Inside Common DLL --> GetUnZippedBytes  Exception --> Empty String" );
            using (MemoryStream outStream = new MemoryStream(o))
            {
                using (GZipStream stream = new GZipStream(outStream, CompressionMode.Decompress,true ))
                {
                    const int size = 4096;
                    byte[] buffer = new byte[size];
                    using (MemoryStream memory = new MemoryStream())
                    {
                        int count = 0;
                        do
                        {
                            count = stream.Read(buffer, 0, size);
                            if (count > 0)
                            {
                                memory.Write(buffer, 0, count);
                            }
                        }
                        while (count > 0);
                        return memory.ToArray();
                    }
                }
             */

        }

        public static void CopyTo(Stream src, Stream dest)
        {
            byte[] bytes = new byte[4096];

            int cnt;

            while ((cnt = src.Read(bytes, 0, bytes.Length)) != 0)
            {
                dest.Write(bytes, 0, cnt);
            }
        }


    }



}

